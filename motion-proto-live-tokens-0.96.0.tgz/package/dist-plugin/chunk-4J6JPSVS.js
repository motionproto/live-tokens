import {
  hexToOklch,
  oklchToCss
} from "./chunk-7TQQTHI6.js";

// src/editor/core/themes/parsers/globalRootBlock.ts
function extractGlobalRootBody(source) {
  const re = /:global\(:root\)\s*\{([^}]*)\}/g;
  const bodies = [];
  let m;
  while ((m = re.exec(source)) !== null) {
    bodies.push(m[1]);
  }
  return bodies.join("\n");
}

// src/editor/core/themes/parsers/mediaBlocks.ts
function stripMediaBlocks(css) {
  const kept = [];
  let from = 0;
  let i = 0;
  while (i < css.length) {
    if (css.startsWith("/*", i)) {
      i = commentEnd(css, i);
    } else if (css[i] === "@" && /^@media\b/i.test(css.slice(i, i + 7))) {
      kept.push(css.slice(from, i));
      i = from = blockEnd(css, i);
    } else {
      i++;
    }
  }
  kept.push(css.slice(from));
  return kept.join("");
}
function commentEnd(css, start) {
  const end = css.indexOf("*/", start + 2);
  return end === -1 ? css.length : end + 2;
}
function blockEnd(css, start) {
  let depth = 0;
  let i = start;
  while (i < css.length) {
    if (css.startsWith("/*", i)) {
      i = commentEnd(css, i);
      continue;
    }
    const c = css[i++];
    if (c === "{") depth++;
    else if (c === "}" && --depth === 0) return i;
  }
  return css.length;
}

// vite-plugin/tokensCssMigrations/cssTokenOps.ts
var DECL_RE = /(^|[\s;{])(--[a-z0-9-]+)\s*:/gi;
var REF_RE = /var\(\s*(--[a-z0-9-]+)/gi;
var DECL_VALUE_RE = /(^|[\s;{])(--[a-z0-9-]+)\s*:([^;}]*)/gi;
function collectDefinedTokens(css) {
  const out = /* @__PURE__ */ new Set();
  for (const m of css.matchAll(DECL_RE)) out.add(m[2]);
  return out;
}
function collectTokenValues(css) {
  const out = /* @__PURE__ */ new Map();
  for (const m of stripMediaBlocks(css).matchAll(DECL_VALUE_RE)) out.set(m[2], m[3].trim());
  return out;
}
function collectReferencedTokens(css) {
  const out = /* @__PURE__ */ new Set();
  for (const m of css.matchAll(REF_RE)) out.add(m[1]);
  return out;
}
function ensureScale(css, opts) {
  const defined = collectDefinedTokens(css);
  const missing = opts.entries.filter((e) => !defined.has(e.name));
  if (missing.length === 0) return css;
  const lines = css.split("\n");
  const { indent, insertAfter } = findInsertionPoint(lines, opts.anchorPrefixes ?? []);
  const block = [];
  if (opts.sectionComment) block.push(`${indent}/* ${opts.sectionComment} */`);
  for (const e of missing) block.push(`${indent}${e.name}: ${e.value};`);
  lines.splice(insertAfter + 1, 0, ...block);
  return lines.join("\n");
}
function renameToken(css, oldName, newName) {
  const defined = collectDefinedTokens(css);
  if (!defined.has(oldName) || defined.has(newName)) return css;
  const re = new RegExp(escapeRe(oldName) + "(?![a-z0-9-])", "gi");
  return css.replace(re, newName);
}
function removeToken(css, name) {
  const lines = css.split("\n");
  const declRe = new RegExp("(^|[\\s;{])" + escapeRe(name) + "\\s*:");
  const kept = lines.filter((line) => !declRe.test(line));
  if (kept.length === lines.length) return css;
  return kept.join("\n");
}
function removeTokensMatching(css, predicate) {
  const lines = css.split("\n");
  const declRe = /^\s*(--[a-z0-9-]+)\s*:/;
  const kept = lines.filter((line) => {
    const m = line.match(declRe);
    return !(m && predicate(m[1]));
  });
  if (kept.length === lines.length) return css;
  return kept.join("\n");
}
function setTokenValue(css, name, value, opts = {}) {
  const lines = css.split("\n");
  const declRe = new RegExp("(^|[\\s;{])(" + escapeRe(name) + ")(\\s*:)([^;}]*)");
  let changed = false;
  for (const root of findTopLevelRoots(lines)) {
    let depth = 1;
    for (let i = root.start + 1; i < root.end; i++) {
      if (depth === 1) {
        const m = lines[i].match(declRe);
        const current = m?.[4].trim();
        if (m && current !== value && (opts.from === void 0 || current === opts.from.trim())) {
          const at = m.index + m[1].length + m[2].length + m[3].length;
          lines[i] = lines[i].slice(0, at) + " " + value + lines[i].slice(at + m[4].length);
          changed = true;
        }
      }
      depth += braceDelta(lines[i]);
    }
  }
  return changed ? lines.join("\n") : css;
}
function appendMediaBlock(css, query, entries, opts = {}) {
  const lines = css.split("\n");
  const at = query.trim();
  const blocks = findTopLevelBlocks(lines, (line) => mediaQueryOf(line) === at);
  const declared = collectDefinedTokens(
    blocks.map((b) => lines.slice(b.start, b.end + 1).join("\n")).join("\n")
  );
  const missing = entries.filter((e) => !declared.has(e.name));
  if (missing.length === 0) return css;
  const media = blocks.find((b) => b.end > b.start);
  if (!media) {
    const block = [`@media ${at} {`, "  :root {", ...declarationLines(missing, "    "), "  }", "}", ""];
    const before = opts.before?.trim();
    const next = before === void 0 ? void 0 : findTopLevelBlocks(lines, (line) => mediaQueryOf(line) === before)[0];
    if (next) {
      lines.splice(next.start, 0, ...block);
      return lines.join("\n");
    }
    while (lines.length > 0 && lines[lines.length - 1].trim() === "") lines.pop();
    return [...lines, "", ...block].join("\n");
  }
  const root = findNestedRoot(lines, media);
  if (!root) {
    lines.splice(media.end, 0, "  :root {", ...declarationLines(missing, "    "), "  }");
    return lines.join("\n");
  }
  let indent = (lines[root.end].match(/^\s*/)?.[0] ?? "") + "  ";
  for (let i = root.start + 1; i < root.end; i++) {
    const m = lines[i].match(/^(\s*)--[a-z0-9-]+\s*:/i);
    if (m) indent = m[1];
  }
  lines.splice(root.end, 0, ...declarationLines(missing, indent));
  return lines.join("\n");
}
function declarationLines(entries, indent) {
  return entries.map((e) => `${indent}${e.name}: ${e.value};`);
}
function findInsertionPoint(lines, anchorPrefixes) {
  const root = findTopLevelRoot(lines);
  if (!root) return { indent: "  ", insertAfter: lines.length - 1 };
  const lastByPrefix = /* @__PURE__ */ new Map();
  let lastDecl = null;
  let depth = 1;
  for (let i = root.start + 1; i < root.end; i++) {
    const line = lines[i];
    if (depth === 1) {
      const m = line.match(/^(\s*)(--[a-z0-9-]+)\s*:/);
      if (m) {
        const hit = { index: i, indent: m[1] || "  " };
        lastDecl = hit;
        for (const prefix of anchorPrefixes) {
          if (m[2].startsWith(prefix)) lastByPrefix.set(prefix, hit);
        }
      }
    }
    depth += braceDelta(line);
  }
  for (const prefix of anchorPrefixes) {
    const hit = lastByPrefix.get(prefix);
    if (hit) return { indent: hit.indent, insertAfter: hit.index };
  }
  return { indent: lastDecl?.indent ?? "  ", insertAfter: root.end - 1 };
}
var ROOT_OPEN_RE = /(^|[\s,]):root[^{]*\{/;
function findTopLevelRoot(lines) {
  return findTopLevelRoots(lines)[0] ?? null;
}
function findTopLevelRoots(lines) {
  return findTopLevelBlocks(lines, (line) => ROOT_OPEN_RE.test(line));
}
function findTopLevelBlocks(lines, opens) {
  const blocks = [];
  let depth = 0;
  for (let i = 0; i < lines.length; i++) {
    if (depth === 0 && opens(lines[i])) {
      const end = blockEnd2(lines, i);
      blocks.push({ start: i, end });
      i = end;
      continue;
    }
    depth += braceDelta(lines[i]);
  }
  return blocks;
}
function findNestedRoot(lines, parent) {
  let depth = 1;
  for (let i = parent.start + 1; i < parent.end; i++) {
    if (depth === 1 && ROOT_OPEN_RE.test(lines[i])) {
      const end = blockEnd2(lines, i);
      if (end > i && end < parent.end) return { start: i, end };
    }
    depth += braceDelta(lines[i]);
  }
  return null;
}
function blockEnd2(lines, start) {
  let depth = 0;
  for (let j = start; j < lines.length; j++) {
    depth += braceDelta(lines[j]);
    if (depth === 0) return j;
  }
  return lines.length - 1;
}
function mediaQueryOf(line) {
  return line.match(/^\s*@media\s+([^{]*?)\s*\{/i)?.[1] ?? null;
}
function braceDelta(line) {
  return (line.match(/\{/g)?.length ?? 0) - (line.match(/\}/g)?.length ?? 0);
}
function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// vite-plugin/tokensCssMigrations/migrations/2026-05-29-typography-scale-additions.ts
var tokensCssMigration_2026_05_29_typographyScaleAdditions = {
  id: "2026-05-29-typography-scale-additions",
  kind: "additive",
  description: "Add --letter-spacing-* and --ease-out-quart scales",
  apply(css) {
    let out = css;
    out = ensureScale(out, {
      sectionComment: "Letter spacing",
      anchorPrefixes: ["--letter-spacing-", "--line-height-", "--font-size-", "--font-"],
      entries: [
        { name: "--letter-spacing-tighter", value: "-0.04em" },
        { name: "--letter-spacing-tight", value: "-0.02em" },
        { name: "--letter-spacing-normal", value: "0" },
        { name: "--letter-spacing-wide", value: "0.04em" },
        { name: "--letter-spacing-wider", value: "0.08em" }
      ]
    });
    out = ensureScale(out, {
      sectionComment: "Easing",
      anchorPrefixes: ["--ease-", "--transition-", "--duration-"],
      entries: [{ name: "--ease-out-quart", value: "cubic-bezier(0.25, 1, 0.5, 1)" }]
    });
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-05-29-sectiondivider-legacy-axis-cleanup.ts
var KEEP_SEGMENTS = /* @__PURE__ */ new Set(["lg", "md", "sm"]);
var tokensCssMigration_2026_05_29_sectiondividerLegacyAxisCleanup = {
  id: "2026-05-29-sectiondivider-legacy-axis-cleanup",
  kind: "breaking",
  description: "Remove legacy --sectiondivider-* tokens not on the lg/md/sm axis",
  apply(css) {
    return removeTokensMatching(css, (name) => {
      if (!name.startsWith("--sectiondivider-")) return false;
      const segment = name.slice("--sectiondivider-".length).split("-")[0];
      return !KEEP_SEGMENTS.has(segment);
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-06-03-transform-scale-additions.ts
var tokensCssMigration_2026_06_03_transformScaleAdditions = {
  id: "2026-06-03-transform-scale-additions",
  kind: "additive",
  description: "Add the --scale-{sm..2xl} transform-multiplier scale",
  apply(css) {
    return ensureScale(css, {
      sectionComment: "Transform-scale multipliers (e.g. hover zoom). 5% per step.",
      anchorPrefixes: ["--blur-", "--shadow-", "--radius-"],
      entries: [
        { name: "--scale-sm", value: "1.05" },
        { name: "--scale-md", value: "1.1" },
        { name: "--scale-lg", value: "1.15" },
        { name: "--scale-xl", value: "1.2" },
        { name: "--scale-2xl", value: "1.25" }
      ]
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-06-04-remove-dead-size-icon-scale.ts
var tokensCssMigration_2026_06_04_removeDeadSizeIconScale = {
  id: "2026-06-04-remove-dead-size-icon-scale",
  kind: "breaking",
  description: "Remove the unused --size-icon-* scale (live scale is --icon-size-*)",
  apply(css) {
    return removeTokensMatching(css, (name) => name.startsWith("--size-icon-"));
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-06-04-easing-color-and-typescale-additions.ts
var tokensCssMigration_2026_06_04_easingColorAndTypescaleAdditions = {
  id: "2026-06-04-easing-color-and-typescale-additions",
  kind: "additive",
  description: "Add the full --ease-* scale, --color-white/black, and --font-size-7xl",
  apply(css) {
    let out = css;
    out = ensureScale(out, {
      anchorPrefixes: ["--ease-", "--transition-", "--duration-"],
      entries: [
        { name: "--ease-linear", value: "linear" },
        { name: "--ease-in-sine", value: "cubic-bezier(0.12, 0, 0.39, 0)" },
        { name: "--ease-out-sine", value: "cubic-bezier(0.61, 1, 0.88, 1)" },
        { name: "--ease-in-out-sine", value: "cubic-bezier(0.37, 0, 0.63, 1)" },
        { name: "--ease-in-quad", value: "cubic-bezier(0.11, 0, 0.5, 0)" },
        { name: "--ease-out-quad", value: "cubic-bezier(0.5, 1, 0.89, 1)" },
        { name: "--ease-in-out-quad", value: "cubic-bezier(0.45, 0, 0.55, 1)" },
        { name: "--ease-in-cubic", value: "cubic-bezier(0.32, 0, 0.67, 0)" },
        { name: "--ease-out-cubic", value: "cubic-bezier(0.33, 1, 0.68, 1)" },
        { name: "--ease-in-out-cubic", value: "cubic-bezier(0.65, 0, 0.35, 1)" },
        { name: "--ease-in-quart", value: "cubic-bezier(0.5, 0, 0.75, 0)" },
        { name: "--ease-out-quart", value: "cubic-bezier(0.25, 1, 0.5, 1)" },
        { name: "--ease-in-out-quart", value: "cubic-bezier(0.76, 0, 0.24, 1)" },
        { name: "--ease-in-quint", value: "cubic-bezier(0.64, 0, 0.78, 0)" },
        { name: "--ease-out-quint", value: "cubic-bezier(0.22, 1, 0.36, 1)" },
        { name: "--ease-in-out-quint", value: "cubic-bezier(0.83, 0, 0.17, 1)" },
        { name: "--ease-in-expo", value: "cubic-bezier(0.7, 0, 0.84, 0)" },
        { name: "--ease-out-expo", value: "cubic-bezier(0.16, 1, 0.3, 1)" },
        { name: "--ease-in-out-expo", value: "cubic-bezier(0.87, 0, 0.13, 1)" },
        { name: "--ease-in-circ", value: "cubic-bezier(0.55, 0, 1, 0.45)" },
        { name: "--ease-out-circ", value: "cubic-bezier(0, 0.55, 0.45, 1)" },
        { name: "--ease-in-out-circ", value: "cubic-bezier(0.85, 0, 0.15, 1)" },
        { name: "--ease-in-back", value: "cubic-bezier(0.36, 0, 0.66, -0.56)" },
        { name: "--ease-out-back", value: "cubic-bezier(0.34, 1.56, 0.64, 1)" },
        { name: "--ease-in-out-back", value: "cubic-bezier(0.68, -0.6, 0.32, 1.6)" },
        {
          name: "--ease-in-elastic",
          value: "linear(0, 0.0007 8.1%, 0.0019 12.1%, 0.0027 13.7%, 0.0046 15.7%, -0.0046 18.7%, -0.0202 22.1%, -0.0234 23.6%, -0.0224 24.9%, -0.0156 26.7%, 0.0091 29.4%, 0.0666 33.4%, 0.0848 34.9%, 0.0916 36.4%, 0.0837 38.1%, 0.0581 40.1%, -0.0204 43.7%, -0.221 51.3%, -0.2825 53.6%, -0.317 55.4%, -0.3253 57.1%, -0.3071 58.8%, -0.2554 60.9%, -0.1295 63.7%, 0.4515 73.1%, 0.7257 78.4%, 0.834 81.2%, 0.9221 84.1%, 0.9817 87.1%, 1.0144 90.4%, 1.026 94.6%, 1)"
        },
        {
          name: "--ease-out-elastic",
          value: "linear(0, 0.974 4.6%, 1.026 5.4%, 1.018 6.9%, 0.952 12.9%, 0.876 15.9%, 0.751 18.8%, 0.557 22.4%, -0.451 36.3%, -0.722 42.9%, -0.832 46.6%, -0.918 51.3%, -0.916 54.8%, -0.832 59.4%, -0.665 64.6%, 0.221 78%, 0.317 81.2%, 0.317 84.4%, 0.281 87.6%, 0.232 91.1%, 0.058 100%)"
        },
        {
          name: "--ease-in-out-elastic",
          value: "linear(0, 0.0001 7.7%, -0.0048 12.7%, -0.0064 14.6%, -0.0064 16.5%, -0.0026 18.5%, 0.0179 21.4%, 0.0617 24.1%, 0.0617 26.5%, 0.0309 29%, -0.0589 32.7%, -0.3 38.1%, -0.4307 40.6%, -0.4844 43%, -0.4844 48%, -0.4307 50.4%, -0.3 52.9%, 0.3 60.5%, 0.4307 63%, 0.4844 65.4%, 0.4844 70.4%, 0.4307 72.8%, 0.3 75.3%, 0.0589 80.7%, -0.0309 84.4%, -0.0617 86.9%, -0.0617 89.3%, -0.0179 92%, 0.0026 94.9%, 0.0064 96.8%, 0.0064 98.7%, 0.0048 100%, 1)"
        },
        {
          name: "--ease-in-bounce",
          value: "linear(0, 0.005, 0.018, 0.039, 0.069, 0.108, 0.156, 0.213, 0.281, 0.36, 0.451, 0.555, 0.674, 0.81, 0.967, 0.881, 0.838, 0.838, 0.881, 0.97, 0.952, 0.95, 0.969, 0.999, 0.984, 0.982, 0.989, 1)"
        },
        {
          name: "--ease-out-bounce",
          value: "linear(0, 0.011, 0.031, 0.018, 0.05, 0.151, 0.301, 0.5, 0.747, 0.945, 0.997, 1, 0.969, 0.954, 0.969, 0.952, 0.952, 0.969, 1, 0.984, 0.982, 0.984, 0.997, 0.984, 0.989, 1)"
        },
        {
          name: "--ease-in-out-bounce",
          value: "linear(0, 0.003, 0.009, 0.019, 0.034, 0.054, 0.078, 0.107, 0.141, 0.18, 0.226, 0.278, 0.337, 0.405, 0.483, 0.471, 0.42, 0.419, 0.46, 0.494, 0.5, 0.506, 0.54, 0.581, 0.58, 0.529, 0.517, 0.595, 0.663, 0.722, 0.774, 0.819, 0.859, 0.893, 0.922, 0.946, 0.966, 0.981, 0.991, 0.997, 1)"
        }
      ]
    });
    out = ensureScale(out, {
      sectionComment: "Invariants \u2014 never themed, not part of any ramp.",
      anchorPrefixes: ["--color-"],
      entries: [
        { name: "--color-white", value: "#ffffff" },
        { name: "--color-black", value: "#000000" }
      ]
    });
    out = ensureScale(out, {
      anchorPrefixes: ["--font-size-", "--font-"],
      entries: [{ name: "--font-size-7xl", value: "4.5rem" }]
    });
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-07-20-line-height-rename.ts
var RENAMES = [
  ["--line-height-xs", "--line-height-none"],
  ["--line-height-sm", "--line-height-tighter"],
  ["--line-height-md", "--line-height-normal"],
  ["--line-height-lg", "--line-height-relaxed"]
];
var SCALE = [
  { name: "--line-height-none", value: "1" },
  { name: "--line-height-tightest", value: "1.1" },
  { name: "--line-height-tighter", value: "1.25" },
  { name: "--line-height-tight", value: "1.35" },
  { name: "--line-height-normal", value: "1.5" },
  { name: "--line-height-relaxed", value: "1.75" }
];
var tokensCssMigration_2026_07_20_lineHeightRename = {
  id: "2026-07-20-line-height-rename",
  kind: "breaking",
  description: "Reshape --line-height-{xs..xl} to leading vocabulary (none/tightest/tighter/tight/normal/relaxed); retire the 2.0 slot",
  apply(css) {
    let out = css;
    for (const [oldName, newName] of RENAMES) out = renameToken(out, oldName, newName);
    out = removeToken(out, "--line-height-xl");
    out = ensureScale(out, {
      anchorPrefixes: ["--line-height-", "--font-size-", "--font-weight-", "--font-"],
      entries: SCALE
    });
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-07-20-semantic-text-styles.ts
var BUNDLE = [
  { name: "--heading-xl-font-family", value: "var(--font-display)" },
  { name: "--heading-xl-font-size", value: "var(--font-size-4xl)" },
  { name: "--heading-xl-font-weight", value: "var(--font-weight-semibold)" },
  { name: "--heading-xl-line-height", value: "var(--line-height-tightest)" },
  { name: "--heading-xl-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--heading-lg-font-family", value: "var(--font-display)" },
  { name: "--heading-lg-font-size", value: "var(--font-size-2xl)" },
  { name: "--heading-lg-font-weight", value: "var(--font-weight-semibold)" },
  { name: "--heading-lg-line-height", value: "var(--line-height-tightest)" },
  { name: "--heading-lg-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--heading-md-font-family", value: "var(--font-display)" },
  { name: "--heading-md-font-size", value: "var(--font-size-xl)" },
  { name: "--heading-md-font-weight", value: "var(--font-weight-semibold)" },
  { name: "--heading-md-line-height", value: "var(--line-height-tighter)" },
  { name: "--heading-md-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--heading-sm-font-family", value: "var(--font-sans)" },
  { name: "--heading-sm-font-size", value: "var(--font-size-lg)" },
  { name: "--heading-sm-font-weight", value: "var(--font-weight-semibold)" },
  { name: "--heading-sm-line-height", value: "var(--line-height-tighter)" },
  { name: "--heading-sm-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--body-md-font-family", value: "var(--font-sans)" },
  { name: "--body-md-font-size", value: "var(--font-size-md)" },
  { name: "--body-md-font-weight", value: "var(--font-weight-normal)" },
  { name: "--body-md-line-height", value: "var(--line-height-normal)" },
  { name: "--body-md-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--body-sm-font-family", value: "var(--font-sans)" },
  { name: "--body-sm-font-size", value: "var(--font-size-sm)" },
  { name: "--body-sm-font-weight", value: "var(--font-weight-normal)" },
  { name: "--body-sm-line-height", value: "var(--line-height-tight)" },
  { name: "--body-sm-letter-spacing", value: "var(--letter-spacing-normal)" },
  // The code bundle's size, leading and tracking belong to 2026-10-08-type-scales,
  // which renames them to `--code-md-*`. An additive migration must not re-add
  // names a later breaking rename removes, or re-running the fold loses
  // idempotency.
  { name: "--code-font-family", value: "var(--font-mono)" },
  { name: "--code-font-weight", value: "var(--font-weight-normal)" },
  { name: "--eyebrow-font-family", value: "var(--font-sans)" },
  { name: "--eyebrow-font-size", value: "var(--font-size-sm)" },
  { name: "--eyebrow-font-weight", value: "var(--font-weight-normal)" },
  { name: "--eyebrow-line-height", value: "var(--line-height-normal)" },
  { name: "--eyebrow-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--eyebrow-text-transform", value: "none" }
];
var tokensCssMigration_2026_07_20_semanticTextStyles = {
  id: "2026-07-20-semantic-text-styles",
  kind: "additive",
  description: "Add the semantic text-style bundles (--heading-*/--body-*/--code-*/--eyebrow-*)",
  apply(css) {
    return ensureScale(css, {
      sectionComment: "Text styles \u2014 semantic typography roles",
      anchorPrefixes: [
        "--eyebrow-",
        "--code-",
        "--body-",
        "--heading-",
        "--letter-spacing-",
        "--line-height-",
        "--font-weight-",
        "--font-size-",
        "--font-"
      ],
      entries: BUNDLE
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-19-oklch-color-values.ts
var HEX_DECLARATION_RE = /(--[a-z0-9-]+:\s*)#([0-9a-f]{6})(?=\s*[;}])/gi;
var tokensCssMigration_2026_08_19_oklchColorValues = {
  id: "2026-08-19-oklch-color-values",
  kind: "breaking",
  description: "Rewrite hex token values as oklch()",
  apply(css) {
    return css.replace(HEX_DECLARATION_RE, (_match, prefix, hex) => {
      const { l, c, h } = hexToOklch(`#${hex}`);
      return `${prefix}${oklchToCss(l, c, h)}`;
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-25-editorial-type-role.ts
var STACK = [{ name: "--font-editorial", value: "var(--font-sans)" }];
var tokensCssMigration_2026_08_25_editorialTypeRole = {
  id: "2026-08-25-editorial-type-role",
  kind: "additive",
  description: "Add the editorial type role (--font-editorial)",
  apply(css) {
    return ensureScale(css, {
      anchorPrefixes: ["--font-mono", "--font-serif", "--font-sans", "--font-display"],
      entries: STACK
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-26-gradient-stops.ts
var STOPS_RE = /^(?:linear|radial)-gradient\(\s*[^,]+,\s*(.+)\)$/i;
var tokensCssMigration_2026_08_26_gradientStops = {
  id: "2026-08-26-gradient-stops",
  kind: "additive",
  description: "Add --gradient-N-stops companions to the gradient slots",
  apply(css) {
    const values = collectTokenValues(css);
    const entries = [];
    for (const [name, value] of values) {
      if (!/^--gradient-\d+$/.test(name)) continue;
      const stops = value.match(STOPS_RE);
      if (stops) entries.push({ name: `${name}-stops`, value: stops[1].trim() });
    }
    if (entries.length === 0) return css;
    return ensureScale(css, { anchorPrefixes: ["--gradient-"], entries });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-27-backdrop-polarity.ts
var MARKER = "[data-backdrop='dark']";
var RULES = `/* BACKDROP POLARITY \u2014 one attribute says which way a surface leans. State it
   in markup (\`<section data-backdrop="dark">\`) or let \`use:backdrop\` measure
   and stamp it. Either way \`light-dark()\` inside resolves the right half, and
   a rule can key on the attribute for what colour alone cannot carry. */

[data-backdrop='light'] {
  color-scheme: light;
}

[data-backdrop='dark'] {
  color-scheme: dark;
}
`;
var tokensCssMigration_2026_08_27_backdropPolarity = {
  id: "2026-08-27-backdrop-polarity",
  kind: "additive",
  description: "Add the [data-backdrop] \u2192 color-scheme rules",
  apply(css) {
    if (css.includes(MARKER)) return css;
    const at = css.indexOf(":root");
    if (at === -1) return `${css.trimEnd()}

${RULES}`;
    return `${css.slice(0, at)}${RULES}
${css.slice(at)}`;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-27-editorial-size-steps.ts
var AXES = ["font-family", "font-size", "font-weight", "line-height", "letter-spacing"];
var BUNDLE2 = [
  { name: "--editorial-md-font-family", value: "var(--font-editorial)" },
  { name: "--editorial-md-font-size", value: "var(--font-size-md)" },
  { name: "--editorial-md-font-weight", value: "var(--font-weight-normal)" },
  { name: "--editorial-md-line-height", value: "var(--line-height-normal)" },
  { name: "--editorial-md-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--editorial-sm-font-family", value: "var(--font-editorial)" },
  { name: "--editorial-sm-font-size", value: "var(--font-size-sm)" },
  { name: "--editorial-sm-font-weight", value: "var(--font-weight-normal)" },
  { name: "--editorial-sm-line-height", value: "var(--line-height-tight)" },
  { name: "--editorial-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
];
var tokensCssMigration_2026_08_27_editorialSizeSteps = {
  id: "2026-08-27-editorial-size-steps",
  kind: "breaking",
  description: "Split the editorial bundle into --editorial-md-* and --editorial-sm-* steps",
  apply(css) {
    let out = css;
    for (const axis of AXES) {
      out = renameToken(out, `--editorial-${axis}`, `--editorial-md-${axis}`);
    }
    return ensureScale(out, {
      sectionComment: "Editorial \u2014 the long-reading role, body face until repointed",
      anchorPrefixes: [
        "--eyebrow-",
        "--code-",
        "--body-",
        "--heading-",
        "--letter-spacing-",
        "--line-height-",
        "--font-weight-",
        "--font-size-",
        "--font-"
      ],
      entries: BUNDLE2
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-27-editorial-large-steps.ts
var BUNDLE3 = [
  { name: "--editorial-xl-font-family", value: "var(--font-editorial)" },
  { name: "--editorial-xl-font-size", value: "var(--font-size-xl)" },
  { name: "--editorial-xl-font-weight", value: "var(--font-weight-normal)" },
  { name: "--editorial-xl-line-height", value: "var(--line-height-tighter)" },
  { name: "--editorial-xl-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--editorial-lg-font-family", value: "var(--font-editorial)" },
  { name: "--editorial-lg-font-size", value: "var(--font-size-lg)" },
  { name: "--editorial-lg-font-weight", value: "var(--font-weight-normal)" },
  { name: "--editorial-lg-line-height", value: "var(--line-height-tight)" },
  { name: "--editorial-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
];
var tokensCssMigration_2026_08_27_editorialLargeSteps = {
  id: "2026-08-27-editorial-large-steps",
  kind: "additive",
  description: "Add the --editorial-lg-* and --editorial-xl-* steps above the reading size",
  apply(css) {
    return ensureScale(css, {
      sectionComment: "Editorial \u2014 the steps above the reading size",
      anchorPrefixes: [
        "--editorial-",
        "--eyebrow-",
        "--code-",
        "--body-",
        "--heading-",
        "--letter-spacing-",
        "--line-height-",
        "--font-weight-",
        "--font-size-",
        "--font-"
      ],
      entries: BUNDLE3
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-09-01-scrim-rename.ts
var RENAMES2 = [
  ["--overlay-low", "--scrim-low"],
  ["--overlay-high", "--scrim-high"],
  ["--overlay", "--scrim"]
];
var tokensCssMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename",
  kind: "breaking",
  description: "Rename --overlay-{low,base,high} to --scrim-*; a scrim dims what is behind it",
  apply(css) {
    let out = css;
    for (const [oldName, newName] of RENAMES2) out = renameToken(out, oldName, newName);
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-09-01-tint-scale.ts
var ENTRIES = [
  { name: "--tint-low", value: "rgba(255, 255, 255, 0.05)" },
  { name: "--tint", value: "rgba(255, 255, 255, 0.1)" },
  { name: "--tint-high", value: "rgba(255, 255, 255, 0.15)" }
];
var tokensCssMigration_2026_09_01_tintScale = {
  id: "2026-09-01-tint-scale",
  kind: "additive",
  description: "Add the --tint-* scale; a tint shades the surface it sits on",
  apply(css) {
    return ensureScale(css, {
      entries: ENTRIES,
      sectionComment: "Tints \u2014 translucent washes that shade the surface they sit on",
      anchorPrefixes: ["--scrim", "--overlay"]
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-09-20-scrim-color-and-opacity.ts
var ENTRIES2 = [
  { name: "--scrim-color", value: "rgb(20, 3, 0)" },
  { name: "--scrim-opacity-low", value: "0.38" },
  { name: "--scrim-opacity", value: "0.51" },
  { name: "--scrim-opacity-high", value: "0.64" }
];
var tokensCssMigration_2026_09_20_scrimColorAndOpacity = {
  id: "2026-09-20-scrim-color-and-opacity",
  kind: "additive",
  description: "Add --scrim-color and --scrim-opacity-*; a scrim's colour and strength are separate tokens",
  apply(css) {
    return ensureScale(css, {
      entries: ENTRIES2,
      sectionComment: "Scrim colour and strength, which each screen mixes where it paints",
      anchorPrefixes: ["--scrim"]
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-09-21-tint-color-and-opacity.ts
var ENTRIES3 = [
  { name: "--tint-color", value: "rgb(255, 255, 255)" },
  { name: "--tint-opacity-low", value: "0.05" },
  { name: "--tint-opacity", value: "0.1" },
  { name: "--tint-opacity-high", value: "0.15" }
];
var tokensCssMigration_2026_09_21_tintColorAndOpacity = {
  id: "2026-09-21-tint-color-and-opacity",
  kind: "additive",
  description: "Add --tint-color and --tint-opacity-*; a tint's colour and strength are separate tokens",
  apply(css) {
    return ensureScale(css, {
      entries: ENTRIES3,
      sectionComment: "Tint colour and strength, which the --tint-* stops compose",
      anchorPrefixes: ["--tint"]
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-10-08-type-scales.ts
var RENAMES3 = [
  ["--code-font-size", "--code-md-font-size"],
  ["--code-line-height", "--code-md-line-height"],
  ["--code-letter-spacing", "--code-md-letter-spacing"]
];
var CARRIED = [
  {
    prefix: "--heading-xl",
    size: "var(--font-size-4xl)",
    links: [
      { name: "--heading-xl-font-family", from: "var(--font-display)", to: "var(--heading-font-family)" },
      { name: "--heading-xl-font-weight", from: "var(--font-weight-semibold)", to: "var(--heading-font-weight)" }
    ]
  },
  {
    prefix: "--heading-lg",
    size: "var(--font-size-2xl)",
    links: [
      { name: "--heading-lg-font-family", from: "var(--font-display)", to: "var(--heading-font-family)" },
      { name: "--heading-lg-font-weight", from: "var(--font-weight-semibold)", to: "var(--heading-font-weight)" }
    ]
  },
  {
    prefix: "--heading-md",
    size: "var(--font-size-xl)",
    links: [
      { name: "--heading-md-font-family", from: "var(--font-display)", to: "var(--heading-font-family)" },
      { name: "--heading-md-font-weight", from: "var(--font-weight-semibold)", to: "var(--heading-font-weight)" }
    ]
  },
  {
    // heading-sm keeps the sans face it shipped with, so only its weight links.
    prefix: "--heading-sm",
    size: "var(--font-size-lg)",
    links: [
      { name: "--heading-sm-font-weight", from: "var(--font-weight-semibold)", to: "var(--heading-font-weight)" }
    ]
  },
  {
    prefix: "--body-md",
    size: "var(--font-size-md)",
    links: [
      { name: "--body-md-font-family", from: "var(--font-sans)", to: "var(--body-font-family)" },
      { name: "--body-md-font-weight", from: "var(--font-weight-normal)", to: "var(--body-font-weight)" }
    ]
  },
  {
    prefix: "--body-sm",
    size: "var(--font-size-sm)",
    links: [
      { name: "--body-sm-font-family", from: "var(--font-sans)", to: "var(--body-font-family)" },
      { name: "--body-sm-font-weight", from: "var(--font-weight-normal)", to: "var(--body-font-weight)" }
    ]
  },
  {
    // 0.91.2 had no code-md face or weight: `--code-font-family` and
    // `--code-font-weight` keep their names as the code usage's settings.
    prefix: "--code-md",
    size: "var(--font-size-sm)",
    links: []
  },
  {
    prefix: "--editorial-xl",
    size: "var(--font-size-xl)",
    links: [
      { name: "--editorial-xl-font-family", from: "var(--font-editorial)", to: "var(--editorial-font-family)" },
      { name: "--editorial-xl-font-weight", from: "var(--font-weight-normal)", to: "var(--editorial-font-weight)" }
    ]
  },
  {
    prefix: "--editorial-lg",
    size: "var(--font-size-lg)",
    links: [
      { name: "--editorial-lg-font-family", from: "var(--font-editorial)", to: "var(--editorial-font-family)" },
      { name: "--editorial-lg-font-weight", from: "var(--font-weight-normal)", to: "var(--editorial-font-weight)" }
    ]
  },
  {
    prefix: "--editorial-md",
    size: "var(--font-size-md)",
    links: [
      { name: "--editorial-md-font-family", from: "var(--font-editorial)", to: "var(--editorial-font-family)" },
      { name: "--editorial-md-font-weight", from: "var(--font-weight-normal)", to: "var(--editorial-font-weight)" }
    ]
  },
  {
    prefix: "--editorial-sm",
    size: "var(--font-size-sm)",
    links: [
      { name: "--editorial-sm-font-family", from: "var(--font-editorial)", to: "var(--editorial-font-family)" },
      { name: "--editorial-sm-font-weight", from: "var(--font-weight-normal)", to: "var(--editorial-font-weight)" }
    ]
  },
  {
    prefix: "--eyebrow",
    size: "var(--font-size-sm)",
    links: [
      { name: "--eyebrow-font-family", from: "var(--font-sans)", to: "var(--body-font-family)" },
      { name: "--eyebrow-font-weight", from: "var(--font-weight-normal)", to: "var(--body-font-weight)" }
    ]
  }
];
var COMPRESSION = [
  { name: "--type-tablet-scale-compression", value: "0.75" },
  { name: "--type-phone-scale-compression", value: "0.63" }
];
var COMPRESSED_VIEWPORTS = ["tablet", "phone"];
function literalRem(size) {
  const m = /^(-?\d*\.?\d+)(rem|px)$/.exec(size.trim());
  if (!m) return null;
  return m[2] === "rem" ? Number(m[1]) : Number(m[1]) / 16;
}
var ALIAS = /^var\(\s*(--[a-z0-9-]+)\s*\)$/i;
function resolvedRem(size, values) {
  const seen = /* @__PURE__ */ new Set();
  let value = size.trim();
  for (let ref = ALIAS.exec(value); ref; ref = ALIAS.exec(value)) {
    const next = values.get(ref[1]);
    if (next === void 0 || seen.has(ref[1])) return null;
    seen.add(ref[1]);
    value = next.trim();
  }
  return literalRem(value);
}
function editedSizes(prefix, rem) {
  const count = String(Number(rem.toFixed(4)));
  return COMPRESSED_VIEWPORTS.map((viewport) => ({
    name: `${prefix}-${viewport}-font-size`,
    value: `min(var(${prefix}-desktop-font-size), calc(pow(${count}, var(--type-${viewport}-scale-compression)) * 1rem))`
  }));
}
var USAGES = [
  {
    usage: "display",
    comment: "Display: type outside the page outline, such as heroes, section titles and big numbers",
    follows: "type",
    settings: [
      { name: "--display-font-family", value: "var(--font-display)" },
      { name: "--display-font-weight", value: "var(--font-weight-semibold)" },
      { name: "--display-scale-base", value: "3" },
      { name: "--display-scale-ratio", value: "1.2" }
    ],
    steps: [
      {
        prefix: "--display-2xl",
        entries: [
          { name: "--display-2xl-font-family", value: "var(--display-font-family)" },
          { name: "--display-2xl-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), 3) * 1rem)" },
          { name: "--display-2xl-tablet-font-size", value: "min(var(--display-2xl-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-2xl-phone-font-size", value: "min(var(--display-2xl-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-2xl-font-size", value: "var(--display-2xl-desktop-font-size)" },
          { name: "--display-2xl-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-2xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--display-2xl-letter-spacing", value: "var(--letter-spacing-tight)" }
        ]
      },
      {
        prefix: "--display-xl",
        entries: [
          { name: "--display-xl-font-family", value: "var(--display-font-family)" },
          { name: "--display-xl-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), 2) * 1rem)" },
          { name: "--display-xl-tablet-font-size", value: "min(var(--display-xl-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-xl-phone-font-size", value: "min(var(--display-xl-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-xl-font-size", value: "var(--display-xl-desktop-font-size)" },
          { name: "--display-xl-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--display-xl-letter-spacing", value: "var(--letter-spacing-tight)" }
        ]
      },
      {
        prefix: "--display-lg",
        entries: [
          { name: "--display-lg-font-family", value: "var(--display-font-family)" },
          { name: "--display-lg-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), 1) * 1rem)" },
          { name: "--display-lg-tablet-font-size", value: "min(var(--display-lg-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-lg-phone-font-size", value: "min(var(--display-lg-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-lg-font-size", value: "var(--display-lg-desktop-font-size)" },
          { name: "--display-lg-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-lg-line-height", value: "var(--line-height-tightest)" },
          { name: "--display-lg-letter-spacing", value: "var(--letter-spacing-tight)" }
        ]
      },
      {
        prefix: "--display-md",
        entries: [
          { name: "--display-md-font-family", value: "var(--display-font-family)" },
          { name: "--display-md-desktop-font-size", value: "calc(var(--display-scale-base) * 1rem)" },
          { name: "--display-md-tablet-font-size", value: "min(var(--display-md-desktop-font-size), calc(pow(var(--display-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-md-phone-font-size", value: "min(var(--display-md-desktop-font-size), calc(pow(var(--display-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-md-font-size", value: "var(--display-md-desktop-font-size)" },
          { name: "--display-md-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-md-line-height", value: "var(--line-height-tightest)" },
          { name: "--display-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--display-sm",
        entries: [
          { name: "--display-sm-font-family", value: "var(--display-font-family)" },
          { name: "--display-sm-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), -1) * 1rem)" },
          { name: "--display-sm-tablet-font-size", value: "min(var(--display-sm-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-sm-phone-font-size", value: "min(var(--display-sm-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-sm-font-size", value: "var(--display-sm-desktop-font-size)" },
          { name: "--display-sm-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-sm-line-height", value: "var(--line-height-tighter)" },
          { name: "--display-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--display-xs",
        entries: [
          { name: "--display-xs-font-family", value: "var(--display-font-family)" },
          { name: "--display-xs-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), -2) * 1rem)" },
          { name: "--display-xs-tablet-font-size", value: "min(var(--display-xs-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-xs-phone-font-size", value: "min(var(--display-xs-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-xs-font-size", value: "var(--display-xs-desktop-font-size)" },
          { name: "--display-xs-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-xs-line-height", value: "var(--line-height-tighter)" },
          { name: "--display-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--display-2xs",
        entries: [
          { name: "--display-2xs-font-family", value: "var(--display-font-family)" },
          { name: "--display-2xs-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), -3) * 1rem)" },
          { name: "--display-2xs-tablet-font-size", value: "min(var(--display-2xs-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-2xs-phone-font-size", value: "min(var(--display-2xs-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-2xs-font-size", value: "var(--display-2xs-desktop-font-size)" },
          { name: "--display-2xs-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-2xs-line-height", value: "var(--line-height-tighter)" },
          { name: "--display-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  },
  {
    usage: "heading",
    comment: "Heading: the page outline, h1 at xl down to h6 at 2xs",
    follows: "display",
    settings: [
      { name: "--heading-font-family", value: "var(--font-display)" },
      { name: "--heading-font-weight", value: "var(--font-weight-semibold)" },
      { name: "--heading-scale-base", value: "1.5" },
      { name: "--heading-scale-ratio", value: "1.25" }
    ],
    steps: [
      {
        prefix: "--heading-2xl",
        entries: [
          { name: "--heading-2xl-font-family", value: "var(--heading-font-family)" },
          { name: "--heading-2xl-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 3) * 1rem)" },
          { name: "--heading-2xl-tablet-font-size", value: "min(var(--heading-2xl-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-2xl-phone-font-size", value: "min(var(--heading-2xl-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-2xl-font-size", value: "var(--heading-2xl-desktop-font-size)" },
          { name: "--heading-2xl-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-2xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--heading-2xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-xl",
        entries: [
          { name: "--heading-xl-font-family", value: "var(--heading-font-family)" },
          { name: "--heading-xl-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 2) * 1rem)" },
          { name: "--heading-xl-tablet-font-size", value: "min(var(--heading-xl-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-xl-phone-font-size", value: "min(var(--heading-xl-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-xl-font-size", value: "var(--heading-xl-desktop-font-size)" },
          { name: "--heading-xl-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--heading-xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-lg",
        entries: [
          { name: "--heading-lg-font-family", value: "var(--heading-font-family)" },
          { name: "--heading-lg-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 1) * 1rem)" },
          { name: "--heading-lg-tablet-font-size", value: "min(var(--heading-lg-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-lg-phone-font-size", value: "min(var(--heading-lg-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-lg-font-size", value: "var(--heading-lg-desktop-font-size)" },
          { name: "--heading-lg-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-lg-line-height", value: "var(--line-height-tightest)" },
          { name: "--heading-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-md",
        entries: [
          { name: "--heading-md-font-family", value: "var(--heading-font-family)" },
          { name: "--heading-md-desktop-font-size", value: "calc(var(--heading-scale-base) * 1rem)" },
          { name: "--heading-md-tablet-font-size", value: "min(var(--heading-md-desktop-font-size), calc(pow(var(--heading-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-md-phone-font-size", value: "min(var(--heading-md-desktop-font-size), calc(pow(var(--heading-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-md-font-size", value: "var(--heading-md-desktop-font-size)" },
          { name: "--heading-md-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-md-line-height", value: "var(--line-height-tighter)" },
          { name: "--heading-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-sm",
        entries: [
          { name: "--heading-sm-font-family", value: "var(--font-sans)" },
          { name: "--heading-sm-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -1) * 1rem)" },
          { name: "--heading-sm-tablet-font-size", value: "min(var(--heading-sm-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-sm-phone-font-size", value: "min(var(--heading-sm-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-sm-font-size", value: "var(--heading-sm-desktop-font-size)" },
          { name: "--heading-sm-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-sm-line-height", value: "var(--line-height-tighter)" },
          { name: "--heading-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-xs",
        entries: [
          { name: "--heading-xs-font-family", value: "var(--font-sans)" },
          { name: "--heading-xs-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -2) * 1rem)" },
          { name: "--heading-xs-tablet-font-size", value: "min(var(--heading-xs-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-xs-phone-font-size", value: "min(var(--heading-xs-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-xs-font-size", value: "var(--heading-xs-desktop-font-size)" },
          { name: "--heading-xs-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-xs-line-height", value: "var(--line-height-tight)" },
          { name: "--heading-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-2xs",
        entries: [
          { name: "--heading-2xs-font-family", value: "var(--font-sans)" },
          { name: "--heading-2xs-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -3) * 1rem)" },
          { name: "--heading-2xs-tablet-font-size", value: "min(var(--heading-2xs-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-2xs-phone-font-size", value: "min(var(--heading-2xs-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-2xs-font-size", value: "var(--heading-2xs-desktop-font-size)" },
          { name: "--heading-2xs-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-2xs-line-height", value: "var(--line-height-tight)" },
          { name: "--heading-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  },
  {
    usage: "body",
    comment: "Body: interface text and short copy",
    follows: "heading",
    settings: [
      { name: "--body-font-family", value: "var(--font-sans)" },
      { name: "--body-font-weight", value: "var(--font-weight-normal)" },
      { name: "--body-scale-base", value: "1" },
      { name: "--body-scale-ratio", value: "1.125" }
    ],
    steps: [
      {
        prefix: "--body-2xl",
        entries: [
          { name: "--body-2xl-font-family", value: "var(--body-font-family)" },
          { name: "--body-2xl-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), 3) * 1rem)" },
          { name: "--body-2xl-tablet-font-size", value: "min(var(--body-2xl-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-2xl-phone-font-size", value: "min(var(--body-2xl-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-2xl-font-size", value: "var(--body-2xl-desktop-font-size)" },
          { name: "--body-2xl-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-2xl-line-height", value: "var(--line-height-tighter)" },
          { name: "--body-2xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-xl",
        entries: [
          { name: "--body-xl-font-family", value: "var(--body-font-family)" },
          { name: "--body-xl-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), 2) * 1rem)" },
          { name: "--body-xl-tablet-font-size", value: "min(var(--body-xl-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-xl-phone-font-size", value: "min(var(--body-xl-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-xl-font-size", value: "var(--body-xl-desktop-font-size)" },
          { name: "--body-xl-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-xl-line-height", value: "var(--line-height-tighter)" },
          { name: "--body-xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-lg",
        entries: [
          { name: "--body-lg-font-family", value: "var(--body-font-family)" },
          { name: "--body-lg-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), 1) * 1rem)" },
          { name: "--body-lg-tablet-font-size", value: "min(var(--body-lg-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-lg-phone-font-size", value: "min(var(--body-lg-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-lg-font-size", value: "var(--body-lg-desktop-font-size)" },
          { name: "--body-lg-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-lg-line-height", value: "var(--line-height-tight)" },
          { name: "--body-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-md",
        entries: [
          { name: "--body-md-font-family", value: "var(--body-font-family)" },
          { name: "--body-md-desktop-font-size", value: "calc(var(--body-scale-base) * 1rem)" },
          { name: "--body-md-tablet-font-size", value: "min(var(--body-md-desktop-font-size), calc(pow(var(--body-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-md-phone-font-size", value: "min(var(--body-md-desktop-font-size), calc(pow(var(--body-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-md-font-size", value: "var(--body-md-desktop-font-size)" },
          { name: "--body-md-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-md-line-height", value: "var(--line-height-normal)" },
          { name: "--body-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-sm",
        entries: [
          { name: "--body-sm-font-family", value: "var(--body-font-family)" },
          { name: "--body-sm-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), -1) * 1rem)" },
          { name: "--body-sm-tablet-font-size", value: "min(var(--body-sm-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-sm-phone-font-size", value: "min(var(--body-sm-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-sm-font-size", value: "var(--body-sm-desktop-font-size)" },
          { name: "--body-sm-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-sm-line-height", value: "var(--line-height-tight)" },
          { name: "--body-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-xs",
        entries: [
          { name: "--body-xs-font-family", value: "var(--body-font-family)" },
          { name: "--body-xs-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), -2) * 1rem)" },
          { name: "--body-xs-tablet-font-size", value: "min(var(--body-xs-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-xs-phone-font-size", value: "min(var(--body-xs-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-xs-font-size", value: "var(--body-xs-desktop-font-size)" },
          { name: "--body-xs-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-xs-line-height", value: "var(--line-height-tight)" },
          { name: "--body-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-2xs",
        entries: [
          { name: "--body-2xs-font-family", value: "var(--body-font-family)" },
          { name: "--body-2xs-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), -3) * 1rem)" },
          { name: "--body-2xs-tablet-font-size", value: "min(var(--body-2xs-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-2xs-phone-font-size", value: "min(var(--body-2xs-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-2xs-font-size", value: "var(--body-2xs-desktop-font-size)" },
          { name: "--body-2xs-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-2xs-line-height", value: "var(--line-height-tight)" },
          { name: "--body-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  },
  {
    usage: "code",
    comment: "Code: code blocks and inline code",
    follows: "body",
    settings: [
      { name: "--code-font-family", value: "var(--font-mono)" },
      { name: "--code-font-weight", value: "var(--font-weight-normal)" },
      { name: "--code-scale-base", value: "0.875" },
      { name: "--code-scale-ratio", value: "1.125" }
    ],
    steps: [
      {
        prefix: "--code-2xl",
        entries: [
          { name: "--code-2xl-font-family", value: "var(--code-font-family)" },
          { name: "--code-2xl-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), 3) * 1rem)" },
          { name: "--code-2xl-tablet-font-size", value: "min(var(--code-2xl-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-2xl-phone-font-size", value: "min(var(--code-2xl-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-2xl-font-size", value: "var(--code-2xl-desktop-font-size)" },
          { name: "--code-2xl-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-2xl-line-height", value: "var(--line-height-normal)" },
          { name: "--code-2xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-xl",
        entries: [
          { name: "--code-xl-font-family", value: "var(--code-font-family)" },
          { name: "--code-xl-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), 2) * 1rem)" },
          { name: "--code-xl-tablet-font-size", value: "min(var(--code-xl-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-xl-phone-font-size", value: "min(var(--code-xl-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-xl-font-size", value: "var(--code-xl-desktop-font-size)" },
          { name: "--code-xl-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-xl-line-height", value: "var(--line-height-normal)" },
          { name: "--code-xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-lg",
        entries: [
          { name: "--code-lg-font-family", value: "var(--code-font-family)" },
          { name: "--code-lg-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), 1) * 1rem)" },
          { name: "--code-lg-tablet-font-size", value: "min(var(--code-lg-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-lg-phone-font-size", value: "min(var(--code-lg-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-lg-font-size", value: "var(--code-lg-desktop-font-size)" },
          { name: "--code-lg-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-lg-line-height", value: "var(--line-height-normal)" },
          { name: "--code-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-md",
        entries: [
          { name: "--code-md-font-family", value: "var(--code-font-family)" },
          { name: "--code-md-desktop-font-size", value: "calc(var(--code-scale-base) * 1rem)" },
          { name: "--code-md-tablet-font-size", value: "min(var(--code-md-desktop-font-size), calc(pow(var(--code-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-md-phone-font-size", value: "min(var(--code-md-desktop-font-size), calc(pow(var(--code-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-md-font-size", value: "var(--code-md-desktop-font-size)" },
          { name: "--code-md-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-md-line-height", value: "var(--line-height-normal)" },
          { name: "--code-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-sm",
        entries: [
          { name: "--code-sm-font-family", value: "var(--code-font-family)" },
          { name: "--code-sm-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), -1) * 1rem)" },
          { name: "--code-sm-tablet-font-size", value: "min(var(--code-sm-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-sm-phone-font-size", value: "min(var(--code-sm-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-sm-font-size", value: "var(--code-sm-desktop-font-size)" },
          { name: "--code-sm-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-sm-line-height", value: "var(--line-height-normal)" },
          { name: "--code-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-xs",
        entries: [
          { name: "--code-xs-font-family", value: "var(--code-font-family)" },
          { name: "--code-xs-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), -2) * 1rem)" },
          { name: "--code-xs-tablet-font-size", value: "min(var(--code-xs-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-xs-phone-font-size", value: "min(var(--code-xs-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-xs-font-size", value: "var(--code-xs-desktop-font-size)" },
          { name: "--code-xs-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-xs-line-height", value: "var(--line-height-normal)" },
          { name: "--code-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-2xs",
        entries: [
          { name: "--code-2xs-font-family", value: "var(--code-font-family)" },
          { name: "--code-2xs-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), -3) * 1rem)" },
          { name: "--code-2xs-tablet-font-size", value: "min(var(--code-2xs-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-2xs-phone-font-size", value: "min(var(--code-2xs-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-2xs-font-size", value: "var(--code-2xs-desktop-font-size)" },
          { name: "--code-2xs-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-2xs-line-height", value: "var(--line-height-normal)" },
          { name: "--code-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  },
  {
    usage: "editorial",
    comment: "Editorial: the long-reading role",
    follows: "code",
    settings: [
      { name: "--editorial-font-family", value: "var(--font-editorial)" },
      { name: "--editorial-font-weight", value: "var(--font-weight-normal)" },
      { name: "--editorial-scale-base", value: "1" },
      { name: "--editorial-scale-ratio", value: "1.125" }
    ],
    steps: [
      {
        prefix: "--editorial-2xl",
        entries: [
          { name: "--editorial-2xl-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-2xl-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 3) * 1rem)" },
          { name: "--editorial-2xl-tablet-font-size", value: "min(var(--editorial-2xl-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-2xl-phone-font-size", value: "min(var(--editorial-2xl-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-2xl-font-size", value: "var(--editorial-2xl-desktop-font-size)" },
          { name: "--editorial-2xl-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-2xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--editorial-2xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-xl",
        entries: [
          { name: "--editorial-xl-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-xl-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 2) * 1rem)" },
          { name: "--editorial-xl-tablet-font-size", value: "min(var(--editorial-xl-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-xl-phone-font-size", value: "min(var(--editorial-xl-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-xl-font-size", value: "var(--editorial-xl-desktop-font-size)" },
          { name: "--editorial-xl-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-xl-line-height", value: "var(--line-height-tighter)" },
          { name: "--editorial-xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-lg",
        entries: [
          { name: "--editorial-lg-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-lg-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 1) * 1rem)" },
          { name: "--editorial-lg-tablet-font-size", value: "min(var(--editorial-lg-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-lg-phone-font-size", value: "min(var(--editorial-lg-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-lg-font-size", value: "var(--editorial-lg-desktop-font-size)" },
          { name: "--editorial-lg-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-lg-line-height", value: "var(--line-height-tight)" },
          { name: "--editorial-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-md",
        entries: [
          { name: "--editorial-md-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-md-desktop-font-size", value: "calc(var(--editorial-scale-base) * 1rem)" },
          { name: "--editorial-md-tablet-font-size", value: "min(var(--editorial-md-desktop-font-size), calc(pow(var(--editorial-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-md-phone-font-size", value: "min(var(--editorial-md-desktop-font-size), calc(pow(var(--editorial-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-md-font-size", value: "var(--editorial-md-desktop-font-size)" },
          { name: "--editorial-md-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-md-line-height", value: "var(--line-height-normal)" },
          { name: "--editorial-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-sm",
        entries: [
          { name: "--editorial-sm-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-sm-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -1) * 1rem)" },
          { name: "--editorial-sm-tablet-font-size", value: "min(var(--editorial-sm-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-sm-phone-font-size", value: "min(var(--editorial-sm-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-sm-font-size", value: "var(--editorial-sm-desktop-font-size)" },
          { name: "--editorial-sm-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-sm-line-height", value: "var(--line-height-tight)" },
          { name: "--editorial-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-xs",
        entries: [
          { name: "--editorial-xs-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-xs-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -2) * 1rem)" },
          { name: "--editorial-xs-tablet-font-size", value: "min(var(--editorial-xs-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-xs-phone-font-size", value: "min(var(--editorial-xs-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-xs-font-size", value: "var(--editorial-xs-desktop-font-size)" },
          { name: "--editorial-xs-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-xs-line-height", value: "var(--line-height-tighter)" },
          { name: "--editorial-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-2xs",
        entries: [
          { name: "--editorial-2xs-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-2xs-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -3) * 1rem)" },
          { name: "--editorial-2xs-tablet-font-size", value: "min(var(--editorial-2xs-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-2xs-phone-font-size", value: "min(var(--editorial-2xs-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-2xs-font-size", value: "var(--editorial-2xs-desktop-font-size)" },
          { name: "--editorial-2xs-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-2xs-line-height", value: "var(--line-height-tighter)" },
          { name: "--editorial-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  }
];
var EYEBROW = [
  { name: "--eyebrow-font-family", value: "var(--body-font-family)" },
  { name: "--eyebrow-desktop-font-size", value: "var(--body-sm-desktop-font-size)" },
  { name: "--eyebrow-tablet-font-size", value: "var(--body-sm-tablet-font-size)" },
  { name: "--eyebrow-phone-font-size", value: "var(--body-sm-phone-font-size)" },
  { name: "--eyebrow-font-size", value: "var(--eyebrow-desktop-font-size)" },
  { name: "--eyebrow-font-weight", value: "var(--body-font-weight)" },
  { name: "--eyebrow-line-height", value: "var(--line-height-normal)" },
  { name: "--eyebrow-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--eyebrow-text-transform", value: "none" }
];
var MEDIA = [
  {
    query: "(max-width: 768px)",
    entries: [
      { name: "--display-2xl-font-size", value: "var(--display-2xl-tablet-font-size)" },
      { name: "--display-xl-font-size", value: "var(--display-xl-tablet-font-size)" },
      { name: "--display-lg-font-size", value: "var(--display-lg-tablet-font-size)" },
      { name: "--display-md-font-size", value: "var(--display-md-tablet-font-size)" },
      { name: "--display-sm-font-size", value: "var(--display-sm-tablet-font-size)" },
      { name: "--display-xs-font-size", value: "var(--display-xs-tablet-font-size)" },
      { name: "--display-2xs-font-size", value: "var(--display-2xs-tablet-font-size)" },
      { name: "--heading-2xl-font-size", value: "var(--heading-2xl-tablet-font-size)" },
      { name: "--heading-xl-font-size", value: "var(--heading-xl-tablet-font-size)" },
      { name: "--heading-lg-font-size", value: "var(--heading-lg-tablet-font-size)" },
      { name: "--heading-md-font-size", value: "var(--heading-md-tablet-font-size)" },
      { name: "--heading-sm-font-size", value: "var(--heading-sm-tablet-font-size)" },
      { name: "--heading-xs-font-size", value: "var(--heading-xs-tablet-font-size)" },
      { name: "--heading-2xs-font-size", value: "var(--heading-2xs-tablet-font-size)" },
      { name: "--body-2xl-font-size", value: "var(--body-2xl-tablet-font-size)" },
      { name: "--body-xl-font-size", value: "var(--body-xl-tablet-font-size)" },
      { name: "--body-lg-font-size", value: "var(--body-lg-tablet-font-size)" },
      { name: "--body-md-font-size", value: "var(--body-md-tablet-font-size)" },
      { name: "--body-sm-font-size", value: "var(--body-sm-tablet-font-size)" },
      { name: "--body-xs-font-size", value: "var(--body-xs-tablet-font-size)" },
      { name: "--body-2xs-font-size", value: "var(--body-2xs-tablet-font-size)" },
      { name: "--editorial-2xl-font-size", value: "var(--editorial-2xl-tablet-font-size)" },
      { name: "--editorial-xl-font-size", value: "var(--editorial-xl-tablet-font-size)" },
      { name: "--editorial-lg-font-size", value: "var(--editorial-lg-tablet-font-size)" },
      { name: "--editorial-md-font-size", value: "var(--editorial-md-tablet-font-size)" },
      { name: "--editorial-sm-font-size", value: "var(--editorial-sm-tablet-font-size)" },
      { name: "--editorial-xs-font-size", value: "var(--editorial-xs-tablet-font-size)" },
      { name: "--editorial-2xs-font-size", value: "var(--editorial-2xs-tablet-font-size)" },
      { name: "--code-2xl-font-size", value: "var(--code-2xl-tablet-font-size)" },
      { name: "--code-xl-font-size", value: "var(--code-xl-tablet-font-size)" },
      { name: "--code-lg-font-size", value: "var(--code-lg-tablet-font-size)" },
      { name: "--code-md-font-size", value: "var(--code-md-tablet-font-size)" },
      { name: "--code-sm-font-size", value: "var(--code-sm-tablet-font-size)" },
      { name: "--code-xs-font-size", value: "var(--code-xs-tablet-font-size)" },
      { name: "--code-2xs-font-size", value: "var(--code-2xs-tablet-font-size)" },
      { name: "--eyebrow-font-size", value: "var(--eyebrow-tablet-font-size)" }
    ]
  },
  {
    query: "(max-width: 480px)",
    entries: [
      { name: "--display-2xl-font-size", value: "var(--display-2xl-phone-font-size)" },
      { name: "--display-xl-font-size", value: "var(--display-xl-phone-font-size)" },
      { name: "--display-lg-font-size", value: "var(--display-lg-phone-font-size)" },
      { name: "--display-md-font-size", value: "var(--display-md-phone-font-size)" },
      { name: "--display-sm-font-size", value: "var(--display-sm-phone-font-size)" },
      { name: "--display-xs-font-size", value: "var(--display-xs-phone-font-size)" },
      { name: "--display-2xs-font-size", value: "var(--display-2xs-phone-font-size)" },
      { name: "--heading-2xl-font-size", value: "var(--heading-2xl-phone-font-size)" },
      { name: "--heading-xl-font-size", value: "var(--heading-xl-phone-font-size)" },
      { name: "--heading-lg-font-size", value: "var(--heading-lg-phone-font-size)" },
      { name: "--heading-md-font-size", value: "var(--heading-md-phone-font-size)" },
      { name: "--heading-sm-font-size", value: "var(--heading-sm-phone-font-size)" },
      { name: "--heading-xs-font-size", value: "var(--heading-xs-phone-font-size)" },
      { name: "--heading-2xs-font-size", value: "var(--heading-2xs-phone-font-size)" },
      { name: "--body-2xl-font-size", value: "var(--body-2xl-phone-font-size)" },
      { name: "--body-xl-font-size", value: "var(--body-xl-phone-font-size)" },
      { name: "--body-lg-font-size", value: "var(--body-lg-phone-font-size)" },
      { name: "--body-md-font-size", value: "var(--body-md-phone-font-size)" },
      { name: "--body-sm-font-size", value: "var(--body-sm-phone-font-size)" },
      { name: "--body-xs-font-size", value: "var(--body-xs-phone-font-size)" },
      { name: "--body-2xs-font-size", value: "var(--body-2xs-phone-font-size)" },
      { name: "--editorial-2xl-font-size", value: "var(--editorial-2xl-phone-font-size)" },
      { name: "--editorial-xl-font-size", value: "var(--editorial-xl-phone-font-size)" },
      { name: "--editorial-lg-font-size", value: "var(--editorial-lg-phone-font-size)" },
      { name: "--editorial-md-font-size", value: "var(--editorial-md-phone-font-size)" },
      { name: "--editorial-sm-font-size", value: "var(--editorial-sm-phone-font-size)" },
      { name: "--editorial-xs-font-size", value: "var(--editorial-xs-phone-font-size)" },
      { name: "--editorial-2xs-font-size", value: "var(--editorial-2xs-phone-font-size)" },
      { name: "--code-2xl-font-size", value: "var(--code-2xl-phone-font-size)" },
      { name: "--code-xl-font-size", value: "var(--code-xl-phone-font-size)" },
      { name: "--code-lg-font-size", value: "var(--code-lg-phone-font-size)" },
      { name: "--code-md-font-size", value: "var(--code-md-phone-font-size)" },
      { name: "--code-sm-font-size", value: "var(--code-sm-phone-font-size)" },
      { name: "--code-xs-font-size", value: "var(--code-xs-phone-font-size)" },
      { name: "--code-2xs-font-size", value: "var(--code-2xs-phone-font-size)" },
      { name: "--eyebrow-font-size", value: "var(--eyebrow-phone-font-size)" }
    ]
  }
];
var DECLARED = new Map(
  USAGES.flatMap((u) => u.steps.flatMap((s) => s.entries)).concat(EYEBROW).map((e) => [e.name, e.value])
);
var TYPE_PRIMITIVES = ["--letter-spacing-", "--line-height-", "--font-weight-", "--font-size-", "--font-"];
var CARRIED_PREFIXES = new Set(CARRIED.map((step) => step.prefix));
function handDeclaredSteps(values) {
  return USAGES.flatMap((u) => u.steps).filter(
    ({ prefix }) => !CARRIED_PREFIXES.has(prefix) && values.has(`${prefix}-font-size`) && !values.has(`${prefix}-desktop-font-size`)
  ).map(({ prefix }) => ({ prefix, links: [] }));
}
var tokensCssMigration_2026_10_08_typeScales = {
  id: "2026-10-08-type-scales",
  kind: "breaking",
  description: "Rebuild the text styles as five type scales with per-viewport sizes, and rename --code-font-size, --code-line-height and --code-letter-spacing to --code-md-*",
  apply(css) {
    let out = css;
    for (const [from, to] of RENAMES3) out = renameToken(out, from, to);
    const values = collectTokenValues(out);
    for (const step of [...CARRIED, ...handDeclaredSteps(values)]) {
      const size = values.get(`${step.prefix}-font-size`);
      if (size === void 0) continue;
      const desktop = `${step.prefix}-desktop-font-size`;
      const edited = size !== step.size;
      const rem = edited ? resolvedRem(size, values) : null;
      out = ensureScale(out, {
        anchorPrefixes: [`${step.prefix}-font-family`, `${step.prefix}-`],
        entries: [
          { name: desktop, value: edited ? size : DECLARED.get(desktop) },
          ...rem === null ? [] : editedSizes(step.prefix, rem)
        ]
      });
      out = setTokenValue(out, `${step.prefix}-font-size`, `var(${desktop})`);
      for (const link of step.links) out = setTokenValue(out, link.name, link.to, { from: link.from });
    }
    out = ensureScale(out, {
      sectionComment: "Text styles: the compression that sets each tablet and phone size",
      anchorPrefixes: ["--type-", ...TYPE_PRIMITIVES],
      entries: COMPRESSION
    });
    for (const block of USAGES) {
      const fallback = [`--${block.usage}-scale-`, `--${block.follows}-`, "--type-"];
      out = ensureScale(out, { sectionComment: block.comment, anchorPrefixes: fallback, entries: block.settings });
      block.steps.forEach((step, i) => {
        const above = block.steps.slice(0, i).reverse().map((s) => `${s.prefix}-`);
        out = ensureScale(out, {
          anchorPrefixes: [
            `${step.prefix}-desktop-font-size`,
            `${step.prefix}-font-family`,
            `${step.prefix}-`,
            ...above,
            ...fallback
          ],
          entries: step.entries
        });
      });
    }
    out = ensureScale(out, {
      anchorPrefixes: ["--eyebrow-desktop-font-size", "--eyebrow-font-family", "--eyebrow-", "--editorial-"],
      entries: EYEBROW
    });
    for (const media of MEDIA) out = appendMediaBlock(out, media.query, media.entries);
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-10-15-responsive-columns.ts
var DESKTOP = [
  {
    structural: "--columns-gutter",
    desktop: "--columns-desktop-gutter",
    shipped: "clamp(0.5rem, 1.5vw, 1.5rem)",
    value: "32px"
  },
  { structural: "--columns-margin", desktop: "--columns-desktop-margin", shipped: "0", value: "32px" }
];
var SMALLER = [
  { name: "--columns-tablet-gutter", value: "24px" },
  { name: "--columns-tablet-margin", value: "24px" },
  { name: "--columns-phone-gutter", value: "16px" },
  { name: "--columns-phone-margin", value: "16px" }
];
var repoints = (viewport) => DESKTOP.map(({ structural }) => ({
  name: structural,
  value: `var(${structural.replace("--columns-", `--columns-${viewport}-`)})`
}));
var tokensCssMigration_2026_10_15_responsiveColumns = {
  id: "2026-10-15-responsive-columns",
  kind: "breaking",
  description: "Give the column grid a gutter and margin per viewport, and re-point --columns-gutter and --columns-margin at them",
  apply(css) {
    const values = collectTokenValues(css);
    const pending = DESKTOP.filter(({ desktop }) => !values.has(desktop));
    let out = ensureScale(css, {
      anchorPrefixes: ["--columns-"],
      entries: [
        ...pending.map(({ structural, desktop, shipped, value }) => {
          const current = values.get(structural);
          return { name: desktop, value: current === void 0 || current === shipped ? value : current };
        }),
        ...SMALLER
      ]
    });
    for (const { structural, desktop } of pending) out = setTokenValue(out, structural, `var(${desktop})`);
    out = ensureScale(out, { anchorPrefixes: ["--columns-"], entries: repoints("desktop") });
    out = appendMediaBlock(out, "(max-width: 767px)", repoints("tablet"), { before: "(max-width: 480px)" });
    return appendMediaBlock(out, "(max-width: 480px)", repoints("phone"));
  }
};

// vite-plugin/tokensCssMigrations/index.ts
var TOKENS_CSS_MIGRATIONS = [
  tokensCssMigration_2026_05_29_typographyScaleAdditions,
  tokensCssMigration_2026_05_29_sectiondividerLegacyAxisCleanup,
  tokensCssMigration_2026_06_03_transformScaleAdditions,
  tokensCssMigration_2026_06_04_removeDeadSizeIconScale,
  tokensCssMigration_2026_06_04_easingColorAndTypescaleAdditions,
  tokensCssMigration_2026_07_20_lineHeightRename,
  tokensCssMigration_2026_07_20_semanticTextStyles,
  tokensCssMigration_2026_08_19_oklchColorValues,
  tokensCssMigration_2026_08_25_editorialTypeRole,
  tokensCssMigration_2026_08_26_gradientStops,
  tokensCssMigration_2026_08_27_backdropPolarity,
  tokensCssMigration_2026_08_27_editorialSizeSteps,
  tokensCssMigration_2026_08_27_editorialLargeSteps,
  tokensCssMigration_2026_09_01_scrimRename,
  tokensCssMigration_2026_09_01_tintScale,
  tokensCssMigration_2026_09_20_scrimColorAndOpacity,
  tokensCssMigration_2026_09_21_tintColorAndOpacity,
  tokensCssMigration_2026_10_08_typeScales,
  tokensCssMigration_2026_10_15_responsiveColumns
];
function runTokensCssMigrations(css) {
  return foldMigrations(css, () => true);
}
function runAdditiveTokensCssMigrations(css) {
  return foldMigrations(css, (m) => m.kind === "additive");
}
function foldMigrations(css, include) {
  let out = css;
  const applied = [];
  for (const m of TOKENS_CSS_MIGRATIONS) {
    if (!include(m)) continue;
    const next = m.apply(out);
    if (next !== out) {
      applied.push(m.id);
      out = next;
    }
  }
  return { css: out, applied, changed: out !== css };
}
function findContractViolations(canonicalCss) {
  const violations = [];
  for (const m of TOKENS_CSS_MIGRATIONS) {
    if (m.kind !== "additive") continue;
    const before = collectTokenValues(canonicalCss);
    const after = collectTokenValues(m.apply(canonicalCss));
    const removed = [...before.keys()].filter((t) => !after.has(t)).sort();
    const changed = [...before.entries()].filter(([t, v]) => after.has(t) && after.get(t) !== v).map(([t]) => t).sort();
    if (removed.length || changed.length) violations.push({ id: m.id, removed, changed });
  }
  return violations;
}
function semverBumpType(prev, next) {
  const p = parseSemver(prev);
  const n = parseSemver(next);
  if (n.major > p.major) return "major";
  if (n.major === p.major && n.minor > p.minor) return "minor";
  if (n.major === p.major && n.minor === p.minor && n.patch > p.patch) return "patch";
  return "none";
}
function parseSemver(v) {
  const [core] = v.replace(/^v/, "").split(/[-+]/);
  const [major = 0, minor = 0, patch = 0] = core.split(".").map((n) => Number(n) || 0);
  return { major, minor, patch };
}
function enforceBreakingRequiresMajor(args) {
  const breakingIds = args.newMigrations.filter((m) => m.kind === "breaking").map((m) => m.id);
  const bump = semverBumpType(args.prevVersion, args.nextVersion);
  if (breakingIds.length === 0 || bump === "major") {
    return { level: "ok", breakingIds, bump, message: "" };
  }
  const pre1 = parseSemver(args.nextVersion).major < 1;
  const ids = breakingIds.join(", ");
  return {
    level: pre1 ? "warn" : "error",
    breakingIds,
    bump,
    message: `Breaking token migration(s) [${ids}] are shipping in a ${bump} bump (${args.prevVersion} -> ${args.nextVersion}). Token names are public API; ` + (pre1 ? `pre-1.0 this is allowed, but the CHANGELOG must flag it under "Changed (breaking)".` : `from 1.0.0 a breaking token change requires a major bump.`)
  };
}
function validateTokensCss(input) {
  const defined = /* @__PURE__ */ new Set([
    ...collectDefinedTokens(input.tokensCss),
    ...collectDefinedTokens(input.generatedCss ?? "")
  ]);
  const referencedBy = /* @__PURE__ */ new Map();
  for (const { name, source } of input.componentSources) {
    const body = extractGlobalRootBody(source);
    if (!body) continue;
    for (const t of collectDefinedTokens(body)) defined.add(t);
    for (const ref of collectReferencedTokens(body)) {
      let set = referencedBy.get(ref);
      if (!set) referencedBy.set(ref, set = /* @__PURE__ */ new Set());
      set.add(name);
    }
  }
  const missing = [];
  for (const [token, names] of referencedBy) {
    if (!defined.has(token)) {
      missing.push({ token, referencedBy: [...names].sort() });
    }
  }
  return missing.sort((a, b) => a.token.localeCompare(b.token));
}

export {
  extractGlobalRootBody,
  collectDefinedTokens,
  collectTokenValues,
  collectReferencedTokens,
  ensureScale,
  renameToken,
  removeToken,
  removeTokensMatching,
  setTokenValue,
  appendMediaBlock,
  TOKENS_CSS_MIGRATIONS,
  runTokensCssMigrations,
  runAdditiveTokensCssMigrations,
  findContractViolations,
  semverBumpType,
  enforceBreakingRequiresMajor,
  validateTokensCss
};
