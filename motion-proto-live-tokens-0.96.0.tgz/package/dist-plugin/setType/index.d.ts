import { c as FontStackVariable, C as ColorsAndType, b as FontStack, F as FontSource } from '../themeTypes-B8_Idrp4.js';
export { r as readLiveTokensConfig, a as resolveDataDirs } from '../dataPaths-BpIK_Obx.js';

type PairingSlot = 'display' | 'body' | 'serif' | 'mono' | 'editorial';
interface PairingFace {
    name: string;
    url: string;
    weights?: number[];
    italics?: boolean;
}
type FontPairing = Partial<Record<PairingSlot, PairingFace>>;
interface PairingChange {
    slot: PairingSlot;
    variable: FontStackVariable;
    from: string | null;
    to: string;
}
interface DroppedSource {
    id: string;
    names: string[];
}
interface FontPairingReport {
    changes: PairingChange[];
    dropped: DroppedSource[];
    changed: boolean;
}
interface FontPairingResult {
    colorsAndType: ColorsAndType;
    report: FontPairingReport;
}
/** Slot order is also the order stamped sources land in `fontSources`;
 *  `check:preset-themes` reads the preset pair back out positionally. */
declare const SLOT_ORDER: PairingSlot[];
declare const SLOT_VARIABLES: Record<PairingSlot, FontStackVariable>;
declare function slugifyFamily(name: string): string;
interface ApplyFontPairingOptions {
    /** `src_preset_` for the shipped presets, so `check:preset-themes` can still
     *  tell a stamped source from one the user added. */
    idPrefix?: string;
}
/**
 * Bind each named slot to a Google Fonts family: stamp the source, put that
 * family at the head of the slot's stack, and keep every fallback behind it.
 * Slots the pairing omits are left exactly as they are.
 */
declare function applyFontPairing(colorsAndType: ColorsAndType, pairing: FontPairing, { idPrefix }?: ApplyFontPairingOptions): FontPairingResult;

interface CssResponse {
    ok: boolean;
    status: number;
    text: () => Promise<string>;
}
type CssFetcher = (url: string) => Promise<CssResponse>;
interface ResolvedGoogleFont {
    /** As Google spells it in the returned CSS, not as the caller typed it. */
    name: string;
    url: string;
    weights: number[];
    italics: boolean;
    probeUrl: string;
}
/**
 * Ask for every weight in both styles. Google silently drops the ones a family
 * does not have and answers 200 anyway, so the returned CSS is a census of the
 * family rather than a yes/no on the request. A 400 here means the family
 * itself is not on Google Fonts.
 */
declare function discoveryUrl(name: string): string;
/** The narrowest URL that still delivers everything the family has. A range
 *  serves one variable file; an enumeration serves one file per weight. */
declare function persistUrlFor(name: string, weights: number[], italics: boolean): string;
/**
 * Verify a family exists on Google Fonts and settle on the URL to persist.
 * Two requests in the common case: one to take the census, one to confirm the
 * narrower URL built from it. A range that the family's axis cannot serve
 * answers 400, so the enumerated form is the fallback rather than the guess.
 */
declare function resolveGoogleFont(name: string, fetcher: CssFetcher): Promise<ResolvedGoogleFont>;

interface WeightRequirement {
    variable: string;
    stack: FontStackVariable;
    weight: number;
}
interface FaceCoverage {
    stack: FontStackVariable;
    family: string;
    required: number[];
    available: number[];
    missing: number[];
    italics: boolean;
}
/**
 * Every weight the token contract asks of each font stack, read off the
 * `-font-family` / `-font-weight` pairing that typography tokens follow.
 * `overrides` takes a theme's own `cssVariables`, so component tokens count
 * the same as the shipped text styles.
 */
declare function requiredWeights(tokensCss: string, overrides?: Record<string, string>): WeightRequirement[];
interface CoveredFace {
    name: string;
    weights: number[];
    italics: boolean;
}
declare function weightCoverage(requirements: WeightRequirement[], faces: Partial<Record<FontStackVariable, CoveredFace>>): FaceCoverage[];

declare function fontPairingLabel(stacks: FontStack[], sources: FontSource[]): string;

export { type ApplyFontPairingOptions, type CoveredFace, type CssFetcher, type CssResponse, type DroppedSource, type FaceCoverage, type FontPairing, type FontPairingReport, type FontPairingResult, type PairingChange, type PairingFace, type PairingSlot, type ResolvedGoogleFont, SLOT_ORDER, SLOT_VARIABLES, type WeightRequirement, applyFontPairing, discoveryUrl, fontPairingLabel, persistUrlFor, requiredWeights, resolveGoogleFont, slugifyFamily, weightCoverage };
