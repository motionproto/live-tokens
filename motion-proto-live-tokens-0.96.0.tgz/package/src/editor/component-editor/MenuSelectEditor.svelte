<script module lang="ts">
  import { buildTypeGroupTokens, buildTypeGroupShareableContexts } from './scaffolding/buildTypeGroupTokens';
  import type { Token, TypeGroupConfig, IntrinsicSpec } from './scaffolding/types';

  export const component = 'menuselect';

  // Non-text tokens per state; text/font lives in typeGroups. Item-shape tokens sit under `menu` so they read as one decision across states.
  const states: Record<string, Token[]> = {
    menu: [
      // The panel floats over arbitrary page content; below ~90% the content behind it ghosts through and it stops reading as a solid, tappable target.
      { label: 'surface color', element: 'frame', groupKey: 'surface', variable: '--menuselect-menu-surface', minOpacity: 90 },
      { label: 'border color', element: 'frame', groupKey: 'border', variable: '--menuselect-menu-border' },
      { label: 'border width', element: 'frame', groupKey: 'width', variable: '--menuselect-menu-border-width' },
      { label: 'corner radius', element: 'frame', groupKey: 'menu-radius', variable: '--menuselect-menu-radius' },
      { label: 'padding', element: 'frame', variable: '--menuselect-menu-padding', groupKey: 'menu-padding' },
      { label: 'item gap', element: 'frame', groupKey: 'gap', variable: '--menuselect-menu-gap' },
      { label: 'shadow', element: 'frame', groupKey: 'shadow', variable: '--menuselect-menu-shadow' },
      { label: 'radius', element: 'item', groupKey: 'item-radius', variable: '--menuselect-item-radius' },
      { label: 'padding', element: 'item', variable: '--menuselect-item-padding', groupKey: 'item-padding' },
    ],
    'default item': [
      { label: 'surface color', element: 'frame', groupKey: 'surface', variable: '--menuselect-default-surface' },
      { label: 'color', element: 'icon', groupKey: 'icon', variable: '--menuselect-default-icon' },
      { label: 'size', element: 'icon', canBeLinked: true, groupKey: 'icon-size', variable: '--menuselect-default-icon-size' },
    ],
    'hover item': [
      { label: 'surface color', element: 'frame', groupKey: 'surface', variable: '--menuselect-hover-surface' },
      { label: 'color', element: 'icon', groupKey: 'icon', variable: '--menuselect-hover-icon' },
      { label: 'size', element: 'icon', canBeLinked: true, groupKey: 'icon-size', variable: '--menuselect-hover-icon-size' },
    ],
    'selected item': [
      { label: 'surface color', element: 'frame', groupKey: 'surface', variable: '--menuselect-selected-surface' },
      { label: 'color', element: 'icon', groupKey: 'icon', variable: '--menuselect-selected-icon' },
      { label: 'size', element: 'icon', canBeLinked: true, groupKey: 'icon-size', variable: '--menuselect-selected-icon-size' },
      { label: 'color', element: 'indicator', groupKey: 'indicator', variable: '--menuselect-selected-indicator' },
    ],
    'disabled item': [
      { label: 'surface color', element: 'frame', groupKey: 'surface', variable: '--menuselect-disabled-surface' },
      { label: 'color', element: 'icon', groupKey: 'icon', variable: '--menuselect-disabled-icon' },
      { label: 'size', element: 'icon', canBeLinked: true, groupKey: 'icon-size', variable: '--menuselect-disabled-icon-size' },
    ],
  };

  // Per-state item-label typography; linkable groupKeys let users collapse or diverge across states.
  const typeGroups: Record<string, TypeGroupConfig[]> = {
    'default item': [{
      legend: '',
      element: 'text',
      colorVariable: '--menuselect-default-text',
      familyVariable: '--menuselect-default-text-font-family',
      sizeVariable: '--menuselect-default-text-font-size',
      weightVariable: '--menuselect-default-text-font-weight',
      lineHeightVariable: '--menuselect-default-text-line-height',
    }],
    'hover item': [{
      legend: '',
      element: 'text',
      colorVariable: '--menuselect-hover-text',
      familyVariable: '--menuselect-hover-text-font-family',
      sizeVariable: '--menuselect-hover-text-font-size',
      weightVariable: '--menuselect-hover-text-font-weight',
      lineHeightVariable: '--menuselect-hover-text-line-height',
    }],
    'selected item': [{
      legend: '',
      element: 'text',
      colorVariable: '--menuselect-selected-text',
      familyVariable: '--menuselect-selected-text-font-family',
      sizeVariable: '--menuselect-selected-text-font-size',
      weightVariable: '--menuselect-selected-text-font-weight',
      lineHeightVariable: '--menuselect-selected-text-line-height',
    }],
    'disabled item': [{
      legend: '',
      element: 'text',
      colorVariable: '--menuselect-disabled-text',
      familyVariable: '--menuselect-disabled-text-font-family',
      sizeVariable: '--menuselect-disabled-text-font-size',
      weightVariable: '--menuselect-disabled-text-font-weight',
      lineHeightVariable: '--menuselect-disabled-text-line-height',
    }],
  };

  const typeGroupTokens: Token[] = buildTypeGroupTokens(typeGroups, {
    component,
    variants: ['default', 'hover', 'selected', 'disabled'],
  });
  export const allTokens: Token[] = [...Object.values(states).flat(), ...typeGroupTokens];

  const linkableContexts = new Map<string, string>([
    ...buildTypeGroupShareableContexts(typeGroups),
    ['--menuselect-default-icon-size', 'default item'],
    ['--menuselect-hover-icon-size', 'hover item'],
    ['--menuselect-selected-icon-size', 'selected item'],
    ['--menuselect-disabled-icon-size', 'disabled item'],
  ]);

  // The hover tint is off unless a project turns it on: the gate holds a
  // transparent layer, a no-op, until it holds the tint itself.
  export const intrinsics: IntrinsicSpec[] = [
    {
      key: 'hover-tint',
      variants: ['default'],
      variable: () => '--menuselect-hover-tint-enabled',
      values: ['var(--color-transparent)', 'var(--menuselect-hover-tint)'],
      default: { default: 'var(--color-transparent)' },
    },
  ];
</script>

<script lang="ts">
  import MenuSelect from '../../system/components/MenuSelect.svelte';
  import VariantGroup from './scaffolding/VariantGroup.svelte';
  import ComponentEditorBase from './scaffolding/ComponentEditorBase.svelte';
  import { editorState, setComponentAlias, clearComponentAlias } from '../core/store/editorStore';
  import { computeLinkedBlock, withLinkedDisabled } from './scaffolding/linkedBlock';
  import Toggle from '../ui/Toggle.svelte';
  import UIPaletteSelector from '../ui/UIPaletteSelector.svelte';

  // One switch. Turning the tint on also stands each hover surface down to its
  // own base, so hover is the tint alone rather than a swap wearing a wash.
  // Written as aliases rather than gated in CSS: a component token's value is
  // substituted at :root, so it can never name a per-variant private var.
  // Off clears the overrides, returning each surface to its shipped default.
  const HOVER_SWAPS: readonly (readonly [hover: string, base: string])[] = [
    ['--menuselect-hover-surface', '--menuselect-default-surface'],
  ];
  const TINT_ON = 'var(--menuselect-hover-tint)';
  const TINT_OFF = 'var(--color-transparent)';

  let tintOn = $derived.by(() => {
    const ref = $editorState.components.menuselect?.aliases['--menuselect-hover-tint-enabled'];
    return (ref?.kind === 'literal' ? ref.value : TINT_OFF) === TINT_ON;
  });

  function setTintOn(checked: boolean) {
    setComponentAlias('menuselect', '--menuselect-hover-tint-enabled', {
      kind: 'literal',
      value: checked ? TINT_ON : TINT_OFF,
    });
    for (const [hover, base] of HOVER_SWAPS) {
      if (checked) setComponentAlias('menuselect', hover, { kind: 'token', name: base });
      else clearComponentAlias('menuselect', hover);
    }
  }

  type Item = { value: string; label: string; icon?: string; disabled?: boolean };
  const items: Item[] = [
    { value: 'option-1', label: 'Option one',   icon: 'fas fa-circle' },
    { value: 'option-2', label: 'Option two',   icon: 'fas fa-square' },
    { value: 'option-3', label: 'Option three', icon: 'fas fa-triangle-exclamation' },
    { value: 'option-4', label: 'Option four',  icon: 'fas fa-ban', disabled: true },
  ];

  let showIcons = $state(true);
  let previewItems = $derived(showIcons ? items : items.map((it) => ({ ...it, icon: undefined })));

  let linked = $derived(computeLinkedBlock(component, linkableContexts, allTokens, $editorState));

  let visibleStates = $derived(Object.fromEntries(
    Object.entries(states).map(([name, list]) => [
      name,
      withLinkedDisabled(list, linked.varSet).map((t) =>
        tintOn && t.variable.endsWith('-hover-surface') ? { ...t, disabled: true } : t,
      ),
    ]),
  ) as Record<string, Token[]>);
</script>

<ComponentEditorBase {component} title="Menu Select" description="A select-style dropdown panel. Items support default, hover, selected, and disabled states." tokens={allTokens} {linked}>
  <VariantGroup
    name="menuselect"
    title="Menu Select"
    states={visibleStates}
    {typeGroups}
    {component}
  >
    {#snippet extraPropertyRows(stateName)}
      {#if stateName === 'hover item'}
        <div class="property-row" data-token-variables="--menuselect-hover-tint-enabled">
          <span class="property-label">tint layer</span>
          <Toggle checked={tintOn} onchange={setTintOn} />
        </div>
        {#if tintOn}
          <div class="property-row">
            <span class="property-label">tint color</span>
            <UIPaletteSelector variable="--menuselect-hover-tint" {component} showNone={false} />
          </div>
        {/if}
      {/if}
    {/snippet}
    {#snippet canvasToolbarExtras()}
      <hr class="canvas-toolbar-divider" />
      <label class="show-icons-row">
        <input type="checkbox" bind:checked={showIcons} />
        <span>Show icons</span>
      </label>
    {/snippet}
    {#snippet children({ activeState })}
      {@const previewValue = activeState === 'selected item' ? 'option-2' : ''}
      {@const previewForceHover = activeState === 'hover item' ? 'option-1' : null}
      <MenuSelect
        items={previewItems}
        value={previewValue}
        forceHoverValue={previewForceHover}
      />
    {/snippet}
  </VariantGroup>
</ComponentEditorBase>

<style>
  .show-icons-row {
    display: inline-flex;
    align-items: center;
    gap: var(--ui-space-6);
    font-size: var(--ui-font-size-sm);
    color: rgba(255, 255, 255, 0.78);
    cursor: pointer;
  }
</style>
