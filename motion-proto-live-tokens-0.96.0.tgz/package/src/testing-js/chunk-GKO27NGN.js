import {
  CONTRACTS_MODULE_ENV
} from "./chunk-SHBYZUPD.js";

// src/testing/vitest.ts
import path from "path";
import { fileURLToPath } from "url";
import { mergeConfig } from "vite";
var CONTRACT_INCLUDE = ["registry.contract.{ts,js}", "component-behavior.contract.{ts,js}"];
var CONTRACT_DIR = path.dirname(fileURLToPath(import.meta.url));
function createVitestConfig(viteConfig, options = {}) {
  return mergeConfig(viteConfig, {
    // `svelte`'s package exports resolve to `index-server.js` without it, whose
    // `mount` throws `lifecycle_function_unavailable`, and whose
    // `createEventDispatcher` is a silent no-op. A project's own vite config
    // states the condition for its build, not for a test run under happy-dom.
    resolve: { conditions: ["browser"] },
    test: {
      ...options.include ? { include: options.include } : { dir: CONTRACT_DIR, include: CONTRACT_INCLUDE },
      // Vitest's own default drops everything under `node_modules`, which is
      // where an installed package's contract file lives.
      exclude: options.exclude ?? [],
      ...options.setupFiles ? { setupFiles: options.setupFiles } : {},
      environment: options.environment ?? "happy-dom",
      environmentOptions: {
        happyDOM: {
          settings: {
            // fontLoader injects <link rel=stylesheet> for the theme's font
            // sources, which happy-dom would fetch from Google and Typekit for
            // real. That puts the public internet on the release gate's
            // critical path; treat the load as satisfied instead.
            disableCSSFileLoading: true,
            handleDisabledFileLoadingAsSuccess: true
          }
        }
      },
      server: { deps: { inline: [/@motion-proto\/live-tokens/, /@fortawesome/] } },
      // Vitest's default preview truncates a failed array-equality assertion
      // to `[ Array(1) ]`, which drops `checkRegistryEntry`'s actual violation
      // text. `check-component --tests` reads that text out of the JSON
      // reporter's `failureMessages` to attribute a finding, so nothing here
      // can afford to be summarized away.
      chaiConfig: { truncateThreshold: 0 },
      ...options.registrySetup || options.contractsModule ? {
        env: {
          ...options.registrySetup ? { LIVE_TOKENS_REGISTRY_SETUP: options.registrySetup } : {},
          ...options.contractsModule ? { [CONTRACTS_MODULE_ENV]: options.contractsModule } : {}
        }
      } : {}
    }
  });
}

export {
  createVitestConfig
};
//# sourceMappingURL=chunk-GKO27NGN.js.map