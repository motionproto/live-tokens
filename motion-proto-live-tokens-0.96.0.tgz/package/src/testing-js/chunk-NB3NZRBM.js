// src/testing/config.ts
import fs from "fs";
import path from "path";

// src/editor/core/routing/ownedRoutes.ts
var DEFAULT_COMPONENTS_PATH = "/live-tokens/components";

// src/testing/config.ts
var TESTING_CONFIG_FILE = "live-tokens.testing.ts";
var COMPONENTS_PATH_ENV = "LIVE_TOKENS_COMPONENTS_PATH";
var COMPONENT_ENV = "LIVE_TOKENS_COMPONENT";
var PAGES_ENV = "LIVE_TOKENS_PAGES";
var PAGE_VIEWPORTS_ENV = "LIVE_TOKENS_PAGE_VIEWPORTS";
var DEFAULT_PAGE_VIEWPORTS = [
  { width: 1280, height: 900 },
  { width: 390, height: 844 }
];
var DEFAULT_DATA_DIR = "src/live-tokens/data";
var DEFAULT_DEV_COMMAND = "npm run dev -- --host {host} --port {port}";
function defineTestingConfig(config) {
  return config;
}
function configuredDataDir(root) {
  try {
    const parsed = JSON.parse(fs.readFileSync(path.join(root, "live-tokens.config.json"), "utf-8"));
    if (parsed && typeof parsed === "object" && typeof parsed.dataDir === "string") {
      return path.resolve(root, parsed.dataDir);
    }
  } catch {
  }
  return path.resolve(root, DEFAULT_DATA_DIR);
}
function resolveTestingConfig(config = {}, root = process.cwd()) {
  const projectRoot = path.resolve(root);
  return {
    root: projectRoot,
    viteConfig: path.resolve(projectRoot, config.viteConfig ?? "vite.config.ts"),
    devCommand: config.devCommand ?? DEFAULT_DEV_COMMAND,
    port: config.port,
    componentsPath: config.componentsPath ?? DEFAULT_COMPONENTS_PATH,
    dataDir: config.dataDir ? path.resolve(projectRoot, config.dataDir) : configuredDataDir(projectRoot),
    registrySetup: config.registrySetup ? path.resolve(projectRoot, config.registrySetup) : void 0,
    contractsModule: config.contractsModule ? path.resolve(projectRoot, config.contractsModule) : void 0,
    pageRoutes: config.pageRoutes ?? {},
    pageViewports: config.pageViewports?.length ? config.pageViewports : DEFAULT_PAGE_VIEWPORTS
  };
}
function devServerCommand(command, host, port) {
  return command.replaceAll("{host}", host).replaceAll("{port}", String(port));
}

export {
  DEFAULT_COMPONENTS_PATH,
  TESTING_CONFIG_FILE,
  COMPONENTS_PATH_ENV,
  COMPONENT_ENV,
  PAGES_ENV,
  PAGE_VIEWPORTS_ENV,
  DEFAULT_PAGE_VIEWPORTS,
  defineTestingConfig,
  resolveTestingConfig,
  devServerCommand
};
//# sourceMappingURL=chunk-NB3NZRBM.js.map