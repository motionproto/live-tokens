// src/testing/contracts/index.ts
import path from "path";
import { pathToFileURL } from "url";

// src/testing/contracts/badge.ts
var variants = [
  "brand",
  "accent",
  "neutral",
  "alternate",
  "canvas",
  "special",
  "success",
  "warning",
  "danger",
  "info"
];
function basePaints(v) {
  return {
    root: {
      paddingTop: `--badge-${v}-padding`,
      borderRadius: `--badge-${v}-radius`,
      borderTopWidth: `--badge-${v}-border-width`,
      boxShadow: `--badge-${v}-shadow`,
      fontFamily: `--badge-${v}-text-font-family`,
      fontSize: `--badge-${v}-text-font-size`,
      fontWeight: `--badge-${v}-text-font-weight`,
      lineHeight: `--badge-${v}-text-line-height`
    },
    icon: { fontSize: `--badge-${v}-icon-size` }
  };
}
function colorPaints(v) {
  return {
    root: {
      backgroundColor: `--badge-${v}-surface`,
      borderTopColor: `--badge-${v}-border`,
      color: `--badge-${v}-text`
    }
  };
}
var badgeContract = {
  id: "badge",
  origin: "system",
  view: { variant: "Brand" },
  root: "root",
  parts: {
    root: ".badge",
    icon: ".icon"
  },
  properties: [
    { variant: "Brand", state: "base", paints: basePaints("brand") },
    { variant: "Brand", state: "colors", paints: colorPaints("brand") },
    ...variants.filter((v) => v !== "brand").flatMap((v) => [
      { variant: v.charAt(0).toUpperCase() + v.slice(1), state: "base", paints: basePaints(v) },
      { variant: v.charAt(0).toUpperCase() + v.slice(1), state: "colors", paints: colorPaints(v) }
    ])
  ],
  states: [{ state: "base" }, { state: "colors" }],
  uncovered: {
    "--badge-brand-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    "--badge-accent-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    "--badge-neutral-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    "--badge-alternate-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    "--badge-canvas-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    "--badge-special-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    "--badge-success-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    "--badge-warning-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    "--badge-danger-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    "--badge-info-blur": "consumed via backdrop-filter: blur(), which no probe covers"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variant: "Brand",
        state: "base",
        variable: "--badge-brand-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--badge-brand-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--badge-brand-border-width", "--badge-brand-radius", "--badge-brand-padding"],
    unchanged: ["--badge-brand-shadow", "--badge-brand-icon-size"],
    aliasedTo: {
      "--badge-brand-border-width": "--border-width-3",
      "--badge-brand-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--badge-brand-border-width" }
  },
  interaction: {
    applicable: false,
    reason: "a badge is a static label with no interactive role"
  },
  behavior: {
    applicable: false,
    reason: "a badge declares no callback prop and answers no event: its props select paint, which the render obligation reads"
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--badge-brand-surface", stroke: "--badge-brand-border" }]
  }
};

// src/testing/contracts/button.ts
var variants2 = ["primary", "secondary", "outline", "success", "danger", "warning"];
var cap = (v) => v.charAt(0).toUpperCase() + v.slice(1);
function basePaints2(v) {
  return {
    root: {
      paddingTop: `--button-${v}-padding`,
      borderRadius: `--button-${v}-radius`,
      borderTopWidth: `--button-${v}-border-width`,
      fontFamily: `--button-${v}-text-font-family`,
      fontSize: `--button-${v}-text-font-size`,
      fontWeight: `--button-${v}-text-font-weight`,
      lineHeight: `--button-${v}-text-line-height`
    },
    icon: { fontSize: `--button-${v}-icon-size` }
  };
}
function statePaints(v, s) {
  const prefix = s === "default" ? `--button-${v}` : `--button-${v}-${s}`;
  const textVar = s === "default" ? `--button-${v}-text` : `--button-${v}-${s}-text`;
  return {
    root: {
      backgroundColor: `${prefix}-surface`,
      borderTopColor: `${prefix}-border`,
      color: textVar
    }
  };
}
var otherVariantProperties = variants2.filter((v) => v !== "primary").flatMap((v) => [
  { variant: cap(v), state: "base", paints: basePaints2(v) },
  { variant: cap(v), state: "default", paints: statePaints(v, "default") },
  { variant: cap(v), state: "hover", paints: statePaints(v, "hover") },
  { variant: cap(v), state: "disabled", paints: statePaints(v, "disabled") }
]);
var buttonContract = {
  id: "button",
  origin: "system",
  view: { variant: "Primary" },
  root: "root",
  parts: {
    root: ".button",
    icon: ".button i"
  },
  properties: [
    { variant: "Primary", state: "base", paints: basePaints2("primary") },
    ...otherVariantProperties,
    { variant: "Outline", state: "active", paints: { root: { backgroundColor: "--button-outline-active-surface" } } },
    {
      setup: [{ kind: "control", selector: ".preview-actions select", value: "small" }],
      paints: {
        root: {
          paddingTop: "--button-small-padding",
          fontSize: "--button-small-text-font-size",
          fontWeight: "--button-small-text-font-weight",
          lineHeight: "--button-small-text-line-height"
        },
        icon: { fontSize: "--button-small-icon-size" }
      }
    }
  ],
  states: [
    { state: "base" },
    { state: "default", paints: statePaints("primary", "default") },
    { state: "hover", forceClass: "force-hover", paints: statePaints("primary", "hover") },
    {
      state: "disabled",
      attributes: { root: { disabled: "" } },
      paints: statePaints("primary", "disabled")
    }
  ],
  uncovered: {
    "--button-shimmer": "gates the ::before sweep with a display toggle, which no probe covers",
    "--button-hover-tint": "consumed inside a background-image tint wash, never appearing verbatim in a computed style",
    "--button-hover-tint-enabled": "the gate for the tint wash above, same limitation"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variant: "Primary",
        state: "base",
        variable: "--button-primary-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--button-primary-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--button-primary-border-width", "--button-primary-radius", "--button-primary-padding"],
    unchanged: ["--button-primary-icon-size"],
    aliasedTo: {
      "--button-primary-border-width": "--border-width-3",
      "--button-primary-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--button-primary-border-width" }
  },
  interaction: {
    part: "root",
    role: "button",
    cases: [
      {
        name: "clicking a button focuses it",
        action: { kind: "click", part: "root" },
        expect: { kind: "focused", part: "root", value: true }
      },
      {
        name: "a disabled button refuses focus",
        state: "disabled",
        action: { kind: "click", part: "root" },
        expect: { kind: "focused", part: "root", value: false }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking a button hands the click on",
        action: { kind: "click", part: "root" },
        expect: { kind: "callback", prop: "onclick", args: [{ type: "click" }] }
      },
      {
        name: "a disabled button stays silent",
        props: { disabled: true },
        action: { kind: "click", part: "root" },
        expect: { kind: "no-callback", prop: "onclick" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--button-primary-surface", stroke: "--button-primary-border" }]
  }
};

// src/testing/contracts/callout.ts
var variants3 = ["info", "success", "warning", "danger"];
function paintsFor(v) {
  return {
    root: {
      backgroundColor: `--callout-${v}-surface`,
      borderTopColor: `--callout-${v}-border`,
      borderTopWidth: `--callout-${v}-border-width`,
      borderLeftWidth: `--callout-${v}-indicator-width`,
      borderRadius: `--callout-${v}-radius`,
      paddingTop: `--callout-${v}-padding`
    },
    label: {
      color: `--callout-${v}-label`,
      fontFamily: `--callout-${v}-label-font-family`,
      fontSize: `--callout-${v}-label-font-size`,
      fontWeight: `--callout-${v}-label-font-weight`,
      lineHeight: `--callout-${v}-label-line-height`
    },
    message: {
      color: `--callout-${v}-text`,
      fontFamily: `--callout-${v}-text-font-family`,
      fontSize: `--callout-${v}-text-font-size`,
      fontWeight: `--callout-${v}-text-font-weight`,
      lineHeight: `--callout-${v}-text-line-height`
    }
  };
}
var calloutContract = {
  id: "callout",
  origin: "system",
  view: { variant: "Info" },
  root: "root",
  parts: {
    root: ".callout",
    label: ".callout-label",
    message: ".callout-message"
  },
  properties: variants3.map((v) => ({ variant: v.charAt(0).toUpperCase() + v.slice(1), paints: paintsFor(v) })),
  states: {
    applicable: false,
    reason: "each variant is one full preset with one state, so the editor renders no state strip"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--callout-info-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--callout-info-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--callout-info-border-width", "--callout-info-radius", "--callout-info-padding"],
    unchanged: ["--callout-info-label-font-size", "--callout-info-text-font-size"],
    aliasedTo: {
      "--callout-info-border-width": "--border-width-3",
      "--callout-info-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--callout-info-border-width" }
  },
  interaction: {
    applicable: false,
    reason: "a callout is a static box with no interactive role"
  },
  behavior: {
    applicable: false,
    reason: "a callout declares no callback prop and answers no event"
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--callout-info-surface", stroke: "--callout-info-border" }]
  }
};

// src/testing/contracts/card.ts
var cardContract = {
  id: "card",
  origin: "system",
  root: "root",
  parts: {
    root: ".card",
    header: ".card-header",
    icon: ".card-icon",
    title: ".card-title",
    body: ".card-body"
  },
  properties: [
    {
      paints: {
        root: {
          backgroundColor: "--card-default-surface",
          borderTopColor: "--card-default-border",
          borderTopWidth: "--card-default-border-width",
          borderRadius: "--card-default-radius",
          boxShadow: "--card-default-shadow"
        },
        header: {
          backgroundColor: "--card-default-header-surface",
          columnGap: "--card-default-header-gap",
          paddingTop: "--card-default-header-padding-top",
          paddingRight: "--card-default-header-padding-right",
          paddingBottom: "--card-default-header-padding-bottom",
          paddingLeft: "--card-default-header-padding-left"
        },
        icon: { fontSize: "--card-default-icon-size" },
        title: {
          color: "--card-default-title",
          fontFamily: "--card-default-title-font-family",
          fontSize: "--card-default-title-font-size",
          fontWeight: "--card-default-title-font-weight",
          lineHeight: "--card-default-title-line-height"
        },
        body: {
          color: "--card-default-body",
          fontFamily: "--card-default-body-font-family",
          fontSize: "--card-default-body-font-size",
          fontWeight: "--card-default-body-font-weight",
          lineHeight: "--card-default-body-line-height",
          paddingTop: "--card-default-body-padding-top",
          paddingRight: "--card-default-body-padding-right",
          paddingBottom: "--card-default-body-padding-bottom",
          paddingLeft: "--card-default-body-padding-left"
        }
      }
    },
    // `click({force:true})` leaves the pointer resting on `root`, so the
    // browser's real `.card:hover` rule applies afterward, no InteractionCase
    // needed. The editor's `.force-hover` reads these same gated tokens, so
    // the state entry below and this one have to agree.
    {
      setup: [{ kind: "click", part: "root" }],
      paints: {
        root: { borderTopColor: "--card-hover-border-enabled", boxShadow: "--card-hover-shadow-enabled" }
      }
    },
    // The per-side entry above drives `-padding-top` directly, which passes
    // regardless of what it's aliased to. This drives the base token instead,
    // proving the `-padding-top: var(--card-default-*-padding)` link itself.
    {
      paints: {
        header: { paddingTop: "--card-default-header-padding" },
        body: { paddingTop: "--card-default-body-padding" }
      }
    }
  ],
  states: [
    { state: "default" },
    // The gate is off by default, so the hover tab has to show the resting
    // card. Naming the gated tokens is what pins that: `--card-hover-border`
    // resolves to `--border-neutral-strong` and would not match.
    {
      state: "hover",
      forceClass: "force-hover",
      paints: {
        root: { borderTopColor: "--card-hover-border-enabled", boxShadow: "--card-hover-shadow-enabled" }
      }
    }
  ],
  uncovered: {
    "--card-default-blur": "consumed via backdrop-filter: blur(), which no probe covers",
    // `--card-hover-border-enabled` is an alias the editor repoints, so the
    // chain is not live and driving these two moves nothing. The runtime reads
    // them only through the per-instance `hover` prop (Card.svelte:47), which
    // the standardized preview never sets. Before force-hover honoured the
    // gate it read `--card-hover-border` directly and the hover state pinned
    // it; that path was the bug.
    "--card-hover-border": "reachable only through the per-instance hover prop, which the preview does not set",
    "--card-hover-shadow": "reachable only through the per-instance hover prop, which the preview does not set"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--card-default-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--card-default-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--card-default-border-width", "--card-default-radius"],
    unchanged: ["--card-default-icon-size"],
    aliasedTo: {
      "--card-default-border-width": "--border-width-3",
      "--card-default-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--card-default-border-width" }
  },
  interaction: {
    applicable: false,
    reason: "a card is a static container with no interactive role"
  },
  behavior: {
    applicable: false,
    reason: "a card declares no callback prop; its header and body arrive as snippets, which a mounted fixture cannot express"
  },
  sketch: {
    style: "pencil",
    parts: [
      { part: "root", fill: "--card-default-surface", stroke: "--card-default-border" },
      { part: "header", fill: "--card-default-header-surface" }
    ]
  }
};

// src/testing/contracts/codesnippet.ts
var codeSnippetContract = {
  id: "codesnippet",
  origin: "system",
  root: "root",
  parts: {
    root: ".codesnippet",
    code: ".code",
    copy: ".copy"
  },
  properties: [
    {
      paints: {
        root: {
          columnGap: "--codesnippet-gap",
          paddingTop: "--codesnippet-padding",
          backgroundColor: "--codesnippet-surface",
          borderTopColor: "--codesnippet-border",
          borderTopWidth: "--codesnippet-border-width",
          borderRadius: "--codesnippet-radius"
        },
        code: {
          color: "--codesnippet-code-text",
          fontFamily: "--codesnippet-code-font-family",
          fontSize: "--codesnippet-code-font-size",
          fontWeight: "--codesnippet-code-font-weight",
          lineHeight: "--codesnippet-code-line-height"
        },
        copy: {
          color: "--codesnippet-icon",
          fontSize: "--codesnippet-icon-size"
        }
      }
    }
  ],
  states: [
    { state: "default" },
    {
      state: "hover",
      forceClass: "force-hover",
      paints: { copy: { color: "--codesnippet-hover-icon" } }
    }
  ],
  uncovered: {
    "--codesnippet-scrollbar-thumb": "drawn via the ::-webkit-scrollbar-thumb pseudo-element and the scrollbar-color property, neither of which a probe can pin to one part",
    "--codesnippet-scrollbar-border-width": "drives ::-webkit-scrollbar height, which a probe cannot read back verbatim"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--codesnippet-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--codesnippet-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--codesnippet-border-width", "--codesnippet-radius", "--codesnippet-padding", "--codesnippet-scrollbar-border-width"],
    unchanged: ["--codesnippet-icon-size"],
    aliasedTo: {
      "--codesnippet-border-width": "--border-width-3",
      "--codesnippet-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--codesnippet-border-width" }
  },
  interaction: {
    part: "copy",
    role: "button",
    cases: [
      {
        name: "clicking copy focuses the button",
        action: { kind: "click", part: "copy" },
        expect: { kind: "focused", part: "copy", value: true }
      }
    ]
  },
  behavior: {
    applicable: false,
    reason: "the copy control reports through the system clipboard and a timed popover, neither of which is a callback prop"
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--codesnippet-surface", stroke: "--codesnippet-border" }]
  }
};

// src/testing/contracts/collapsiblesection.ts
function clickHover() {
  return [{ kind: "control", selector: '.tabs-selectors.substrip .state-tab-btn:has-text("Hover")' }];
}
function headerPaints(v, s) {
  const p = `--collapsiblesection-${v}-${s}`;
  const header = {
    backgroundColor: `${p}-surface`,
    paddingTop: `${p}-padding`
  };
  if (v === "hairline") {
    header.borderBottomColor = `${p}-hairline-color`;
    header.borderBottomWidth = `${p}-hairline-width`;
  }
  return {
    header,
    label: {
      color: `${p}-label`,
      fontFamily: `${p}-label-font-family`,
      fontSize: `${p}-label-font-size`,
      fontWeight: `${p}-label-font-weight`,
      lineHeight: `${p}-label-line-height`
    },
    icon: { color: `${p}-icon`, fontSize: `${p}-icon-size` }
  };
}
var collapsibleSectionContract = {
  id: "collapsiblesection",
  origin: "system",
  view: { variant: "Container", state: "Body" },
  root: "root",
  parts: {
    root: ".es-root",
    header: ".section-header",
    label: ".section-label",
    icon: ".toggle-icon",
    body: ".section-content",
    toggleButton: ".section-toggle-button"
  },
  properties: [
    {
      variant: "Container",
      state: "Container",
      paints: {
        root: {
          borderTopColor: "--collapsiblesection-container-frame-border",
          borderTopWidth: "--collapsiblesection-container-frame-border-width",
          borderRadius: "--collapsiblesection-container-frame-radius"
        }
      }
    },
    { variant: "Container", state: "Header", paints: headerPaints("container", "default") },
    { variant: "Container", state: "Header", setup: clickHover(), paints: headerPaints("container", "hover") },
    {
      variant: "Container",
      state: "Body",
      paints: { body: { backgroundColor: "--collapsiblesection-container-open-surface", paddingTop: "--collapsiblesection-container-open-padding" } }
    },
    { variant: "Chromeless", state: "Header", paints: headerPaints("chromeless", "default") },
    { variant: "Chromeless", state: "Header", setup: clickHover(), paints: headerPaints("chromeless", "hover") },
    { variant: "Chromeless", state: "Body", paints: { body: { paddingTop: "--collapsiblesection-chromeless-open-padding" } } },
    { variant: "With Hairline", state: "Header", paints: headerPaints("hairline", "default") },
    { variant: "With Hairline", state: "Header", setup: clickHover(), paints: headerPaints("hairline", "hover") },
    { variant: "With Hairline", state: "Body", paints: { body: { paddingTop: "--collapsiblesection-hairline-open-padding" } } }
  ],
  states: [{ state: "Container" }, { state: "Header" }, { state: "Body" }],
  persistence: {
    cases: [
      {
        shape: "token",
        variant: "Container",
        state: "Container",
        variable: "--collapsiblesection-container-frame-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--collapsiblesection-container-frame-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--collapsiblesection-container-frame-border-width", "--collapsiblesection-container-frame-radius"],
    unchanged: ["--collapsiblesection-container-default-icon-size"],
    aliasedTo: {
      "--collapsiblesection-container-frame-border-width": "--border-width-3",
      "--collapsiblesection-container-frame-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--collapsiblesection-container-frame-border-width" }
  },
  interaction: {
    part: "toggleButton",
    role: "button",
    // No activation case: CollapsibleSectionEditor's preview drives `open`
    // off the active state tab and never wires `ontoggle` back to it, so
    // clicking the real button here can't move `aria-expanded` (same
    // constraint documented on ToggleEditor in toggle.ts).
    cases: [
      {
        name: "clicking the toggle button focuses it",
        action: { kind: "click", part: "toggleButton" },
        expect: { kind: "focused", part: "toggleButton", value: true }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking the chevron asks to toggle",
        props: { label: "Details" },
        action: { kind: "click", part: "toggleButton" },
        expect: { kind: "callback", prop: "ontoggle", args: [] }
      },
      {
        name: "open drives the chevron",
        props: { label: "Details", open: true },
        expect: { kind: "attribute", part: "toggleButton", name: "aria-expanded", value: "true" }
      },
      {
        name: "clicking leaves the section where the prop put it",
        props: { label: "Details" },
        action: { kind: "click", part: "toggleButton" },
        expect: { kind: "attribute", part: "toggleButton", name: "aria-expanded", value: "false" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [
      { part: "root", stroke: "--collapsiblesection-container-frame-border" },
      { part: "header", fill: "--collapsiblesection-container-default-surface" },
      { part: "body", fill: "--collapsiblesection-container-open-surface" }
    ]
  }
};

// src/testing/contracts/cornerbadge.ts
var variants4 = [
  "brand",
  "accent",
  "neutral",
  "alternate",
  "canvas",
  "special",
  "success",
  "warning",
  "danger",
  "info"
];
function colorPaints2(v) {
  return {
    badge: {
      backgroundColor: `--cornerbadge-${v}-surface`,
      borderTopColor: `--cornerbadge-${v}-border`,
      color: `--cornerbadge-${v}-text`
    }
  };
}
var basePaints3 = {
  root: { bottom: "--cornerbadge-margin" },
  badge: {
    borderTopLeftRadius: "--cornerbadge-inner-radius",
    borderTopRightRadius: "--cornerbadge-v-axis-radius",
    borderBottomRightRadius: "--cornerbadge-outer-radius",
    borderBottomLeftRadius: "--cornerbadge-h-axis-radius",
    paddingTop: "--cornerbadge-padding",
    fontFamily: "--cornerbadge-text-font-family",
    fontSize: "--cornerbadge-text-font-size",
    fontWeight: "--cornerbadge-text-font-weight",
    lineHeight: "--cornerbadge-text-line-height"
  }
};
var cornerBadgeContract = {
  id: "cornerbadge",
  origin: "system",
  view: { variant: "Brand" },
  root: "root",
  parts: {
    root: ".cornerbadge",
    badge: ".cornerbadge .badge"
  },
  properties: [
    {
      variant: "Brand",
      paints: {
        root: basePaints3.root,
        badge: { ...basePaints3.badge, ...colorPaints2("brand").badge }
      }
    },
    ...variants4.filter((v) => v !== "brand").map((v) => ({
      variant: v.charAt(0).toUpperCase() + v.slice(1),
      paints: colorPaints2(v)
    }))
  ],
  states: [{ state: "base" }, { state: "colors" }],
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--cornerbadge-outer-radius",
        observe: { part: "badge", css: "borderBottomRightRadius" }
      }
    ],
    resetVariable: "--cornerbadge-outer-radius"
  },
  theme: {
    theme: "ocean",
    changed: ["--cornerbadge-outer-radius", "--cornerbadge-inner-radius", "--cornerbadge-margin"],
    unchanged: ["--cornerbadge-text-font-size"],
    aliasedTo: {
      "--cornerbadge-outer-radius": "--radius-md",
      "--cornerbadge-inner-radius": "--radius-md"
    },
    observe: { part: "badge", css: "borderBottomRightRadius", variable: "--cornerbadge-outer-radius" }
  },
  interaction: {
    applicable: false,
    reason: "a corner badge is a static marker with no interactive role"
  },
  behavior: {
    applicable: false,
    reason: "a corner badge declares no callback prop and answers no event"
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "badge", fill: "--cornerbadge-brand-surface", stroke: "--cornerbadge-brand-border" }]
  }
};

// src/testing/contracts/dialog.ts
var dialogContract = {
  id: "dialog",
  origin: "system",
  root: "root",
  parts: {
    backdrop: ".dialog-backdrop",
    root: ".dialog",
    header: ".dialog-header",
    title: ".dialog-title",
    closeButton: ".dialog-close",
    body: ".dialog-body",
    footer: ".dialog-footer",
    confirmButton: ".dialog-footer-buttons button:last-of-type",
    cancelButton: ".dialog-footer-buttons button:first-of-type"
  },
  properties: [
    {
      paints: {
        backdrop: { backgroundColor: "--dialog-scrim-surface" },
        root: {
          backgroundColor: "--dialog-surface",
          borderTopColor: "--dialog-border",
          borderTopWidth: "--dialog-border-width",
          borderRadius: "--dialog-radius",
          boxShadow: "--dialog-shadow"
        },
        header: {
          backgroundColor: "--dialog-header-surface",
          borderBottomColor: "--dialog-header-hairline-color",
          borderBottomWidth: "--dialog-header-hairline-width",
          paddingTop: "--dialog-header-padding"
        },
        title: {
          color: "--dialog-title",
          fontFamily: "--dialog-title-font-family",
          fontSize: "--dialog-title-font-size",
          fontWeight: "--dialog-title-font-weight",
          lineHeight: "--dialog-title-line-height"
        },
        closeButton: {
          color: "--dialog-close-icon",
          fontSize: "--dialog-close-icon-size"
        },
        body: {
          paddingTop: "--dialog-body-padding",
          color: "--dialog-body",
          fontFamily: "--dialog-body-font-family",
          fontSize: "--dialog-body-font-size",
          fontWeight: "--dialog-body-font-weight",
          lineHeight: "--dialog-body-line-height"
        },
        footer: {
          borderTopColor: "--dialog-footer-hairline-color",
          borderTopWidth: "--dialog-footer-hairline-width",
          paddingTop: "--dialog-footer-padding"
        }
      }
    }
  ],
  states: [
    { state: "scrim" },
    { state: "dialog" },
    { state: "header" },
    { state: "body" },
    { state: "footer" }
  ],
  uncovered: {
    "--dialog-blur": "consumed via backdrop-filter: blur(), which no probe covers"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        state: "dialog",
        variable: "--dialog-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      },
      {
        shape: "config",
        state: "footer",
        control: '.button-variant-row:has(.property-label:text-is("right button")) select',
        configKey: "--dialog-confirm-variant",
        observe: { part: "confirmButton", css: "backgroundColor" }
      },
      {
        shape: "config",
        state: "footer",
        control: '.button-variant-row:has(.property-label:text-is("left button")) select',
        configKey: "--dialog-cancel-variant",
        observe: { part: "cancelButton", css: "backgroundColor" }
      }
    ],
    resetVariable: "--dialog-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--dialog-border-width", "--dialog-radius", "--dialog-header-padding", "--dialog-footer-padding"],
    unchanged: ["--dialog-close-icon-size", "--dialog-title-font-size"],
    aliasedTo: {
      "--dialog-border-width": "--border-width-4",
      "--dialog-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--dialog-border-width" }
  },
  interaction: {
    part: "closeButton",
    role: "button",
    cases: [
      {
        name: "clicking the close icon focuses it",
        action: { kind: "click", part: "closeButton" },
        expect: { kind: "focused", part: "closeButton", value: true }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking close asks to close",
        props: { open: true, inline: true, title: "Confirm" },
        action: { kind: "click", part: "closeButton" },
        expect: { kind: "callback", prop: "onclose", args: [] }
      },
      {
        name: "title drives the heading",
        props: { open: true, inline: true, title: "Confirm" },
        expect: { kind: "text", part: "title", value: "Confirm" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [
      { part: "root", fill: "--dialog-surface", stroke: "--dialog-border" },
      { part: "header", fill: "--dialog-header-surface" }
    ]
  }
};

// src/testing/contracts/iconbutton.ts
var variants5 = ["primary", "secondary", "outline", "success", "danger", "warning"];
var cap2 = (v) => v.charAt(0).toUpperCase() + v.slice(1);
function basePaints4(v) {
  return {
    root: {
      paddingTop: `--iconbutton-${v}-padding`,
      borderRadius: `--iconbutton-${v}-radius`,
      borderTopWidth: `--iconbutton-${v}-border-width`
    },
    icon: { fontSize: `--iconbutton-${v}-icon-size` }
  };
}
function statePaints2(v, s) {
  const prefix = s === "default" ? `--iconbutton-${v}` : `--iconbutton-${v}-${s}`;
  const iconVar = s === "default" ? `--iconbutton-${v}-icon` : `--iconbutton-${v}-${s}-icon`;
  return {
    root: { backgroundColor: `${prefix}-surface`, borderTopColor: `${prefix}-border` },
    icon: { color: iconVar }
  };
}
var otherVariantProperties2 = variants5.filter((v) => v !== "primary").flatMap((v) => [
  { variant: cap2(v), state: "base", paints: basePaints4(v) },
  { variant: cap2(v), state: "default", paints: statePaints2(v, "default") },
  { variant: cap2(v), state: "hover", paints: statePaints2(v, "hover") },
  { variant: cap2(v), state: "disabled", paints: statePaints2(v, "disabled") }
]);
var iconButtonContract = {
  id: "iconbutton",
  origin: "system",
  view: { variant: "Primary" },
  root: "root",
  parts: {
    root: ".icon-button",
    icon: ".icon-button i"
  },
  properties: [
    { variant: "Primary", state: "base", paints: basePaints4("primary") },
    ...otherVariantProperties2,
    { variant: "Outline", state: "active", paints: { root: { backgroundColor: "--iconbutton-outline-active-surface" } } },
    {
      setup: [{ kind: "control", selector: ".preview-actions select", value: "small" }],
      paints: {
        root: { paddingTop: "--iconbutton-small-padding" },
        icon: { fontSize: "--iconbutton-small-icon-size" }
      }
    }
  ],
  states: [
    { state: "base" },
    { state: "default", paints: statePaints2("primary", "default") },
    { state: "hover", forceClass: "force-hover", paints: statePaints2("primary", "hover") },
    {
      state: "disabled",
      attributes: { root: { disabled: "" } },
      paints: statePaints2("primary", "disabled")
    }
  ],
  uncovered: {
    "--iconbutton-hover-tint": "consumed inside a background-image tint wash, never appearing verbatim in a computed style",
    "--iconbutton-hover-tint-enabled": "the gate for the tint wash above, same limitation"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variant: "Primary",
        state: "base",
        variable: "--iconbutton-primary-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--iconbutton-primary-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--iconbutton-primary-border-width", "--iconbutton-primary-radius", "--iconbutton-primary-padding"],
    unchanged: ["--iconbutton-primary-icon-size"],
    aliasedTo: {
      "--iconbutton-primary-border-width": "--border-width-3",
      "--iconbutton-primary-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--iconbutton-primary-border-width" }
  },
  interaction: {
    part: "root",
    role: "button",
    cases: [
      {
        name: "clicking an icon button focuses it",
        action: { kind: "click", part: "root" },
        expect: { kind: "focused", part: "root", value: true }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking an icon button hands the click on",
        props: { icon: "fas fa-check", ariaLabel: "Confirm" },
        action: { kind: "click", part: "root" },
        expect: { kind: "callback", prop: "onclick", args: [{ type: "click" }] }
      },
      {
        name: "a disabled icon button stays silent",
        props: { icon: "fas fa-check", ariaLabel: "Confirm", disabled: true },
        action: { kind: "click", part: "root" },
        expect: { kind: "no-callback", prop: "onclick" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--iconbutton-primary-surface", stroke: "--iconbutton-primary-border" }]
  }
};

// src/testing/contracts/image.ts
function framePaints(v) {
  return {
    root: {
      borderTopColor: `--image-${v}-border`,
      borderTopWidth: `--image-${v}-border-width`,
      borderRadius: `--image-${v}-radius`,
      boxShadow: `--image-${v}-shadow`
    }
  };
}
var imageContract = {
  id: "image",
  origin: "system",
  view: { variant: "Default" },
  root: "root",
  parts: {
    root: ".image",
    img: ".image img"
  },
  properties: [
    { variant: "Default", paints: framePaints("default") },
    { variant: "Bare", paints: framePaints("bare") }
  ],
  states: {
    applicable: false,
    reason: "each variant is one frame preset with one state, so the editor renders no state strip"
  },
  uncovered: {
    "--image-zoom-scale": "consumed inside transform: scale(), never appears verbatim in a computed style"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--image-default-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      },
      {
        shape: "literal",
        control: 'label.zoom-enable:has-text("Use zoom on hover") input',
        variable: "--image-zoom-enabled",
        observe: { part: "img", css: "transform" }
      }
    ],
    resetVariable: "--image-default-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--image-default-border-width", "--image-default-radius"],
    unchanged: ["--image-default-shadow", "--image-zoom-scale"],
    aliasedTo: {
      "--image-default-border-width": "--border-width-3",
      "--image-default-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--image-default-border-width" }
  },
  interaction: {
    applicable: false,
    reason: "a framed picture carries no interactive role; the zoom effect is a hover transform, not an action"
  },
  behavior: {
    applicable: false,
    reason: "an image declares no callback prop; zoom is a hover transform the browser paints"
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", stroke: "--image-default-border" }]
  }
};

// src/testing/contracts/imagelightbox.ts
var imageLightboxContract = {
  id: "imagelightbox",
  origin: "system",
  view: { setup: [{ kind: "click", part: "thumb" }] },
  root: "root",
  parts: {
    root: ".image-lightbox-wrapper",
    thumb: ".image-lightbox-thumb",
    overlay: { selector: ".image-lightbox-overlay", portal: true },
    stage: { selector: ".image-lightbox-stage", portal: true },
    closeButton: { selector: ".image-lightbox-close", portal: true },
    closeIcon: { selector: ".image-lightbox-close svg", portal: true },
    prevButton: { selector: ".image-lightbox-nav-prev", portal: true },
    nextButton: { selector: ".image-lightbox-nav-next", portal: true },
    counter: { selector: ".image-lightbox-counter", portal: true },
    toolbar: { selector: ".image-lightbox-toolbar", portal: true }
  },
  properties: [
    {
      paints: {
        thumb: {
          backgroundColor: "--imagelightbox-tile-surface",
          borderTopColor: "--imagelightbox-tile-border",
          borderTopWidth: "--imagelightbox-tile-border-width",
          borderRadius: "--imagelightbox-tile-radius",
          boxShadow: "--imagelightbox-tile-shadow"
        },
        overlay: { backgroundColor: "--imagelightbox-scrim-surface" },
        closeButton: {
          backgroundColor: "--imagelightbox-chrome-surface",
          borderTopColor: "--imagelightbox-chrome-border",
          borderTopWidth: "--imagelightbox-chrome-border-width",
          borderRadius: "--imagelightbox-chrome-radius",
          color: "--imagelightbox-chrome-icon"
        },
        closeIcon: { stroke: "--imagelightbox-chrome-icon" }
      }
    },
    // `click({force:true})` leaves the pointer resting on `nextButton`, so the
    // browser's real `.image-lightbox-nav:hover` rule applies afterward.
    // Unlike `closeButton`, clicking it does not close the modal.
    {
      setup: [{ kind: "click", part: "nextButton" }],
      paints: { nextButton: { backgroundColor: "--imagelightbox-chrome-hover-surface" } }
    }
  ],
  states: [{ state: "tile" }, { state: "overlay" }, { state: "chrome" }],
  persistence: {
    cases: [
      {
        // No `state` here: "tile" is the panel's own default tab, and every
        // `selectView` re-clicks whatever `state` names even when it is
        // already active. While the modal is open, that click's target sits
        // under the overlay's full-viewport hit area, so skipping it avoids
        // an avoidable trip through the same close-on-click behavior `setup`
        // is about to use on purpose. `setup` closes the modal the
        // contract-level view opened so the "tile" token control (behind the
        // still-open overlay otherwise) is reachable, by pressing Escape on
        // `root` rather than clicking `closeButton`. `assertPersistence`
        // replays `setup` twice back to back (once directly, once inside
        // `driveControl`). Measured against a live page: `closeLightbox`'s
        // `open = false` write happens inside an animation `onfinish`
        // callback that a `settle()` cycle doesn't durably wait out, so
        // `closeButton` — a portaled element that unmounts once that callback
        // fires — can still be gone, still be there, or about to vanish
        // mid-click, depending on exactly when it lands relative to the
        // harness's round trips. A second `closeButton` click inherits that
        // uncertainty. Leading with a `thumb` click to guarantee a target for
        // the `closeButton` click that follows inherits it from the other
        // side instead: `openLightbox`'s own `if (open) return` reads the
        // same not-yet-written flag, so it can no-op rather than reopen, and
        // nothing then re-drives it — reproduced empirically, a deterministic
        // dead end. Escape on `root` avoids both: `root` is never portaled,
        // so the action always has a target, and replaying it before the
        // first press has finished closing re-enters `closeLightbox` rather
        // than skipping it, so every replay drives the component strictly
        // further toward closed. (Escape also collapses the components
        // editor's own drawer, but nothing else this obligation reads lives
        // there, and `reopen()` between obligations restores it.)
        shape: "token",
        setup: [{ kind: "press", part: "root", key: "Escape" }],
        variable: "--imagelightbox-tile-border-width",
        observe: { part: "thumb", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--imagelightbox-tile-border-width"
  },
  theme: {
    // Closes the modal the contract-level setup opened: the Theme Picker
    // trigger lives in the chrome behind it, and the still-open overlay
    // blocks clicks the same way it does for the persistence case above.
    // Unlike that case, `assertThemeProjection` runs `setup` only once, so
    // the double-replay hazard doesn't apply and a plain `closeButton` click
    // is enough — and it has to be a click, not the Escape this contract's
    // persistence case uses, because Escape also collapses the drawer this
    // obligation's own `.theme-name-trigger` lives in.
    setup: [{ kind: "click", part: "closeButton" }],
    theme: "halloween",
    changed: ["--imagelightbox-tile-border-width", "--imagelightbox-tile-radius", "--imagelightbox-chrome-border-width", "--imagelightbox-chrome-radius"],
    unchanged: ["--imagelightbox-tile-shadow"],
    aliasedTo: {
      "--imagelightbox-tile-border-width": "--border-width-2",
      "--imagelightbox-tile-radius": "--radius-none"
    },
    observe: { part: "thumb", css: "borderTopWidth", variable: "--imagelightbox-tile-border-width" }
  },
  interaction: {
    part: "nextButton",
    role: "button",
    cases: [
      {
        name: "clicking the next chevron focuses it",
        action: { kind: "click", part: "nextButton" },
        expect: { kind: "focused", part: "nextButton", value: true }
      }
    ]
  },
  // `overlay` and `closeButton` are inside `.image-lightbox-modal`, which
  // `use:portal` moves to `document.body`. The standardized preview scopes
  // `data-sketch` to its own `.sketch-scope` wrapper rather than the document
  // root, so a portaled part sits outside the CSS ancestor match this contract
  // can observe, even though PART_SPECS draws it on a real host page (where
  // Sketch mode's scope is the page root). `thumb` never portals, so it is the
  // part this contract can pin.
  behavior: {
    applicable: false,
    reason: "the lightbox declares no callback prop; opening portals a modal sized from measured geometry, which happy-dom has no layout for"
  },
  sketch: {
    style: "pencil",
    parts: [
      { part: "thumb", fill: "--imagelightbox-tile-surface", stroke: "--imagelightbox-tile-border" }
    ]
  }
};

// src/testing/contracts/inlineeditactions.ts
function statePaints3(btn, s) {
  const p = `--inlineeditactions-${btn}-${s}`;
  const button = btn === "save" ? "saveBtn" : "cancelBtn";
  return {
    // `-icon-size` lands as `font-size` on the button itself (the icon glyph
    // inherits it), not on a separate icon element — and a declared "icon"
    // part here would be the button's own `<i class="fas ...">`, whose native
    // ::before glyph content is never 'none', which reads as "drawn" to
    // `assertNoSketchPaint` regardless of sketch mode.
    [button]: {
      backgroundColor: `${p}-surface`,
      borderTopColor: `${p}-border`,
      borderTopWidth: `${p}-border-width`,
      borderRadius: `${p}-radius`,
      paddingTop: `${p}-padding`,
      color: `${p}-text`,
      fontSize: `${p}-icon-size`
    }
  };
}
var inlineEditActionsContract = {
  id: "inlineeditactions",
  origin: "system",
  view: { variant: "Save button" },
  root: "saveBtn",
  parts: {
    saveBtn: ".save-btn",
    cancelBtn: ".cancel-btn"
  },
  // Every entry names its own `state` explicitly. VariantGroup mirrors the
  // last-clicked state tab across sibling variants (for the linked-block
  // chart), so switching variants without repeating `state` would silently
  // carry the previous entry's tab forward.
  properties: [
    { variant: "Save button", state: "default", paints: statePaints3("save", "default") },
    { variant: "Save button", state: "hover", paints: statePaints3("save", "hover") },
    { variant: "Cancel button", state: "default", paints: statePaints3("cancel", "default") },
    { variant: "Cancel button", state: "hover", paints: statePaints3("cancel", "hover") }
  ],
  states: [
    { state: "default" },
    { state: "hover" }
  ],
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--inlineeditactions-save-default-border-width",
        observe: { part: "saveBtn", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--inlineeditactions-save-default-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--inlineeditactions-save-default-border-width", "--inlineeditactions-save-default-radius"],
    unchanged: ["--inlineeditactions-save-default-icon-size"],
    aliasedTo: {
      "--inlineeditactions-save-default-border-width": "--border-width-2",
      "--inlineeditactions-save-default-radius": "--radius-none"
    },
    observe: { part: "saveBtn", css: "borderTopWidth", variable: "--inlineeditactions-save-default-border-width" }
  },
  interaction: {
    part: "saveBtn",
    role: "button",
    cases: [
      {
        name: "clicking save focuses the button",
        action: { kind: "click", part: "saveBtn" },
        expect: { kind: "focused", part: "saveBtn", value: true }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking save reports it",
        action: { kind: "click", part: "saveBtn" },
        expect: { kind: "callback", prop: "onsave", args: [{ type: "click" }] }
      },
      {
        name: "clicking cancel reports it",
        action: { kind: "click", part: "cancelBtn" },
        expect: { kind: "callback", prop: "oncancel", args: [{ type: "click" }] }
      },
      {
        name: "disabled actions stay silent",
        props: { disabled: true },
        action: { kind: "click", part: "saveBtn" },
        expect: { kind: "no-callback", prop: "onsave" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [
      { part: "saveBtn", fill: "--inlineeditactions-save-default-surface", stroke: "--inlineeditactions-save-default-border" },
      { part: "cancelBtn", fill: "--inlineeditactions-cancel-default-surface", stroke: "--inlineeditactions-cancel-default-border" }
    ]
  }
};

// src/testing/contracts/input.ts
var noError = [
  { kind: "control", selector: ".canvas-toolbar-select", value: "password" },
  { kind: "control", selector: '.toolbar-check:has-text("Error") input', check: false }
];
var inputContract = {
  id: "input",
  origin: "system",
  view: {
    setup: [
      { kind: "control", selector: ".canvas-toolbar-select", value: "password" },
      { kind: "control", selector: '.toolbar-check:has-text("Error") input', check: true }
    ]
  },
  root: "root",
  parts: {
    root: ".input-field",
    field: ".input-control",
    label: ".input-label",
    icon: ".input-icon",
    toggleButton: ".input-icon-button",
    hint: ".input-hint",
    errorMsg: ".input-error",
    placeholder: { selector: ".input-control", pseudo: "::placeholder" }
  },
  properties: [
    {
      paints: {
        root: { rowGap: "--input-gap" },
        field: {
          borderRadius: "--input-radius",
          borderTopWidth: "--input-border-width",
          paddingTop: "--input-padding",
          backgroundColor: "--input-default-surface",
          borderTopColor: "--input-default-border",
          color: "--input-default-text",
          fontFamily: "--input-default-text-font-family",
          fontSize: "--input-default-text-font-size",
          fontWeight: "--input-default-text-font-weight",
          lineHeight: "--input-default-text-line-height"
        },
        icon: {
          color: "--input-default-icon",
          fontSize: "--input-default-icon-size"
        },
        label: {
          color: "--input-label",
          fontFamily: "--input-label-font-family",
          fontSize: "--input-label-font-size",
          fontWeight: "--input-label-font-weight",
          lineHeight: "--input-label-line-height"
        },
        hint: {
          color: "--input-hint",
          fontFamily: "--input-hint-font-family",
          fontSize: "--input-hint-font-size",
          fontWeight: "--input-hint-font-weight",
          lineHeight: "--input-hint-line-height"
        },
        placeholder: { color: "--input-default-placeholder" }
      }
    },
    // `assertProperties` (here) drives a controlled pixel probe, so a
    // unitless line-height round-trips fine. `assertPaintMap` (states, below)
    // reads the real, already-resolved value through `normalize()`, which
    // cannot recompute a unitless multiplier outside the field's own
    // font-size context, so these three stay out of `states`.
    {
      state: "focused",
      setup: noError,
      paints: { field: { lineHeight: "--input-focused-text-line-height" } }
    },
    {
      state: "disabled",
      setup: noError,
      paints: { field: { lineHeight: "--input-disabled-text-line-height" } }
    },
    {
      state: "error",
      paints: { errorMsg: { lineHeight: "--input-error-line-height" } }
    }
  ],
  states: [
    { state: "field" },
    { state: "default" },
    {
      state: "focused",
      forceClass: "force-focus",
      setup: noError,
      paints: {
        field: {
          backgroundColor: "--input-focused-surface",
          outlineColor: "--input-focused-border",
          outlineWidth: "--input-focused-border-width",
          color: "--input-focused-text",
          fontFamily: "--input-focused-text-font-family",
          fontSize: "--input-focused-text-font-size",
          fontWeight: "--input-focused-text-font-weight"
        },
        icon: { color: "--input-focused-icon", fontSize: "--input-focused-icon-size" }
      }
    },
    {
      state: "disabled",
      attributes: { field: { disabled: "" } },
      paints: {
        field: {
          backgroundColor: "--input-disabled-surface",
          borderTopColor: "--input-disabled-border",
          color: "--input-disabled-text",
          fontFamily: "--input-disabled-text-font-family",
          fontSize: "--input-disabled-text-font-size",
          fontWeight: "--input-disabled-text-font-weight"
        },
        icon: { color: "--input-disabled-icon", fontSize: "--input-disabled-icon-size" }
      }
    },
    { state: "label" },
    { state: "hint" },
    {
      state: "error",
      paints: {
        field: { outlineColor: "--input-error-border", outlineWidth: "--input-error-border-width" },
        errorMsg: {
          color: "--input-error",
          fontFamily: "--input-error-font-family",
          fontSize: "--input-error-font-size",
          fontWeight: "--input-error-font-weight"
        }
      }
    }
  ],
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--input-border-width",
        observe: { part: "field", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--input-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--input-border-width", "--input-radius", "--input-padding"],
    unchanged: ["--input-label-font-size", "--input-default-icon-size"],
    aliasedTo: {
      "--input-border-width": "--border-width-3",
      "--input-radius": "--radius-none"
    },
    observe: { part: "field", css: "borderTopWidth", variable: "--input-border-width" }
  },
  interaction: {
    part: "field",
    role: "textbox",
    cases: [
      {
        name: "typing writes into the field",
        action: { kind: "type", part: "field", text: "probe" },
        expect: { kind: "valueChanges", part: "field" }
      },
      {
        name: "clicking the reveal toggle presses it",
        action: { kind: "click", part: "toggleButton" },
        expect: { kind: "attribute", part: "toggleButton", name: "aria-pressed", value: "true" }
      },
      {
        name: "a disabled field refuses focus",
        state: "disabled",
        action: { kind: "click", part: "field" },
        expect: { kind: "focused", part: "field", value: false }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "typing reports every keystroke",
        props: { label: "Name" },
        action: { kind: "input", part: "field", value: "probe" },
        expect: { kind: "callback", prop: "oninput", args: ["probe"] }
      },
      {
        name: "an error marks the field invalid",
        props: { label: "Name", error: "Required" },
        expect: { kind: "attribute", part: "field", name: "aria-invalid", value: "true" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "field", fill: "--input-default-surface", stroke: "--input-default-border" }]
  }
};

// src/testing/contracts/menuselect.ts
function itemTextPaints(s, full) {
  const paints = {
    color: `--menuselect-${s}-text`,
    fontFamily: `--menuselect-${s}-text-font-family`,
    fontSize: `--menuselect-${s}-text-font-size`,
    fontWeight: `--menuselect-${s}-text-font-weight`
  };
  if (full) paints.lineHeight = `--menuselect-${s}-text-line-height`;
  return paints;
}
var behaviorItems = [
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" }
];
var menuSelectContract = {
  id: "menuselect",
  origin: "system",
  view: { state: "selected item" },
  root: "root",
  parts: {
    root: ".menuselect",
    item: ".menuselect-item",
    icon: ".menuselect-item .menuselect-icon",
    label: ".menuselect-item .menuselect-label",
    selectedItem: ".menuselect-item.selected",
    selectedIcon: ".menuselect-item.selected .menuselect-icon",
    indicator: ".menuselect-indicator",
    disabledItem: ".menuselect-item:disabled",
    disabledIcon: ".menuselect-item:disabled .menuselect-icon"
  },
  properties: [
    {
      state: "menu",
      paints: {
        root: {
          backgroundColor: "--menuselect-menu-surface",
          borderTopColor: "--menuselect-menu-border",
          borderTopWidth: "--menuselect-menu-border-width",
          borderRadius: "--menuselect-menu-radius",
          boxShadow: "--menuselect-menu-shadow",
          rowGap: "--menuselect-menu-gap",
          paddingTop: "--menuselect-menu-padding"
        },
        item: {
          borderRadius: "--menuselect-item-radius",
          paddingTop: "--menuselect-item-padding"
        }
      }
    },
    { state: "default item", paints: { item: itemTextPaints("default", true) } },
    { state: "hover item", paints: { item: itemTextPaints("hover", true) } },
    { state: "selected item", paints: { selectedItem: itemTextPaints("selected", true) } },
    { state: "disabled item", paints: { disabledItem: itemTextPaints("disabled", true) } }
  ],
  states: [
    { state: "menu" },
    {
      state: "default item",
      paints: {
        item: { backgroundColor: "--menuselect-default-surface", ...itemTextPaints("default", false) },
        icon: { color: "--menuselect-default-icon", fontSize: "--menuselect-default-icon-size" }
      }
    },
    {
      state: "hover item",
      paints: {
        item: { backgroundColor: "--menuselect-hover-surface", ...itemTextPaints("hover", false) },
        icon: { color: "--menuselect-hover-icon", fontSize: "--menuselect-hover-icon-size" }
      }
    },
    {
      state: "selected item",
      paints: {
        selectedItem: { backgroundColor: "--menuselect-selected-surface", ...itemTextPaints("selected", false) },
        selectedIcon: { color: "--menuselect-selected-icon", fontSize: "--menuselect-selected-icon-size" },
        indicator: { color: "--menuselect-selected-indicator" }
      }
    },
    {
      state: "disabled item",
      attributes: { disabledItem: { disabled: "" } },
      paints: {
        disabledItem: { backgroundColor: "--menuselect-disabled-surface", ...itemTextPaints("disabled", false) },
        disabledIcon: { color: "--menuselect-disabled-icon", fontSize: "--menuselect-disabled-icon-size" }
      }
    }
  ],
  uncovered: {
    "--menuselect-hover-tint": "consumed inside a background-image tint wash, never appearing verbatim in a computed style",
    "--menuselect-hover-tint-enabled": "the gate for the tint wash above, same limitation"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        state: "menu",
        variable: "--menuselect-menu-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--menuselect-menu-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--menuselect-menu-border-width", "--menuselect-menu-radius", "--menuselect-item-padding"],
    unchanged: ["--menuselect-default-icon-size", "--menuselect-default-text-font-size"],
    aliasedTo: {
      "--menuselect-menu-border-width": "--border-width-3",
      "--menuselect-menu-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--menuselect-menu-border-width" }
  },
  interaction: {
    part: "item",
    role: "option",
    cases: [
      {
        name: "clicking an item selects it",
        action: { kind: "click", part: "item" },
        expect: { kind: "attribute", part: "item", name: "aria-selected", value: "true" }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking an item asks for its value",
        props: { items: behaviorItems, value: "weekly" },
        action: { kind: "click", part: "item" },
        expect: { kind: "callback", prop: "onchange", args: ["daily"] }
      },
      {
        name: "value drives the selected item",
        props: { items: behaviorItems, value: "daily" },
        expect: { kind: "attribute", part: "item", name: "aria-selected", value: "true" }
      },
      {
        name: "a disabled item stays silent",
        props: { items: [{ ...behaviorItems[0], disabled: true }, behaviorItems[1]], value: "weekly" },
        action: { kind: "click", part: "item" },
        expect: { kind: "no-callback", prop: "onchange" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--menuselect-menu-surface", stroke: "--menuselect-menu-border" }]
  }
};

// src/testing/contracts/notification.ts
var variants6 = ["info", "success", "warning", "danger"];
function paintsFor2(v) {
  return {
    root: {
      borderTopColor: `--notification-${v}-border`,
      borderTopWidth: `--notification-${v}-border-width`,
      borderRadius: `--notification-${v}-radius`,
      color: `--notification-${v}-text`,
      fontFamily: `--notification-${v}-text-font-family`,
      fontSize: `--notification-${v}-text-font-size`,
      fontWeight: `--notification-${v}-text-font-weight`,
      lineHeight: `--notification-${v}-text-line-height`
    },
    header: {
      backgroundColor: `--notification-${v}-surface`,
      paddingTop: `--notification-${v}-padding`
    },
    icon: {
      color: `--notification-${v}-icon`,
      fontSize: `--notification-${v}-icon-size`
    },
    title: {
      color: `--notification-${v}-title`,
      fontFamily: `--notification-${v}-title-font-family`,
      fontSize: `--notification-${v}-title-font-size`,
      fontWeight: `--notification-${v}-title-font-weight`,
      lineHeight: `--notification-${v}-title-line-height`
    },
    actionBackdrop: { backgroundColor: `--notification-${v}-action-surface` }
  };
}
var notificationContract = {
  id: "notification",
  origin: "system",
  view: {
    variant: "Info",
    setup: [
      { kind: "control", selector: '.toolbar-check:has-text("Header button") input', check: true },
      { kind: "control", selector: '.toolbar-check:has-text("Dismissible") input', check: true }
    ]
  },
  root: "root",
  parts: {
    root: ".notification",
    header: ".notification-header",
    icon: ".notification-header i",
    title: ".notification-title",
    actionBackdrop: ".action-button-backdrop",
    actionButton: ".action-button-backdrop button",
    closeButton: ".notification-close"
  },
  properties: variants6.map((v) => ({ variant: v.charAt(0).toUpperCase() + v.slice(1), paints: paintsFor2(v) })),
  states: [{ state: "base" }, { state: "colors" }],
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--notification-info-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--notification-info-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--notification-info-border-width", "--notification-info-radius", "--notification-info-padding"],
    unchanged: ["--notification-info-icon-size"],
    aliasedTo: {
      "--notification-info-border-width": "--border-width-3",
      "--notification-info-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--notification-info-border-width" }
  },
  interaction: {
    part: "actionButton",
    role: "button",
    cases: [
      {
        name: "clicking the header action focuses it",
        action: { kind: "click", part: "actionButton" },
        expect: { kind: "focused", part: "actionButton", value: true }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking dismiss reports it",
        props: { title: "Saved", description: "Your changes are live.", dismissible: true },
        action: { kind: "click", part: "closeButton" },
        expect: { kind: "callback", prop: "ondismiss", args: [] }
      },
      {
        name: "title drives the heading",
        props: { title: "Saved", description: "Your changes are live." },
        expect: { kind: "text", part: "title", value: "Saved" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [
      { part: "root", stroke: "--notification-info-border" },
      { part: "header", fill: "--notification-info-surface" }
    ]
  }
};

// src/testing/contracts/panel.ts
var panelContract = {
  id: "panel",
  origin: "system",
  root: "root",
  parts: {
    root: ".panel"
  },
  properties: [
    {
      paints: {
        root: {
          borderTopColor: "--panel-frame-border",
          borderTopWidth: "--panel-frame-border-width",
          borderRadius: "--panel-frame-radius",
          backgroundImage: "--panel-stage-surface",
          paddingTop: "--panel-stage-padding",
          paddingLeft: "--panel-stage-inline-padding",
          columnGap: "--panel-stage-gap"
        }
      }
    }
  ],
  states: {
    applicable: false,
    reason: "the editor renders one token group (default) with no state strip"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--panel-frame-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      },
      {
        shape: "gradient",
        variable: "--panel-stage-surface",
        observe: { part: "root", css: "backgroundColor" }
      }
    ],
    resetVariable: "--panel-frame-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--panel-frame-border-width", "--panel-frame-radius", "--panel-stage-inline-padding", "--panel-stage-padding"],
    unchanged: ["--panel-stage-gap"],
    aliasedTo: {
      "--panel-frame-border-width": "--border-width-3",
      "--panel-frame-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--panel-frame-border-width" }
  },
  interaction: {
    applicable: false,
    reason: "a framed container carries no interactive role"
  },
  behavior: {
    applicable: false,
    reason: "a panel declares no callback prop; its content arrives as a snippet"
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--panel-stage-surface", stroke: "--panel-frame-border" }]
  }
};

// src/testing/contracts/progressbar.ts
var progressBarContract = {
  id: "progressbar",
  origin: "system",
  root: "root",
  parts: {
    root: ".progress",
    track: ".progress-track",
    fill: ".progress-fill",
    label: ".progress-label > span:not(.progress-value)",
    value: ".progress-value"
  },
  properties: [
    {
      paints: {
        root: { rowGap: "--progressbar-label-gap" },
        track: {
          backgroundColor: "--progressbar-track-surface",
          borderTopColor: "--progressbar-track-border",
          borderTopWidth: "--progressbar-track-border-width",
          borderRadius: "--progressbar-radius",
          height: "--progressbar-track-height"
        },
        fill: { backgroundColor: "--progressbar-fill" },
        label: {
          color: "--progressbar-label",
          fontFamily: "--progressbar-label-font-family",
          fontSize: "--progressbar-label-font-size",
          fontWeight: "--progressbar-label-font-weight",
          lineHeight: "--progressbar-label-line-height"
        },
        value: {
          color: "--progressbar-value",
          fontFamily: "--progressbar-value-font-family",
          fontSize: "--progressbar-value-font-size",
          fontWeight: "--progressbar-value-font-weight",
          lineHeight: "--progressbar-value-line-height"
        }
      }
    }
  ],
  states: {
    applicable: false,
    reason: "the editor renders one token group (default) with no state strip"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--progressbar-track-border-width",
        observe: { part: "track", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--progressbar-track-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--progressbar-radius", "--progressbar-track-border-width"],
    unchanged: ["--progressbar-track-height"],
    aliasedTo: {
      "--progressbar-radius": "--radius-none",
      "--progressbar-track-border-width": "--border-width-3"
    },
    observe: { part: "track", css: "borderTopWidth", variable: "--progressbar-track-border-width" }
  },
  interaction: {
    applicable: false,
    reason: "a progress readout carries no interactive role"
  },
  behavior: {
    cases: [
      {
        name: "value drives the readout",
        props: { label: "Upload", value: 60 },
        expect: { kind: "text", part: "value", value: "60%" }
      },
      {
        name: "a value past the end clamps",
        props: { label: "Upload", value: 140 },
        expect: { kind: "text", part: "value", value: "100%" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "track", fill: "--progressbar-track-surface", stroke: "--progressbar-track-border" }]
  }
};

// src/testing/contracts/radiobutton.ts
function statePaints4(s, full) {
  const dotFill = { backgroundColor: `--radiobutton-${s}-dot-fill` };
  if (full) dotFill.width = `--radiobutton-${s}-dot-size`;
  const label = {
    color: `--radiobutton-${s}-label`,
    fontFamily: `--radiobutton-${s}-label-font-family`,
    fontSize: `--radiobutton-${s}-label-font-size`,
    fontWeight: `--radiobutton-${s}-label-font-weight`
  };
  if (full) label.lineHeight = `--radiobutton-${s}-label-line-height`;
  return {
    dot: {
      borderTopColor: `--radiobutton-${s}-dot-border-color`,
      borderTopWidth: `--radiobutton-${s}-dot-border-width`
    },
    dotFill,
    label
  };
}
var radioButtonContract = {
  id: "radiobutton",
  origin: "system",
  root: "root",
  parts: {
    root: ".radio-button",
    dot: ".radio-dot",
    dotFill: { selector: ".radio-dot-fill" },
    label: ".radio-label"
  },
  properties: [
    { paints: statePaints4("default", true) },
    { state: "hover", paints: statePaints4("hover", true) },
    { state: "selected", paints: statePaints4("selected", true) }
  ],
  states: [
    { state: "default" },
    {
      state: "hover",
      forceClass: "force-hover",
      paints: statePaints4("hover", false)
    },
    {
      state: "selected",
      forceClass: "selected",
      paints: statePaints4("selected", false)
    }
  ],
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--radiobutton-default-dot-border-width",
        observe: { part: "dot", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--radiobutton-default-dot-border-width"
  },
  theme: {
    theme: "halloween",
    changed: [
      "--radiobutton-default-dot-border-width",
      "--radiobutton-hover-dot-border-width",
      "--radiobutton-selected-dot-border-width"
    ],
    unchanged: ["--radiobutton-default-label-font-size"],
    aliasedTo: {
      "--radiobutton-default-dot-border-width": "--border-width-4"
    },
    observe: { part: "dot", css: "borderTopWidth", variable: "--radiobutton-default-dot-border-width" }
  },
  interaction: {
    part: "root",
    role: "button",
    cases: [
      {
        name: "clicking a radio option focuses it",
        action: { kind: "click", part: "root" },
        expect: { kind: "focused", part: "root", value: true }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking an option reports it",
        props: { label: "Weekly" },
        action: { kind: "click", part: "root" },
        expect: { kind: "callback", prop: "onclick", args: [] }
      },
      {
        name: "label names the option",
        props: { label: "Weekly" },
        expect: { kind: "text", part: "label", value: "Weekly" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "dot", fill: "--radiobutton-default-dot-fill", stroke: "--radiobutton-default-dot-border-color" }]
  }
};

// src/testing/contracts/sectiondivider.ts
var showOptionalContent = [
  { kind: "control", selector: 'label.element-show-toggle:has-text("Show description") input', check: true },
  { kind: "control", selector: 'label.element-show-toggle:has-text("Show eyebrow") input', check: true }
];
function variantPaints(v) {
  return {
    root: {
      paddingTop: `--sectiondivider-${v}-padding`,
      borderRadius: `--sectiondivider-${v}-radius`,
      borderTopWidth: `--sectiondivider-${v}-border-width`,
      borderTopColor: `--sectiondivider-${v}-border`,
      boxShadow: `--sectiondivider-${v}-shadow`,
      backgroundImage: `--sectiondivider-${v}-surface`
    },
    titleRow: { paddingTop: `--sectiondivider-${v}-title-padding` },
    title: {
      color: `--sectiondivider-${v}-title`,
      fontFamily: `--sectiondivider-${v}-title-font-family`,
      fontSize: `--sectiondivider-${v}-title-font-size`,
      fontWeight: `--sectiondivider-${v}-title-font-weight`,
      lineHeight: `--sectiondivider-${v}-title-line-height`,
      letterSpacing: `--sectiondivider-${v}-title-letter-spacing`
    },
    descriptionRow: { paddingTop: `--sectiondivider-${v}-description-padding` },
    description: {
      color: `--sectiondivider-${v}-description`,
      fontFamily: `--sectiondivider-${v}-description-font-family`,
      fontSize: `--sectiondivider-${v}-description-font-size`,
      fontWeight: `--sectiondivider-${v}-description-font-weight`,
      lineHeight: `--sectiondivider-${v}-description-line-height`
    },
    eyebrow: {
      paddingTop: `--sectiondivider-${v}-eyebrow-padding`,
      color: `--sectiondivider-${v}-eyebrow`,
      fontFamily: `--sectiondivider-${v}-eyebrow-font-family`,
      fontSize: `--sectiondivider-${v}-eyebrow-font-size`,
      fontWeight: `--sectiondivider-${v}-eyebrow-font-weight`,
      letterSpacing: `--sectiondivider-${v}-eyebrow-letter-spacing`
    },
    hairline: {
      backgroundColor: `--sectiondivider-${v}-hairline-color`,
      height: `--sectiondivider-${v}-hairline-width`
    }
  };
}
var sectionDividerContract = {
  id: "sectiondivider",
  origin: "system",
  view: { variant: "Large", setup: showOptionalContent },
  root: "root",
  parts: {
    root: ".section-divider",
    titleRow: ".title-row",
    title: ".divider-label",
    descriptionRow: ".description-row",
    description: ".divider-description",
    eyebrow: ".divider-eyebrow",
    hairline: ".sd-hairline"
  },
  properties: [
    { variant: "Large", setup: showOptionalContent, paints: variantPaints("lg") },
    { variant: "Medium", setup: showOptionalContent, paints: variantPaints("md") },
    { variant: "Small", setup: showOptionalContent, paints: variantPaints("sm") }
  ],
  states: {
    applicable: false,
    reason: "each variant is one full preset with one state, so the editor renders no state strip"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--sectiondivider-lg-hairline-color",
        observe: { part: "hairline", css: "backgroundColor" }
      },
      {
        shape: "gradient",
        variable: "--sectiondivider-lg-surface",
        observe: { part: "root", css: "backgroundColor" }
      },
      {
        shape: "literal",
        control: '.sd-intrinsic-row:has(.property-label:text-is("alignment")) select',
        variable: "--sectiondivider-lg-align",
        observe: { part: "root", css: "textAlign" }
      }
    ],
    resetVariable: "--sectiondivider-lg-hairline-color"
  },
  theme: {
    theme: "halloween",
    changed: [
      "--sectiondivider-lg-radius",
      "--sectiondivider-lg-border-width",
      "--sectiondivider-lg-hairline-width",
      "--sectiondivider-lg-hairline-color"
    ],
    unchanged: [
      "--sectiondivider-lg-padding",
      "--sectiondivider-lg-shadow",
      "--sectiondivider-lg-title",
      "--sectiondivider-lg-border",
      "--sectiondivider-lg-title-font-size"
    ],
    aliasedTo: {
      "--sectiondivider-lg-radius": "--radius-none",
      "--sectiondivider-lg-border-width": "--border-width-3",
      "--sectiondivider-lg-hairline-width": "--border-width-3"
    },
    observe: { part: "root", css: "borderRadius", variable: "--sectiondivider-lg-radius" }
  },
  interaction: {
    applicable: false,
    reason: "a divider is a static banner: no interactive role, nothing focusable, no pointer behaviour"
  },
  behavior: {
    applicable: false,
    reason: "a divider declares no callback prop and answers no event"
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "hairline", fill: "--sectiondivider-lg-hairline-color" }]
  }
};

// src/testing/contracts/segmentedcontrol.ts
var behaviorSegments = [
  { value: "grid", label: "Grid" },
  { value: "list", label: "List" }
];
var segmentedControlContract = {
  id: "segmentedcontrol",
  origin: "system",
  view: { state: "selected option" },
  root: "root",
  parts: {
    root: ".segmented-control",
    segment: ".segment",
    icon: ".segment i",
    selectedSegment: ".segment.selected",
    selectedIcon: ".segment.selected i",
    hairline: ".segment-hairline"
  },
  properties: [
    {
      state: "control bar",
      paints: {
        root: {
          backgroundColor: "--segmentedcontrol-bar-surface",
          borderTopColor: "--segmentedcontrol-bar-border",
          borderTopWidth: "--segmentedcontrol-bar-border-width",
          borderRadius: "--segmentedcontrol-bar-radius",
          columnGap: "--segmentedcontrol-bar-gap",
          paddingTop: "--segmentedcontrol-bar-padding"
        },
        hairline: {
          backgroundColor: "--segmentedcontrol-hairline-color",
          width: "--segmentedcontrol-hairline-width",
          marginTop: "--segmentedcontrol-hairline-inset"
        }
      }
    },
    {
      state: "option base",
      paints: {
        segment: {
          paddingTop: "--segmentedcontrol-option-padding",
          columnGap: "--segmentedcontrol-option-gap",
          borderRadius: "--segmentedcontrol-selected-radius"
        },
        icon: { fontSize: "--segmentedcontrol-option-icon-size" }
      }
    },
    {
      state: "default option",
      paints: {
        segment: {
          lineHeight: "--segmentedcontrol-option-text-line-height"
        }
      }
    },
    {
      state: "selected option",
      paints: { selectedSegment: { lineHeight: "--segmentedcontrol-selected-text-line-height" } }
    },
    {
      state: "disabled option",
      paints: { segment: { lineHeight: "--segmentedcontrol-disabled-text-line-height" } }
    },
    {
      state: "hover option",
      paints: { segment: { lineHeight: "--segmentedcontrol-option-hover-text-line-height" } }
    },
    {
      setup: [{ kind: "control", selector: ".preview-actions select", value: "small" }],
      paints: {
        root: { borderRadius: "--segmentedcontrol-bar-small-radius", paddingTop: "--segmentedcontrol-bar-small-padding" },
        segment: {
          borderRadius: "--segmentedcontrol-selected-small-radius",
          paddingTop: "--segmentedcontrol-option-small-padding",
          columnGap: "--segmentedcontrol-option-small-gap",
          fontSize: "--segmentedcontrol-option-small-text-font-size",
          lineHeight: "--segmentedcontrol-option-small-text-line-height"
        },
        icon: { fontSize: "--segmentedcontrol-option-small-icon-size" },
        hairline: { width: "--segmentedcontrol-small-hairline-width", marginTop: "--segmentedcontrol-small-hairline-inset" }
      }
    }
  ],
  states: [
    { state: "control bar" },
    { state: "option base" },
    {
      state: "default option",
      paints: {
        icon: { color: "--segmentedcontrol-option-icon" },
        segment: {
          color: "--segmentedcontrol-option-text",
          fontFamily: "--segmentedcontrol-option-text-font-family",
          fontSize: "--segmentedcontrol-option-text-font-size",
          fontWeight: "--segmentedcontrol-option-text-font-weight"
        }
      }
    },
    {
      state: "selected option",
      paints: {
        selectedSegment: {
          backgroundColor: "--segmentedcontrol-selected-surface",
          outlineColor: "--segmentedcontrol-selected-border",
          outlineWidth: "--segmentedcontrol-selected-border-width",
          color: "--segmentedcontrol-selected-text",
          fontFamily: "--segmentedcontrol-selected-text-font-family",
          fontSize: "--segmentedcontrol-selected-text-font-size",
          fontWeight: "--segmentedcontrol-selected-text-font-weight"
        },
        selectedIcon: { color: "--segmentedcontrol-selected-icon" }
      }
    },
    {
      state: "hover option",
      paints: {
        segment: {
          backgroundColor: "--segmentedcontrol-option-hover-surface",
          color: "--segmentedcontrol-option-hover-text",
          fontFamily: "--segmentedcontrol-option-hover-text-font-family",
          fontSize: "--segmentedcontrol-option-hover-text-font-size",
          fontWeight: "--segmentedcontrol-option-hover-text-font-weight"
        },
        icon: { color: "--segmentedcontrol-option-hover-icon" }
      }
    },
    {
      state: "disabled option",
      attributes: { segment: { disabled: "" } },
      paints: {
        segment: {
          backgroundColor: "--segmentedcontrol-disabled-surface",
          color: "--segmentedcontrol-disabled-text",
          fontFamily: "--segmentedcontrol-disabled-text-font-family",
          fontSize: "--segmentedcontrol-disabled-text-font-size",
          fontWeight: "--segmentedcontrol-disabled-text-font-weight"
        },
        icon: { color: "--segmentedcontrol-disabled-icon" }
      }
    }
  ],
  uncovered: {
    "--segmentedcontrol-hover-tint": "consumed inside a background-image tint wash, never appearing verbatim in a computed style",
    "--segmentedcontrol-hover-tint-enabled": "the gate for the tint wash above, same limitation"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        state: "control bar",
        variable: "--segmentedcontrol-bar-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--segmentedcontrol-bar-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--segmentedcontrol-bar-border-width", "--segmentedcontrol-bar-radius", "--segmentedcontrol-option-padding"],
    unchanged: ["--segmentedcontrol-option-icon-size"],
    aliasedTo: {
      "--segmentedcontrol-bar-border-width": "--border-width-3",
      "--segmentedcontrol-bar-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--segmentedcontrol-bar-border-width" }
  },
  interaction: {
    part: "segment",
    role: "radio",
    cases: [
      {
        name: "clicking a segment checks it",
        action: { kind: "click", part: "segment" },
        expect: { kind: "attribute", part: "segment", name: "aria-checked", value: "true" }
      },
      {
        name: "a disabled control refuses focus",
        state: "disabled option",
        action: { kind: "click", part: "segment" },
        expect: { kind: "focused", part: "segment", value: false }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking a segment asks for its value",
        props: { segments: behaviorSegments, value: "list" },
        action: { kind: "click", part: "segment" },
        expect: { kind: "callback", prop: "onchange", args: ["grid"] }
      },
      {
        name: "value drives the checked segment",
        props: { segments: behaviorSegments, value: "grid" },
        expect: { kind: "attribute", part: "segment", name: "aria-checked", value: "true" }
      },
      {
        name: "a disabled control stays silent",
        props: { segments: behaviorSegments, value: "list", disabled: true },
        action: { kind: "click", part: "segment" },
        expect: { kind: "no-callback", prop: "onchange" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [
      { part: "root", fill: "--segmentedcontrol-bar-surface", stroke: "--segmentedcontrol-bar-border" },
      { part: "selectedSegment", fill: "--segmentedcontrol-selected-surface", stroke: "--segmentedcontrol-selected-border" }
    ]
  }
};

// src/testing/contracts/sidenavigation.ts
function sub(label) {
  return [{ kind: "control", selector: `.tabs-selectors.substrip .state-tab-btn:has-text("${label}")` }];
}
function titlePaints(s) {
  return {
    title: {
      backgroundColor: `--sidenavigation-title-${s}-surface`,
      borderTopColor: `--sidenavigation-title-${s}-border`,
      borderTopWidth: `--sidenavigation-title-${s}-border-width`,
      borderLeftColor: `--sidenavigation-title-${s}-indicator`,
      borderLeftWidth: `--sidenavigation-title-${s}-indicator-width`,
      paddingTop: `--sidenavigation-title-${s}-padding`
    },
    titleLinkBox: {
      color: `--sidenavigation-title-${s}-label`,
      fontFamily: `--sidenavigation-title-${s}-label-font-family`,
      fontSize: `--sidenavigation-title-${s}-label-font-size`,
      fontWeight: `--sidenavigation-title-${s}-label-font-weight`,
      lineHeight: `--sidenavigation-title-${s}-label-line-height`
    }
  };
}
function togglePaints(s) {
  return {
    toggle: {
      backgroundColor: `--sidenavigation-toggle-${s}-surface`,
      borderTopColor: `--sidenavigation-toggle-${s}-border`,
      borderTopWidth: `--sidenavigation-toggle-${s}-border-width`,
      borderRadius: `--sidenavigation-toggle-${s}-radius`,
      paddingTop: `--sidenavigation-toggle-${s}-padding`,
      color: `--sidenavigation-toggle-${s}-icon`
    },
    toggleIcon: { fontSize: `--sidenavigation-toggle-${s}-icon-size` }
  };
}
function sectionPaints(part, labelPart, s) {
  return {
    [part]: {
      backgroundColor: `--sidenavigation-section-${s}-surface`,
      borderLeftColor: `--sidenavigation-section-${s}-indicator`,
      borderLeftWidth: `--sidenavigation-section-${s}-indicator-width`
    },
    [labelPart]: {
      color: `--sidenavigation-section-${s}-text`,
      fontFamily: `--sidenavigation-section-${s}-text-font-family`,
      fontSize: `--sidenavigation-section-${s}-text-font-size`,
      fontWeight: `--sidenavigation-section-${s}-text-font-weight`,
      lineHeight: `--sidenavigation-section-${s}-text-line-height`
    }
  };
}
function itemPaints(part, s) {
  return {
    [part]: {
      backgroundColor: `--sidenavigation-item-${s}-surface`,
      borderLeftColor: `--sidenavigation-item-${s}-indicator`,
      borderLeftWidth: `--sidenavigation-item-${s}-indicator-width`,
      paddingTop: `--sidenavigation-item-${s}-padding`,
      color: `--sidenavigation-item-${s}-text`,
      fontFamily: `--sidenavigation-item-${s}-text-font-family`,
      fontSize: `--sidenavigation-item-${s}-text-font-size`,
      fontWeight: `--sidenavigation-item-${s}-text-font-weight`,
      lineHeight: `--sidenavigation-item-${s}-text-line-height`
    }
  };
}
function footerPaints(s) {
  return {
    footer: {
      backgroundColor: `--sidenavigation-footer-${s}-surface`,
      borderLeftColor: `--sidenavigation-footer-${s}-indicator`,
      borderLeftWidth: `--sidenavigation-footer-${s}-indicator-width`,
      paddingTop: `--sidenavigation-footer-${s}-padding`,
      columnGap: `--sidenavigation-footer-${s}-gap`,
      color: `--sidenavigation-footer-${s}-text`,
      fontFamily: `--sidenavigation-footer-${s}-text-font-family`,
      fontSize: `--sidenavigation-footer-${s}-text-font-size`,
      fontWeight: `--sidenavigation-footer-${s}-text-font-weight`,
      lineHeight: `--sidenavigation-footer-${s}-text-line-height`
    },
    footerIcon: {
      color: `--sidenavigation-footer-${s}-icon`,
      fontSize: `--sidenavigation-footer-${s}-icon-size`
    }
  };
}
var sideNavigationContract = {
  id: "sidenavigation",
  origin: "system",
  // Section has no currentPath-driven selected state (unlike Item, whose
  // demo path lands inside section-1): it lights up only through the force
  // mechanism behind the "Selected" sub-tab, so the inventory's one view has
  // to land there for `sectionSelected` to resolve at all.
  view: { state: "Section", setup: sub("Selected") },
  root: "root",
  parts: {
    root: ".sidenavigation",
    title: ".sn-title",
    titleLinkBox: ".sn-title-label",
    toggle: ".sn-toggle",
    toggleIcon: ".sn-toggle i",
    sectionWrap: ".sn-section",
    section: ".sn-section-header:not(.selected)",
    sectionLabel: ".sn-section-header:not(.selected) .section-label",
    sectionSelected: ".sn-section-header.selected",
    sectionLabelSelected: ".sn-section-header.selected .section-label",
    item: ".sn-item:not(.selected)",
    itemSelected: ".sn-item.selected",
    footer: ".sn-footer",
    footerIcon: ".sn-footer i"
  },
  properties: [
    {
      state: "Panel",
      setup: [],
      paints: {
        root: {
          backgroundColor: "--sidenavigation-panel-surface",
          borderRightColor: "--sidenavigation-panel-border",
          borderRightWidth: "--sidenavigation-panel-border-width",
          paddingTop: "--sidenavigation-panel-padding"
        },
        item: { paddingLeft: "--sidenavigation-panel-item-padding" },
        footer: { marginTop: "--sidenavigation-panel-footer-gap" },
        sectionWrap: { marginTop: "--sidenavigation-panel-section-gap" }
      }
    },
    {
      state: "Title Block",
      setup: [],
      paints: {
        title: { columnGap: "--sidenavigation-title-gap", borderRadius: "--sidenavigation-title-radius" },
        titleLinkBox: {
          backgroundColor: "--sidenavigation-title-label-surface",
          borderTopColor: "--sidenavigation-title-label-border",
          borderTopWidth: "--sidenavigation-title-label-border-width",
          borderRadius: "--sidenavigation-title-label-radius",
          paddingTop: "--sidenavigation-title-label-padding"
        }
      }
    },
    { state: "Title", setup: [], paints: titlePaints("default") },
    { state: "Title", setup: sub("Hover"), paints: titlePaints("hover") },
    { state: "Title", setup: sub("Selected"), paints: titlePaints("selected") },
    { state: "Toggle", setup: [], paints: togglePaints("default") },
    { state: "Toggle", setup: sub("Hover"), paints: togglePaints("hover") },
    { state: "Section", setup: [], paints: sectionPaints("section", "sectionLabel", "default") },
    { state: "Section", setup: sub("Hover"), paints: sectionPaints("section", "sectionLabel", "hover") },
    { state: "Section", setup: sub("Selected"), paints: sectionPaints("sectionSelected", "sectionLabelSelected", "selected") },
    { state: "Item", setup: [], paints: itemPaints("item", "default") },
    { state: "Item", setup: sub("Hover"), paints: itemPaints("item", "hover") },
    { state: "Item", setup: [], paints: itemPaints("itemSelected", "selected") },
    { state: "Footer", setup: [], paints: footerPaints("default") },
    { state: "Footer", setup: sub("Hover"), paints: footerPaints("hover") },
    { state: "Footer", setup: sub("Selected"), paints: footerPaints("selected") }
  ],
  states: [
    { state: "Panel", setup: [] },
    { state: "Title", setup: [] },
    { state: "Title Block", setup: [] },
    { state: "Toggle", setup: [] },
    { state: "Section", setup: [] },
    { state: "Item", setup: [] },
    { state: "Footer", setup: [] },
    { state: "Animation", setup: [] }
  ],
  uncovered: {
    "--sidenavigation-open-duration": "consumed by a width transition, no probe covers duration",
    "--sidenavigation-open-easing": "consumed by a width transition, no probe covers an easing curve",
    "--sidenavigation-close-duration": "consumed by a width transition, no probe covers duration",
    "--sidenavigation-close-easing": "consumed by a width transition, no probe covers an easing curve",
    "--sidenavigation-hover-tint": "consumed inside a background-image tint wash, never appearing verbatim in a computed style",
    "--sidenavigation-hover-tint-enabled": "the gate for the tint wash above, same limitation"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        state: "Panel",
        setup: [],
        variable: "--sidenavigation-panel-border-width",
        observe: { part: "root", css: "borderRightWidth" }
      }
    ],
    resetVariable: "--sidenavigation-panel-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--sidenavigation-panel-border-width", "--sidenavigation-title-default-border-width"],
    unchanged: ["--sidenavigation-toggle-default-icon-size"],
    aliasedTo: {
      "--sidenavigation-panel-border-width": "--border-width-3",
      "--sidenavigation-title-default-border-width": "--border-width-3"
    },
    observe: { part: "root", css: "borderRightWidth", variable: "--sidenavigation-panel-border-width" }
  },
  interaction: {
    part: "toggle",
    role: "button",
    cases: [
      {
        name: "clicking the toggle collapses the rail",
        action: { kind: "click", part: "toggle" },
        expect: { kind: "attribute", part: "toggle", name: "aria-expanded", value: "false" }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking the rail toggle reports it",
        props: { title: "Docs" },
        action: { kind: "click", part: "toggle" },
        expect: { kind: "callback", prop: "ontoggle", args: [] }
      },
      {
        name: "open drives the toggle",
        props: { title: "Docs", open: false },
        expect: { kind: "attribute", part: "toggle", name: "aria-expanded", value: "false" }
      },
      {
        name: "clicking leaves the rail where the prop put it",
        props: { title: "Docs", open: true },
        action: { kind: "click", part: "toggle" },
        expect: { kind: "attribute", part: "toggle", name: "aria-expanded", value: "true" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--sidenavigation-panel-surface", stroke: "--sidenavigation-panel-border" }]
  }
};

// src/testing/contracts/slider.ts
function variantPaints2(v) {
  return {
    track: {
      backgroundColor: `--slider-${v}-track-surface`,
      borderTopColor: `--slider-${v}-track-border`,
      borderTopWidth: `--slider-${v}-track-border-width`,
      borderRadius: `--slider-${v}-track-radius`,
      height: `--slider-${v}-track-height`
    },
    fill: { backgroundColor: `--slider-${v}-fill` },
    thumb: {
      backgroundColor: `--slider-${v}-thumb-surface`,
      borderTopColor: `--slider-${v}-thumb-border`,
      borderTopWidth: `--slider-${v}-thumb-border-width`,
      borderRadius: `--slider-${v}-thumb-radius`,
      width: `--slider-${v}-thumb-size`,
      boxShadow: `--slider-${v}-thumb-shadow`
    }
  };
}
function variantStates(v, variant) {
  return [
    {
      variant,
      state: "default",
      attributes: { input: { disabled: null } },
      paints: { thumb: { backgroundColor: `--slider-${v}-thumb-surface` } }
    },
    {
      variant,
      state: "hover",
      forceClass: "force-hover",
      paints: {
        thumb: {
          backgroundColor: `--slider-${v}-hover-thumb-surface`,
          borderTopColor: `--slider-${v}-hover-thumb-border`
        }
      }
    },
    {
      variant,
      state: "disabled",
      attributes: { input: { disabled: "" } },
      paints: {
        track: { backgroundColor: `--slider-${v}-disabled-track-surface` },
        fill: { backgroundColor: `--slider-${v}-disabled-fill` },
        thumb: {
          backgroundColor: `--slider-${v}-disabled-thumb-surface`,
          borderTopColor: `--slider-${v}-disabled-thumb-border`
        }
      }
    }
  ];
}
var sliderContract = {
  id: "slider",
  origin: "system",
  view: { variant: "Single" },
  root: "root",
  parts: {
    root: ".slider",
    track: ".slider-track",
    fill: ".slider-fill",
    thumb: ".cap",
    input: "input.thumb",
    label: ".slider-label > span:not(.slider-value)",
    value: ".slider-value"
  },
  properties: [
    {
      variant: "Single",
      paints: {
        ...variantPaints2("single"),
        root: { rowGap: "--slider-label-gap" },
        label: {
          color: "--slider-label",
          fontFamily: "--slider-label-font-family",
          fontSize: "--slider-label-font-size",
          fontWeight: "--slider-label-font-weight",
          lineHeight: "--slider-label-line-height"
        },
        value: {
          color: "--slider-value",
          fontFamily: "--slider-value-font-family",
          fontSize: "--slider-value-font-size",
          fontWeight: "--slider-value-font-weight",
          lineHeight: "--slider-value-line-height"
        }
      }
    },
    { variant: "Range", paints: variantPaints2("range") }
  ],
  states: [
    ...variantStates("single", "Single"),
    ...variantStates("range", "Range")
  ],
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--slider-single-track-surface",
        observe: { part: "track", css: "backgroundColor" }
      },
      {
        shape: "opacity",
        variable: "--slider-single-fill",
        observe: { part: "fill", css: "backgroundColor" }
      }
    ],
    resetVariable: "--slider-single-track-surface"
  },
  theme: {
    theme: "ocean",
    changed: [
      "--slider-single-track-surface",
      "--slider-single-fill",
      "--slider-single-thumb-surface"
    ],
    unchanged: [
      "--slider-single-track-height",
      "--slider-single-track-radius",
      "--slider-single-thumb-size",
      "--slider-single-track-border-width"
    ],
    aliasedTo: {
      "--slider-single-track-surface": "--surface-neutral-lowest",
      "--slider-single-fill": "--surface-brand-high"
    },
    observe: { part: "track", css: "backgroundColor", variable: "--slider-single-track-surface" }
  },
  interaction: {
    part: "input",
    role: "slider",
    cases: [
      {
        name: "arrow right raises the value",
        action: { kind: "press", part: "input", key: "ArrowRight" },
        expect: { kind: "valueMoves", part: "input", direction: "up" }
      },
      {
        name: "arrow left lowers the value",
        action: { kind: "press", part: "input", key: "ArrowLeft" },
        expect: { kind: "valueMoves", part: "input", direction: "down" }
      },
      {
        name: "Home takes the value to the floor",
        action: { kind: "press", part: "input", key: "Home" },
        expect: { kind: "valueBecomes", part: "input", value: "0" }
      },
      {
        name: "dragging the thumb along the track raises the value",
        action: { kind: "dragTo", part: "thumb", along: "track", fraction: 0.85 },
        expect: { kind: "valueMoves", part: "input", direction: "up" }
      },
      {
        name: "taking hold of the thumb focuses the slider",
        action: { kind: "dragTo", part: "thumb", along: "track", fraction: 0.5 },
        expect: { kind: "focused", part: "input", value: true }
      },
      {
        name: "a disabled slider ignores the arrow keys",
        state: "disabled",
        action: { kind: "press", part: "input", key: "ArrowRight" },
        expect: { kind: "valueHolds", part: "input" }
      },
      {
        name: "a disabled slider refuses focus",
        state: "disabled",
        action: { kind: "dragTo", part: "thumb", along: "track", fraction: 0.5 },
        expect: { kind: "focused", part: "input", value: false }
      }
    ]
  },
  behavior: {
    // No disabled case: a range reports through `input`, and a dispatched
    // input event reaches a disabled control, so the case would assert the
    // environment rather than the slider.
    cases: [
      {
        name: "moving the thumb reports the value",
        props: { label: "Level", value: 30 },
        action: { kind: "input", part: "input", value: "70" },
        expect: { kind: "callback", prop: "onchange", args: [70] }
      },
      {
        name: "a range thumb reports both ends",
        props: { variant: "range", low: 25, high: 75 },
        action: { kind: "input", part: "input", value: "10" },
        expect: { kind: "callback", prop: "onrangechange", args: [10, 75] }
      },
      {
        name: "value drives the readout",
        props: { label: "Level", value: 30 },
        expect: { kind: "text", part: "value", value: "30" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [
      {
        part: "track",
        fill: "--slider-single-track-surface",
        stroke: "--slider-single-track-border"
      },
      { part: "fill", fill: "--slider-single-fill" }
    ]
  }
};

// src/testing/contracts/tabbar.ts
function tabPaints(part, iconPart, s, full) {
  const tab = {
    backgroundColor: `--tabbar-${s}-surface`,
    borderTopColor: `--tabbar-${s}-tab-border-color`,
    borderTopWidth: `--tabbar-${s}-tab-border-width`,
    borderBottomColor: `--tabbar-${s}-border`,
    borderBottomWidth: `--tabbar-${s}-indicator-width`,
    borderTopLeftRadius: `--tabbar-${s}-tab-top-radius`,
    borderBottomLeftRadius: `--tabbar-${s}-tab-bottom-radius`,
    paddingTop: `--tabbar-${s}-padding`,
    color: `--tabbar-${s}-text`,
    fontFamily: `--tabbar-${s}-text-font-family`,
    fontSize: `--tabbar-${s}-text-font-size`,
    fontWeight: `--tabbar-${s}-text-font-weight`
  };
  if (full) tab.lineHeight = `--tabbar-${s}-text-line-height`;
  return {
    [part]: tab,
    [iconPart]: { fontSize: `--tabbar-${s}-icon-size` }
  };
}
var behaviorTabs = [
  { id: "one", label: "One" },
  { id: "two", label: "Two" }
];
var tabBarContract = {
  id: "tabbar",
  origin: "system",
  root: "root",
  parts: {
    root: ".tab-bar",
    tab: ".tab:not(.selected):not(:disabled)",
    icon: ".tab:not(.selected):not(:disabled) i",
    tabSelected: ".tab.selected",
    selectedIcon: ".tab.selected i",
    disabledTab: ".tab:disabled",
    disabledIcon: ".tab:disabled i",
    // Position-stable: clicking `tab` (".tab:not(.selected)") makes that very
    // tab selected, which would invalidate that selector out from under a
    // focus check re-resolved after the click.
    secondTab: ".tab:nth-of-type(2)"
  },
  properties: [
    {
      state: "bar",
      paints: {
        root: {
          borderBottomColor: "--tabbar-bar-hairline-color",
          borderBottomWidth: "--tabbar-bar-hairline-width",
          marginTop: "--tabbar-bar-top-margin",
          paddingBottom: "--tabbar-bar-bottom-padding",
          marginBottom: "--tabbar-bar-bottom-margin",
          columnGap: "--tabbar-tab-gap"
        }
      }
    },
    { state: "default tab", paints: tabPaints("tab", "icon", "default", true) },
    { state: "hover tab", paints: tabPaints("tab", "icon", "hover", true) },
    { state: "selected tab", paints: tabPaints("tabSelected", "selectedIcon", "selected", true) },
    { state: "disabled tab", paints: tabPaints("disabledTab", "disabledIcon", "disabled", true) }
  ],
  states: [
    { state: "bar" },
    { state: "default tab", paints: tabPaints("tab", "icon", "default", false) },
    { state: "hover tab", paints: tabPaints("tab", "icon", "hover", false) },
    { state: "selected tab", paints: tabPaints("tabSelected", "selectedIcon", "selected", false) },
    {
      state: "disabled tab",
      attributes: { disabledTab: { disabled: "" } },
      paints: tabPaints("disabledTab", "disabledIcon", "disabled", false)
    }
  ],
  uncovered: {
    "--tabbar-hover-tint": "consumed inside a background-image tint wash, never appearing verbatim in a computed style",
    "--tabbar-hover-tint-enabled": "the gate for the tint wash above, same limitation"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        state: "default tab",
        variable: "--tabbar-default-tab-border-width",
        observe: { part: "tab", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--tabbar-default-tab-border-width"
  },
  theme: {
    theme: "halloween",
    // The indicator width is the canary for re-migration replay: the tabbar
    // pair (2026-05-29-tabbar-indicator-thickness-to-per-state-width,
    // 2026-09-07-stroke-role-renames) rewrites it to --border-width-2 if a
    // reader migrates a theme-embedded config off a stamp of 0 instead of the
    // theme's componentSchemaVersion.
    changed: [
      "--tabbar-default-tab-border-width",
      "--tabbar-default-padding",
      "--tabbar-default-indicator-width"
    ],
    unchanged: ["--tabbar-default-icon-size"],
    aliasedTo: {
      "--tabbar-default-tab-border-width": "--border-width-2",
      "--tabbar-default-indicator-width": "--border-width-4"
    },
    observe: { part: "tab", css: "borderTopWidth", variable: "--tabbar-default-tab-border-width" }
  },
  interaction: {
    part: "secondTab",
    role: "button",
    cases: [
      {
        name: "clicking a tab focuses it",
        action: { kind: "click", part: "secondTab" },
        expect: { kind: "focused", part: "secondTab", value: true }
      },
      {
        name: "a disabled tab refuses focus",
        state: "disabled tab",
        action: { kind: "click", part: "disabledTab" },
        expect: { kind: "focused", part: "disabledTab", value: false }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking a tab asks for it",
        props: { tabs: behaviorTabs, value: "one" },
        action: { kind: "click", part: "secondTab" },
        expect: { kind: "callback", prop: "onchange", args: ["two"] }
      },
      {
        name: "clicking leaves the selection where the prop put it",
        props: { tabs: behaviorTabs, value: "one" },
        action: { kind: "click", part: "secondTab" },
        expect: { kind: "text", part: "tabSelected", value: "One" }
      },
      {
        name: "a disabled tab stays silent",
        props: { tabs: [behaviorTabs[0], { ...behaviorTabs[1], disabled: true }], value: "one" },
        action: { kind: "click", part: "secondTab" },
        expect: { kind: "no-callback", prop: "onchange" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [
      { part: "tab", fill: "--tabbar-default-surface", stroke: "--tabbar-default-border" },
      { part: "tabSelected", fill: "--tabbar-selected-surface", stroke: "--tabbar-selected-border" }
    ]
  }
};

// src/testing/contracts/table.ts
var tableContract = {
  id: "table",
  origin: "system",
  root: "wrapper",
  parts: {
    wrapper: ".table-wrapper",
    th: ".table-wrapper th",
    td: ".table-wrapper td"
  },
  properties: [
    {
      paints: {
        wrapper: {
          backgroundColor: "--table-default-surface",
          borderTopColor: "--table-default-border",
          borderTopWidth: "--table-default-border-width",
          borderRadius: "--table-default-radius",
          boxShadow: "--table-default-shadow"
        },
        th: {
          backgroundColor: "--table-default-header-surface",
          color: "--table-default-header-text",
          fontFamily: "--table-default-header-font-family",
          fontSize: "--table-default-header-font-size",
          fontWeight: "--table-default-header-font-weight",
          lineHeight: "--table-default-header-line-height",
          borderBottomColor: "--table-default-header-hairline-color",
          borderBottomWidth: "--table-default-header-hairline-width",
          paddingTop: "--table-default-header-padding",
          borderRightColor: "--table-default-column-hairline-color",
          borderRightWidth: "--table-default-column-hairline-width"
        },
        td: {
          backgroundColor: "--table-default-row-surface",
          color: "--table-default-cell-text",
          fontFamily: "--table-default-cell-font-family",
          fontSize: "--table-default-cell-font-size",
          fontWeight: "--table-default-cell-font-weight",
          lineHeight: "--table-default-cell-line-height",
          paddingTop: "--table-default-cell-padding",
          borderBottomColor: "--table-default-row-hairline-color",
          borderBottomWidth: "--table-default-row-hairline-width"
        }
      }
    }
  ],
  states: [
    { state: "wrapper" },
    { state: "header" },
    { state: "cell" },
    { state: "row" },
    { state: "column" }
  ],
  uncovered: {
    "--table-default-row-stripe-surface": "layered as a background-image on every even row; a probe cannot pin a single verbatim computed value to that selector"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--table-default-border-width",
        observe: { part: "wrapper", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--table-default-border-width"
  },
  theme: {
    theme: "halloween",
    changed: [
      "--table-default-border-width",
      "--table-default-radius",
      "--table-default-header-hairline-width",
      "--table-default-header-padding"
    ],
    unchanged: ["--table-default-header-font-size"],
    aliasedTo: {
      "--table-default-border-width": "--border-width-4",
      "--table-default-radius": "--radius-none"
    },
    observe: { part: "wrapper", css: "borderTopWidth", variable: "--table-default-border-width" }
  },
  interaction: {
    applicable: false,
    reason: "a styled table wrapper carries no interactive role"
  },
  behavior: {
    applicable: false,
    reason: "a table wrapper declares no callback prop; its rows arrive as a snippet"
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "wrapper", fill: "--table-default-surface", stroke: "--table-default-border" }]
  }
};

// src/testing/contracts/toggle.ts
var defaultPaints = {
  root: { columnGap: "--toggle-gap" },
  track: {
    backgroundColor: "--toggle-track-surface",
    borderTopColor: "--toggle-track-border",
    borderTopWidth: "--toggle-track-border-width",
    borderRadius: "--toggle-track-radius"
  },
  thumb: {
    backgroundColor: "--toggle-thumb-surface",
    borderTopColor: "--toggle-thumb-border",
    width: "--toggle-thumb-size",
    left: "--toggle-track-padding"
  },
  label: {
    color: "--toggle-label",
    fontFamily: "--toggle-label-font-family",
    fontSize: "--toggle-label-font-size",
    fontWeight: "--toggle-label-font-weight"
  }
};
var toggleContract = {
  id: "toggle",
  origin: "system",
  root: "root",
  parts: {
    root: ".toggle",
    track: ".track",
    thumb: ".thumb",
    label: ".label"
  },
  properties: [{ paints: defaultPaints }],
  states: [
    {
      state: "default",
      attributes: { root: { "aria-checked": "false" } }
    },
    {
      state: "hover",
      forceClass: "force-hover",
      paints: {
        track: { backgroundColor: "--toggle-hover-track-surface" },
        thumb: { backgroundColor: "--toggle-hover-thumb-surface" }
      }
    },
    {
      state: "on",
      attributes: { root: { "aria-checked": "true" } },
      paints: {
        track: { backgroundColor: "--toggle-on-track-surface", borderTopColor: "--toggle-on-track-border" },
        thumb: { backgroundColor: "--toggle-on-thumb-surface", borderTopColor: "--toggle-on-thumb-border" }
      }
    },
    {
      state: "on hover",
      forceClass: "force-hover",
      attributes: { root: { "aria-checked": "true" } },
      paints: {
        track: { backgroundColor: "--toggle-on-hover-track-surface" },
        thumb: { backgroundColor: "--toggle-on-hover-thumb-surface" }
      }
    },
    {
      state: "disabled",
      attributes: { root: { disabled: "" } },
      paints: {
        track: { backgroundColor: "--toggle-disabled-track-surface" },
        thumb: { backgroundColor: "--toggle-disabled-thumb-surface" },
        label: { color: "--toggle-disabled-label" }
      }
    }
  ],
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--toggle-track-border-width",
        observe: { part: "track", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--toggle-track-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--toggle-track-border-width", "--toggle-track-radius"],
    unchanged: ["--toggle-thumb-size", "--toggle-gap"],
    aliasedTo: {
      "--toggle-track-border-width": "--border-width-3",
      "--toggle-track-radius": "--radius-none"
    },
    observe: { part: "track", css: "borderTopWidth", variable: "--toggle-track-border-width" }
  },
  interaction: {
    part: "root",
    role: "switch",
    // No activation case: Toggle.svelte is controlled (`onclick` only calls
    // `onchange?.(!checked)`, it never flips `checked` itself), and
    // ToggleEditor.svelte's preview drives `checked` off the state tab
    // without wiring `onchange` back to it. Clicking the real control in this
    // demo has no observable effect on `aria-checked`, so an activation case
    // would assert a no-op rather than the switch's behavior.
    cases: [
      {
        name: "clicking a toggle focuses it",
        action: { kind: "click", part: "root" },
        expect: { kind: "focused", part: "root", value: true }
      },
      {
        name: "a disabled toggle refuses focus",
        state: "disabled",
        action: { kind: "click", part: "root" },
        expect: { kind: "focused", part: "root", value: false }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "clicking an off toggle asks for on",
        props: { checked: false },
        action: { kind: "click", part: "root" },
        expect: { kind: "callback", prop: "onchange", args: [true] }
      },
      {
        name: "clicking leaves the switch where the prop put it",
        props: { checked: false },
        action: { kind: "click", part: "root" },
        expect: { kind: "attribute", part: "root", name: "aria-checked", value: "false" }
      },
      {
        name: "clicking an on toggle asks for off",
        props: { checked: true },
        action: { kind: "click", part: "root" },
        expect: { kind: "callback", prop: "onchange", args: [false] }
      },
      {
        name: "checked drives aria-checked",
        props: { checked: true },
        expect: { kind: "attribute", part: "root", name: "aria-checked", value: "true" }
      },
      {
        name: "a disabled toggle stays silent",
        props: { checked: false, disabled: true },
        action: { kind: "click", part: "root" },
        expect: { kind: "no-callback", prop: "onchange" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "track", fill: "--toggle-track-surface", stroke: "--toggle-track-border" }]
  }
};

// src/testing/contracts/tooltip.ts
var tooltipContract = {
  id: "tooltip",
  origin: "system",
  root: "root",
  parts: {
    root: ".tooltip",
    arrow: { selector: ".tooltip", pseudo: "::after" }
  },
  properties: [
    {
      paints: {
        root: {
          backgroundColor: "--tooltip-surface",
          color: "--tooltip-text",
          borderTopColor: "--tooltip-border",
          borderTopWidth: "--tooltip-border-width",
          borderRadius: "--tooltip-radius",
          paddingTop: "--tooltip-padding",
          boxShadow: "--tooltip-shadow",
          fontFamily: "--tooltip-text-font-family",
          fontSize: "--tooltip-text-font-size",
          fontWeight: "--tooltip-text-font-weight",
          lineHeight: "--tooltip-text-line-height"
        },
        arrow: {
          borderRightColor: "--tooltip-border",
          borderRightWidth: "--tooltip-border-width"
        }
      }
    }
  ],
  states: {
    applicable: false,
    reason: "the editor renders one token group (tooltip) with no state strip"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--tooltip-border",
        observe: { part: "root", css: "borderTopColor" }
      }
    ],
    resetVariable: "--tooltip-border"
  },
  theme: {
    theme: "halloween",
    changed: ["--tooltip-border-width", "--tooltip-padding", "--tooltip-radius"],
    unchanged: ["--tooltip-text-font-size"],
    aliasedTo: {
      "--tooltip-border-width": "--border-width-3",
      "--tooltip-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--tooltip-border-width" }
  },
  interaction: {
    applicable: false,
    reason: "a hint carries no interactive role; visibility follows the trigger element's hover or focus, which this component does not own"
  },
  behavior: {
    cases: [
      {
        name: "text drives the hint",
        props: { text: "Copy to clipboard" },
        expect: { kind: "text", part: "root", value: "Copy to clipboard" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--tooltip-surface" }]
  }
};

// src/testing/contracts/videolightbox.ts
var videoLightboxContract = {
  id: "videolightbox",
  origin: "system",
  root: "root",
  // The editor renders an `inline` copy of the open lightbox beside the tile,
  // so the overlay and close button are measurable without opening a modal.
  parts: {
    root: ".videolightbox",
    trigger: ".videolightbox-trigger",
    badge: ".videolightbox-badge",
    badgeIcon: ".videolightbox-badge svg",
    overlay: ".videolightbox-modal.inline",
    closeButton: ".videolightbox-modal.inline .videolightbox-close",
    closeIcon: ".videolightbox-modal.inline .videolightbox-close svg"
  },
  properties: [
    {
      paints: {
        root: {
          backgroundColor: "--videolightbox-tile-surface",
          borderTopColor: "--videolightbox-tile-border",
          borderTopWidth: "--videolightbox-tile-border-width",
          borderRadius: "--videolightbox-tile-radius",
          boxShadow: "--videolightbox-tile-shadow"
        },
        overlay: {
          backgroundColor: "--videolightbox-scrim-surface",
          paddingTop: "--videolightbox-overlay-padding"
        },
        closeButton: {
          backgroundColor: "--videolightbox-chrome-surface",
          borderTopColor: "--videolightbox-chrome-border",
          borderTopWidth: "--videolightbox-chrome-border-width",
          borderRadius: "--videolightbox-chrome-radius",
          color: "--videolightbox-chrome-icon"
        },
        closeIcon: { stroke: "--videolightbox-chrome-icon" },
        badge: {
          backgroundColor: "--videolightbox-badge-default-surface",
          borderTopColor: "--videolightbox-badge-default-border",
          borderTopWidth: "--videolightbox-badge-default-border-width",
          width: "--videolightbox-badge-default-size",
          color: "--videolightbox-badge-default-icon"
        },
        badgeIcon: { width: "--videolightbox-badge-default-icon-size" }
      }
    },
    {
      state: "hover",
      paints: {
        badge: {
          backgroundColor: "--videolightbox-badge-hover-surface",
          borderTopColor: "--videolightbox-badge-hover-border",
          color: "--videolightbox-badge-hover-icon"
        }
      }
    },
    // The inline close button has no handler, so the click leaves the pointer
    // resting on it and its real :hover rule applies.
    {
      setup: [{ kind: "click", part: "closeButton" }],
      paints: { closeButton: { backgroundColor: "--videolightbox-chrome-hover-surface" } }
    }
  ],
  states: [{ state: "default" }, { state: "hover" }],
  uncovered: {
    "--videolightbox-overlay-duration": "consumed inside the opacity transition shorthand, never a standalone computed value",
    "--videolightbox-overlay-easing": "consumed inside the opacity transition shorthand, never a standalone computed value",
    "--videolightbox-badge-duration": "consumed inside the badge transition shorthand, never a standalone computed value",
    "--videolightbox-badge-easing": "consumed inside the badge transition shorthand, never a standalone computed value"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--videolightbox-tile-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--videolightbox-tile-border-width"
  },
  theme: {
    theme: "halloween",
    changed: [
      "--videolightbox-tile-border-width",
      "--videolightbox-tile-radius",
      "--videolightbox-chrome-border-width",
      "--videolightbox-chrome-radius"
    ],
    unchanged: ["--videolightbox-tile-shadow"],
    aliasedTo: {
      "--videolightbox-tile-border-width": "--border-width-2",
      "--videolightbox-tile-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--videolightbox-tile-border-width" }
  },
  interaction: {
    part: "trigger",
    role: "button",
    cases: [
      {
        name: "clicking the still opens the lightbox",
        action: { kind: "click", part: "trigger" },
        expect: { kind: "attribute", part: "trigger", name: "aria-expanded", value: "true" }
      }
    ]
  },
  behavior: {
    applicable: false,
    reason: "the lightbox declares no callback prop; opening portals a modal and plays media, which happy-dom cannot run"
  },
  sketch: {
    style: "pencil",
    parts: [
      { part: "root", fill: "--videolightbox-tile-surface", stroke: "--videolightbox-tile-border" }
    ]
  }
};

// src/testing/contracts/videoframe.ts
var videoFrameContract = {
  id: "videoframe",
  origin: "system",
  root: "root",
  parts: {
    root: ".videoframe-frame",
    clip: ".videoframe-clip",
    trigger: ".videoframe-trigger",
    badge: ".videoframe-badge",
    badgeIcon: ".videoframe-badge svg"
  },
  properties: [
    {
      paints: {
        root: {
          backgroundColor: "--videoframe-frame-surface",
          borderTopColor: "--videoframe-frame-border",
          borderTopWidth: "--videoframe-frame-border-width",
          borderRadius: "--videoframe-frame-radius"
        },
        clip: { backgroundColor: "--videoframe-clip-surface" },
        badge: {
          backgroundColor: "--videoframe-badge-default-surface",
          borderTopColor: "--videoframe-badge-default-border",
          borderTopWidth: "--videoframe-badge-default-border-width",
          width: "--videoframe-badge-default-size",
          color: "--videoframe-badge-default-icon"
        },
        badgeIcon: { width: "--videoframe-badge-default-icon-size" }
      }
    },
    {
      state: "hover",
      paints: {
        badge: {
          backgroundColor: "--videoframe-badge-hover-surface",
          borderTopColor: "--videoframe-badge-hover-border",
          color: "--videoframe-badge-hover-icon"
        }
      }
    }
  ],
  states: [{ state: "default" }, { state: "hover" }],
  uncovered: {
    "--videoframe-badge-duration": "consumed inside the badge transition shorthand, never a standalone computed value",
    "--videoframe-badge-easing": "consumed inside the badge transition shorthand, never a standalone computed value"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--videoframe-frame-border-width",
        observe: { part: "root", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--videoframe-frame-border-width"
  },
  theme: {
    theme: "halloween",
    changed: ["--videoframe-frame-border-width", "--videoframe-frame-radius"],
    unchanged: ["--videoframe-badge-default-size"],
    aliasedTo: {
      "--videoframe-frame-border-width": "--border-width-3",
      "--videoframe-frame-radius": "--radius-none"
    },
    observe: { part: "root", css: "borderTopWidth", variable: "--videoframe-frame-border-width" }
  },
  interaction: {
    part: "trigger",
    role: "button",
    cases: [
      {
        name: "clicking the poster starts the clip",
        action: { kind: "click", part: "trigger" },
        expect: { kind: "attribute", part: "root", name: "data-playing", value: "true" }
      }
    ]
  },
  behavior: {
    applicable: false,
    reason: "the frame declares no callback prop; playback is the browser's own media element"
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "root", fill: "--videoframe-frame-surface", stroke: "--videoframe-frame-border" }]
  }
};

// src/testing/contracts/slidepager.ts
var behaviorSlides = [
  { src: "a.webp", alt: "First slide" },
  { src: "b.webp", alt: "Second slide" },
  { src: "c.webp", alt: "Third slide" }
];
var slidePagerContract = {
  id: "slidepager",
  origin: "system",
  root: "root",
  // The editor renders an `inline` copy of the full-screen read beside the
  // pager, so the overlay and its close button are measurable in place.
  parts: {
    root: ".slidepager",
    frame: ".slidepager .slidepager-frame",
    stage: ".slidepager .slidepager-stage",
    bar: ".slidepager > .slidepager-bar",
    prevControl: '.slidepager > .slidepager-bar [data-nav="prev"]',
    nextControl: '.slidepager > .slidepager-bar [data-nav="next"]',
    controlIcon: '.slidepager > .slidepager-bar [data-nav="next"] svg',
    counter: ".slidepager > .slidepager-bar .slidepager-counter",
    overlay: ".slidepager-modal.inline",
    closeButton: ".slidepager-modal.inline .slidepager-close"
  },
  properties: [
    {
      paints: {
        frame: {
          backgroundColor: "--slidepager-frame-surface",
          borderTopColor: "--slidepager-frame-border",
          borderTopWidth: "--slidepager-frame-border-width",
          borderRadius: "--slidepager-frame-radius",
          boxShadow: "--slidepager-frame-shadow"
        },
        bar: { columnGap: "--slidepager-bar-gap", paddingTop: "--slidepager-bar-padding" },
        nextControl: {
          backgroundColor: "--slidepager-control-surface",
          borderTopColor: "--slidepager-control-border",
          borderTopWidth: "--slidepager-control-border-width",
          borderRadius: "--slidepager-control-radius",
          width: "--slidepager-control-size",
          color: "--slidepager-control-icon"
        },
        controlIcon: { width: "--slidepager-control-icon-size" },
        counter: {
          color: "--slidepager-counter-text",
          fontFamily: "--slidepager-counter-font-family",
          fontSize: "--slidepager-counter-font-size",
          fontWeight: "--slidepager-counter-font-weight",
          lineHeight: "--slidepager-counter-line-height",
          letterSpacing: "--slidepager-counter-letter-spacing"
        },
        overlay: {
          backgroundColor: "--slidepager-scrim-surface",
          paddingTop: "--slidepager-overlay-padding"
        },
        closeButton: { top: "--slidepager-close-margin" }
      }
    },
    // The inline close button has no handler, so the click leaves the pointer
    // resting on it and its real :hover rule applies.
    {
      setup: [{ kind: "click", part: "closeButton" }],
      paints: {
        closeButton: {
          backgroundColor: "--slidepager-control-hover-surface",
          borderTopColor: "--slidepager-control-hover-border",
          color: "--slidepager-control-hover-icon"
        }
      }
    },
    // The preview opens on the middle slide, so one click back lands on the
    // first and disables the control under the pointer.
    {
      setup: [{ kind: "click", part: "prevControl" }],
      paints: {
        prevControl: {
          backgroundColor: "--slidepager-control-disabled-surface",
          borderTopColor: "--slidepager-control-disabled-border",
          color: "--slidepager-control-disabled-icon"
        }
      }
    }
  ],
  states: [{ state: "default" }, { state: "hover" }, { state: "disabled" }],
  uncovered: {
    "--slidepager-overlay-duration": "consumed inside the opacity transition shorthand, never a standalone computed value",
    "--slidepager-overlay-easing": "consumed inside the opacity transition shorthand, never a standalone computed value"
  },
  persistence: {
    cases: [
      {
        shape: "token",
        variable: "--slidepager-frame-border-width",
        observe: { part: "frame", css: "borderTopWidth" }
      }
    ],
    resetVariable: "--slidepager-frame-border-width"
  },
  theme: {
    theme: "halloween",
    changed: [
      "--slidepager-frame-border-width",
      "--slidepager-frame-radius",
      "--slidepager-control-border-width",
      "--slidepager-control-radius"
    ],
    unchanged: ["--slidepager-control-size"],
    aliasedTo: {
      "--slidepager-frame-border-width": "--border-width-3",
      "--slidepager-frame-radius": "--radius-none"
    },
    observe: { part: "frame", css: "borderTopWidth", variable: "--slidepager-frame-border-width" }
  },
  interaction: {
    part: "stage",
    role: "button",
    cases: [
      {
        name: "the next chevron moves the frame to the next slide",
        action: { kind: "click", part: "nextControl" },
        expect: { kind: "attribute", part: "stage", name: "aria-label", value: "Open slide 3 full screen" }
      }
    ]
  },
  behavior: {
    cases: [
      {
        name: "the next chevron reports the slide it moved to",
        props: { slides: behaviorSlides, index: 0 },
        action: { kind: "click", part: "nextControl" },
        expect: { kind: "callback", prop: "onchange", args: [1] }
      },
      {
        name: "the previous chevron is silent on the first slide",
        props: { slides: behaviorSlides, index: 0 },
        action: { kind: "click", part: "prevControl" },
        expect: { kind: "no-callback", prop: "onchange" }
      },
      {
        name: "the counter names the slide index opens on",
        props: { slides: behaviorSlides, index: 2 },
        expect: { kind: "text", part: "counter", value: "3 / 3" }
      }
    ]
  },
  sketch: {
    style: "pencil",
    parts: [{ part: "frame", fill: "--slidepager-frame-surface", stroke: "--slidepager-frame-border" }]
  }
};

// src/testing/contracts/index.ts
var shippedContracts = [
  badgeContract,
  buttonContract,
  calloutContract,
  cardContract,
  codeSnippetContract,
  collapsibleSectionContract,
  cornerBadgeContract,
  dialogContract,
  iconButtonContract,
  imageContract,
  imageLightboxContract,
  inlineEditActionsContract,
  inputContract,
  menuSelectContract,
  notificationContract,
  panelContract,
  progressBarContract,
  radioButtonContract,
  sectionDividerContract,
  segmentedControlContract,
  sideNavigationContract,
  sliderContract,
  tabBarContract,
  tableContract,
  toggleContract,
  tooltipContract,
  videoLightboxContract,
  videoFrameContract,
  slidePagerContract
];
var CONTRACTS_MODULE_ENV = "LIVE_TOKENS_CONTRACTS_MODULE";
async function loadCustomContracts() {
  const modulePath = process.env[CONTRACTS_MODULE_ENV];
  if (!modulePath) return [];
  const mod = await import(pathToFileURL(path.resolve(modulePath)).href);
  const value = mod.default ?? mod.contracts;
  if (!Array.isArray(value)) {
    throw new Error(
      `${CONTRACTS_MODULE_ENV}=${modulePath} does not export a contracts array (default export or a named "contracts" export)`
    );
  }
  return value;
}
async function allContracts(contracts = shippedContracts) {
  const custom = await loadCustomContracts();
  return custom.length > 0 ? [...contracts, ...custom] : contracts;
}
async function selectedContracts(contracts = shippedContracts) {
  const all = await allContracts(contracts);
  const requested = process.env.LIVE_TOKENS_COMPONENT;
  return requested ? all.filter((contract) => contract.id === requested) : all;
}

export {
  shippedContracts,
  CONTRACTS_MODULE_ENV,
  allContracts,
  selectedContracts
};
//# sourceMappingURL=chunk-SHBYZUPD.js.map