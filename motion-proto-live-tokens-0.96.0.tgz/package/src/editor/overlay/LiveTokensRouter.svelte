<script module lang="ts">
  import type { Component } from 'svelte';

  /**
   * One entry per consumer route. `label` + `icon` make it appear in the
   * overlay's nav rail; `source` powers the "Page Source" button. Omit
   * `label` to keep the route reachable by URL but absent from the rail
   * (matches the existing playground/unlisted route pattern).
   *
   * Provide either `component` (eager) or `lazy` (code-split). Use `lazy`
   * for any page that side-effect-imports a stylesheet at the top of its
   * module, so those imports only evaluate when the route is visited and
   * don't leak into unrelated routes (most importantly the editor pages).
   *
   * `props` lets one page component serve many paths: a `resolve()` match can
   * hand the page the matched segment (an id or slug) so a single component
   * renders each dynamic route.
   */
  export interface RouteEntry {
    component?: Component<any, any, any>;
    lazy?: () => Promise<{ default: Component<any, any, any> }>;
    props?: Record<string, unknown>;
    label?: string;
    icon?: string;
    source?: string;
    /** Hide the overlay's "Page Source" button on this route. */
    hidePageSource?: boolean;
  }

  /**
   * Override the package's dev-only routes, which default to the reserved
   * `/live-tokens/*` namespace (`/live-tokens/editor`, `/live-tokens/components`,
   * `/live-tokens/colors`, `/live-tokens/docs`) so they never collide with
   * consumer pages. Pass a string to relocate a route; pass `false` to disable
   * it entirely (no dispatch and, for `components`/`colors`/`docs`, no
   * auto-injected nav-rail entry).
   */
  export interface EditorRouteOverrides {
    editor?: string | false;
    components?: string | false;
    colors?: string | false;
    docs?: string | false;
  }

  /**
   * Resolve a path to the single entry that renders it. Precedence, after the
   * package-owned `/live-tokens/*` routes (editor, components, colors, docs)
   * have already been matched by the component:
   *
   *   1. `pages[route]` — exact static match.
   *   2. `resolve(route)` — consumer code, where params / prefixes / gating
   *      live; returning `null` means "not mine" and resolution falls through.
   *   3. `pages['/']` — final fallback (return your own entry from `resolve`
   *      for a real 404 instead).
   *
   * With only `pages` passed this is exactly today's `pages[route] ?? pages['/']`.
   * One resolved entry drives both dispatch and "Page Source", so a dynamic
   * route's source can never desync from its page.
   */
  export function resolveRoute(
    pages: Record<string, RouteEntry>,
    resolve: ((route: string) => RouteEntry | null) | undefined,
    route: string,
  ): RouteEntry | null {
    return pages[route] ?? resolve?.(route) ?? pages['/'] ?? null;
  }

  /** The click facts the interception decision reads, so it can be tested
      without constructing a DOM MouseEvent. */
  export interface LinkClick {
    button: number;
    ctrlKey: boolean;
    metaKey: boolean;
    shiftKey: boolean;
    altKey: boolean;
    defaultPrevented: boolean;
  }

  /**
   * The path a left-click on `anchor` should navigate to in-app, or `null` to
   * leave the click to the browser.
   *
   * Interception cancels the click, so every link this claims and cannot serve
   * is a link that silently does nothing. It therefore claims a link only when
   * the anchor asks for ordinary same-tab navigation *and* `claimsRoute` says a
   * route renders that path — which leaves anything else the origin serves (a
   * PDF or an image under `public/`, a download, a server-rendered endpoint) to
   * load for real.
   *
   * `pages['/']` is a fallback for *rendering* an unmatched path, not a claim on
   * it: treating it as one is what made every unrouted URL look interceptable.
   */
  export function resolveLinkNavigation(
    anchor: Pick<Element, 'getAttribute' | 'hasAttribute'>,
    e: LinkClick,
    claimsRoute: (pathname: string) => boolean,
    base: string,
  ): string | null {
    if (e.defaultPrevented) return null;
    // Middle- and right-clicks reach `auxclick`, not `click`, in current
    // browsers; the guard costs nothing and keeps the contract explicit.
    if (e.button !== 0) return null;
    if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return null;

    const target = anchor.getAttribute('target');
    if (target && target !== '_self') return null;
    if (anchor.hasAttribute('download')) return null;
    if (anchor.getAttribute('rel')?.split(/\s+/).includes('external')) return null;

    const href = anchor.getAttribute('href');
    // Relative and absolute-URL hrefs stay the browser's; only root-relative
    // paths are candidates. `//host/x` starts with `/` and is cross-origin, and
    // pushState would throw on it, so the origin check below has to run too.
    if (!href?.startsWith('/')) return null;

    let url: URL;
    try {
      url = new URL(href, base);
    } catch {
      return null;
    }
    if (url.origin !== new URL(base).origin) return null;

    if (!claimsRoute(url.pathname)) return null;

    return url.pathname + url.search + url.hash;
  }
</script>

<script lang="ts">
  import LiveEditorOverlay from './LiveEditorOverlay.svelte';
  import ColumnsOverlay from './ColumnsOverlay.svelte';
  import { route, navigate } from '../core/routing/router';
  import { DEFAULT_EDITOR_PATH, DEFAULT_COMPONENTS_PATH, DEFAULT_COLORS_PATH, DEFAULT_DOCS_PATH } from '../core/routing/ownedRoutes';
  import { setSketchPageRoot } from '../core/sketch/sketchStore';

  interface Props {
    pages: Record<string, RouteEntry>;
    /**
     * Compute an entry for paths not in `pages` — this is where params,
     * prefixes, and conditional gating live. See `resolveRoute` for the full
     * precedence: `pages` wins over `resolve`, and `pages['/']` is the final
     * fallback.
     */
    resolve?: (route: string) => RouteEntry | null;
    editorRoutes?: EditorRouteOverrides;
  }

  let { pages, resolve, editorRoutes = {} }: Props = $props();

  let editorEnabled = $derived(editorRoutes.editor !== false);
  let componentsEnabled = $derived(editorRoutes.components !== false);
  let colorsEnabled = $derived(editorRoutes.colors !== false);
  let docsEnabled = $derived(editorRoutes.docs !== false);
  let editorPath = $derived(typeof editorRoutes.editor === 'string' ? editorRoutes.editor : DEFAULT_EDITOR_PATH);
  let componentsPath = $derived(typeof editorRoutes.components === 'string' ? editorRoutes.components : DEFAULT_COMPONENTS_PATH);
  let colorsPath = $derived(typeof editorRoutes.colors === 'string' ? editorRoutes.colors : DEFAULT_COLORS_PATH);
  let docsPath = $derived(typeof editorRoutes.docs === 'string' ? editorRoutes.docs : DEFAULT_DOCS_PATH);

  const isDev = import.meta.env.DEV;
  let isEditor = $derived(isDev && editorEnabled && $route === editorPath);
  let isComponentEditor = $derived(isDev && componentsEnabled && $route === componentsPath);
  let isColors = $derived(isDev && colorsEnabled && $route === colorsPath);
  let isDocs = $derived(isDev && docsEnabled && $route === docsPath);

  // A sketchstyle paints the page and never the editor's own chrome. Which
  // routes are chrome is this component's knowledge alone, since a consumer can
  // relocate them, so it hands the sketch layer the root to paint.
  $effect(() => {
    setSketchPageRoot(isEditor || isComponentEditor || isColors || isDocs ? null : document.documentElement);
  });

  // The single entry that renders the current route. Owned routes are handled
  // by the isEditor/isComponentEditor/isColors/isDocs branches, so they resolve
  // to null here; everything else flows through resolveRoute and drives both
  // dispatch (component + props) and page-source from this one value.
  let resolvedEntry = $derived(
    isEditor || isComponentEditor || isColors || isDocs ? null : resolveRoute(pages, resolve, $route),
  );

  // Pages with a label show up in the nav rail, in declaration order. In dev,
  // the colors, components-editor, and docs routes are auto-appended so they're
  // reachable from every page. Docs ship from the package, so consumers
  // reference the guide in the editor while building without vendoring a copy.
  let navLinks = $derived([
    ...Object.entries(pages)
      .filter(([, e]) => !!e.label)
      .map(([path, e]) => ({ path, label: e.label!, icon: e.icon ?? '' })),
    ...(isDev && colorsEnabled
      ? [{ path: colorsPath, label: 'Colors', icon: 'fa-palette' }]
      : []),
    ...(isDev && componentsEnabled
      ? [{ path: componentsPath, label: 'Components', icon: 'fa-puzzle-piece' }]
      : []),
    ...(isDev && docsEnabled
      ? [{ path: docsPath, label: 'Docs', icon: 'fa-book' }]
      : []),
  ]);

  // Static-page sources, plus the resolved entry's source for the current
  // route — so a resolve()-matched dynamic route gets "Page Source" too, keyed
  // on the live path ($route) the overlay looks up.
  let pageSources = $derived({
    ...Object.fromEntries(
      Object.entries(pages)
        .filter(([, e]) => !!e.source)
        .map(([path, e]) => [path, e.source!]),
    ),
    ...(resolvedEntry?.source ? { [$route]: resolvedEntry.source } : {}),
  });

  // The package-owned components, colors, and docs routes hide the page-source
  // button (no consumer source file backs them).
  let hidePageSourceOn = $derived([
    ...Object.entries(pages)
      .filter(([, e]) => e.hidePageSource)
      .map(([path]) => path),
    ...(resolvedEntry?.hidePageSource ? [$route] : []),
    ...(componentsEnabled ? [componentsPath] : []),
    ...(colorsEnabled ? [colorsPath] : []),
    ...(docsEnabled ? [docsPath] : []),
  ]);

  // Dispatch the current route. Editor pages are dynamically imported so they
  // don't ship in non-editor route bundles. Consumer pages dispatch via
  // `entry.lazy()` when provided (so each page's CSS side-effect imports stay
  // out of other routes), or via the eagerly-imported `entry.component`.
  let pagePromise = $derived.by(() => {
    // `import.meta.env.DEV` inline, not `isDev`: the build replaces it with a
    // literal and drops these branches and their chunks.
    if (import.meta.env.DEV) {
      if (isEditor) return import('../pages/Editor.svelte');
      if (isComponentEditor) return import('../pages/ComponentEditorPage.svelte');
      if (isColors) return import('../pages/ColorsPage.svelte');
      if (isDocs) return import('../docs/Docs.svelte');
    }
    const entry = resolvedEntry;
    if (!entry) return Promise.resolve({ default: null as unknown as Component<any, any, any> });
    if (entry.lazy) return entry.lazy();
    if (entry.component) return Promise.resolve({ default: entry.component });
    return Promise.resolve({ default: null as unknown as Component<any, any, any> });
  });

  // Which paths this router can actually render. The `pages['/']` fallback in
  // resolveRoute is deliberately not consulted: it renders an unmatched path,
  // it does not claim one.
  function claimsRoute(pathname: string): boolean {
    if (pathname in pages) return true;
    if (isDev && editorEnabled && pathname === editorPath) return true;
    if (isDev && componentsEnabled && pathname === componentsPath) return true;
    if (isDev && colorsEnabled && pathname === colorsPath) return true;
    if (isDev && docsEnabled && pathname === docsPath) return true;
    return !!resolve?.(pathname);
  }

  // In-app link interception: turn left-clicks on anchors this router can serve
  // into navigate() calls, so route state updates without a full reload.
  // Everything else — a new tab, a download, a file under `public/`, another
  // origin — keeps the browser's own handling.
  function handleClick(e: MouseEvent) {
    const anchor = (e.target as Element | null)?.closest?.('a[href]');
    if (!anchor) return;
    const path = resolveLinkNavigation(anchor, e, claimsRoute, window.location.href);
    if (!path) return;
    e.preventDefault();
    navigate(path);
  }
</script>

<!-- svelte-ignore a11y_click_events_have_key_events, a11y_no_noninteractive_element_interactions, a11y_no_static_element_interactions -->
<div
  class="lt-app"
  data-live-tokens-page
  class:is-editor={isEditor}
  class:is-component-editor={isComponentEditor}
  class:is-colors={isColors}
  onclick={handleClick}
>
  <LiveEditorOverlay {navLinks} {pageSources} {hidePageSourceOn} {editorPath} {componentsPath} {colorsPath} />
  <ColumnsOverlay />

  {#await pagePromise then m}
    {@const PageComponent = m.default}
    {#if PageComponent}
      <PageComponent {...resolvedEntry?.props ?? {}} />
    {/if}
  {/await}
</div>

<style>
  :global(html) {
    scrollbar-gutter: stable;
  }

  :global(body) {
    background: var(--page-bg);
    background-attachment: var(--page-bg-attachment, fixed);
  }

  .lt-app {
    width: 100%;
    min-height: 100vh;
    color: var(--text-primary);
    /* Set by LiveEditorOverlay when docked-open. Extends layout past the
       fixed panel so the viewport can scroll to reveal hidden content. */
    padding-right: var(--lt-overlay-scroll-pad, 0px);
  }

  .lt-app.is-editor,
  .lt-app.is-colors {
    background: black;
  }

  .lt-app.is-component-editor {
    min-height: 0;
    height: 100vh;
    padding-right: 0;
    background: black;
    overflow: hidden;
  }
</style>
