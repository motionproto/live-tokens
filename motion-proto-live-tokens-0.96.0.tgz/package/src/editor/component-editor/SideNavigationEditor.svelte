<script module lang="ts">
  import { buildTypeGroupColorTokens } from './scaffolding/buildTypeGroupTokens';
  import type { Token, TypeGroupConfig, IntrinsicSpec } from './scaffolding/types';

  export const component = 'sidenavigation';

  // Single-variant component with five structural parts. Three of them (Title,
  // Item, Footer) carry default/hover/selected interaction sub-states; Toggle
  // carries default/hover. Panel is geometry only. Keys use the " / " convention
  // VariantGroup recognises for two-tier parts/state strips.
  const STATEFUL_STATES = ['default', 'hover', 'selected'] as const;
  const TOGGLE_STATES = ['default', 'hover'] as const;
  type StatefulState = typeof STATEFUL_STATES[number];
  type ToggleState = typeof TOGGLE_STATES[number];

  const STATE_LABELS: Record<string, string> = {
    default: 'Default',
    hover: 'Hover',
    selected: 'Selected',
  };

  // --- Panel --------------------------------------------------------------
  const panelTokens: Token[] = [
    { label: 'surface color', groupKey: 'panel-surface', variable: '--sidenavigation-panel-surface' },
    { label: 'border color', groupKey: 'panel-border', variable: '--sidenavigation-panel-border' },
    { label: 'border width', canBeLinked: true, groupKey: 'border-width', variable: '--sidenavigation-panel-border-width' },
    { label: 'padding', canBeLinked: true, groupKey: 'padding', variable: '--sidenavigation-panel-padding' },
    { label: 'section gap', groupKey: 'panel-section-gap', variable: '--sidenavigation-panel-section-gap' },
    { label: 'item indent', splittable: false, groupKey: 'panel-item-padding', variable: '--sidenavigation-panel-item-padding' },
    { label: 'footer gap', groupKey: 'panel-footer-gap', variable: '--sidenavigation-panel-footer-gap' },
  ];

  // --- Animation ----------------------------------------------------------
  const animationTokens: Token[] = [
    { label: 'open duration', groupKey: 'open-duration', variable: '--sidenavigation-open-duration' },
    { label: 'open easing', groupKey: 'open-easing', variable: '--sidenavigation-open-easing' },
    { label: 'close duration', groupKey: 'close-duration', variable: '--sidenavigation-close-duration' },
    { label: 'close easing', groupKey: 'close-easing', variable: '--sidenavigation-close-easing' },
  ];

  // --- Title --------------------------------------------------------------
  // Title is a flex card containing the label box + toggle box. Per-state
  // tokens drive the card chrome (surface, border, padding); the stateless
  // bar + label-box structure lives in `titleBlockTokens` since it doesn't
  // vary across default/hover/selected.
  function titleStateTokens(s: StatefulState): Token[] {
    return [
      { label: 'surface color', groupKey: 'title-surface', variable: `--sidenavigation-title-${s}-surface` },
      { label: 'border color', groupKey: 'title-border', variable: `--sidenavigation-title-${s}-border` },
      { label: 'border width', canBeLinked: true, groupKey: 'title-border-width', variable: `--sidenavigation-title-${s}-border-width` },
      { label: 'indicator color', groupKey: 'title-indicator', variable: `--sidenavigation-title-${s}-indicator` },
      { label: 'indicator width', canBeLinked: true, groupKey: 'title-indicator-width', variable: `--sidenavigation-title-${s}-indicator-width` },
      { label: 'padding', canBeLinked: true, groupKey: 'title-padding', variable: `--sidenavigation-title-${s}-padding` },
    ];
  }
  // Stateless title-bar structure ("Title Block" tab): the bar's own geometry
  // plus the inner label box. Separate from the stateful Title tab because
  // these don't vary by interaction state. Label-box rows are prefixed "label"
  // to disambiguate from the bar's own corner radius.
  const titleBlockTokens: Token[] = [
    { label: 'gap', canBeLinked: true, groupKey: 'title-gap', variable: '--sidenavigation-title-gap' },
    { label: 'corner radius', canBeLinked: true, groupKey: 'title-radius', variable: '--sidenavigation-title-radius' },
    { label: 'label surface color', groupKey: 'title-label-surface', variable: '--sidenavigation-title-label-surface' },
    { label: 'label border color', groupKey: 'title-label-border', variable: '--sidenavigation-title-label-border' },
    { label: 'label border width', canBeLinked: true, groupKey: 'title-label-border-width', variable: '--sidenavigation-title-label-border-width' },
    { label: 'label corner radius', canBeLinked: true, groupKey: 'title-label-radius', variable: '--sidenavigation-title-label-radius' },
    { label: 'label padding', canBeLinked: true, groupKey: 'title-label-padding', variable: '--sidenavigation-title-label-padding' },
  ];
  function titleStateTypeGroups(s: StatefulState): TypeGroupConfig[] {
    return [{
      legend: 'title label',
      colorVariable: `--sidenavigation-title-${s}-label`,
      familyVariable: `--sidenavigation-title-${s}-label-font-family`,
      sizeVariable: `--sidenavigation-title-${s}-label-font-size`,
      weightVariable: `--sidenavigation-title-${s}-label-font-weight`,
      lineHeightVariable: `--sidenavigation-title-${s}-label-line-height`,
    }];
  }
  const titleTypographyTokens: Token[] = STATEFUL_STATES.flatMap((s) => [
    { label: 'font family', canBeLinked: true, groupKey: 'title-label-font-family', variable: `--sidenavigation-title-${s}-label-font-family` },
    { label: 'font size', canBeLinked: true, groupKey: 'title-label-font-size', variable: `--sidenavigation-title-${s}-label-font-size` },
    { label: 'font weight', canBeLinked: true, groupKey: 'title-label-font-weight', variable: `--sidenavigation-title-${s}-label-font-weight` },
    { label: 'line height', canBeLinked: true, groupKey: 'title-label-line-height', variable: `--sidenavigation-title-${s}-label-line-height` },
  ]);

  // --- Toggle -------------------------------------------------------------
  function toggleStateTokens(s: ToggleState): Token[] {
    return [
      { label: 'surface color', groupKey: 'toggle-surface', variable: `--sidenavigation-toggle-${s}-surface` },
      { label: 'border color', groupKey: 'toggle-border', variable: `--sidenavigation-toggle-${s}-border` },
      { label: 'border width', canBeLinked: true, groupKey: 'toggle-border-width', variable: `--sidenavigation-toggle-${s}-border-width` },
      { label: 'corner radius', canBeLinked: true, groupKey: 'toggle-radius', variable: `--sidenavigation-toggle-${s}-radius` },
      { label: 'padding', canBeLinked: true, groupKey: 'toggle-padding', variable: `--sidenavigation-toggle-${s}-padding` },
      { label: 'icon color', groupKey: 'toggle-icon', variable: `--sidenavigation-toggle-${s}-icon` },
      { label: 'icon size', canBeLinked: true, groupKey: 'toggle-icon-size', variable: `--sidenavigation-toggle-${s}-icon-size` },
    ];
  }

  // --- Section ------------------------------------------------------------
  // Section header is a CollapsibleSection wrapped in `.sn-section-header`;
  // the wrapper paints surface + left indicator and forwards section text
  // tokens into the inner CollapsibleSection (chromeless variant) by
  // shadowing its slots, so section typography is editable per-state
  // without modifying CollapsibleSection itself.
  function sectionStateTokens(s: StatefulState): Token[] {
    return [
      { label: 'surface color', groupKey: 'section-surface', variable: `--sidenavigation-section-${s}-surface` },
      { label: 'indicator color', groupKey: 'section-indicator', variable: `--sidenavigation-section-${s}-indicator` },
      { label: 'indicator width', canBeLinked: true, groupKey: 'section-indicator-width', variable: `--sidenavigation-section-${s}-indicator-width` },
    ];
  }
  function sectionStateTypeGroups(s: StatefulState): TypeGroupConfig[] {
    return [{
      legend: 'section text',
      colorVariable: `--sidenavigation-section-${s}-text`,
      familyVariable: `--sidenavigation-section-${s}-text-font-family`,
      sizeVariable: `--sidenavigation-section-${s}-text-font-size`,
      weightVariable: `--sidenavigation-section-${s}-text-font-weight`,
      lineHeightVariable: `--sidenavigation-section-${s}-text-line-height`,
    }];
  }
  const sectionTypographyTokens: Token[] = STATEFUL_STATES.flatMap((s) => [
    { label: 'font family', canBeLinked: true, groupKey: 'section-text-font-family', variable: `--sidenavigation-section-${s}-text-font-family` },
    { label: 'font size', canBeLinked: true, groupKey: 'section-text-font-size', variable: `--sidenavigation-section-${s}-text-font-size` },
    { label: 'font weight', canBeLinked: true, groupKey: 'section-text-font-weight', variable: `--sidenavigation-section-${s}-text-font-weight` },
    { label: 'line height', canBeLinked: true, groupKey: 'section-text-line-height', variable: `--sidenavigation-section-${s}-text-line-height` },
  ]);

  // --- Item ---------------------------------------------------------------
  function itemStateTokens(s: StatefulState): Token[] {
    return [
      { label: 'surface color', groupKey: 'item-surface', variable: `--sidenavigation-item-${s}-surface` },
      { label: 'padding', canBeLinked: true, groupKey: 'item-padding', variable: `--sidenavigation-item-${s}-padding` },
      { label: 'indicator color', groupKey: 'item-indicator', variable: `--sidenavigation-item-${s}-indicator` },
      { label: 'indicator width', canBeLinked: true, groupKey: 'item-indicator-width', variable: `--sidenavigation-item-${s}-indicator-width` },
    ];
  }
  function itemStateTypeGroups(s: StatefulState): TypeGroupConfig[] {
    return [{
      legend: 'item text',
      colorVariable: `--sidenavigation-item-${s}-text`,
      familyVariable: `--sidenavigation-item-${s}-text-font-family`,
      sizeVariable: `--sidenavigation-item-${s}-text-font-size`,
      weightVariable: `--sidenavigation-item-${s}-text-font-weight`,
      lineHeightVariable: `--sidenavigation-item-${s}-text-line-height`,
    }];
  }
  const itemTypographyTokens: Token[] = STATEFUL_STATES.flatMap((s) => [
    { label: 'font family', canBeLinked: true, groupKey: 'item-text-font-family', variable: `--sidenavigation-item-${s}-text-font-family` },
    { label: 'font size', canBeLinked: true, groupKey: 'item-text-font-size', variable: `--sidenavigation-item-${s}-text-font-size` },
    { label: 'font weight', canBeLinked: true, groupKey: 'item-text-font-weight', variable: `--sidenavigation-item-${s}-text-font-weight` },
    { label: 'line height', canBeLinked: true, groupKey: 'item-text-line-height', variable: `--sidenavigation-item-${s}-text-line-height` },
  ]);

  // --- Footer -------------------------------------------------------------
  function footerStateTokens(s: StatefulState): Token[] {
    return [
      { label: 'surface color', groupKey: 'footer-surface', variable: `--sidenavigation-footer-${s}-surface` },
      { label: 'padding', canBeLinked: true, groupKey: 'footer-padding', variable: `--sidenavigation-footer-${s}-padding` },
      { label: 'icon gap', groupKey: 'footer-gap', variable: `--sidenavigation-footer-${s}-gap` },
      { label: 'indicator color', groupKey: 'footer-indicator', variable: `--sidenavigation-footer-${s}-indicator` },
      { label: 'indicator width', canBeLinked: true, groupKey: 'footer-indicator-width', variable: `--sidenavigation-footer-${s}-indicator-width` },
      { label: 'icon color', groupKey: 'footer-icon', variable: `--sidenavigation-footer-${s}-icon` },
      { label: 'icon size', canBeLinked: true, groupKey: 'footer-icon-size', variable: `--sidenavigation-footer-${s}-icon-size` },
    ];
  }
  function footerStateTypeGroups(s: StatefulState): TypeGroupConfig[] {
    return [{
      legend: 'footer text',
      colorVariable: `--sidenavigation-footer-${s}-text`,
      familyVariable: `--sidenavigation-footer-${s}-text-font-family`,
      sizeVariable: `--sidenavigation-footer-${s}-text-font-size`,
      weightVariable: `--sidenavigation-footer-${s}-text-font-weight`,
      lineHeightVariable: `--sidenavigation-footer-${s}-text-line-height`,
    }];
  }
  const footerTypographyTokens: Token[] = STATEFUL_STATES.flatMap((s) => [
    { label: 'font family', canBeLinked: true, groupKey: 'footer-text-font-family', variable: `--sidenavigation-footer-${s}-text-font-family` },
    { label: 'font size', canBeLinked: true, groupKey: 'footer-text-font-size', variable: `--sidenavigation-footer-${s}-text-font-size` },
    { label: 'font weight', canBeLinked: true, groupKey: 'footer-text-font-weight', variable: `--sidenavigation-footer-${s}-text-font-weight` },
    { label: 'line height', canBeLinked: true, groupKey: 'footer-text-line-height', variable: `--sidenavigation-footer-${s}-text-line-height` },
  ]);

  // Assemble part/state map. " / " separator triggers the two-tier strip.
  const states: Record<string, Token[]> = {
    'Panel': panelTokens,
    ...Object.fromEntries(STATEFUL_STATES.map((s) => [`Title / ${STATE_LABELS[s]}`, titleStateTokens(s)])),
    'Title Block': titleBlockTokens,
    ...Object.fromEntries(TOGGLE_STATES.map((s) => [`Toggle / ${STATE_LABELS[s]}`, toggleStateTokens(s)])),
    ...Object.fromEntries(STATEFUL_STATES.map((s) => [`Section / ${STATE_LABELS[s]}`, sectionStateTokens(s)])),
    ...Object.fromEntries(STATEFUL_STATES.map((s) => [`Item / ${STATE_LABELS[s]}`, itemStateTokens(s)])),
    ...Object.fromEntries(STATEFUL_STATES.map((s) => [`Footer / ${STATE_LABELS[s]}`, footerStateTokens(s)])),
    'Animation': animationTokens,
  };
  const typeGroups: Record<string, TypeGroupConfig[]> = {
    ...Object.fromEntries(STATEFUL_STATES.map((s) => [`Title / ${STATE_LABELS[s]}`, titleStateTypeGroups(s)])),
    ...Object.fromEntries(STATEFUL_STATES.map((s) => [`Section / ${STATE_LABELS[s]}`, sectionStateTypeGroups(s)])),
    ...Object.fromEntries(STATEFUL_STATES.map((s) => [`Item / ${STATE_LABELS[s]}`, itemStateTypeGroups(s)])),
    ...Object.fromEntries(STATEFUL_STATES.map((s) => [`Footer / ${STATE_LABELS[s]}`, footerStateTypeGroups(s)])),
  };

  // Color groupKeys derive structurally from the part+role: stripping the
  // `--sidenavigation-` prefix and the state segment leaves `section-text`,
  // `item-text`, `footer-text`, `title-label` — so the per-part text colors stay
  // distinct instead of collapsing into one inferred `text` link group (which
  // would phantom-link parts the per-part font groupKeys deliberately keep apart).
  export const allTokens: Token[] = [
    ...Object.values(states).flat(),
    ...buildTypeGroupColorTokens(typeGroups, { component, variants: [...STATEFUL_STATES] }),
    ...titleTypographyTokens,
    ...sectionTypographyTokens,
    ...itemTypographyTokens,
    ...footerTypographyTokens,
  ];

  // Link contexts: within each part, the per-state values share a link tree so
  // a single edit can fan padding/border-width/typography across default/hover/selected.
  const linkableContexts = new Map<string, string>([
    ...STATEFUL_STATES.flatMap((s): Array<[string, string]> => [
      [`--sidenavigation-title-${s}-border-width`, `title ${s}`],
      [`--sidenavigation-title-${s}-indicator-width`, `title ${s}`],
      [`--sidenavigation-title-${s}-padding`, `title ${s}`],
      [`--sidenavigation-title-${s}-label-font-family`, `title ${s}`],
      [`--sidenavigation-title-${s}-label-font-size`, `title ${s}`],
      [`--sidenavigation-title-${s}-label-font-weight`, `title ${s}`],
      [`--sidenavigation-title-${s}-label-line-height`, `title ${s}`],
    ]),
    ...TOGGLE_STATES.flatMap((s): Array<[string, string]> => [
      [`--sidenavigation-toggle-${s}-border-width`, `toggle ${s}`],
      [`--sidenavigation-toggle-${s}-radius`, `toggle ${s}`],
      [`--sidenavigation-toggle-${s}-padding`, `toggle ${s}`],
      [`--sidenavigation-toggle-${s}-icon-size`, `toggle ${s}`],
    ]),
    ...STATEFUL_STATES.flatMap((s): Array<[string, string]> => [
      [`--sidenavigation-section-${s}-indicator-width`, `section ${s}`],
      [`--sidenavigation-section-${s}-text-font-family`, `section ${s}`],
      [`--sidenavigation-section-${s}-text-font-size`, `section ${s}`],
      [`--sidenavigation-section-${s}-text-font-weight`, `section ${s}`],
      [`--sidenavigation-section-${s}-text-line-height`, `section ${s}`],
    ]),
    ...STATEFUL_STATES.flatMap((s): Array<[string, string]> => [
      [`--sidenavigation-item-${s}-padding`, `item ${s}`],
      [`--sidenavigation-item-${s}-indicator-width`, `item ${s}`],
      [`--sidenavigation-item-${s}-text-font-family`, `item ${s}`],
      [`--sidenavigation-item-${s}-text-font-size`, `item ${s}`],
      [`--sidenavigation-item-${s}-text-font-weight`, `item ${s}`],
      [`--sidenavigation-item-${s}-text-line-height`, `item ${s}`],
    ]),
    ...STATEFUL_STATES.flatMap((s): Array<[string, string]> => [
      [`--sidenavigation-footer-${s}-padding`, `footer ${s}`],
      [`--sidenavigation-footer-${s}-indicator-width`, `footer ${s}`],
      [`--sidenavigation-footer-${s}-icon-size`, `footer ${s}`],
      [`--sidenavigation-footer-${s}-text-font-family`, `footer ${s}`],
      [`--sidenavigation-footer-${s}-text-font-size`, `footer ${s}`],
      [`--sidenavigation-footer-${s}-text-font-weight`, `footer ${s}`],
      [`--sidenavigation-footer-${s}-text-line-height`, `footer ${s}`],
    ]),
    ['--sidenavigation-panel-border-width', 'panel'],
    ['--sidenavigation-panel-padding', 'panel'],
    ['--sidenavigation-title-label-border-width', 'title block'],
  ]);

  // The hover tint is off unless a project turns it on: the gate holds a
  // transparent layer, a no-op, until it holds the tint itself.
  export const intrinsics: IntrinsicSpec[] = [
    {
      key: 'hover-tint',
      variants: ['default'],
      variable: () => '--sidenavigation-hover-tint-enabled',
      values: ['var(--color-transparent)', 'var(--sidenavigation-hover-tint)'],
      default: { default: 'var(--color-transparent)' },
    },
  ];
</script>

<script lang="ts">
  import SideNavigation, { type SideNavSection, type SideNavFooter } from '../../system/components/SideNavigation.svelte';
  import VariantGroup from './scaffolding/VariantGroup.svelte';
  import ComponentEditorBase from './scaffolding/ComponentEditorBase.svelte';
  import { editorState, setComponentAlias, clearComponentAlias } from '../core/store/editorStore';
  import { computeLinkedBlock, withLinkedDisabled } from './scaffolding/linkedBlock';
  import Toggle from '../ui/Toggle.svelte';
  import UIPaletteSelector from '../ui/UIPaletteSelector.svelte';

  // One switch. Turning the tint on also stands each hover surface down to its
  // own base, so hover is the tint alone rather than a swap wearing a wash.
  // Written as aliases rather than gated in CSS: a component token's value is
  // substituted at :root, so it can never name a per-variant private var.
  // Off clears the overrides, returning each surface to its shipped default.
  const HOVER_SWAPS: readonly (readonly [hover: string, base: string])[] = [
    ['--sidenavigation-title-hover-surface', '--sidenavigation-title-default-surface'],
    ['--sidenavigation-toggle-hover-surface', '--sidenavigation-toggle-default-surface'],
    ['--sidenavigation-section-hover-surface', '--sidenavigation-section-default-surface'],
    ['--sidenavigation-item-hover-surface', '--sidenavigation-item-default-surface'],
    ['--sidenavigation-footer-hover-surface', '--sidenavigation-footer-default-surface'],
  ];
  const TINT_ON = 'var(--sidenavigation-hover-tint)';
  const TINT_OFF = 'var(--color-transparent)';

  let tintOn = $derived.by(() => {
    const ref = $editorState.components.sidenavigation?.aliases['--sidenavigation-hover-tint-enabled'];
    return (ref?.kind === 'literal' ? ref.value : TINT_OFF) === TINT_ON;
  });

  function setTintOn(checked: boolean) {
    setComponentAlias('sidenavigation', '--sidenavigation-hover-tint-enabled', {
      kind: 'literal',
      value: checked ? TINT_ON : TINT_OFF,
    });
    for (const [hover, base] of HOVER_SWAPS) {
      if (checked) setComponentAlias('sidenavigation', hover, { kind: 'token', name: base });
      else clearComponentAlias('sidenavigation', hover);
    }
  }

  const demoSections: SideNavSection[] = [
    {
      path: 'section-1',
      title: 'Section 1',
      hasIndexPage: true,
      items: [
        { path: 'section-1/item-1', title: 'Item 1' },
        { path: 'section-1/item-2', title: 'Item 2' },
        { path: 'section-1/item-3', title: 'Item 3' },
      ],
    },
    {
      path: 'section-2',
      title: 'Section 2',
      hasIndexPage: true,
      items: [],
    },
  ];
  const demoFooter: SideNavFooter = {
    path: 'footer',
    title: 'Footer',
    icon: 'fa-solid fa-file-lines',
  };

  let linked = $derived(computeLinkedBlock(component, linkableContexts, allTokens, $editorState));
  let previewOpen = $state(true);

  let visibleStates = $derived(Object.fromEntries(
    Object.entries(states).map(([name, list]) => [
      name,
      withLinkedDisabled(list, linked.varSet).map((t) =>
        tintOn && t.variable.endsWith('-hover-surface') ? { ...t, disabled: true } : t,
      ),
    ]),
  ) as Record<string, Token[]>);

  // Map the shown part/state to the demo's force-hover / force-selected hooks
  // so token edits always have a row painted in that state for the viewer.
  function deriveForce(activeState: string) {
    const [part, sub] = activeState.includes(' / ') ? activeState.split(' / ') : [activeState, ''];
    const partKey = part.toLowerCase();
    const subKey = sub.toLowerCase();
    let forceHoverPart: 'title' | 'toggle' | 'item' | 'footer' | 'section' | null = null;
    let forceSelectedPart: 'title' | 'item' | 'footer' | 'section' | null = null;
    if (subKey === 'hover' && (partKey === 'title' || partKey === 'toggle' || partKey === 'item' || partKey === 'footer' || partKey === 'section')) {
      forceHoverPart = partKey;
    } else if (subKey === 'selected' && (partKey === 'title' || partKey === 'item' || partKey === 'footer' || partKey === 'section')) {
      forceSelectedPart = partKey;
    }
    return { forceHoverPart, forceSelectedPart };
  }
</script>

<ComponentEditorBase
  {component}
  title="Side Navigation"
  description="Collapsible left panel with title header, sections, sub-page links, and an optional footer link."
  tokens={allTokens}
  {linked}
>
  <VariantGroup
    name="sidenavigation"
    title="Side Navigation"
    states={visibleStates}
    {typeGroups}
    {component}
    selectorLabel="Part"
  >
    {#snippet extraPropertyRows(stateName)}
      {#if stateName.endsWith(' / Hover')}
        <div class="property-row" data-token-variables="--sidenavigation-hover-tint-enabled">
          <span class="property-label">tint layer</span>
          <Toggle checked={tintOn} onchange={setTintOn} />
        </div>
        {#if tintOn}
          <div class="property-row">
            <span class="property-label">tint color</span>
            <UIPaletteSelector variable="--sidenavigation-hover-tint" {component} showNone={false} />
          </div>
        {/if}
      {/if}
    {/snippet}
    {#snippet children({ activeState })}
      {@const { forceHoverPart, forceSelectedPart } = deriveForce(activeState)}
      <div class="sn-preview-frame">
        <SideNavigation
          sections={demoSections}
          footer={demoFooter}
          title="Title"
          titleHref="#"
          currentPath="section-1/item-2"
          open={previewOpen}
          ontoggle={() => (previewOpen = !previewOpen)}
          {forceHoverPart}
          {forceSelectedPart}
        />
      </div>
    {/snippet}
  </VariantGroup>
</ComponentEditorBase>

<style>
  /* Frame reserves room for the panel at its widest (so collapse animates into
     empty space rather than reshaping the canvas), and lets the panel manage
     its own width via the open/closed tokens. */
  .sn-preview-frame {
    min-width: 16rem;
    min-height: 26rem;
    display: flex;
    align-items: stretch;
  }
  .sn-preview-frame :global(.sidenavigation) {
    height: auto;
  }
</style>
