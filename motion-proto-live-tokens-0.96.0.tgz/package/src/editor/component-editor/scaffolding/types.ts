/** A component's catalogue entry: what it is, what to use it for, what to use
    instead, the rules of use, and what any guidance-bearing prop's values
    mean. Exported as `catalogue` from the runtime file's `<script module>`
    block — the Svelte compiler drops a leading HTML comment before it
    reaches the running editor, so this is the one form every reader (CLI,
    registry, consumer) can read. */
export type CatalogueEntry = {
  /** One sentence: what the component is. */
  description: string;
  /** The condition that makes this component the right one. */
  whenToUse: string;
  /** Each row rules the component out. `use` is the component id
      (`table`, never `Table`) that fits instead. */
  whenNotToUse: Array<{ when: string; use?: string }>;
  /** Rules of use, one sentence each. */
  constraints?: string[];
  /** Keyed by prop name; the value explains that prop's values. */
  props?: Record<string, string>;
};

/** Editor token: a single CSS custom property the user can theme. */
export type Token = {
  label: string;
  variable: string;
  /** When true, this token participates in the linked block when ≥2 variants agree on its value. */
  canBeLinked?: boolean;
  /** Used by the editor store to identify cross-variant counterparts (e.g. all `border-width` tokens link). */
  groupKey?: string;
  /** Token row is rendered in a disabled state (still visible). */
  disabled?: boolean;
  /** Token row is omitted entirely. */
  hidden?: boolean;
  /** When the linked block collapses several same-label same-value rows into one,
      the surviving row carries the other groupKey leads here so writes co-propagate. */
  mergeVariables?: string[];
  /** When false, a padding-shaped token renders only the single-value control
      (no split-to-sides affordance). For tokens consumed via a one-axis CSS
      property like `padding-bottom: var(--x)`, splitting yields side values
      that have nowhere to render — hide the toggle so users can't get into
      that state. Defaults to true for padding-shaped tokens. */
  splittable?: boolean;
  /** Optional element grouping (e.g. 'frame', 'header', 'body'). When a state
      has tokens or type-groups tagged with two or more distinct elements,
      StateBlock partitions the panel into labeled subsections — typography
      and properties for each element render together. */
  element?: string;
  /** Hint to the editor that this token's alias is a structured payload
      (currently only `kind: 'gradient'`). Drives Copy-from's per-kind
      branch — gradient aliases need family-swap of in-family stop colors
      rather than a verbatim ref copy. Distinct from `picker`: `kind`
      marks the value's data shape; `picker` selects the editor control. */
  kind?: 'gradient';
  /** Color-family slug for this token's owning variant (e.g. `brand`,
      `accent`). Set on gradient-kind tokens so Copy-from's family-swap
      can compute the src→dst family substitution. */
  family?: string;
  /** Opacity floor (0-100) for a colour token. A surface that floats over
      arbitrary page content has to stay legible and hit-obvious there, so the
      picker refuses to take it below this percentage and drops the `None`
      chip. Shipped defaults are held above the floor by the registry
      contract test. */
  minOpacity?: number;
};

/** An intrinsic: a structural/display property (alignment, hairline position,
    element visibility) driven by a bespoke editor control rather than the
    generic token grid. Unlike a Token it carries the default twice — once in
    the runtime component's `:global(:root)` and once in the editor's read-back
    (`default` below, which the getters fall back to when unset). Those two
    copies must agree or the control displays a state the page doesn't render
    (the SectionDivider align bug). The intrinsics contract test pins them. */
export type IntrinsicSpec = {
  /** Stable id, used in diagnostics and to key getters off the spec. */
  key: string;
  /** Variant keys this intrinsic spans (e.g. ['lg','md','sm']). */
  variants: string[];
  /** Per-variant CSS custom property. */
  variable: (variant: string) => string;
  /** Allowed raw values; the runtime `:root` default must be one of these. */
  values: string[];
  /** Editor's unset-default raw value per variant — the read-back getters
      source their default from here. Pinned to the runtime `:global(:root)`
      default by the intrinsics contract test. */
  default: Record<string, string>;
  /** Folds render-equivalent raw values to one canonical form before
      comparison (e.g. SectionDivider's 'above-description' ≡ 'below-label'). */
  normalize?: (raw: string) => string;
};

/** Editor type-group: a fieldset containing a coordinated set of typography tokens
    (text color + font-family/size/weight/line-height) for a piece of content
    (e.g. a card title, notification body). */
export type TypeGroupConfig = {
  legend?: string;
  colorVariable: string;
  colorLabel?: string;
  /** Whether this typography color participates in its declared cross-context
   *  sibling group. Kept explicit because most state colors are independent. */
  colorCanBeLinked?: boolean;
  familyVariable?: string;
  familyLabel?: string;
  sizeVariable?: string;
  sizeLabel?: string;
  weightVariable?: string;
  weightLabel?: string;
  lineHeightVariable?: string;
  lineHeightLabel?: string;
  letterSpacingVariable?: string;
  letterSpacingLabel?: string;
  /** Explicit groupKey for this group's color token. Wins over every derivation
      (structural or `groupKeyFor`) and is never recomputed — the durable, one-line
      fix when the derived key is wrong. */
  colorGroupKey?: string;
  /** See `Token.element` — when present, StateBlock groups this fieldset under
      the matching element subsection. */
  element?: string;
};
