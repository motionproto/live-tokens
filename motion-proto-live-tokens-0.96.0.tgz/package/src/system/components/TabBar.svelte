<script module lang="ts">
  import type { CatalogueEntry } from '../../editor/component-editor/scaffolding/types';

  export const catalogue = {
    description: 'Tabs that swap the content below them.',
    whenToUse: 'two to seven views the reader moves between inside one page.',
    whenNotToUse: [
      { when: 'the switch sits among other controls in a row.', use: 'segmentedcontrol' },
      { when: 'the choice changes the URL.', use: 'sidenavigation' },
    ],
  } satisfies CatalogueEntry;
</script>

<script lang="ts">
  import { createEventDispatcher } from 'svelte';

  interface Tab {
    id: string;
    label: string;
    icon?: string;
    disabled?: boolean;
  }

  interface Props {
    /** Wash the hovered surface with the theme's tint. `undefined` inherits the
        global default; `true`/`false` force this instance on/off. */
    hoverTint?: boolean | undefined;
    tabs?: Tab[];
    value?: string;
    iconOnly?: boolean;
    class?: string;
    /** Fires with the id of the tab the reader picked. */
    onchange?: (id: string) => void;
  }

  let {
    hoverTint = undefined,
    tabs = [],
    value = '',
    iconOnly = false,
    class: className = '',
    onchange
  }: Props = $props();

  // Per-instance override of the global hover-tint intrinsic; undefined leaves :root in charge.
  let hoverTintValue = $derived(
    hoverTint === undefined ? undefined : hoverTint ? 'var(--tabbar-hover-tint)' : 'var(--color-transparent)',
  );

  // Dual-fire bridge — see Button.svelte for the deprecation timeline.
  const dispatch = createEventDispatcher<{
    tabChange: string;
  }>();

  function selectTab(tab: Tab) {
    if (!tab.disabled) {
      onchange?.(tab.id);
      dispatch('tabChange', tab.id);
    }
  }
</script>

<div
  class="tab-bar {className}"
  style:--tabbar-hover-tint-enabled={hoverTintValue}
>
  {#each tabs as tab}
    <button
      class="tab"
      class:selected={value === tab.id}
      class:icon-only={iconOnly}
      disabled={tab.disabled}
      onclick={() => selectTab(tab)}
    >
      {#if tab.icon}
        <i class={tab.icon}></i>
      {/if}
      {#if !iconOnly}
        <span>{tab.label}</span>
      {/if}
    </button>
  {/each}
</div>

<style lang="scss">
  @use '../styles/padding' as *;

  :global(:root) {
    /* Hover tint: an optional wash over the hovered surface, one stop for the
       whole component. Off by default; the gate holds the tint when enabled. */
    --tabbar-hover-tint: var(--tint);
    --tabbar-hover-tint-enabled: var(--color-transparent);

    /* Bar */
    --tabbar-bar-hairline-color: var(--border-neutral-subtle);
    --tabbar-bar-hairline-width: var(--border-width-1);
    --tabbar-bar-top-margin: var(--space-0);
    --tabbar-bar-bottom-padding: var(--space-0);
    --tabbar-bar-bottom-margin: var(--space-0);
    --tabbar-tab-gap: var(--space-2);

    /* Default tab */
    --tabbar-default-text: var(--text-tertiary);
    --tabbar-default-text-font-family: var(--font-sans);
    --tabbar-default-text-font-size: var(--font-size-md);
    --tabbar-default-text-font-weight: var(--font-weight-light);
    --tabbar-default-text-line-height: var(--line-height-normal);
    --tabbar-default-icon-size: var(--icon-size-md);
    --tabbar-default-padding: var(--space-8);
    --tabbar-default-border: var(--color-transparent);
    --tabbar-default-surface: var(--color-transparent);
    --tabbar-default-tab-border-color: var(--color-transparent);
    --tabbar-default-tab-border-width: var(--border-width-0);
    --tabbar-default-tab-top-radius: var(--radius-none);
    --tabbar-default-tab-bottom-radius: var(--radius-none);
    --tabbar-default-indicator-width: var(--border-width-2);

    /* Hover tab */
    --tabbar-hover-text: var(--text-secondary);
    --tabbar-hover-surface: var(--surface-neutral-lower);
    --tabbar-hover-text-font-family: var(--font-sans);
    --tabbar-hover-text-font-size: var(--font-size-md);
    --tabbar-hover-text-font-weight: var(--font-weight-light);
    --tabbar-hover-text-line-height: var(--line-height-normal);
    --tabbar-hover-icon-size: var(--icon-size-md);
    --tabbar-hover-padding: var(--space-8);
    --tabbar-hover-border: var(--color-transparent);
    --tabbar-hover-tab-border-color: var(--color-transparent);
    --tabbar-hover-tab-border-width: var(--border-width-0);
    --tabbar-hover-tab-top-radius: var(--radius-none);
    --tabbar-hover-tab-bottom-radius: var(--radius-none);
    --tabbar-hover-indicator-width: var(--border-width-2);

    /* Selected tab */
    --tabbar-selected-text: var(--text-primary);
    --tabbar-selected-border: var(--color-brand-500);
    --tabbar-selected-surface: var(--tint-low);
    --tabbar-selected-text-font-family: var(--font-sans);
    --tabbar-selected-text-font-size: var(--font-size-md);
    --tabbar-selected-text-font-weight: var(--font-weight-light);
    --tabbar-selected-text-line-height: var(--line-height-normal);
    --tabbar-selected-icon-size: var(--icon-size-md);
    --tabbar-selected-padding: var(--space-8);
    --tabbar-selected-tab-border-color: var(--color-transparent);
    --tabbar-selected-tab-border-width: var(--border-width-0);
    --tabbar-selected-tab-top-radius: var(--radius-none);
    --tabbar-selected-tab-bottom-radius: var(--radius-none);
    --tabbar-selected-indicator-width: var(--border-width-2);

    /* Disabled tab */
    --tabbar-disabled-text: var(--text-disabled);
    --tabbar-disabled-text-font-family: var(--font-sans);
    --tabbar-disabled-text-font-size: var(--font-size-md);
    --tabbar-disabled-text-font-weight: var(--font-weight-light);
    --tabbar-disabled-text-line-height: var(--line-height-normal);
    --tabbar-disabled-icon-size: var(--icon-size-md);
    --tabbar-disabled-padding: var(--space-8);
    --tabbar-disabled-border: var(--color-transparent);
    --tabbar-disabled-surface: var(--color-transparent);
    --tabbar-disabled-tab-border-color: var(--color-transparent);
    --tabbar-disabled-tab-border-width: var(--border-width-0);
    --tabbar-disabled-tab-top-radius: var(--radius-none);
    --tabbar-disabled-tab-bottom-radius: var(--radius-none);
    --tabbar-disabled-indicator-width: var(--border-width-2);
  }

  .tab-bar {
    display: flex;
    gap: var(--tabbar-tab-gap);
    border-bottom: var(--tabbar-bar-hairline-width) solid var(--tabbar-bar-hairline-color);
    margin-top: var(--tabbar-bar-top-margin);
    padding-bottom: var(--tabbar-bar-bottom-padding);
    margin-bottom: var(--tabbar-bar-bottom-margin);
  }

  /* Per-state tokens are bound to `--_*` custom properties below. The actual
     layout-affecting declarations (padding, border, border-radius, font-*)
     are written exactly once on `.tab`, so a hover or selected state change can
     only repaint, not relayout. When two states resolve to the same value,
     the computed property is identical and no reshape is triggered. The
     `transition: all` of the old rule has also been narrowed to paint-only
     properties — otherwise it would try to animate layout changes between
     states that happen to differ in tokens. */
  .tab {
    --_text-color: var(--tabbar-default-text);
    --_text-family: var(--tabbar-default-text-font-family);
    --_text-size: var(--tabbar-default-text-font-size);
    --_text-weight: var(--tabbar-default-text-font-weight);
    --_text-line-height: var(--tabbar-default-text-line-height);
    --_icon-size: var(--tabbar-default-icon-size);
    --_surface: var(--tabbar-default-surface);
    --_indicator-color: var(--tabbar-default-border);
    --_indicator-width: var(--tabbar-default-indicator-width);
    --_padding: var(--tabbar-default-padding);
    --_border-color: var(--tabbar-default-tab-border-color);
    --_border-width: var(--tabbar-default-tab-border-width);
    --_top-radius: var(--tabbar-default-tab-top-radius);
    --_bottom-radius: var(--tabbar-default-tab-bottom-radius);

    display: inline-flex;
    align-items: center;
    gap: var(--space-6);
    padding: var(--_padding) calc(var(--_padding) * 2);
    background: var(--_surface);
    border: var(--_border-width) solid var(--_border-color);
    /* Indicator accent owns the bottom edge. Both width and color rebind
       per state — `--tabbar-{state}-indicator-width` and
       `--tabbar-{state}-border` (the indicator color slot). */
    border-bottom: var(--_indicator-width) solid var(--_indicator-color);
    border-radius: var(--_top-radius) var(--_top-radius) var(--_bottom-radius) var(--_bottom-radius);
    color: var(--_text-color);
    font-family: var(--_text-family);
    font-size: var(--_text-size);
    font-weight: var(--_text-weight);
    line-height: var(--_text-line-height);
    cursor: pointer;
    transition:
      background var(--duration-150),
      color var(--duration-150),
      border-color var(--duration-150);
    position: relative;
  }

  .tab i {
    font-size: var(--_icon-size);
  }

  .tab:hover:not(:disabled):not(.selected),
  .tab-bar.force-hover .tab:not(:disabled):not(.selected) {
    background-image: linear-gradient(var(--tabbar-hover-tint-enabled), var(--tabbar-hover-tint-enabled));
    --_text-color: var(--tabbar-hover-text);
    --_text-family: var(--tabbar-hover-text-font-family);
    --_text-size: var(--tabbar-hover-text-font-size);
    --_text-weight: var(--tabbar-hover-text-font-weight);
    --_text-line-height: var(--tabbar-hover-text-line-height);
    --_icon-size: var(--tabbar-hover-icon-size);
    --_surface: var(--tabbar-hover-surface);
    --_indicator-color: var(--tabbar-hover-border);
    --_indicator-width: var(--tabbar-hover-indicator-width);
    --_padding: var(--tabbar-hover-padding);
    --_border-color: var(--tabbar-hover-tab-border-color);
    --_border-width: var(--tabbar-hover-tab-border-width);
    --_top-radius: var(--tabbar-hover-tab-top-radius);
    --_bottom-radius: var(--tabbar-hover-tab-bottom-radius);
  }

  .tab.selected {
    --_text-color: var(--tabbar-selected-text);
    --_text-family: var(--tabbar-selected-text-font-family);
    --_text-size: var(--tabbar-selected-text-font-size);
    --_text-weight: var(--tabbar-selected-text-font-weight);
    --_text-line-height: var(--tabbar-selected-text-line-height);
    --_icon-size: var(--tabbar-selected-icon-size);
    --_surface: var(--tabbar-selected-surface);
    --_indicator-color: var(--tabbar-selected-border);
    --_indicator-width: var(--tabbar-selected-indicator-width);
    --_padding: var(--tabbar-selected-padding);
    --_border-color: var(--tabbar-selected-tab-border-color);
    --_border-width: var(--tabbar-selected-tab-border-width);
    --_top-radius: var(--tabbar-selected-tab-top-radius);
    --_bottom-radius: var(--tabbar-selected-tab-bottom-radius);
  }

  .tab:disabled {
    --_text-color: var(--tabbar-disabled-text);
    --_text-family: var(--tabbar-disabled-text-font-family);
    --_text-size: var(--tabbar-disabled-text-font-size);
    --_text-weight: var(--tabbar-disabled-text-font-weight);
    --_text-line-height: var(--tabbar-disabled-text-line-height);
    --_icon-size: var(--tabbar-disabled-icon-size);
    --_surface: var(--tabbar-disabled-surface);
    --_indicator-color: var(--tabbar-disabled-border);
    --_indicator-width: var(--tabbar-disabled-indicator-width);
    --_padding: var(--tabbar-disabled-padding);
    --_border-color: var(--tabbar-disabled-tab-border-color);
    --_border-width: var(--tabbar-disabled-tab-border-width);
    --_top-radius: var(--tabbar-disabled-tab-top-radius);
    --_bottom-radius: var(--tabbar-disabled-tab-bottom-radius);
    cursor: not-allowed;
  }

  .tab.icon-only {
    padding: var(--space-8) var(--space-12);
  }
</style>
