"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// vite-plugin/migrateData/index.ts
var migrateData_exports = {};
__export(migrateData_exports, {
  migrateData: () => migrateData,
  readLiveTokensConfig: () => readLiveTokensConfig,
  resolveDataDirs: () => resolveDataDirs
});
module.exports = __toCommonJS(migrateData_exports);

// vite-plugin/migrateData/migrateData.ts
var import_fs3 = __toESM(require("fs"), 1);
var import_path3 = __toESM(require("path"), 1);

// vite-plugin/files/versionedFileResourceServer.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
function versionedFileResourceServer(opts) {
  const dir = opts.dir;
  const activePath = import_path.default.join(dir, "_active.json");
  const productionPath = import_path.default.join(dir, "_production.json");
  const workingPath = import_path.default.join(dir, "_working.json");
  const defaultName = opts.defaultName ?? "default";
  const resolvedDir = import_path.default.resolve(dir);
  const resolvedPackageDir = opts.packageDir ? import_path.default.resolve(opts.packageDir) : null;
  function ensureDir() {
    if (!import_fs.default.existsSync(dir)) {
      import_fs.default.mkdirSync(dir, { recursive: true });
    }
  }
  function ensureMeta() {
    if (!import_fs.default.existsSync(activePath)) {
      import_fs.default.writeFileSync(activePath, JSON.stringify({ activeFile: defaultName }));
      opts.onWrite?.(activePath);
    }
    if (!import_fs.default.existsSync(productionPath)) {
      import_fs.default.writeFileSync(productionPath, JSON.stringify({ productionFile: defaultName }));
      opts.onWrite?.(productionPath);
    }
  }
  function filePath(name) {
    return import_path.default.join(dir, `${name}.json`);
  }
  function existingPath(name) {
    const local = filePath(name);
    if (import_fs.default.existsSync(local)) return local;
    if (resolvedPackageDir) {
      const pkg = import_path.default.join(resolvedPackageDir, `${name}.json`);
      if (import_fs.default.existsSync(pkg)) return pkg;
    }
    return null;
  }
  function isPackageFile(name) {
    if (!resolvedPackageDir) return false;
    const pkg = import_path.default.join(resolvedPackageDir, `${name}.json`);
    if (!import_fs.default.existsSync(pkg)) return false;
    const local = import_path.default.resolve(filePath(name));
    if (local === pkg) {
      return opts.packageOwnedNames ? opts.packageOwnedNames.includes(name) : true;
    }
    return !import_fs.default.existsSync(local);
  }
  function readJson(name) {
    const resolved = existingPath(name);
    if (!resolved) return null;
    return JSON.parse(import_fs.default.readFileSync(resolved, "utf-8"));
  }
  function listNames() {
    const names = [];
    const seen = /* @__PURE__ */ new Set();
    const collect = (d) => {
      if (!d || !import_fs.default.existsSync(d)) return;
      for (const f of import_fs.default.readdirSync(d)) {
        if (!f.endsWith(".json") || f.startsWith("_")) continue;
        const name = f.slice(0, -".json".length);
        if (seen.has(name)) continue;
        seen.add(name);
        names.push(name);
      }
    };
    collect(resolvedDir);
    if (resolvedPackageDir && resolvedPackageDir !== resolvedDir) collect(resolvedPackageDir);
    return names;
  }
  function getActiveName() {
    try {
      const data = JSON.parse(import_fs.default.readFileSync(activePath, "utf-8"));
      return data.activeFile || defaultName;
    } catch {
      return defaultName;
    }
  }
  function getProductionName() {
    try {
      const data = JSON.parse(import_fs.default.readFileSync(productionPath, "utf-8"));
      return data.productionFile || defaultName;
    } catch {
      return defaultName;
    }
  }
  function setActiveName(name) {
    import_fs.default.writeFileSync(activePath, JSON.stringify({ activeFile: name }));
    opts.onWrite?.(activePath);
  }
  function setProductionName(name) {
    import_fs.default.writeFileSync(productionPath, JSON.stringify({ productionFile: name }));
    opts.onWrite?.(productionPath);
  }
  function hasWorking() {
    return import_fs.default.existsSync(workingPath);
  }
  function readWorking() {
    if (!import_fs.default.existsSync(workingPath)) return null;
    const parsed = JSON.parse(import_fs.default.readFileSync(workingPath, "utf-8"));
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error(`${workingPath} does not hold a JSON object`);
    }
    return parsed;
  }
  function writeWorking(data) {
    ensureDir();
    import_fs.default.writeFileSync(workingPath, JSON.stringify(data, null, 2));
    opts.onWrite?.(workingPath);
  }
  function clearWorking() {
    if (!import_fs.default.existsSync(workingPath)) return;
    import_fs.default.unlinkSync(workingPath);
    opts.onWrite?.(workingPath);
  }
  return {
    dir,
    activePath,
    productionPath,
    workingPath,
    ensureDir,
    ensureMeta,
    filePath,
    existingPath,
    isPackageFile,
    readJson,
    listNames,
    getActiveName,
    getProductionName,
    setActiveName,
    setProductionName,
    hasWorking,
    readWorking,
    writeWorking,
    clearWorking
  };
}

// src/editor/core/themes/migrations/2026-04-24-legacy-keys-and-bg-to-canvas.ts
var LEGACY_KEY_RENAMES = {
  "--empty": "--page-bg",
  "--empty-attachment": "--page-bg-attachment",
  // Orphan exports dropped from tokens.css; no new home — silently discard.
  "--border-neutral": null,
  // Shadow cleanup: these five tokens were removed (low/zero consumers,
  // aesthetic drift). Dialog migrated onto --shadow-2xl; focus rings moved
  // to their own --ring-focus-* namespace, which themes don't carry by
  // default — tokens.css provides the canonical values.
  "--shadow-app": null,
  "--shadow-card": null,
  "--shadow-overlay": null,
  "--shadow-focus": null,
  "--shadow-glow-green": null
};
var BG_TO_CANVAS_PREFIXES = ["--color-bg-", "--surface-bg", "--border-bg", "--text-bg"];
function migrateBgToCanvas(rawVars) {
  for (const oldKey of Object.keys(rawVars)) {
    for (const prefix of BG_TO_CANVAS_PREFIXES) {
      if (!oldKey.startsWith(prefix)) continue;
      const suffix = oldKey.slice(prefix.length);
      if (suffix && !suffix.startsWith("-")) continue;
      const newKey = prefix.replace("-bg", "-canvas") + suffix;
      if (newKey === oldKey) continue;
      const value = rawVars[oldKey];
      delete rawVars[oldKey];
      if (!(newKey in rawVars)) rawVars[newKey] = value;
      break;
    }
  }
}
function migrateLegacyKeys(rawVars) {
  for (const [oldKey, newKey] of Object.entries(LEGACY_KEY_RENAMES)) {
    if (!(oldKey in rawVars)) continue;
    const value = rawVars[oldKey];
    delete rawVars[oldKey];
    if (newKey && !(newKey in rawVars)) rawVars[newKey] = value;
  }
  migrateBgToCanvas(rawVars);
}
var colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas = {
  id: "2026-04-24-legacy-keys-and-bg-to-canvas",
  fromVersion: 0,
  toVersion: 1,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = { ...rawVars };
    migrateLegacyKeys(out);
    return out;
  }
};

// src/editor/core/themes/migrations/2026-04-24-component-prefix-and-suffix-renames.ts
var COMPONENT_PREFIX_RENAMES = {
  "--segment-": "--segmentedcontrol-",
  "--collapsible-": "--collapsiblesection-",
  "--progress-": "--progressbar-",
  "--section-divider-": "--sectiondivider-",
  "--radio-": "--radiobutton-",
  "--inline-edit-": "--inlineeditactions-"
};
var COMPONENT_SUFFIX_RENAMES = {
  progressbar: [["-track-bg", "-track-surface"]],
  inlineeditactions: [
    ["-bg-hover", "-hover-surface"],
    ["-bg", "-surface"]
  ]
};
var componentMigration_2026_04_24_prefixAndSuffixRenames = {
  id: "2026-04-24-component-prefix-and-suffix-renames",
  fromVersion: 0,
  toVersion: 1,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const component = meta.component ?? "";
    const out = {};
    const suffixRules = COMPONENT_SUFFIX_RENAMES[component] ?? [];
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key === "--detail-nav-bg") key = "--detailnav-surface";
      for (const [oldPrefix, newPrefix] of Object.entries(COMPONENT_PREFIX_RENAMES)) {
        if (key.startsWith(oldPrefix)) {
          key = newPrefix + key.slice(oldPrefix.length);
          break;
        }
      }
      for (const [oldSuffix, newSuffix] of suffixRules) {
        if (key.endsWith(oldSuffix)) {
          key = key.slice(0, -oldSuffix.length) + newSuffix;
          break;
        }
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-04-27-segmentedcontrol-disabled-flatten.ts
var OPTION_DISABLED_PREFIX = "--segmentedcontrol-option-disabled-";
var DISABLED_PREFIX = "--segmentedcontrol-disabled-";
var SELECTED_DISABLED_PREFIX = "--segmentedcontrol-selected-disabled-";
var SELECTED_HOVER_PREFIX = "--segmentedcontrol-selected-hover-";
var componentMigration_2026_04_27_segmentedcontrolDisabledFlatten = {
  id: "2026-04-27-segmentedcontrol-disabled-flatten",
  fromVersion: 1,
  toVersion: 2,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key.startsWith(SELECTED_DISABLED_PREFIX)) continue;
      if (key.startsWith(SELECTED_HOVER_PREFIX)) continue;
      if (key.startsWith(OPTION_DISABLED_PREFIX)) {
        key = DISABLED_PREFIX + key.slice(OPTION_DISABLED_PREFIX.length);
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-08-collapsiblesection-variant-namespace.ts
var PREFIX = "--collapsiblesection-";
var STATE_NAMES = /* @__PURE__ */ new Set(["default", "hover", "active", "expanded"]);
var componentMigration_2026_05_08_collapsiblesectionVariantNamespace = {
  id: "2026-05-08-collapsiblesection-variant-namespace",
  fromVersion: 2,
  toVersion: 3,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "collapsiblesection") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key.startsWith(PREFIX)) {
        const tail = key.slice(PREFIX.length);
        const firstSegment = tail.split("-", 1)[0];
        if (STATE_NAMES.has(firstSegment)) {
          key = `${PREFIX}container-${tail}`;
        }
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-08-collapsiblesection-frame-and-cleanup.ts
var PFX = "--collapsiblesection-";
var componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup = {
  id: "2026-05-08-collapsiblesection-frame-and-cleanup",
  fromVersion: 3,
  toVersion: 4,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "collapsiblesection") return { ...rawVars };
    const out = {};
    for (const prop of ["surface", "border", "border-width", "radius"]) {
      const src = `${PFX}container-default-${prop}`;
      if (src in rawVars) {
        out[`${PFX}container-frame-${prop}`] = rawVars[src];
      }
    }
    for (const [key, value] of Object.entries(rawVars)) {
      if (/^--collapsiblesection-chromeless-(default|hover|active)-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-container-(hover|active)-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-container-default-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-divider-(default|hover|active)-radius$/.test(key)) continue;
      if (/^--collapsiblesection-(chromeless|divider|container)-expanded-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-(chromeless|divider)-expanded-surface$/.test(key)) continue;
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-10-sectiondivider-gradient-stops.ts
var PFX2 = "--sectiondivider-";
var VARIANTS = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
var OLD_STOP_RE = /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-gradient-stop-\d+$/;
var componentMigration_2026_05_10_sectiondividerGradientStops = {
  id: "2026-05-10-sectiondivider-gradient-stops",
  fromVersion: 4,
  toVersion: 5,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (OLD_STOP_RE.test(key)) continue;
      out[key] = value;
    }
    const setIfMissing = (key, fallback) => {
      if (!(key in out)) out[key] = fallback;
    };
    for (const v of VARIANTS) {
      const old1 = rawVars[`${PFX2}${v}-gradient-stop-1`];
      const old2 = rawVars[`${PFX2}${v}-gradient-stop-2`];
      const old4 = rawVars[`${PFX2}${v}-gradient-stop-4`];
      setIfMissing(`${PFX2}${v}-gradient-angle`, "--gradient-angle-diagonal");
      setIfMissing(`${PFX2}${v}-gradient-stop-1-color`, old1 ?? `--surface-${v}-highest`);
      setIfMissing(`${PFX2}${v}-gradient-stop-1-position`, "--gradient-stop-start");
      setIfMissing(`${PFX2}${v}-gradient-stop-2-color`, old2 ?? `--surface-${v}-higher`);
      setIfMissing(`${PFX2}${v}-gradient-stop-2-position`, "--gradient-stop-mid");
      setIfMissing(`${PFX2}${v}-gradient-stop-3-color`, old4 ?? `--surface-${v}`);
      setIfMissing(`${PFX2}${v}-gradient-stop-3-position`, "--gradient-stop-end");
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-13-primary-to-brand.ts
var PALETTE_STEPS = ["100", "200", "300", "400", "500", "600", "700", "800", "850", "900", "950"];
var SURFACE_SUFFIXES = ["lowest", "lower", "low", "high", "higher", "highest"];
var BORDER_SUFFIXES = ["faint", "subtle", "medium", "strong"];
var TEXT_SUFFIXES = ["secondary", "tertiary", "muted", "disabled"];
var RENAME_MAP = (() => {
  const m = {};
  for (const step of PALETTE_STEPS) m[`--color-primary-${step}`] = `--color-brand-${step}`;
  m["--surface-primary"] = "--surface-brand";
  for (const suf of SURFACE_SUFFIXES) m[`--surface-primary-${suf}`] = `--surface-brand-${suf}`;
  m["--border-primary"] = "--border-brand";
  for (const suf of BORDER_SUFFIXES) m[`--border-primary-${suf}`] = `--border-brand-${suf}`;
  m["--text-primary-color"] = "--text-brand";
  for (const suf of TEXT_SUFFIXES) m[`--text-primary-${suf}`] = `--text-brand-${suf}`;
  return m;
})();
function renameToken(name) {
  return RENAME_MAP[name] ?? name;
}
function renameKeys(rawVars) {
  const out = {};
  for (const [k, v] of Object.entries(rawVars)) {
    out[renameToken(k)] = v;
  }
  return out;
}
function renameKeysAndValues(rawVars) {
  const out = {};
  for (const [k, v] of Object.entries(rawVars)) {
    out[renameToken(k)] = renameToken(v);
  }
  return out;
}
var colorsAndTypeMigration_2026_05_13_primaryToBrand = {
  id: "2026-05-13-primary-to-brand-theme",
  fromVersion: 1,
  toVersion: 2,
  appliesTo: "colors-and-type",
  apply: renameKeys
};
var componentMigration_2026_05_13_primaryToBrand = {
  id: "2026-05-13-primary-to-brand-component",
  fromVersion: 5,
  toVersion: 6,
  appliesTo: "component-config",
  apply: renameKeysAndValues
};

// src/editor/core/themes/migrations/2026-05-19-collapsiblesection-drop-frame-surface.ts
function dropFrameSurface(rawVars, meta) {
  if (meta.component !== "collapsiblesection") return rawVars;
  const { "--collapsiblesection-container-frame-surface": _drop, ...rest } = rawVars;
  return rest;
}
var componentMigration_2026_05_19_collapsiblesectionDropFrameSurface = {
  id: "2026-05-19-collapsiblesection-drop-frame-surface",
  fromVersion: 6,
  toVersion: 7,
  appliesTo: "component-config",
  apply: dropFrameSurface
};

// src/editor/core/themes/migrations/2026-05-19-sectiondivider-rich-gradient.ts
var FLAT_RE = /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-gradient-(angle|stop-[123]-(color|position))$/;
var componentMigration_2026_05_19_sectiondividerRichGradient = {
  id: "2026-05-19-sectiondivider-rich-gradient",
  fromVersion: 7,
  toVersion: 8,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (FLAT_RE.test(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-20-sectiondivider-slim-variants.ts
var VARIANTS2 = ["lg", "md", "sm"];
var SUFFIX_RENAMES = [
  [/-title-border-width$/, "-title-outline-width"],
  [/-title-stroke-color$/, "-title-outline-color"],
  [
    /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-padding$/,
    "--sectiondivider-$1-spacing"
  ]
];
function renameKeySuffix(key) {
  for (const [re, repl] of SUFFIX_RENAMES) {
    if (re.test(key)) return key.replace(re, repl);
  }
  return key;
}
function splitFamilyKey(key) {
  const m = key.match(/^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-(.+)$/);
  if (!m) return null;
  return { family: m[1], suffix: m[2] };
}
var componentMigration_2026_05_20_sectiondividerSlimVariants = {
  id: "2026-05-20-sectiondivider-slim-variants",
  fromVersion: 8,
  toVersion: 9,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    const canvasValues = {};
    for (const [rawKey, value] of Object.entries(rawVars)) {
      const key = renameKeySuffix(rawKey);
      const parts = splitFamilyKey(key);
      if (!parts) {
        out[key] = value;
        continue;
      }
      if (parts.family !== "canvas") continue;
      canvasValues[parts.suffix] = value;
    }
    for (const suffix of Object.keys(canvasValues)) {
      for (const v of VARIANTS2) {
        out[`--sectiondivider-${v}-${suffix}`] = canvasValues[suffix];
      }
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-21-sectiondivider-spacing-to-padding.ts
var componentMigration_2026_05_21_sectiondividerSpacingToPadding = {
  id: "2026-05-21-sectiondivider-spacing-to-padding",
  fromVersion: 9,
  toVersion: 10,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const renamed = key.replace(
        /^--sectiondivider-(lg|md|sm)-spacing$/,
        "--sectiondivider-$1-padding"
      );
      out[renamed] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-22-sectiondivider-intrinsics-to-css.ts
var componentMigration_2026_05_22_sectiondividerIntrinsicsToCss = {
  id: "2026-05-22-sectiondivider-intrinsics-to-css",
  fromVersion: 10,
  toVersion: 11,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const VARIANTS4 = ["lg", "md", "sm"];
    const prefix = "--sectiondivider-";
    const dropped = /* @__PURE__ */ new Set();
    for (const v of VARIANTS4) {
      dropped.add(`${prefix}${v}-show-eyebrow`);
      dropped.add(`${prefix}${v}-show-description`);
      dropped.add(`${prefix}${v}-show-hairline`);
      dropped.add(`${prefix}${v}-hairline`);
      dropped.add(`${prefix}${v}-eyebrow-uppercase`);
    }
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (dropped.has(key)) continue;
      out[key] = value;
    }
    for (const v of VARIANTS4) {
      const showEyebrow = rawVars[`${prefix}${v}-show-eyebrow`];
      if (showEyebrow !== void 0) {
        out[`${prefix}${v}-eyebrow-display`] = showEyebrow === "1" ? "block" : "none";
      }
      const showDesc = rawVars[`${prefix}${v}-show-description`];
      if (showDesc !== void 0) {
        out[`${prefix}${v}-description-display`] = showDesc === "1" ? "flex" : "none";
      }
      const showHair = rawVars[`${prefix}${v}-show-hairline`];
      const oldHair = rawVars[`${prefix}${v}-hairline`];
      const oldHairIsPos = typeof oldHair === "string" && oldHair !== "" && oldHair !== "off";
      let newHair;
      if (showHair === "") newHair = "none";
      else if (showHair === "1") newHair = oldHairIsPos ? oldHair : "above-label";
      else if (oldHair !== void 0) newHair = oldHairIsPos ? oldHair : "none";
      if (newHair !== void 0) {
        out[`${prefix}${v}-hairline`] = newHair;
      }
      const upper = rawVars[`${prefix}${v}-eyebrow-uppercase`];
      if (upper !== void 0) {
        out[`${prefix}${v}-eyebrow-text-transform`] = upper === "1" ? "uppercase" : "none";
      }
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-segmentedcontrol-divider-inset.ts
var componentMigration_2026_05_24_segmentedcontrolDividerInset = {
  id: "2026-05-24-segmentedcontrol-divider-inset",
  fromVersion: 11,
  toVersion: 12,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === "--segmentedcontrol-divider-height") continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-promote-state-shared-tokens.ts
var BUTTON_VARIANTS = ["primary", "secondary", "outline", "success", "danger", "warning"];
var BUTTON_STATES = ["hover", "disabled"];
var BUTTON_PROPS = ["padding", "radius", "border-width"];
var buttonDeadKeys = new Set(
  BUTTON_VARIANTS.flatMap(
    (v) => BUTTON_STATES.flatMap(
      (s) => BUTTON_PROPS.map((p) => `--button-${v}-${s}-${p}`)
    )
  )
);
var segmentedcontrolDeadKeys = /* @__PURE__ */ new Set([
  "--segmentedcontrol-selected-icon-size",
  "--segmentedcontrol-option-hover-icon-size",
  "--segmentedcontrol-disabled-icon-size"
]);
var componentMigration_2026_05_24_promoteStateSharedTokens = {
  id: "2026-05-24-promote-state-shared-tokens",
  fromVersion: 12,
  toVersion: 13,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const dead = meta.component === "button" ? buttonDeadKeys : meta.component === "segmentedcontrol" ? segmentedcontrolDeadKeys : null;
    if (!dead) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (dead.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-progressbar-collapse-variants.ts
var PRIMARY_PREFIX = "--progressbar-primary-";
var NEW_PREFIX = "--progressbar-";
var DROP_PREFIXES = [
  "--progressbar-success-",
  "--progressbar-warning-",
  "--progressbar-danger-",
  "--progressbar-info-"
];
var componentMigration_2026_05_24_progressbarCollapseVariants = {
  id: "2026-05-24-progressbar-collapse-variants",
  fromVersion: 13,
  toVersion: 14,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "progressbar") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      if (DROP_PREFIXES.some((p) => oldKey.startsWith(p))) continue;
      const key = oldKey.startsWith(PRIMARY_PREFIX) ? NEW_PREFIX + oldKey.slice(PRIMARY_PREFIX.length) : oldKey;
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-collapsiblesection-drop-active-state.ts
function dropActiveState(rawVars, meta) {
  if (meta.component !== "collapsiblesection") return rawVars;
  const re = /^--collapsiblesection-(chromeless|divider|container)-active-/;
  const out = {};
  for (const [key, value] of Object.entries(rawVars)) {
    if (re.test(key)) continue;
    out[key] = value;
  }
  return out;
}
var componentMigration_2026_05_24_collapsiblesectionDropActiveState = {
  id: "2026-05-24-collapsiblesection-drop-active-state",
  fromVersion: 14,
  toVersion: 15,
  appliesTo: "component-config",
  apply: dropActiveState
};

// src/editor/core/themes/migrations/2026-05-25-cornerbadge-flatten-variants.ts
var VARIANTS3 = ["primary", "accent", "neutral", "alternate", "canvas", "special", "success", "warning", "danger", "info"];
var RE = new RegExp(`^--corner-badge-(${VARIANTS3.join("|")})-(.+)$`);
var CURRENT_COLOR_PROPS = /* @__PURE__ */ new Set(["surface", "border", "text"]);
function flattenVariants(rawVars, meta) {
  if (meta.component !== "cornerbadge") return rawVars;
  const out = {};
  const collected = /* @__PURE__ */ new Map();
  for (const [key, value] of Object.entries(rawVars)) {
    const m = key.match(RE);
    if (m) {
      const prop = m[2];
      if (CURRENT_COLOR_PROPS.has(prop)) {
        out[key] = value;
        continue;
      }
      if (!collected.has(prop)) collected.set(prop, value);
      continue;
    }
    out[key] = value;
  }
  for (const [prop, value] of collected) {
    const flatKey = `--corner-badge-${prop}`;
    if (!(flatKey in out)) out[flatKey] = value;
  }
  return out;
}
var componentMigration_2026_05_25_cornerbadgeFlattenVariants = {
  id: "2026-05-25-cornerbadge-flatten-variants",
  fromVersion: 15,
  toVersion: 16,
  appliesTo: "component-config",
  apply: flattenVariants
};

// src/editor/core/themes/migrations/2026-05-26-drop-overlay-extra-stops.ts
var DROPPED_TO_KEPT = {
  "--overlay-lowest": "--overlay-low",
  "--overlay-lower": "--overlay-low",
  "--overlay-higher": "--overlay-high",
  "--overlay-highest": "--overlay-high"
};
var colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops = {
  id: "2026-05-26-drop-overlay-extra-stops-theme",
  fromVersion: 2,
  toVersion: 3,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key in DROPPED_TO_KEPT) continue;
      out[key] = value;
    }
    return out;
  }
};
var componentMigration_2026_05_26_dropOverlayExtraStops = {
  id: "2026-05-26-drop-overlay-extra-stops-component",
  fromVersion: 16,
  toVersion: 17,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[key] = DROPPED_TO_KEPT[value] ?? value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-tabbar-indicator-thickness-to-per-state-width.ts
var TABBAR_STATES = ["default", "hover", "active", "disabled"];
var OLD_KEY = "--tabbar-bar-indicator-thickness";
var FALLBACK = "--border-width-2";
var componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth = {
  id: "2026-05-29-tabbar-indicator-thickness-to-per-state-width",
  fromVersion: 17,
  toVersion: 18,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "tabbar") return { ...rawVars };
    const seed = rawVars[OLD_KEY] ?? FALLBACK;
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === OLD_KEY) continue;
      out[key] = value;
    }
    for (const state of TABBAR_STATES) {
      const newKey = `--tabbar-${state}-indicator-border-width`;
      if (!(newKey in out)) out[newKey] = seed;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-segmentedcontrol-small-divider-rename.ts
var RENAMES = {
  "--segmentedcontrol-divider-small-thickness": "--segmentedcontrol-small-divider-thickness",
  "--segmentedcontrol-divider-small-inset": "--segmentedcontrol-small-divider-inset"
};
var componentMigration_2026_05_29_segmentedcontrolSmallDividerRename = {
  id: "2026-05-29-segmentedcontrol-small-divider-rename",
  fromVersion: 18,
  toVersion: 19,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMES[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-toggle-derive-track-from-thumb.ts
var componentMigration_2026_05_29_toggleDeriveTrackFromThumb = {
  id: "2026-05-29-toggle-derive-track-from-thumb",
  fromVersion: 19,
  toVersion: 20,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "toggle") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === "--toggle-track-width" || key === "--toggle-track-thickness") continue;
      out[key] = value;
    }
    if (!("--toggle-track-padding" in out)) {
      out["--toggle-track-padding"] = "--space-2";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-08-13-drop-legacy-shape-space-keys.ts
var DROPPED = /* @__PURE__ */ new Set([
  "--badge-trait-radius",
  "--badge-trait-padding",
  "--sectiondivider-padding",
  "--dialog-primary-default-radius",
  "--dialog-primary-default-padding",
  "--dialog-primary-hover-radius",
  "--dialog-primary-hover-padding",
  "--dialog-secondary-default-radius",
  "--dialog-secondary-default-padding",
  "--dialog-secondary-hover-radius",
  "--dialog-secondary-hover-padding"
]);
var colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys = {
  id: "2026-08-13-drop-legacy-shape-space-keys",
  fromVersion: 3,
  toVersion: 4,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-08-15-line-height-scale-rename.ts
var RENAMED = {
  "--line-height-xs": "--line-height-none",
  "--line-height-sm": "--line-height-tighter",
  "--line-height-md": "--line-height-normal",
  "--line-height-lg": "--line-height-relaxed",
  "--line-height-xl": "--line-height-relaxed"
};
var REFERENCE = /--line-height-(?:xs|sm|md|lg|xl)(?![\w-])/g;
function renameValues(rawVars) {
  const out = {};
  for (const [key, value] of Object.entries(rawVars)) {
    out[key] = typeof value === "string" ? value.replace(REFERENCE, (name) => RENAMED[name]) : value;
  }
  return out;
}
var colorsAndTypeMigration_2026_08_15_lineHeightScaleRename = {
  id: "2026-08-15-line-height-scale-rename-colors-and-type",
  fromVersion: 4,
  toVersion: 5,
  appliesTo: "colors-and-type",
  apply: renameValues
};
var componentMigration_2026_08_15_lineHeightScaleRename = {
  id: "2026-08-15-line-height-scale-rename-component",
  fromVersion: 20,
  toVersion: 21,
  appliesTo: "component-config",
  apply: renameValues
};

// src/editor/core/themes/migrations/2026-09-01-scrim-rename.ts
var RENAMED2 = {
  "--overlay-low": "--scrim-low",
  "--overlay": "--scrim",
  "--overlay-high": "--scrim-high"
};
var RENAMED_COMPONENT_KEYS = {
  "--dialog-overlay-surface": "--dialog-scrim-surface"
};
var colorsAndTypeMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename-theme",
  fromVersion: 5,
  toVersion: 6,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMED2[key] ?? key] = value;
    }
    return out;
  }
};
var componentMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename-component",
  fromVersion: 21,
  toVersion: 22,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMED_COMPONENT_KEYS[key] ?? key] = RENAMED2[value] ?? value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-tint-rename.ts
var RENAMED3 = {
  "--hover-low": "--tint-low",
  "--hover": "--tint",
  "--hover-high": "--tint-high"
};
var colorsAndTypeMigration_2026_09_01_tintRename = {
  id: "2026-09-01-tint-rename-theme",
  fromVersion: 6,
  toVersion: 7,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[RENAMED3[key] ?? key] = value;
    return out;
  }
};
var componentMigration_2026_09_01_tintRename = {
  id: "2026-09-01-tint-rename-component",
  fromVersion: 22,
  toVersion: 23,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[key] = RENAMED3[value] ?? value;
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-tabbar-active-tint.ts
var componentMigration_2026_09_01_tabbarActiveTint = {
  id: "2026-09-01-tabbar-active-tint",
  fromVersion: 23,
  toVersion: 24,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "tabbar") return { ...rawVars };
    const out = { ...rawVars };
    if (out["--tabbar-active-surface"] === "--scrim-low") {
      out["--tabbar-active-surface"] = "--tint-low";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-gate-suffix-enabled.ts
var RENAMED4 = {
  "--card-hover-border-active": "--card-hover-border-enabled",
  "--card-hover-shadow-active": "--card-hover-shadow-enabled",
  "--image-zoom-hover": "--image-zoom-enabled",
  "--image-grow-hover": "--image-grow-enabled"
};
var componentMigration_2026_09_01_gateSuffixEnabled = {
  id: "2026-09-01-gate-suffix-enabled",
  fromVersion: 24,
  toVersion: 25,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[RENAMED4[key] ?? key] = value;
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-02-sectiondivider-drop-title-outline.ts
var DROPPED2 = new Set(
  ["lg", "md", "sm"].flatMap((v) => [
    `--sectiondivider-${v}-title-outline-width`,
    `--sectiondivider-${v}-title-outline-color`
  ])
);
var componentMigration_2026_09_02_sectiondividerDropTitleOutline = {
  id: "2026-09-02-sectiondivider-drop-title-outline",
  fromVersion: 25,
  toVersion: 26,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED2.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-03-drop-legacy-component-keys.ts
var DROPPED3 = /* @__PURE__ */ new Set([
  "--badge-trait-surface",
  "--badge-trait-text",
  "--badge-trait-text-font-family",
  "--badge-trait-text-font-size",
  "--badge-trait-text-font-weight",
  "--badge-trait-text-line-height",
  "--badge-trait-border",
  "--badge-trait-border-width",
  "--badge-trait-shadow",
  "--sectiondivider-title",
  "--sectiondivider-title-font-family",
  "--sectiondivider-title-font-size",
  "--sectiondivider-title-font-weight",
  "--sectiondivider-title-line-height",
  "--sectiondivider-title-border-width",
  "--sectiondivider-title-stroke-color",
  "--sectiondivider-description",
  "--sectiondivider-description-font-family",
  "--sectiondivider-description-font-size",
  "--sectiondivider-description-font-weight",
  "--sectiondivider-description-line-height",
  "--dialog-primary-default-surface",
  "--dialog-primary-default-text",
  "--dialog-primary-default-border",
  "--dialog-primary-default-border-width",
  "--dialog-primary-hover-surface",
  "--dialog-primary-hover-text",
  "--dialog-primary-hover-border",
  "--dialog-primary-hover-border-width",
  "--dialog-secondary-default-text",
  "--dialog-secondary-default-border",
  "--dialog-secondary-default-border-width",
  "--dialog-secondary-hover-surface",
  "--dialog-secondary-hover-text",
  "--dialog-secondary-hover-border",
  "--dialog-secondary-hover-border-width"
]);
var colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys = {
  id: "2026-09-03-drop-legacy-component-keys",
  fromVersion: 7,
  toVersion: 8,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED3.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-07-stroke-role-renames.ts
var RENAMES2 = {
  tabbar: Object.fromEntries(
    ["default", "hover", "active", "disabled"].map((s) => [
      `--tabbar-${s}-indicator-border-width`,
      `--tabbar-${s}-indicator-width`
    ])
  ),
  collapsiblesection: Object.fromEntries(
    ["default", "hover"].flatMap((s) => [
      [`--collapsiblesection-divider-${s}-border`, `--collapsiblesection-divider-${s}-hairline-color`],
      [`--collapsiblesection-divider-${s}-border-width`, `--collapsiblesection-divider-${s}-hairline-thickness`]
    ])
  ),
  dialog: Object.fromEntries(
    ["header", "footer"].flatMap((part) => [
      [`--dialog-${part}-border`, `--dialog-${part}-divider`],
      [`--dialog-${part}-border-width`, `--dialog-${part}-divider-width`]
    ])
  ),
  table: {
    "--table-default-header-border": "--table-default-header-divider",
    "--table-default-header-border-width": "--table-default-header-divider-width"
  }
};
var componentMigration_2026_09_07_strokeRoleRenames = {
  id: "2026-09-07-stroke-role-renames",
  fromVersion: 26,
  toVersion: 27,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES2[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-selected-state.ts
var RADIOBUTTON_SUFFIXES = [
  "dot-border-color",
  "dot-border-width",
  "dot-fill",
  "dot-size",
  "label",
  "label-font-family",
  "label-font-size",
  "label-font-weight",
  "label-line-height"
];
var TABBAR_SUFFIXES = [
  "border",
  "icon-size",
  "indicator-width",
  "padding",
  "surface",
  "tab-border-color",
  "tab-border-width",
  "tab-bottom-radius",
  "tab-top-radius",
  "text",
  "text-font-family",
  "text-font-size",
  "text-font-weight",
  "text-line-height"
];
var SIDENAVIGATION_SUFFIXES = {
  title: [
    "accent",
    "accent-width",
    "border",
    "border-width",
    "label",
    "label-font-family",
    "label-font-size",
    "label-font-weight",
    "label-line-height",
    "padding",
    "surface"
  ],
  section: [
    "accent",
    "accent-width",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ],
  item: [
    "accent",
    "accent-width",
    "padding",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ],
  footer: [
    "accent",
    "accent-width",
    "gap",
    "icon",
    "icon-size",
    "padding",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ]
};
var RENAMES3 = {
  radiobutton: Object.fromEntries(
    RADIOBUTTON_SUFFIXES.map((s) => [`--radiobutton-active-${s}`, `--radiobutton-selected-${s}`])
  ),
  tabbar: Object.fromEntries(
    TABBAR_SUFFIXES.map((s) => [`--tabbar-active-${s}`, `--tabbar-selected-${s}`])
  ),
  sidenavigation: Object.fromEntries(
    Object.entries(SIDENAVIGATION_SUFFIXES).flatMap(
      ([part, suffixes]) => suffixes.map((s) => [
        `--sidenavigation-${part}-active-${s}`,
        `--sidenavigation-${part}-selected-${s}`
      ])
    )
  )
};
var componentMigration_2026_09_13_selectedState = {
  id: "2026-09-13-selected-state",
  fromVersion: 27,
  toVersion: 28,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES3[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-hairline.ts
var COLLAPSIBLESECTION_SUFFIXES = [
  "surface",
  "hairline-color",
  "padding",
  "label",
  "label-font-family",
  "label-font-size",
  "label-font-weight",
  "label-line-height",
  "icon",
  "icon-size"
];
var COLLAPSIBLESECTION_STATES = ["default", "hover"];
var RENAMES4 = {
  dialog: {
    "--dialog-header-divider": "--dialog-header-hairline-color",
    "--dialog-header-divider-width": "--dialog-header-hairline-width",
    "--dialog-footer-divider": "--dialog-footer-hairline-color",
    "--dialog-footer-divider-width": "--dialog-footer-hairline-width"
  },
  table: {
    "--table-default-header-divider": "--table-default-header-hairline-color",
    "--table-default-header-divider-width": "--table-default-header-hairline-width",
    "--table-default-row-divider": "--table-default-row-hairline-color",
    "--table-default-row-divider-width": "--table-default-row-hairline-width",
    "--table-default-column-divider": "--table-default-column-hairline-color",
    "--table-default-column-divider-width": "--table-default-column-hairline-width"
  },
  tabbar: {
    "--tabbar-bar-divider": "--tabbar-bar-hairline-color",
    "--tabbar-bar-divider-thickness": "--tabbar-bar-hairline-width"
  },
  segmentedcontrol: {
    "--segmentedcontrol-divider-color": "--segmentedcontrol-hairline-color",
    "--segmentedcontrol-divider-thickness": "--segmentedcontrol-hairline-width",
    "--segmentedcontrol-divider-inset": "--segmentedcontrol-hairline-inset",
    "--segmentedcontrol-small-divider-thickness": "--segmentedcontrol-small-hairline-width",
    "--segmentedcontrol-small-divider-inset": "--segmentedcontrol-small-hairline-inset"
  },
  collapsiblesection: {
    ...Object.fromEntries(
      COLLAPSIBLESECTION_STATES.flatMap((state) => [
        ...COLLAPSIBLESECTION_SUFFIXES.map((s) => [
          `--collapsiblesection-divider-${state}-${s}`,
          `--collapsiblesection-hairline-${state}-${s}`
        ]),
        [
          `--collapsiblesection-divider-${state}-hairline-thickness`,
          `--collapsiblesection-hairline-${state}-hairline-width`
        ]
      ])
    ),
    "--collapsiblesection-divider-expanded-padding": "--collapsiblesection-hairline-expanded-padding"
  },
  sectiondivider: {
    "--sectiondivider-lg-hairline-thickness": "--sectiondivider-lg-hairline-width",
    "--sectiondivider-md-hairline-thickness": "--sectiondivider-md-hairline-width",
    "--sectiondivider-sm-hairline-thickness": "--sectiondivider-sm-hairline-width"
  }
};
var componentMigration_2026_09_13_hairline = {
  id: "2026-09-13-hairline",
  fromVersion: 28,
  toVersion: 29,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES4[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-indicator.ts
var SIDENAVIGATION_PARTS = ["title", "section", "item", "footer"];
var SIDENAVIGATION_STATES = ["default", "hover", "selected"];
var CALLOUT_VARIANTS = ["info", "success", "warning", "danger"];
var RENAMES5 = {
  sidenavigation: Object.fromEntries(
    SIDENAVIGATION_PARTS.flatMap(
      (part) => SIDENAVIGATION_STATES.flatMap((state) => [
        [
          `--sidenavigation-${part}-${state}-accent`,
          `--sidenavigation-${part}-${state}-indicator`
        ],
        [
          `--sidenavigation-${part}-${state}-accent-width`,
          `--sidenavigation-${part}-${state}-indicator-width`
        ]
      ])
    )
  ),
  callout: Object.fromEntries(
    CALLOUT_VARIANTS.map((v) => [
      `--callout-${v}-accent-width`,
      `--callout-${v}-indicator-width`
    ])
  )
};
var componentMigration_2026_09_13_indicator = {
  id: "2026-09-13-indicator",
  fromVersion: 29,
  toVersion: 30,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES5[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-sectiondivider-surface.ts
var SECTIONDIVIDER_VARIANTS = ["lg", "md", "sm"];
var RENAMES6 = {
  sectiondivider: Object.fromEntries(
    SECTIONDIVIDER_VARIANTS.map((v) => [
      `--sectiondivider-${v}-background`,
      `--sectiondivider-${v}-surface`
    ])
  )
};
var componentMigration_2026_09_13_sectiondividerSurface = {
  id: "2026-09-13-sectiondivider-surface",
  fromVersion: 30,
  toVersion: 31,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES6[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-20-imagelightbox-scrim.ts
var RENAMES7 = {
  "--imagelightbox-overlay-surface": "--imagelightbox-scrim-surface"
};
var componentMigration_2026_09_20_imagelightboxScrim = {
  id: "2026-09-20-imagelightbox-scrim",
  fromVersion: 35,
  toVersion: 36,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "imagelightbox") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMES7[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-20-scrim-color-and-opacity.ts
var STOPS = {
  "--scrim-low": "--scrim-opacity-low",
  "--scrim": "--scrim-opacity",
  "--scrim-high": "--scrim-opacity-high"
};
var SURFACE = /^--(imagelightbox|dialog)-scrim-surface$/;
var componentMigration_2026_09_20_scrimColorAndOpacity = {
  id: "2026-09-20-scrim-color-and-opacity",
  fromVersion: 36,
  toVersion: 37,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const match = SURFACE.exec(key);
      if (!match) {
        out[key] = value;
        continue;
      }
      const stem = `--${match[1]}-scrim`;
      const stop = STOPS[value];
      out[`${stem}-color`] = stop ? "--scrim-color" : value;
      out[`${stem}-opacity`] = stop ?? "1";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-21-wash-color-and-opacity.ts
var FAMILIES = ["scrim", "tint"];
var COLOR_MIX_RE = /^color-mix\(in srgb,\s*var\((--[a-z0-9-]+)\)\s+(\d+(?:\.\d+)?)%,\s*transparent\)$/i;
var PLAIN_VAR_RE = /^var\((--[a-z0-9-]+)\)$/i;
function parseFill(raw) {
  const s = raw.trim();
  const mix = s.match(COLOR_MIX_RE);
  if (mix) return { color: mix[1], opacity: Math.min(100, Number(mix[2])) / 100 };
  const plain = s.match(PLAIN_VAR_RE);
  return plain ? { color: plain[1], opacity: 1 } : null;
}
var colorsAndTypeMigration_2026_09_21_washColorAndOpacity = {
  id: "2026-09-21-wash-color-and-opacity",
  fromVersion: 8,
  toVersion: 9,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = { ...rawVars };
    for (const family of FAMILIES) {
      let color = null;
      for (const suffix of ["", "-low", "-high"]) {
        const key = `--${family}${suffix}`;
        const parsed = out[key] === void 0 ? null : parseFill(out[key]);
        if (!parsed) continue;
        color ??= parsed.color;
        out[`--${family}-opacity${suffix}`] = String(parsed.opacity);
        delete out[key];
      }
      if (color) out[`--${family}-color`] = `var(${color})`;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-10-15-responsive-columns.ts
var RENAMES8 = {
  "--columns-gutter": "--columns-desktop-gutter",
  "--columns-margin": "--columns-desktop-margin"
};
var SHIPPED = {
  "--columns-count": ["12"],
  "--columns-gutter": ["32px"],
  "--columns-margin": ["0px", "0"]
};
var colorsAndTypeMigration_2026_10_15_responsiveColumns = {
  id: "2026-10-15-responsive-columns",
  fromVersion: 9,
  toVersion: 10,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    return Object.fromEntries(
      Object.entries(rawVars).filter(([name, value]) => !SHIPPED[name]?.includes(value.trim())).map(([name, value]) => [RENAMES8[name] ?? name, value])
    );
  }
};

// src/editor/core/themes/migrations/2026-09-21-scrim-surface.ts
var STOPS2 = {
  "--scrim-opacity-low": "--scrim-low",
  "--scrim-opacity": "--scrim",
  "--scrim-opacity-high": "--scrim-high"
};
var PAIR = /^--(imagelightbox|dialog)-scrim-(color|opacity)$/;
var ref = (value) => value.startsWith("--") ? `var(${value})` : value;
function fill(color, opacity) {
  if (color === "--scrim-color" && STOPS2[opacity]) return STOPS2[opacity];
  if (opacity === "1") return color;
  const pct = Number.isFinite(Number(opacity)) ? `${Number(opacity) * 100}%` : `calc(${ref(opacity)} * 100%)`;
  return `color-mix(in srgb, ${ref(color)} ${pct}, transparent)`;
}
var componentMigration_2026_09_21_scrimSurface = {
  id: "2026-09-21-scrim-surface",
  fromVersion: 37,
  toVersion: 38,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    const pairs = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const match = PAIR.exec(key);
      if (!match) {
        out[key] = value;
        continue;
      }
      (pairs[match[1]] ??= {})[match[2]] = value;
    }
    for (const [id, { color = "--scrim-color", opacity = "--scrim-opacity-high" }] of Object.entries(pairs)) {
      out[`--${id}-scrim-surface`] = fill(color, opacity);
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-cornerbadge-prefix.ts
var RENAMES9 = {
  cornerbadge: {
    "--corner-badge-margin": "--cornerbadge-margin",
    "--corner-badge-outer-radius": "--cornerbadge-outer-radius",
    "--corner-badge-inner-radius": "--cornerbadge-inner-radius",
    "--corner-badge-h-axis-radius": "--cornerbadge-h-axis-radius",
    "--corner-badge-v-axis-radius": "--cornerbadge-v-axis-radius",
    "--corner-badge-padding": "--cornerbadge-padding",
    "--corner-badge-text-font-family": "--cornerbadge-text-font-family",
    "--corner-badge-text-font-size": "--cornerbadge-text-font-size",
    "--corner-badge-text-font-weight": "--cornerbadge-text-font-weight",
    "--corner-badge-text-line-height": "--cornerbadge-text-line-height",
    "--corner-badge-primary-surface": "--cornerbadge-primary-surface",
    "--corner-badge-primary-border": "--cornerbadge-primary-border",
    "--corner-badge-primary-text": "--cornerbadge-primary-text",
    "--corner-badge-accent-surface": "--cornerbadge-accent-surface",
    "--corner-badge-accent-border": "--cornerbadge-accent-border",
    "--corner-badge-accent-text": "--cornerbadge-accent-text",
    "--corner-badge-neutral-surface": "--cornerbadge-neutral-surface",
    "--corner-badge-neutral-border": "--cornerbadge-neutral-border",
    "--corner-badge-neutral-text": "--cornerbadge-neutral-text",
    "--corner-badge-alternate-surface": "--cornerbadge-alternate-surface",
    "--corner-badge-alternate-border": "--cornerbadge-alternate-border",
    "--corner-badge-alternate-text": "--cornerbadge-alternate-text",
    "--corner-badge-canvas-surface": "--cornerbadge-canvas-surface",
    "--corner-badge-canvas-border": "--cornerbadge-canvas-border",
    "--corner-badge-canvas-text": "--cornerbadge-canvas-text",
    "--corner-badge-special-surface": "--cornerbadge-special-surface",
    "--corner-badge-special-border": "--cornerbadge-special-border",
    "--corner-badge-special-text": "--cornerbadge-special-text",
    "--corner-badge-success-surface": "--cornerbadge-success-surface",
    "--corner-badge-success-border": "--cornerbadge-success-border",
    "--corner-badge-success-text": "--cornerbadge-success-text",
    "--corner-badge-warning-surface": "--cornerbadge-warning-surface",
    "--corner-badge-warning-border": "--cornerbadge-warning-border",
    "--corner-badge-warning-text": "--cornerbadge-warning-text",
    "--corner-badge-danger-surface": "--cornerbadge-danger-surface",
    "--corner-badge-danger-border": "--cornerbadge-danger-border",
    "--corner-badge-danger-text": "--cornerbadge-danger-text",
    "--corner-badge-info-surface": "--cornerbadge-info-surface",
    "--corner-badge-info-border": "--cornerbadge-info-border",
    "--corner-badge-info-text": "--cornerbadge-info-text"
  }
};
var componentMigration_2026_09_13_cornerbadgePrefix = {
  id: "2026-09-13-cornerbadge-prefix",
  fromVersion: 31,
  toVersion: 32,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES9[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-toggle-label.ts
var RENAMES10 = {
  toggle: {
    "--toggle-label-text": "--toggle-label",
    "--toggle-disabled-label-text": "--toggle-disabled-label"
  }
};
var componentMigration_2026_09_13_toggleLabel = {
  id: "2026-09-13-toggle-label",
  fromVersion: 32,
  toVersion: 33,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES10[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-collapsiblesection-open.ts
var RENAMES11 = {
  collapsiblesection: {
    "--collapsiblesection-chromeless-expanded-padding": "--collapsiblesection-chromeless-open-padding",
    "--collapsiblesection-hairline-expanded-padding": "--collapsiblesection-hairline-open-padding",
    "--collapsiblesection-container-expanded-surface": "--collapsiblesection-container-open-surface",
    "--collapsiblesection-container-expanded-padding": "--collapsiblesection-container-open-padding"
  }
};
var componentMigration_2026_09_13_collapsiblesectionOpen = {
  id: "2026-09-13-collapsiblesection-open",
  fromVersion: 33,
  toVersion: 34,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES11[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-badge-brand.ts
var BADGE_SUFFIXES = [
  "surface",
  "text",
  "border",
  "text-font-family",
  "text-font-size",
  "text-font-weight",
  "text-line-height",
  "border-width",
  "radius",
  "padding",
  "shadow",
  "blur",
  "icon-size"
];
var CORNERBADGE_SUFFIXES = ["surface", "border", "text"];
var RENAMES12 = {
  badge: Object.fromEntries(
    BADGE_SUFFIXES.map((s) => [`--badge-primary-${s}`, `--badge-brand-${s}`])
  ),
  cornerbadge: Object.fromEntries(
    CORNERBADGE_SUFFIXES.map((s) => [`--cornerbadge-primary-${s}`, `--cornerbadge-brand-${s}`])
  )
};
var componentMigration_2026_09_13_badgeBrand = {
  id: "2026-09-13-badge-brand",
  fromVersion: 34,
  toVersion: 35,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES12[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/index.ts
var MIGRATIONS = [
  colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas,
  colorsAndTypeMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_04_24_prefixAndSuffixRenames,
  componentMigration_2026_04_27_segmentedcontrolDisabledFlatten,
  componentMigration_2026_05_08_collapsiblesectionVariantNamespace,
  componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup,
  componentMigration_2026_05_10_sectiondividerGradientStops,
  componentMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_05_19_collapsiblesectionDropFrameSurface,
  componentMigration_2026_05_19_sectiondividerRichGradient,
  componentMigration_2026_05_20_sectiondividerSlimVariants,
  componentMigration_2026_05_21_sectiondividerSpacingToPadding,
  componentMigration_2026_05_22_sectiondividerIntrinsicsToCss,
  componentMigration_2026_05_24_segmentedcontrolDividerInset,
  componentMigration_2026_05_24_promoteStateSharedTokens,
  componentMigration_2026_05_24_progressbarCollapseVariants,
  componentMigration_2026_05_24_collapsiblesectionDropActiveState,
  componentMigration_2026_05_25_cornerbadgeFlattenVariants,
  colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth,
  componentMigration_2026_05_29_segmentedcontrolSmallDividerRename,
  componentMigration_2026_05_29_toggleDeriveTrackFromThumb,
  colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys,
  colorsAndTypeMigration_2026_08_15_lineHeightScaleRename,
  componentMigration_2026_08_15_lineHeightScaleRename,
  colorsAndTypeMigration_2026_09_01_scrimRename,
  componentMigration_2026_09_01_scrimRename,
  colorsAndTypeMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tabbarActiveTint,
  componentMigration_2026_09_01_gateSuffixEnabled,
  componentMigration_2026_09_02_sectiondividerDropTitleOutline,
  colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys,
  componentMigration_2026_09_07_strokeRoleRenames,
  componentMigration_2026_09_13_selectedState,
  componentMigration_2026_09_13_hairline,
  componentMigration_2026_09_13_indicator,
  componentMigration_2026_09_13_sectiondividerSurface,
  componentMigration_2026_09_13_cornerbadgePrefix,
  componentMigration_2026_09_13_toggleLabel,
  componentMigration_2026_09_13_collapsiblesectionOpen,
  componentMigration_2026_09_13_badgeBrand,
  componentMigration_2026_09_20_imagelightboxScrim,
  componentMigration_2026_09_20_scrimColorAndOpacity,
  colorsAndTypeMigration_2026_09_21_washColorAndOpacity,
  componentMigration_2026_09_21_scrimSurface,
  colorsAndTypeMigration_2026_10_15_responsiveColumns
];
function countFor(kind) {
  return MIGRATIONS.filter((m) => m.appliesTo === kind).length;
}
var CURRENT_COLORS_AND_TYPE_SCHEMA_VERSION = countFor("colors-and-type");
var CURRENT_COMPONENT_SCHEMA_VERSION = countFor("component-config");
function runMigrations(kind, fileVersion, rawVars, meta = {}) {
  const applicable = MIGRATIONS.filter((m) => m.appliesTo === kind && m.fromVersion >= fileVersion).sort((a, b) => a.toVersion - b.toVersion);
  let out = { ...rawVars };
  for (const m of applicable) {
    out = m.apply(out, meta);
  }
  return out;
}

// src/editor/core/themes/migrateComponentConfig.ts
function migrateComponentConfig(component, aliasesIn, rawConfig, fileVersion) {
  const stringPart = {};
  const objectPart = {};
  for (const [k, v] of Object.entries(aliasesIn)) {
    if (typeof v === "string") stringPart[k] = v;
    else objectPart[k] = v;
  }
  const configOut = {};
  for (const [k, v] of Object.entries(rawConfig ?? {})) {
    if (typeof v === "string") stringPart[k] = v;
    else configOut[k] = v;
  }
  if (component === "sectiondivider") {
    synthesizeSectionDividerGradients(stringPart, objectPart);
  }
  const migratedString = runMigrations("component-config", fileVersion, stringPart, { component });
  const migratedObject = component === "sectiondivider" ? renameSectionDividerObjectSlots(objectPart) : objectPart;
  return {
    aliases: { ...migratedString, ...migratedObject },
    config: configOut
  };
}
var FAMILIES2 = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
var SIZE_VARIANTS = ["lg", "md", "sm"];
function renameSectionDividerObjectSlots(objectPart) {
  const canvasSourceKeys = [
    "--sectiondivider-canvas-background",
    "--sectiondivider-canvas-gradient",
    "--sectiondivider-color-canvas-background"
  ];
  let canvasGradient;
  for (const key of canvasSourceKeys) {
    if (objectPart[key] !== void 0) {
      canvasGradient = objectPart[key];
      break;
    }
  }
  const out = {};
  for (const [key, value] of Object.entries(objectPart)) {
    let isFamilyGradient = false;
    for (const f of FAMILIES2) {
      if (key === `--sectiondivider-${f}-background` || key === `--sectiondivider-${f}-gradient` || key === `--sectiondivider-color-${f}-background`) {
        isFamilyGradient = true;
        break;
      }
    }
    if (isFamilyGradient) continue;
    const backgroundVariant = SIZE_VARIANTS.find((v) => key === `--sectiondivider-${v}-background`);
    if (backgroundVariant) {
      out[`--sectiondivider-${backgroundVariant}-surface`] = value;
      continue;
    }
    out[key] = value;
  }
  if (canvasGradient !== void 0) {
    for (const v of SIZE_VARIANTS) {
      out[`--sectiondivider-${v}-surface`] = canvasGradient;
    }
  }
  return out;
}
var SECTIONDIVIDER_VARIANTS2 = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
function synthesizeSectionDividerGradients(stringPart, objectPart) {
  const GRADIENT_ANGLE_TOKENS = {
    "--gradient-angle-horizontal": 90,
    "--gradient-angle-vertical": 180,
    "--gradient-angle-diagonal": 135,
    "--gradient-angle-counter-diagonal": 45
  };
  const GRADIENT_STOP_POSITIONS = {
    "--gradient-stop-start": 0,
    "--gradient-stop-mid": 50,
    "--gradient-stop-end": 100
  };
  const parseAngle = (raw) => {
    if (!raw) return 135;
    if (raw.startsWith("--")) return GRADIENT_ANGLE_TOKENS[raw] ?? 135;
    const m = raw.match(/^(-?\d+(?:\.\d+)?)\s*deg$/i);
    return m ? parseFloat(m[1]) : 135;
  };
  const parsePosition = (raw, fallback) => {
    if (!raw) return fallback;
    if (raw.startsWith("--")) return GRADIENT_STOP_POSITIONS[raw] ?? fallback;
    const m = raw.match(/^(-?\d+(?:\.\d+)?)\s*%$/);
    return m ? parseFloat(m[1]) : fallback;
  };
  const parseStopColor = (raw) => {
    if (!raw) return null;
    if (raw.startsWith("--")) return { color: raw };
    const mix = raw.match(/^color-mix\(\s*in\s+srgb\s*,\s*var\((--[a-z0-9-]+)\)\s+([\d.]+)%\s*,\s*transparent\s*\)$/i);
    if (mix) return { color: mix[1], opacity: parseFloat(mix[2]) };
    return null;
  };
  for (const v of SECTIONDIVIDER_VARIANTS2) {
    const slot = `--sectiondivider-${v}-gradient`;
    if (slot in objectPart) continue;
    const angleKey = `${slot}-angle`;
    const has1 = stringPart[`${slot}-stop-1-color`] !== void 0;
    const has2 = stringPart[`${slot}-stop-2-color`] !== void 0;
    const has3 = stringPart[`${slot}-stop-3-color`] !== void 0;
    if (!has1 && !has2 && !has3) continue;
    const stops = [];
    const positionDefaults = [0, 50, 100];
    for (let i = 1; i <= 3; i++) {
      const c = parseStopColor(stringPart[`${slot}-stop-${i}-color`]);
      if (!c) continue;
      const pos = parsePosition(stringPart[`${slot}-stop-${i}-position`], positionDefaults[i - 1]);
      stops.push({ position: pos, color: c.color, ...c.opacity !== void 0 ? { opacity: c.opacity } : {} });
    }
    if (stops.length < 2) continue;
    objectPart[slot] = {
      kind: "gradient",
      value: {
        type: "linear",
        angle: parseAngle(stringPart[angleKey]),
        stops
      }
    };
  }
}

// src/editor/core/themes/themeTypes.ts
var THEME_SCHEMA_VERSION = 5;

// src/editor/core/components/componentConfigKeys.ts
var KNOWN_COMPONENT_CONFIG_KEYS = /* @__PURE__ */ new Set([
  "--dialog-confirm-variant",
  "--dialog-cancel-variant",
  // SectionDivider per-variant `color-family` is editor metadata that drives
  // the family-swap rewrite on aliases. It is not a runtime CSS value, so it
  // stays in the config bucket. The other intrinsics (align, hairline,
  // eyebrow/description visibility, eyebrow text-transform) now flow through
  // the alias bucket as cascading CSS vars — see the 2026-05-22 migration.
  "--sectiondivider-lg-color-family",
  "--sectiondivider-md-color-family",
  "--sectiondivider-sm-color-family"
]);

// src/live-tokens/data/sketch-styles/pencil.json
var pencil_default = {
  name: "Pencil",
  settings: {
    label: "Pencil",
    blurb: "Two graphite passes on their own seeds, so the outline disagrees with itself the way a hand coming back round does. The grain is drawn long and on the diagonal, the way a pencil shades.",
    fillTravel: 0.75,
    strokeTravel: 1.25,
    wobble: 30,
    roughness: 3,
    borderWavelength: 1,
    waveform: 1,
    strokeWidth: 1.25,
    doubleStroke: true,
    retraceOffset: 1.5,
    retracePass: "reseeded",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.15,
    pressureMod: 0.3,
    pooling: 0,
    strokeInk: 0.85,
    maskOn: true,
    maskBlobX: 525,
    maskBlobY: 47,
    maskBlobLinked: false,
    maskAngle: 67,
    maskOutputMin: 0.59,
    maskOutputMax: 1,
    maskOctaves: 3,
    maskGrain: "turbulence",
    maskPosterize: 1,
    maskSoftness: 0,
    jitterX: 1.5,
    jitterY: 1.5,
    jitterRot: 0.35,
    jitterScale: 0.022,
    cornerSpread: 6,
    cornerTravel: 4.5,
    iconTravel: 0.75,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 1
  },
  updatedAt: "2026-08-28T14:35:06.291Z",
  createdAt: "2026-08-28T14:35:06.291Z"
};

// src/live-tokens/data/sketch-styles/marker.json
var marker_default = {
  name: "Marker",
  settings: {
    label: "Marker",
    blurb: "Broad translucent nib gone round twice on the same line, so the overlap darkens and the ink pools where it slows.",
    fillTravel: 2,
    strokeTravel: 1.5,
    wobble: 56,
    roughness: 3,
    borderWavelength: 1.3,
    waveform: 1.4,
    strokeWidth: 4,
    doubleStroke: true,
    retraceOffset: 2.2,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.2,
    pressureMod: 0.25,
    pooling: 2,
    strokeInk: 0.52,
    maskOn: true,
    maskBlobX: 230,
    maskBlobY: 230,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.76,
    maskOutputMax: 1,
    maskOctaves: 3,
    maskGrain: "fractal",
    maskPosterize: 4,
    maskSoftness: 0,
    jitterX: 3,
    jitterY: 3,
    jitterRot: 0.8,
    jitterScale: 0.045,
    cornerSpread: 10,
    cornerTravel: 8,
    iconTravel: 1.25,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 4
  },
  updatedAt: "2026-08-28T14:45:04.324Z",
  createdAt: "2026-08-28T14:45:04.324Z"
};

// src/live-tokens/data/sketch-styles/whiteboard.json
var whiteboard_default = {
  name: "Whiteboard",
  settings: {
    label: "Whiteboard",
    blurb: "The fattest nib on glass. One long smooth undulation, and a veined mask that streaks the fill like a half-wiped board.",
    fillTravel: 2.5,
    strokeTravel: 2.5,
    wobble: 90,
    roughness: 1,
    borderWavelength: 1.5,
    waveform: 1,
    strokeWidth: 5.5,
    doubleStroke: true,
    retraceOffset: 3,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.15,
    pressureMod: 0.15,
    pooling: 3.5,
    strokeInk: 0.66,
    maskOn: true,
    maskBlobX: 180,
    maskBlobY: 38,
    maskBlobLinked: false,
    maskAngle: 0,
    maskOutputMin: 0.68,
    maskOutputMax: 1,
    maskOctaves: 3,
    maskGrain: "turbulence",
    maskPosterize: 3,
    maskSoftness: 0,
    jitterX: 4.5,
    jitterY: 4.5,
    jitterRot: 3,
    jitterScale: 0.07,
    cornerSpread: 14,
    cornerTravel: 11,
    iconTravel: 1.75,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 1.5
  },
  updatedAt: "2026-08-28T14:46:58.140Z",
  createdAt: "2026-08-28T14:46:58.140Z"
};

// src/live-tokens/data/sketch-styles/hatched.json
var hatched_default = {
  name: "Hatched",
  settings: {
    label: "Hatched",
    blurb: "An etching. The fill is angled shading, the outline a single hard-edged scratch that chatters along its length. No mask: the hatch is the texture.",
    fillTravel: 1.25,
    strokeTravel: 1.5,
    wobble: 24,
    roughness: 3,
    borderWavelength: 1,
    waveform: 3,
    strokeWidth: 1.5,
    doubleStroke: false,
    retraceOffset: 1.2,
    retracePass: "copy",
    fillStyle: "hatched",
    hatchInk: 0.5,
    strokeStyle: "solid",
    pressure: 0.3,
    pressureMod: 0.45,
    pooling: 0.8,
    strokeInk: 1,
    maskOn: true,
    maskBlobX: 10,
    maskBlobY: 600,
    maskBlobLinked: false,
    maskAngle: 150,
    maskOutputMin: 0.35,
    maskOutputMax: 1,
    maskOctaves: 2,
    maskGrain: "turbulence",
    maskPosterize: 1,
    maskSoftness: 1.5,
    jitterX: 1.5,
    jitterY: 1.5,
    jitterRot: 0.4,
    jitterScale: 0.03,
    cornerSpread: 6,
    cornerTravel: 6,
    iconTravel: 1.25,
    iconWavelength: 0.5,
    iconMaskOn: false,
    iconMaskScale: 1
  },
  updatedAt: "2026-08-28T21:17:18.232Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/live-tokens/data/sketch-styles/dashed.json
var dashed_default = {
  name: "Dashed",
  settings: {
    label: "Dashed",
    blurb: "A drafting outline. One slow drift along the ruler, broken into strokes, with jitter, mask and pressure all off. The clean pole.",
    fillTravel: 0.5,
    strokeTravel: 1,
    wobble: 120,
    roughness: 1,
    borderWavelength: 1,
    waveform: 1,
    strokeWidth: 1.5,
    doubleStroke: false,
    retraceOffset: 1.2,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "dashed",
    pressure: 0,
    pressureMod: 0,
    pooling: 0,
    strokeInk: 1,
    maskOn: false,
    maskBlobX: 100,
    maskBlobY: 100,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.45,
    maskOutputMax: 1,
    maskOctaves: 2,
    maskGrain: "fractal",
    maskPosterize: 1,
    maskSoftness: 1.5,
    jitterX: 0,
    jitterY: 0,
    jitterRot: 0,
    jitterScale: 0,
    cornerSpread: 4,
    cornerTravel: 3,
    iconTravel: 0,
    iconWavelength: 0.625,
    iconMaskOn: false,
    iconMaskScale: 1
  },
  updatedAt: "2026-08-28T15:47:36.934Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/live-tokens/data/sketch-styles/napkin.json
var napkin_default = {
  name: "Napkin",
  settings: {
    label: "Napkin",
    blurb: "Ballpoint in a hurry. Everything loose at once: a square wave sends every edge to full travel, and the second pass lands wherever it lands.",
    fillTravel: 3,
    strokeTravel: 2.25,
    wobble: 50,
    roughness: 3,
    borderWavelength: 1,
    waveform: 2.5,
    strokeWidth: 2.25,
    doubleStroke: true,
    retraceOffset: 4,
    retracePass: "reseeded",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.45,
    pressureMod: 0.6,
    pooling: 2.5,
    strokeInk: 1,
    maskOn: true,
    maskBlobX: 150,
    maskBlobY: 150,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.62,
    maskOutputMax: 1,
    maskOctaves: 2,
    maskGrain: "fractal",
    maskPosterize: 2,
    maskSoftness: 5,
    jitterX: 6,
    jitterY: 6,
    jitterRot: 1.8,
    jitterScale: 0.075,
    cornerSpread: 20,
    cornerTravel: 17,
    iconTravel: 2.25,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 3.6
  },
  updatedAt: "2026-08-28T15:47:36.934Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/live-tokens/data/sketch-styles/dry.json
var dry_default = {
  name: "Dry marker",
  settings: {
    label: "Dry marker",
    blurb: "Ink that ran out. One scratchy pass that breaks up along its length, over a fill the mask has worn nearly through in patches.",
    fillTravel: 2.25,
    strokeTravel: 1.75,
    wobble: 50,
    roughness: 3,
    borderWavelength: 0.5,
    waveform: 2,
    strokeWidth: 3.5,
    doubleStroke: false,
    retraceOffset: 1.2,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.4,
    pressureMod: 0.8,
    pooling: 1.5,
    strokeInk: 0.4,
    maskOn: true,
    maskBlobX: 170,
    maskBlobY: 170,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.57,
    maskOutputMax: 0.91,
    maskOctaves: 2,
    maskGrain: "fractal",
    maskPosterize: 4,
    maskSoftness: 1.75,
    jitterX: 5,
    jitterY: 5,
    jitterRot: 1.4,
    jitterScale: 0.08,
    cornerSpread: 16,
    cornerTravel: 13,
    iconTravel: 1.75,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 3.8
  },
  updatedAt: "2026-08-28T21:19:51.383Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/editor/core/sketch/sketchStyles.ts
var SHIPPED_FILES = { pencil: pencil_default, marker: marker_default, whiteboard: whiteboard_default, hatched: hatched_default, dashed: dashed_default, napkin: napkin_default, dry: dry_default };
var SHIPPED_SKETCH_SETTINGS = Object.fromEntries(
  Object.entries(SHIPPED_FILES).map(([id, file]) => [id, file.settings])
);
var DEFAULT_SKETCH_STYLE = "marker";
function hydrateSketchSettings(raw) {
  const base = SHIPPED_SKETCH_SETTINGS[DEFAULT_SKETCH_STYLE];
  const stored = raw ?? {};
  const out = { ...base };
  for (const key of Object.keys(base)) {
    if (stored[key] !== void 0) out[key] = stored[key];
  }
  if (out.fillStyle === "none") out.fillStyle = base.fillStyle;
  convertTiledMask(stored, out);
  convertCutToLevels(stored, out);
  carryLevelsToOutput(stored, out);
  halveSwingDials(stored, out);
  splitBlobAxes(stored, out);
  convertCyclesToWavelength(stored, out);
  convertIconTileToScale(stored, out);
  restoreDerivedRetrace(stored, out);
  return out;
}
function restoreDerivedRetrace(stored, out) {
  if (stored.retraceOffset === void 0) {
    out.retraceOffset = Number(Math.max(1.2, out.strokeWidth * 0.55).toFixed(2));
  }
}
var SWING_DIALS = {
  fillScale: "fillTravel",
  strokeScale: "strokeTravel",
  iconScale: "iconTravel",
  cornerShift: "cornerTravel"
};
function convertCyclesToWavelength(stored, out) {
  const cycles = stored.frequency;
  if (typeof cycles === "number" && cycles > 0) out.wobble = Math.round(1 / cycles);
  for (const [legacy, key] of [
    ["borderFrequency", "borderWavelength"],
    ["iconFrequency", "iconWavelength"]
  ]) {
    const multiple = stored[legacy];
    if (typeof multiple === "number" && multiple > 0) {
      out[key] = Number((1 / multiple).toFixed(3));
    }
  }
  const layers = stored.octaves;
  if (typeof layers === "number") out.roughness = Math.min(3, Math.max(1, layers));
}
function splitBlobAxes(stored, out) {
  const blob = stored.maskBlob;
  if (typeof blob !== "number") return;
  out.maskBlobX = blob;
  out.maskBlobY = blob;
  out.maskBlobLinked = true;
}
function convertIconTileToScale(stored, out) {
  const tile = stored.iconMaskTile;
  if (typeof tile !== "number") return;
  out.iconMaskScale = Math.min(5, Math.max(0.5, Number((tile / 90).toFixed(2))));
}
function halveSwingDials(stored, out) {
  for (const [legacy, key] of Object.entries(SWING_DIALS)) {
    const value = stored[legacy];
    if (typeof value === "number") out[key] = value / 2;
  }
}
function convertTiledMask(stored, out) {
  const scale = stored.maskScale;
  if (typeof scale !== "number") return;
  const freq = stored.maskFrequency;
  if (typeof freq === "number") {
    out.maskBlobX = Math.round(scale / (freq * LEGACY_TILE));
    out.maskBlobY = out.maskBlobX;
  }
  const soft = stored.maskSoftness;
  if (typeof soft === "number") out.maskSoftness = Number((soft * scale / LEGACY_TILE).toFixed(1));
}
function convertCutToLevels(stored, out) {
  const contrast = stored.maskContrast;
  const coverage = stored.maskCoverage;
  if (typeof contrast !== "number" || typeof coverage !== "number") return;
  const veined = out.maskGrain === "turbulence";
  const [lo, hi] = veined ? LEGACY_RANGE.turbulence : LEGACY_RANGE.fractal;
  const pivot = veined ? 0.55 - 0.5 * coverage : 0.8 - 0.6 * coverage;
  const level = (raw) => Math.min(1, Math.max(0, (raw - lo) / (hi - lo)));
  out.maskOutputMin = Number(level(pivot - 0.5 / contrast).toFixed(2));
  out.maskOutputMax = Number(Math.max(out.maskOutputMin + 0.02, level(pivot + 0.5 / contrast)).toFixed(2));
}
function carryLevelsToOutput(stored, out) {
  if (typeof stored.maskLevelMin === "number") out.maskOutputMin = stored.maskLevelMin;
  if (typeof stored.maskLevelMax === "number") out.maskOutputMax = stored.maskLevelMax;
}
var LEGACY_RANGE = { fractal: [0.24, 0.77], turbulence: [0.02, 0.6] };
var LEGACY_TILE = 600;

// vite-plugin/themes/normalizeTheme.ts
function asObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function isColorsAndTypeShaped(raw) {
  const obj = asObject(raw);
  if (!obj) return false;
  if ("theme" in obj || "colorsAndType" in obj) return false;
  return "cssVariables" in obj || "editorConfigs" in obj;
}
function stripFileMarker(value) {
  if (!("_fileName" in value)) return value;
  const { _fileName, ...rest } = value;
  return rest;
}
function asString(value, fallback) {
  return typeof value === "string" && value ? value : fallback;
}
function migrateEmbeddedKey(src) {
  const { theme, ...rest } = src;
  return { ...rest, colorsAndType: theme };
}
function routeKnownConfigKeys(aliases, config) {
  const outAliases = { ...aliases };
  const outConfig = { ...config };
  for (const key of Object.keys(outAliases)) {
    if (!KNOWN_COMPONENT_CONFIG_KEYS.has(key)) continue;
    if (outConfig[key] === void 0) outConfig[key] = outAliases[key];
    delete outAliases[key];
  }
  return { aliases: outAliases, config: outConfig };
}
function migrateEmbeddedComponentConfig(comp, config, fileVersion) {
  const { schemaVersion: _entryStamp, aliases: rawAliases, config: rawConfig, ...rest } = config;
  const aliasesIn = asObject(rawAliases);
  if (!aliasesIn) {
    return rawConfig !== void 0 ? { ...rest, config: rawConfig } : rest;
  }
  const migratedConfig = migrateComponentConfig(
    comp,
    aliasesIn,
    asObject(rawConfig) ?? void 0,
    fileVersion
  );
  const split = routeKnownConfigKeys(migratedConfig.aliases, migratedConfig.config);
  const out = { ...rest, aliases: split.aliases };
  if (rawConfig !== void 0 || Object.keys(split.config).length > 0) {
    out.config = split.config;
  }
  return out;
}
function normalizeTheme(raw, resolvers) {
  const input = asObject(raw) ?? {};
  const migrated = input.schemaVersion !== THEME_SCHEMA_VERSION;
  const inputVersion = typeof input.schemaVersion === "number" ? input.schemaVersion : 0;
  const src = inputVersion < 3 ? migrateEmbeddedKey(input) : input;
  const componentSchemaVersion = typeof input.componentSchemaVersion === "number" ? input.componentSchemaVersion : 0;
  const dropped = [];
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const embeddedColorsAndType = asObject(src.colorsAndType);
  let colorsAndType = null;
  if (embeddedColorsAndType) {
    colorsAndType = stripFileMarker(embeddedColorsAndType);
  } else {
    const colorsAndTypeName = asString(src.colorsAndType, "default");
    colorsAndType = asObject(resolvers.readColorsAndType(colorsAndTypeName));
    if (!colorsAndType) {
      dropped.push(`colors-and-type:${colorsAndTypeName}`);
      if (colorsAndTypeName !== "default") colorsAndType = asObject(resolvers.readColorsAndType("default"));
    }
    if (colorsAndType) colorsAndType = resolvers.normalizeColorsAndType(stripFileMarker(colorsAndType));
  }
  const componentConfigs = {};
  for (const [comp, value] of Object.entries(asObject(src.componentConfigs) ?? {})) {
    const embedded2 = asObject(value);
    let resolvedConfig;
    if (embedded2) {
      resolvedConfig = stripFileMarker(embedded2);
    } else {
      const configName = asString(value, "default");
      const resolved = asObject(resolvers.readComponentConfig(comp, configName));
      if (!resolved) {
        dropped.push(`${comp}/${configName}`);
        continue;
      }
      resolvedConfig = stripFileMarker(resolved);
    }
    componentConfigs[comp] = migrateEmbeddedComponentConfig(comp, resolvedConfig, componentSchemaVersion);
  }
  const filled = { components: [], aliases: 0, orphans: 0 };
  for (const comp of resolvers.listComponentNames()) {
    const base = asObject(resolvers.readComponentConfig(comp, "default"));
    const baseAliases = base ? asObject(base.aliases) : null;
    if (!base || !baseAliases) continue;
    const entry = componentConfigs[comp];
    if (!entry) {
      const { schemaVersion: _standaloneStamp, ...rest } = stripFileMarker(base);
      componentConfigs[comp] = structuredClone(rest);
      filled.components.push(comp);
      continue;
    }
    const entryAliases = asObject(entry.aliases) ?? {};
    for (const key of Object.keys(baseAliases)) {
      if (key in entryAliases) continue;
      entryAliases[key] = structuredClone(baseAliases[key]);
      filled.aliases++;
    }
    entry.aliases = entryAliases;
    for (const key of Object.keys(entryAliases)) {
      if (!(key in baseAliases)) filled.orphans++;
    }
  }
  const embedded = asObject(src.sketchSettings) ?? asObject(src.sketchStyle);
  const sketchSettings = embedded ? hydrateSketchSettings(embedded) : void 0;
  return {
    theme: {
      name: asString(src.name, "Untitled"),
      createdAt: asString(src.createdAt, now),
      updatedAt: asString(src.updatedAt, now),
      schemaVersion: THEME_SCHEMA_VERSION,
      colorsAndType,
      componentConfigs,
      componentSchemaVersion: CURRENT_COMPONENT_SCHEMA_VERSION,
      ...sketchSettings ? { sketchSettings } : {}
    },
    dropped,
    migrated,
    filled
  };
}

// vite-plugin/files/nameAllocator.ts
function nextAvailableName(exists, baseName, maxAttempts = 1e3) {
  if (!exists(baseName)) return baseName;
  for (let i = 2; i < maxAttempts; i++) {
    const candidate = `${baseName}-${i}`;
    if (!exists(candidate)) return candidate;
  }
  throw new Error(`Could not allocate a non-colliding name for "${baseName}"`);
}

// vite-plugin/files/legacyLayout.ts
var import_fs2 = __toESM(require("fs"), 1);
var import_path2 = __toESM(require("path"), 1);
function jsonFiles(dir) {
  if (!import_fs2.default.existsSync(dir)) return [];
  try {
    return import_fs2.default.readdirSync(dir).filter((f) => f.endsWith(".json")).map((f) => import_path2.default.join(dir, f));
  } catch {
    return [];
  }
}
function isDirectory(dir) {
  try {
    return import_fs2.default.statSync(dir).isDirectory();
  } catch {
    return false;
  }
}
function parseJsonFile(file) {
  try {
    return JSON.parse(import_fs2.default.readFileSync(file, "utf-8"));
  } catch {
    return null;
  }
}
function holdsATheme(themesDir) {
  return jsonFiles(themesDir).some((file) => {
    if (import_path2.default.basename(file).startsWith("_")) return false;
    const raw = parseJsonFile(file);
    if (!raw || typeof raw !== "object") return false;
    return "colorsAndType" in raw || "theme" in raw;
  });
}
function detectLegacyLayout(input) {
  const manifestsDir = input.configuredManifestsDir ?? import_path2.default.join(input.dataDir, "manifests");
  const themesHoldAThemeFile = holdsATheme(input.themesDir);
  if (isDirectory(manifestsDir) && !themesHoldAThemeFile) {
    return { manifestsDir, evidence: `${manifestsDir} is the pre-0.48 whole-theme directory` };
  }
  if (jsonFiles(input.colorsAndTypeDir).length > 0) return null;
  for (const file of jsonFiles(input.themesDir)) {
    if (import_path2.default.basename(file).startsWith("_")) continue;
    if (isColorsAndTypeShaped(parseJsonFile(file))) {
      return { manifestsDir, evidence: `${file} is a colors-and-type file, not a theme` };
    }
  }
  const pointer = ["_active.json", "_production.json"].map((name) => import_path2.default.join(input.themesDir, name)).find((p) => import_fs2.default.existsSync(p));
  if (pointer && !themesHoldAThemeFile && !import_fs2.default.existsSync(input.colorsAndTypeDir)) {
    return {
      manifestsDir,
      evidence: `${pointer} points at colors and type, and there is no ${import_path2.default.basename(input.colorsAndTypeDir)} directory`
    };
  }
  return null;
}
function planLegacyRenames(layout, input) {
  const defaultColorsAndType = import_path2.default.join(input.dataDir, "colors-and-type");
  const defaultThemes = import_path2.default.join(input.dataDir, "themes");
  if (input.configuredManifestsDir && import_path2.default.resolve(input.configuredManifestsDir) !== import_path2.default.join(input.dataDir, "manifests")) {
    throw new Error(
      `This project uses the pre-0.48 data layout (${layout.evidence}), and live-tokens.config.json sets the retired "manifestsDir" key to ${input.configuredManifestsDir}. That directory holds the whole themes, which now belong in ${input.themesDir}. Move it there by hand, drop the "manifestsDir" key, then run the migration again.`
    );
  }
  if (import_path2.default.resolve(input.colorsAndTypeDir) !== import_path2.default.resolve(defaultColorsAndType) || import_path2.default.resolve(input.themesDir) !== import_path2.default.resolve(defaultThemes)) {
    throw new Error(
      `This project uses the pre-0.48 data layout (${layout.evidence}), and its data directories are configured to custom paths (colorsAndTypeDir=${input.colorsAndTypeDir}, themesDir=${input.themesDir}). The migration cannot tell which directory holds what. Move the old colors-and-type directory to ${input.colorsAndTypeDir} and the old whole-theme directory to ${input.themesDir} by hand, then run the migration again.`
    );
  }
  const renames = [];
  if (import_fs2.default.existsSync(input.themesDir)) {
    renames.push({ from: input.themesDir, to: input.colorsAndTypeDir });
  }
  if (import_fs2.default.existsSync(layout.manifestsDir)) {
    renames.push({ from: layout.manifestsDir, to: input.themesDir });
  }
  return renames;
}
function applyLegacyRenames(renames) {
  for (const { from, to } of renames) {
    if (import_fs2.default.existsSync(to)) {
      const contents = import_fs2.default.readdirSync(to);
      if (contents.length > 0) {
        throw new Error(
          `Cannot move ${from} to ${to}: ${to} already exists and holds ${contents.length} file(s). Move or delete it, then run the migration again.`
        );
      }
      import_fs2.default.rmdirSync(to);
    }
    import_fs2.default.mkdirSync(import_path2.default.dirname(to), { recursive: true });
    import_fs2.default.renameSync(from, to);
  }
}

// vite-plugin/migrateData/migrateData.ts
var RECOVERED_SLUG = "recovered-production";
var RECOVERED_NAME = "Recovered production";
var MARKER_KEYS = ["_fileName", "_source"];
var VOLATILE_KEYS = [...MARKER_KEYS, "updatedAt"];
function isObject(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
function sortDeep(value) {
  if (Array.isArray(value)) return value.map(sortDeep);
  if (!isObject(value)) return value;
  const out = {};
  for (const key of Object.keys(value).sort()) out[key] = sortDeep(value[key]);
  return out;
}
function comparable(value) {
  if (!isObject(value)) return JSON.stringify(sortDeep(value));
  const stable = {};
  for (const key of Object.keys(value).sort()) {
    if (VOLATILE_KEYS.includes(key)) continue;
    stable[key] = sortDeep(value[key]);
  }
  return JSON.stringify(stable);
}
function sameContent(a, b) {
  return comparable(a) === comparable(b);
}
function stripMarkers(value) {
  const out = {};
  for (const [key, v] of Object.entries(value)) {
    if (!MARKER_KEYS.includes(key)) out[key] = v;
  }
  return out;
}
function readPointerName(file, key) {
  if (!import_fs3.default.existsSync(file)) return null;
  try {
    const name = JSON.parse(import_fs3.default.readFileSync(file, "utf-8"))[key];
    return typeof name === "string" && name ? name : null;
  } catch {
    return null;
  }
}
function localNamedFiles(dir) {
  if (!import_fs3.default.existsSync(dir)) return [];
  return import_fs3.default.readdirSync(dir).filter((f) => f.endsWith(".json") && !f.startsWith("_")).map((f) => f.slice(0, -".json".length)).filter((name) => name !== "default");
}
function componentNames(componentConfigsDir) {
  if (!import_fs3.default.existsSync(componentConfigsDir)) return [];
  return import_fs3.default.readdirSync(componentConfigsDir, { withFileTypes: true }).filter((e) => e.isDirectory()).map((e) => e.name).sort();
}
function shippedNames(packageDataDir, subdir) {
  try {
    const pkgRoot = import_path3.default.resolve(packageDataDir, "..", "..", "..");
    const pkg = JSON.parse(import_fs3.default.readFileSync(import_path3.default.join(pkgRoot, "package.json"), "utf-8"));
    const files = Array.isArray(pkg.files) ? pkg.files : [];
    const prefix = `src/live-tokens/data/${subdir}/`;
    return files.filter((f) => f.startsWith(prefix) && /^[^/]+\.json$/.test(f.slice(prefix.length))).map((f) => import_path3.default.basename(f, ".json"));
  } catch {
    return [];
  }
}
function migrateData(opts) {
  const { componentConfigsDir, check = false } = opts;
  const packageDataDir = opts.packageDataDir;
  const layoutInput = {
    dataDir: opts.dataDir,
    colorsAndTypeDir: opts.colorsAndTypeDir,
    themesDir: opts.themesDir,
    configuredManifestsDir: opts.legacyManifestsDir
  };
  const legacyLayout = detectLegacyLayout(layoutInput);
  const legacyRenames = legacyLayout ? planLegacyRenames(legacyLayout, layoutInput) : [];
  const sketchStylesFrom = import_path3.default.join(opts.dataDir, "sketch-presets");
  const sketchStylesTo = import_path3.default.join(opts.dataDir, "sketch-styles");
  const sketchStylesRenames = import_fs3.default.existsSync(sketchStylesFrom) ? [{ from: sketchStylesFrom, to: sketchStylesTo }] : [];
  const renames = [...legacyRenames, ...sketchStylesRenames];
  if (!check) applyLegacyRenames(renames);
  const planningLegacy = legacyLayout !== null && check;
  const colorsAndTypeDir = planningLegacy ? opts.themesDir : opts.colorsAndTypeDir;
  const themesDir = planningLegacy ? legacyLayout.manifestsDir : opts.themesDir;
  const reported = (p) => {
    if (!planningLegacy) return p;
    for (const { from, to } of renames) {
      if (p.startsWith(from + import_path3.default.sep)) return import_path3.default.join(to, p.slice(from.length + 1));
    }
    return p;
  };
  const colorsRes = versionedFileResourceServer({
    dir: colorsAndTypeDir,
    packageDir: packageDataDir ? import_path3.default.join(packageDataDir, "colors-and-type") : void 0,
    packageOwnedNames: packageDataDir ? shippedNames(packageDataDir, "colors-and-type") : void 0
  });
  const themesRes = versionedFileResourceServer({
    dir: themesDir,
    packageDir: packageDataDir ? import_path3.default.join(packageDataDir, "themes") : void 0
  });
  const componentResources = /* @__PURE__ */ new Map();
  const compRes = (comp) => {
    let r = componentResources.get(comp);
    if (!r) {
      r = versionedFileResourceServer({
        dir: import_path3.default.join(componentConfigsDir, comp),
        packageDir: packageDataDir ? import_path3.default.join(packageDataDir, "component-configs", comp) : void 0,
        packageOwnedNames: packageDataDir ? shippedNames(packageDataDir, `component-configs/${comp}`) : void 0
      });
      componentResources.set(comp, r);
    }
    return r;
  };
  const comps = componentNames(componentConfigsDir);
  const legacyPointers = [];
  for (const dir of [colorsAndTypeDir, ...comps.map((c) => import_path3.default.join(componentConfigsDir, c))]) {
    for (const name of ["_active.json", "_production.json"]) {
      const p = import_path3.default.join(dir, name);
      if (import_fs3.default.existsSync(p)) legacyPointers.push(p);
    }
  }
  const empty = {
    status: "clean",
    renames,
    production: null,
    recoveredThemePath: null,
    workingWritten: [],
    workingKept: [],
    deletedFiles: [],
    deletedPointers: [],
    keptUserFiles: [],
    notThemes: [],
    droppedRefs: [],
    shadowedDefaults: [],
    upgradedThemes: []
  };
  if (legacyPointers.length === 0) {
    if (!legacyLayout && renames.length === 0) return empty;
    return { ...empty, status: check ? "planned" : "healed" };
  }
  const resolvers = {
    readColorsAndType: (name) => colorsRes.readJson(name),
    readComponentConfig: (comp, name) => compRes(comp).readJson(name),
    listComponentNames: () => comps,
    normalizeColorsAndType: (colorsAndType) => colorsAndType
  };
  const upgradedThemes = [];
  const notThemes = [];
  const droppedRefs = [];
  const themes = [];
  for (const slug of themesRes.listNames()) {
    let raw;
    try {
      raw = themesRes.readJson(slug);
    } catch {
      continue;
    }
    if (!raw) continue;
    if (isColorsAndTypeShaped(raw)) {
      notThemes.push(themesRes.filePath(slug));
      continue;
    }
    const { theme, migrated, dropped } = normalizeTheme(raw, resolvers);
    themes.push({ slug, theme });
    for (const ref2 of dropped) {
      droppedRefs.push(
        `theme "${slug}": the reference ${ref2} resolved to nothing, so it carries the shipped default instead`
      );
    }
    if (migrated && import_fs3.default.existsSync(themesRes.filePath(slug))) {
      upgradedThemes.push(themesRes.filePath(slug));
      if (!check) import_fs3.default.writeFileSync(themesRes.filePath(slug), JSON.stringify(theme, null, 2));
    }
  }
  const themeBySlug = new Map(themes.map((t) => [t.slug, t.theme]));
  const resolveName = (res, dir, file, key) => {
    const name = readPointerName(import_path3.default.join(dir, file), key);
    if (!name || res.existingPath(name) === null) return "default";
    return name;
  };
  const readPointed = (res, name) => {
    try {
      return res.readJson(name);
    } catch (err) {
      const file = res.existingPath(name) ?? res.filePath(name);
      throw new Error(
        `${file} will not parse (${err instanceof Error ? err.message : String(err)}), and a retired pointer names it. Fix or delete the file, then run the migration again.`
      );
    }
  };
  const defaultConfig = (comp) => compRes(comp).readJson("default");
  const themeConfigFor = (theme, comp) => {
    const embedded = theme.componentConfigs[comp];
    return embedded ? { ...embedded, component: comp } : defaultConfig(comp);
  };
  const prodColorsName = resolveName(colorsRes, colorsAndTypeDir, "_production.json", "productionFile");
  const prodConfigNames = new Map(
    comps.map((comp) => [
      comp,
      resolveName(compRes(comp), import_path3.default.join(componentConfigsDir, comp), "_production.json", "productionFile")
    ])
  );
  const prodColors = readPointed(colorsRes, prodColorsName);
  const prodConfigs = new Map(
    comps.map((comp) => [comp, readPointed(compRes(comp), prodConfigNames.get(comp))])
  );
  const allDefault = prodColorsName === "default" && [...prodConfigNames.values()].every((n) => n === "default");
  const matchesPointedProduction = (theme) => sameContent(theme.colorsAndType, prodColors) && comps.every((comp) => sameContent(themeConfigFor(theme, comp), prodConfigs.get(comp)));
  let production;
  let recoveredTheme = null;
  let recoveredThemePath = null;
  if (allDefault) {
    production = { slug: "default", how: "all-default" };
  } else {
    const match = themes.find((t) => matchesPointedProduction(t.theme));
    if (match) {
      production = { slug: match.slug, how: "matched" };
    } else {
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const componentConfigs = {};
      for (const comp of comps) {
        const pointed = prodConfigs.get(comp);
        if (!isObject(pointed)) continue;
        componentConfigs[comp] = stripMarkers(pointed);
      }
      recoveredTheme = {
        name: RECOVERED_NAME,
        createdAt: now,
        updatedAt: now,
        schemaVersion: THEME_SCHEMA_VERSION,
        colorsAndType: isObject(prodColors) ? stripMarkers(prodColors) : null,
        componentConfigs,
        // The configs above are what boot just wrote (`prodConfigs`, read off
        // the pointed files), at the current component schema — not 0, which
        // would misdescribe them as unmigrated.
        componentSchemaVersion: CURRENT_COMPONENT_SCHEMA_VERSION
      };
      const slug = nextAvailableName((n) => themesRes.existingPath(n) !== null, RECOVERED_SLUG);
      recoveredThemePath = themesRes.filePath(slug);
      production = { slug, how: "recovered" };
    }
  }
  const activeThemeSlug = themesRes.getActiveName();
  const activeTheme = themeBySlug.get(activeThemeSlug) ?? null;
  const workingWritten = [];
  const workingKept = [];
  const planWorking = (res, live, saved) => {
    if (!isObject(live) || sameContent(live, saved)) return;
    if (res.hasWorking()) {
      workingKept.push(res.workingPath);
      return;
    }
    workingWritten.push(res.workingPath);
    if (!check) res.writeWorking(stripMarkers(live));
  };
  const activeColorsName = resolveName(colorsRes, colorsAndTypeDir, "_active.json", "activeFile");
  planWorking(
    colorsRes,
    readPointed(colorsRes, activeColorsName),
    activeTheme?.colorsAndType ?? colorsRes.readJson("default")
  );
  for (const comp of comps) {
    const activeName = resolveName(
      compRes(comp),
      import_path3.default.join(componentConfigsDir, comp),
      "_active.json",
      "activeFile"
    );
    planWorking(
      compRes(comp),
      readPointed(compRes(comp), activeName),
      activeTheme ? themeConfigFor(activeTheme, comp) : defaultConfig(comp)
    );
  }
  const deletedFiles = [];
  const keptUserFiles = [];
  const sweep = (res, dir, savedCopies) => {
    for (const name of localNamedFiles(dir)) {
      if (res.isPackageFile(name)) continue;
      let content;
      try {
        content = res.readJson(name);
      } catch {
        keptUserFiles.push(res.filePath(name));
        continue;
      }
      const matched = themes.some((t) => sameContent(savedCopies(t.theme), content));
      if (!matched) {
        keptUserFiles.push(res.filePath(name));
        continue;
      }
      deletedFiles.push(res.filePath(name));
      if (!check) import_fs3.default.unlinkSync(res.filePath(name));
    }
  };
  sweep(colorsRes, colorsAndTypeDir, (theme) => theme.colorsAndType);
  for (const comp of comps) {
    sweep(compRes(comp), import_path3.default.join(componentConfigsDir, comp), (theme) => themeConfigFor(theme, comp));
  }
  const shadowedDefaults = [];
  const localDefault = import_path3.default.join(colorsAndTypeDir, "default.json");
  const packageDefault = packageDataDir ? import_path3.default.join(packageDataDir, "colors-and-type", "default.json") : null;
  if (packageDefault && import_fs3.default.existsSync(localDefault) && import_fs3.default.existsSync(packageDefault) && import_path3.default.resolve(localDefault) !== import_path3.default.resolve(packageDefault)) {
    try {
      const local = JSON.parse(import_fs3.default.readFileSync(localDefault, "utf-8"));
      const shipped = JSON.parse(import_fs3.default.readFileSync(packageDefault, "utf-8"));
      if (!sameContent(local, shipped)) shadowedDefaults.push(localDefault);
    } catch {
    }
  }
  if (!check) {
    for (const p of legacyPointers) import_fs3.default.unlinkSync(p);
  }
  if (!check) {
    if (recoveredTheme && recoveredThemePath) {
      themesRes.ensureDir();
      import_fs3.default.writeFileSync(recoveredThemePath, JSON.stringify(recoveredTheme, null, 2));
    }
    themesRes.ensureDir();
    themesRes.setProductionName(production.slug);
  }
  return {
    status: check ? "planned" : "healed",
    renames,
    production,
    recoveredThemePath: recoveredThemePath && reported(recoveredThemePath),
    workingWritten: workingWritten.map(reported),
    workingKept: workingKept.map(reported),
    deletedFiles: deletedFiles.map(reported),
    deletedPointers: legacyPointers.map(reported),
    keptUserFiles: keptUserFiles.map(reported),
    notThemes: notThemes.map(reported),
    droppedRefs,
    shadowedDefaults: shadowedDefaults.map(reported),
    upgradedThemes: upgradedThemes.map(reported)
  };
}

// vite-plugin/files/dataPaths.ts
var import_fs4 = __toESM(require("fs"), 1);
var import_path4 = __toESM(require("path"), 1);
var DEFAULT_DATA_DIR = "src/live-tokens/data";
var TEST_DATA_DIR_ENV = "LIVE_TOKENS_TEST_DATA_DIR";
function testDataDir() {
  const raw = process.env[TEST_DATA_DIR_ENV];
  return raw && raw.trim() !== "" ? import_path4.default.resolve(raw.trim()) : void 0;
}
var KNOWN_CONFIG_KEYS = /* @__PURE__ */ new Set([
  "dataDir",
  "colorsAndTypeDir",
  "componentConfigsDir",
  "themesDir",
  "manifestsDir",
  "tokensCssPath",
  "componentDirs",
  "checks"
]);
var cached = null;
function readLiveTokensConfig() {
  if (cached) return cached;
  try {
    const configPath = import_path4.default.resolve("live-tokens.config.json");
    if (!import_fs4.default.existsSync(configPath)) return cached = {};
    const parsed = JSON.parse(import_fs4.default.readFileSync(configPath, "utf-8"));
    if (!parsed || typeof parsed !== "object") return cached = {};
    const unknown = Object.keys(parsed).filter(
      (k) => k !== "$schema" && !KNOWN_CONFIG_KEYS.has(k)
    );
    if (unknown.length > 0) {
      console.warn(
        `[live-tokens] Unknown key(s) in live-tokens.config.json: ${unknown.join(", ")}. Known keys: ${Array.from(KNOWN_CONFIG_KEYS).join(", ")}.`
      );
    }
    cached = parsed;
    return cached;
  } catch {
    return cached = {};
  }
}
function resolveDataDirs(opts = {}) {
  const isolated = testDataDir();
  if (isolated) {
    return {
      dataDir: isolated,
      colorsAndTypeDir: import_path4.default.join(isolated, "colors-and-type"),
      componentConfigsDir: import_path4.default.join(isolated, "component-configs"),
      themesDir: import_path4.default.join(isolated, "themes"),
      sketchStylesDir: import_path4.default.join(isolated, "sketch-styles")
    };
  }
  const fileConfig = readLiveTokensConfig();
  const dataDirRaw = opts.dataDir ?? fileConfig.dataDir ?? DEFAULT_DATA_DIR;
  const dataDir = import_path4.default.resolve(dataDirRaw);
  const sub = (name) => import_path4.default.resolve(dataDir, name);
  return {
    dataDir,
    colorsAndTypeDir: opts.colorsAndTypeDir ? import_path4.default.resolve(opts.colorsAndTypeDir) : fileConfig.colorsAndTypeDir ? import_path4.default.resolve(fileConfig.colorsAndTypeDir) : sub("colors-and-type"),
    componentConfigsDir: opts.componentConfigsDir ? import_path4.default.resolve(opts.componentConfigsDir) : fileConfig.componentConfigsDir ? import_path4.default.resolve(fileConfig.componentConfigsDir) : sub("component-configs"),
    themesDir: opts.themesDir ? import_path4.default.resolve(opts.themesDir) : fileConfig.themesDir ? import_path4.default.resolve(fileConfig.themesDir) : sub("themes"),
    sketchStylesDir: sub("sketch-styles"),
    legacyManifestsDir: fileConfig.manifestsDir ? import_path4.default.resolve(fileConfig.manifestsDir) : void 0
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  migrateData,
  readLiveTokensConfig,
  resolveDataDirs
});
