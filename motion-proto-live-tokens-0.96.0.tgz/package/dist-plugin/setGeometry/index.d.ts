import { A as AliasDiskValue, a as ComponentConfig } from '../themeTypes-B8_Idrp4.js';
export { r as readLiveTokensConfig, a as resolveDataDirs } from '../dataPaths-BpIK_Obx.js';
export { C as CURRENT_COMPONENT_SCHEMA_VERSION } from '../index-4N-Orzzi.js';

type AdjustKind = 'radius' | 'padding' | 'gap' | 'border-width' | 'hairline-width' | 'indicator-width';
interface AdjustOp {
    /** Component id; omitted applies the op to every config. */
    target?: string;
    kind: AdjustKind;
    set?: string;
    shift?: number;
    /** Radius shifts only: admits `--radius-full` as the top step of the scale. */
    full?: boolean;
}
type SkipReason = 'raw-value' | 'off-scale' | 'clamped' | 'pill-preserved' | 'none-preserved';
interface AliasChange {
    variable: string;
    from: string;
    to: string;
}
interface AliasSkip {
    variable: string;
    value: AliasDiskValue;
    reason: SkipReason;
}
interface ComponentReport {
    component: string;
    changes: AliasChange[];
    skips: AliasSkip[];
}
interface AdjustReport {
    components: ComponentReport[];
}
interface AdjustResult {
    configs: Record<string, ComponentConfig>;
    report: AdjustReport;
}
declare function adjustAliases(configs: Record<string, ComponentConfig>, ops: readonly AdjustOp[], now: string): AdjustResult;

type TokenKind = 'surface' | 'border' | 'border-width' | 'hairline-width' | 'indicator-width' | 'radius' | 'track-height' | 'hairline-inset' | 'dot-size' | 'length' | 'blur' | 'scale' | 'shadow' | 'font-family' | 'font-weight' | 'font-size' | 'line-height' | 'letter-spacing' | 'padding' | 'gap' | 'duration' | 'easing' | 'text-color';
/** Side-aware kind test. Per-side paddings (`--card-default-body-padding-top`)
    are written by UIPaddingSelector and never declared as editor tokens, so
    `rawKind` never meets one; the CLI does, and they belong with their parent. */
declare function matchesKind(variable: string, kind: TokenKind): boolean;

export { type AdjustKind, type AdjustOp, type AdjustReport, type AdjustResult, type AliasChange, type AliasSkip, type ComponentReport, type SkipReason, adjustAliases, matchesKind };
