/**
 * Schema-versioned migration runner.
 *
 * Each migration lives in its own dated file (`YYYY-MM-DD-<short-name>.ts`)
 * and exports a `Migration` object. Saved theme / component-config files
 * carry a `schemaVersion` stamp; on load, only migrations with
 * `fromVersion >= file.schemaVersion` are applied — once every on-disk file
 * is past a given version, that migration's bookkeeping is dead code and
 * the file can be deleted.
 *
 * ColorsAndType and component-config have INDEPENDENT version sequences. Every
 * theme migration steps the theme version; every component-config migration
 * steps the component-config version. There is no shared 'both' kind.
 */
export interface MigrationMeta {
  /** Component id when the migration runs in component-config context. */
  component?: string;
}

export interface Migration {
  /** Unique identifier; convention: `YYYY-MM-DD-<short-name>`. */
  id: string;
  /** Pre-condition version — files at or below this are unmigrated for this step. */
  fromVersion: number;
  /** Post-condition version — files past this no longer need this migration. */
  toVersion: number;
  /** Which storage flavor this applies to. */
  appliesTo: 'colors-and-type' | 'component-config';
  /** Pure transform on the raw vars map. May add, remove, or rename keys. */
  apply(rawVars: Record<string, string>, meta: MigrationMeta): Record<string, string>;
}

import { colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas } from './2026-04-24-legacy-keys-and-bg-to-canvas';
import { componentMigration_2026_04_24_prefixAndSuffixRenames } from './2026-04-24-component-prefix-and-suffix-renames';
import { componentMigration_2026_04_27_segmentedcontrolDisabledFlatten } from './2026-04-27-segmentedcontrol-disabled-flatten';
import { componentMigration_2026_05_08_collapsiblesectionVariantNamespace } from './2026-05-08-collapsiblesection-variant-namespace';
import { componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup } from './2026-05-08-collapsiblesection-frame-and-cleanup';
import { componentMigration_2026_05_10_sectiondividerGradientStops } from './2026-05-10-sectiondivider-gradient-stops';
import {
  colorsAndTypeMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_05_13_primaryToBrand,
} from './2026-05-13-primary-to-brand';
import { componentMigration_2026_05_19_collapsiblesectionDropFrameSurface } from './2026-05-19-collapsiblesection-drop-frame-surface';
import { componentMigration_2026_05_19_sectiondividerRichGradient } from './2026-05-19-sectiondivider-rich-gradient';
import { componentMigration_2026_05_20_sectiondividerSlimVariants } from './2026-05-20-sectiondivider-slim-variants';
import { componentMigration_2026_05_21_sectiondividerSpacingToPadding } from './2026-05-21-sectiondivider-spacing-to-padding';
import { componentMigration_2026_05_22_sectiondividerIntrinsicsToCss } from './2026-05-22-sectiondivider-intrinsics-to-css';
import { componentMigration_2026_05_24_segmentedcontrolDividerInset } from './2026-05-24-segmentedcontrol-divider-inset';
import { componentMigration_2026_05_24_promoteStateSharedTokens } from './2026-05-24-promote-state-shared-tokens';
import { componentMigration_2026_05_24_progressbarCollapseVariants } from './2026-05-24-progressbar-collapse-variants';
import { componentMigration_2026_05_24_collapsiblesectionDropActiveState } from './2026-05-24-collapsiblesection-drop-active-state';
import { componentMigration_2026_05_25_cornerbadgeFlattenVariants } from './2026-05-25-cornerbadge-flatten-variants';
import {
  colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_26_dropOverlayExtraStops,
} from './2026-05-26-drop-overlay-extra-stops';
import { componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth } from './2026-05-29-tabbar-indicator-thickness-to-per-state-width';
import { componentMigration_2026_05_29_segmentedcontrolSmallDividerRename } from './2026-05-29-segmentedcontrol-small-divider-rename';
import { componentMigration_2026_05_29_toggleDeriveTrackFromThumb } from './2026-05-29-toggle-derive-track-from-thumb';
import { colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys } from './2026-08-13-drop-legacy-shape-space-keys';
import {
  colorsAndTypeMigration_2026_08_15_lineHeightScaleRename,
  componentMigration_2026_08_15_lineHeightScaleRename,
} from './2026-08-15-line-height-scale-rename';
import {
  colorsAndTypeMigration_2026_09_01_scrimRename,
  componentMigration_2026_09_01_scrimRename,
} from './2026-09-01-scrim-rename';
import {
  colorsAndTypeMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tintRename,
} from './2026-09-01-tint-rename';
import { componentMigration_2026_09_01_tabbarActiveTint } from './2026-09-01-tabbar-active-tint';
import { componentMigration_2026_09_01_gateSuffixEnabled } from './2026-09-01-gate-suffix-enabled';
import { componentMigration_2026_09_02_sectiondividerDropTitleOutline } from './2026-09-02-sectiondivider-drop-title-outline';
import { colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys } from './2026-09-03-drop-legacy-component-keys';
import { componentMigration_2026_09_07_strokeRoleRenames } from './2026-09-07-stroke-role-renames';
import { componentMigration_2026_09_13_selectedState } from './2026-09-13-selected-state';
import { componentMigration_2026_09_13_hairline } from './2026-09-13-hairline';
import { componentMigration_2026_09_13_indicator } from './2026-09-13-indicator';
import { componentMigration_2026_09_13_sectiondividerSurface } from './2026-09-13-sectiondivider-surface';
import { componentMigration_2026_09_20_imagelightboxScrim } from './2026-09-20-imagelightbox-scrim';
import { componentMigration_2026_09_20_scrimColorAndOpacity } from './2026-09-20-scrim-color-and-opacity';
import { colorsAndTypeMigration_2026_09_21_washColorAndOpacity } from './2026-09-21-wash-color-and-opacity';
import { colorsAndTypeMigration_2026_10_15_responsiveColumns } from './2026-10-15-responsive-columns';
import { componentMigration_2026_09_21_scrimSurface } from './2026-09-21-scrim-surface';
import { componentMigration_2026_09_13_cornerbadgePrefix } from './2026-09-13-cornerbadge-prefix';
import { componentMigration_2026_09_13_toggleLabel } from './2026-09-13-toggle-label';
import { componentMigration_2026_09_13_collapsiblesectionOpen } from './2026-09-13-collapsiblesection-open';
import { componentMigration_2026_09_13_badgeBrand } from './2026-09-13-badge-brand';

/**
 * Registered migrations. Order in this array does not matter — the runner
 * filters by `appliesTo` and sorts by `toVersion` before applying.
 */
export const MIGRATIONS: Migration[] = [
  colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas,
  colorsAndTypeMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_04_24_prefixAndSuffixRenames,
  componentMigration_2026_04_27_segmentedcontrolDisabledFlatten,
  componentMigration_2026_05_08_collapsiblesectionVariantNamespace,
  componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup,
  componentMigration_2026_05_10_sectiondividerGradientStops,
  componentMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_05_19_collapsiblesectionDropFrameSurface,
  componentMigration_2026_05_19_sectiondividerRichGradient,
  componentMigration_2026_05_20_sectiondividerSlimVariants,
  componentMigration_2026_05_21_sectiondividerSpacingToPadding,
  componentMigration_2026_05_22_sectiondividerIntrinsicsToCss,
  componentMigration_2026_05_24_segmentedcontrolDividerInset,
  componentMigration_2026_05_24_promoteStateSharedTokens,
  componentMigration_2026_05_24_progressbarCollapseVariants,
  componentMigration_2026_05_24_collapsiblesectionDropActiveState,
  componentMigration_2026_05_25_cornerbadgeFlattenVariants,
  colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth,
  componentMigration_2026_05_29_segmentedcontrolSmallDividerRename,
  componentMigration_2026_05_29_toggleDeriveTrackFromThumb,
  colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys,
  colorsAndTypeMigration_2026_08_15_lineHeightScaleRename,
  componentMigration_2026_08_15_lineHeightScaleRename,
  colorsAndTypeMigration_2026_09_01_scrimRename,
  componentMigration_2026_09_01_scrimRename,
  colorsAndTypeMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tabbarActiveTint,
  componentMigration_2026_09_01_gateSuffixEnabled,
  componentMigration_2026_09_02_sectiondividerDropTitleOutline,
  colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys,
  componentMigration_2026_09_07_strokeRoleRenames,
  componentMigration_2026_09_13_selectedState,
  componentMigration_2026_09_13_hairline,
  componentMigration_2026_09_13_indicator,
  componentMigration_2026_09_13_sectiondividerSurface,
  componentMigration_2026_09_13_cornerbadgePrefix,
  componentMigration_2026_09_13_toggleLabel,
  componentMigration_2026_09_13_collapsiblesectionOpen,
  componentMigration_2026_09_13_badgeBrand,
  componentMigration_2026_09_20_imagelightboxScrim,
  componentMigration_2026_09_20_scrimColorAndOpacity,
  colorsAndTypeMigration_2026_09_21_washColorAndOpacity,
  componentMigration_2026_09_21_scrimSurface,
  colorsAndTypeMigration_2026_10_15_responsiveColumns,
];

function countFor(kind: 'colors-and-type' | 'component-config'): number {
  return MIGRATIONS.filter((m) => m.appliesTo === kind).length;
}

/**
 * Current schema versions. Computed from the registered migrations so that
 * adding a new dated migration file (and importing it above) auto-bumps the
 * relevant constant.
 */
export const CURRENT_COLORS_AND_TYPE_SCHEMA_VERSION = countFor('colors-and-type');
export const CURRENT_COMPONENT_SCHEMA_VERSION = countFor('component-config');

/**
 * Apply all migrations for a given kind whose fromVersion is at or above the
 * file's stamped version. Pure: returns a new map; never mutates the input.
 *
 * The "fromVersion >= fileVersion" filter is what gives this its TTL: once
 * every saved file has been resaved past version N, the migration with
 * fromVersion=N can be deleted without affecting any load path.
 */
export function runMigrations(
  kind: 'colors-and-type' | 'component-config',
  fileVersion: number,
  rawVars: Record<string, string>,
  meta: MigrationMeta = {},
): Record<string, string> {
  const applicable = MIGRATIONS
    .filter((m) => m.appliesTo === kind && m.fromVersion >= fileVersion)
    .sort((a, b) => a.toVersion - b.toVersion);
  let out = { ...rawVars };
  for (const m of applicable) {
    out = m.apply(out, meta);
  }
  return out;
}
