import { P as PaletteConfig, H as HarmonyAxis, G as GradientDiskToken, O as Oklch, d as HarmonyMode } from '../themeTypes-B8_Idrp4.js';
export { r as readLiveTokensConfig, a as resolveDataDirs } from '../dataPaths-BpIK_Obx.js';
export { C as CURRENT_COMPONENT_SCHEMA_VERSION } from '../index-4N-Orzzi.js';

/**
 * Pure palette → CSS-variable derivation.
 *
 * Mirrors the logic that previously lived only inside `PaletteEditor.svelte`'s
 * reactive emission, but as standalone functions so the editor store can emit
 * palette-derived vars at boot without requiring any editor component to be
 * mounted. Without this module the disabled-state preview (and any other
 * `var(--surface-neutral)` consumer) reads a stale value on reload until the
 * user opens the LiveEditorOverlay and mounts the PaletteEditors.
 *
 * The PaletteEditor still owns *editing* preview (draft hex picked but not
 * yet committed to overrides). Once committed via the store, this module
 * derives the same CSS vars from the persisted config.
 */

type SchemeDirection = 'light' | 'dark';

/**
 * Base colors → the theme's color state: ten OKLCH base colors + a scheme give
 * the palettes, the harmony axes, the swatch gradients, and the override bag,
 * with AA floors enforced on derived text tokens. Choosing the base colors
 * lives in the live-tokens-set-colors skill; the CLI reaches this via
 * `dist-plugin/setColors`, so keep this module Node-safe (no DOM).
 *
 * This is one dimension of a theme, not a theme: the caller merges the result
 * into the live colors and type, and `save-theme` composes the document.
 */

interface ColorsInput {
    scheme: SchemeDirection;
    /** The one color each palette's ramp derives from (all 10 required); hex string or numeric OKLCH. */
    baseColors: Record<string, Oklch | string>;
    /** Advisory record of the harmony reasoning; the base colors stay ground truth. */
    harmony?: {
        mode: HarmonyMode;
    };
    /** Page-background sky. Off by default; the skill turns it on only when the
     *  request evokes atmosphere. The engine derives the stops itself, on the
     *  scheme's safe side of the Canvas anchor. */
    canvasGradient?: boolean;
}
/** The live colors and type this pass reads before it replaces the color
 *  state: the override bag, so every name no palette owns rides through, and
 *  the swatch gradients, so user-tuned ones survive. Shadow opacity is
 *  derived, not carried — see `shadowVars`. */
interface CarryForward {
    cssVariables?: Record<string, string>;
    gradients?: GradientDiskToken[];
}
interface ContrastCheck {
    textVar: string;
    floor: number;
    /** Worst (lowest-ratio) surface this text was checked against. */
    against: string;
    ratio: number;
    pass: boolean;
    corrected: boolean;
}
interface BuildColorsReport {
    scheme: SchemeDirection;
    checks: ContrastCheck[];
    failures: string[];
    /** 'recipes' when the engine replaced absent/stock swatch gradients with the
     *  family-relative recipes; 'carried' when user-tuned ones rode through. */
    gradients: 'recipes' | 'carried';
    /** Present when the input opted into the page-background sky: either
     *  'on, <sky> → <anchor>' or a 'skipped — …' explanation when the Canvas
     *  anchors at the ramp edge and leaves no room. */
    canvasGradient?: string;
    /** The derived shadow opacity and the canvas lightness it came from. */
    shadows: string;
}
/** The color dimension of a colors-and-type document. Every other key —
 *  name, timestamps, fonts, schema version — belongs to the caller. */
interface ColorsState {
    editorConfigs: Record<string, PaletteConfig>;
    harmonyAxes: HarmonyAxis[];
    gradients: GradientDiskToken[];
    cssVariables: Record<string, string>;
}
interface BuildColorsResult {
    colors: ColorsState;
    report: BuildColorsReport;
}
declare function buildColors(input: ColorsInput, carry?: CarryForward): BuildColorsResult;

/** Sanitize a display name to a safe file name. Pure — no DOM, no fs. */
declare function sanitizeFileName(name: string): string;

export { type BuildColorsReport, type BuildColorsResult, type CarryForward, type ColorsInput, type ColorsState, type ContrastCheck, buildColors, sanitizeFileName };
