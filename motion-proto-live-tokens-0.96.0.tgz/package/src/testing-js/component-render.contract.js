import {
  ContractHarness
} from "./chunk-X6KHEVIG.js";
import {
  openComponentsEditor
} from "./chunk-WIZ6W7UT.js";
import "./chunk-3UKGXCDL.js";
import "./chunk-NB3NZRBM.js";
import {
  selectedContracts
} from "./chunk-SHBYZUPD.js";

// src/testing/component-render.contract.ts
import fs from "fs";
import path from "path";
import { expect, test } from "@playwright/test";
test.describe.configure({ mode: "parallel" });
function discoverDefaultAliases() {
  const root = path.resolve(process.env.LIVE_TOKENS_DATA_DIR ?? "src/live-tokens/data", "component-configs");
  const cases = [];
  for (const directory of fs.readdirSync(root).sort()) {
    const file = path.join(root, directory, "default.json");
    if (!fs.existsSync(file)) continue;
    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    const component = data.component ?? directory;
    for (const variable of Object.keys(data.aliases ?? {}).sort()) {
      cases.push({ component, variable });
    }
  }
  return cases;
}
var requestedComponent = process.env.LIVE_TOKENS_COMPONENT;
var aliasCases = discoverDefaultAliases().filter(({ component }) => !requestedComponent || component === requestedComponent);
var aliasesByComponent = /* @__PURE__ */ new Map();
for (const { component, variable } of aliasCases) {
  const variables = aliasesByComponent.get(component) ?? [];
  variables.push(variable);
  aliasesByComponent.set(component, variables);
}
var TOKEN_OPTION_SELECTOR = [
  ".ui-ts-dropdown .static-chip:not(.active):not(:disabled)",
  ".ui-ts-dropdown .ui-option-item:not(.active):not(:disabled)",
  ".ui-ts-dropdown .font-size-row:not(.active):not(:disabled)"
].join(", ");
async function exerciseVisibleTokenControls(page, componentAliases, exercised, proof) {
  const group = page.locator(".variant-group:visible");
  const settle = () => page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  await settle();
  const variables = await group.locator(".ui-token-selector:visible[data-token-variable]:not(.disabled):not(.locked)").evaluateAll((elements) => [...new Set(elements.map((element) => element.dataset.tokenVariable).filter((value) => !!value))]);
  const pending = variables.filter((variable) => componentAliases.includes(variable) && !exercised.has(variable));
  if (pending.length === 0) return;
  if (!proof.tokenWrite) {
    for (const variable of pending) {
      if (await clickThroughTokenControl(page, variable, settle)) {
        exercised.add(variable);
        proof.tokenWrite = true;
        break;
      }
    }
  }
  const offered = await page.evaluate(async ({ names, optionSelector }) => {
    const frame = () => new Promise((resolve) => requestAnimationFrame(() => resolve()));
    const visibleGroup = [...document.querySelectorAll(".variant-group")].find((element) => element.checkVisibility());
    const counts = {};
    for (const name of names) {
      const selector = [...visibleGroup?.querySelectorAll(
        `.ui-token-selector[data-token-variable="${CSS.escape(name)}"]:not(.disabled):not(.locked)`
      ) ?? []].find((element) => element.checkVisibility());
      const trigger = selector?.querySelector(".ui-ts-trigger");
      if (!selector || !trigger) continue;
      trigger.click();
      await frame();
      await frame();
      counts[name] = selector.querySelectorAll(optionSelector).length;
      trigger.click();
      await frame();
    }
    return counts;
  }, { names: pending.filter((variable) => !exercised.has(variable)), optionSelector: TOKEN_OPTION_SELECTOR });
  for (const [variable, count] of Object.entries(offered)) {
    if (count > 0) exercised.add(variable);
  }
}
async function clickThroughTokenControl(page, variable, settle) {
  const selector = page.locator(".variant-group:visible").locator(`.ui-token-selector:visible[data-token-variable="${variable}"]:not(.disabled):not(.locked)`).first();
  if (await selector.count() === 0) return false;
  const before = await page.evaluate((name) => document.documentElement.style.getPropertyValue(name).trim(), variable);
  let after = before;
  let foundOption = false;
  for (let attempt = 0; attempt < 4 && after === before; attempt++) {
    await settle();
    await selector.locator(".ui-ts-trigger").click();
    const options = selector.locator(TOKEN_OPTION_SELECTOR);
    const count = await options.count();
    if (count === 0) {
      await selector.locator(".ui-ts-trigger").click();
      break;
    }
    foundOption = true;
    await options.nth(attempt % count).click();
    await settle();
    after = await page.evaluate((name) => document.documentElement.style.getPropertyValue(name).trim(), variable);
  }
  if (!foundOption) return false;
  expect(after, `${variable} did not write through its editor control`).not.toBe(before);
  return true;
}
async function exerciseVisibleSplitPaddingControls(page, componentAliases, exercised, proof) {
  const group = page.locator(".variant-group:visible");
  const variables = await group.locator(".merge-btn:visible[data-padding-parent-variable]").evaluateAll((elements) => [...new Set(elements.map((element) => element.dataset.paddingParentVariable).filter((value) => !!value))]);
  for (const variable of variables) {
    if (!componentAliases.includes(variable) || exercised.has(variable)) continue;
    const merge = group.locator(`.merge-btn:visible[data-padding-parent-variable="${variable}"]`).first();
    if (await merge.count()) await merge.click();
  }
  if (variables.length > 0) {
    await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
    await exerciseVisibleTokenControls(page, componentAliases, exercised, proof);
  }
}
async function exerciseVisibleCompositeControls(page, componentAliases, exercised) {
  const toggled = [];
  const group = page.locator(".variant-group:visible");
  const controls = group.locator("[data-token-variables]:visible");
  for (let index = 0; index < await controls.count(); index++) {
    const control = controls.nth(index);
    const variables = (await control.getAttribute("data-token-variables") ?? "").split(/\s+/).filter((variable) => componentAliases.includes(variable) && !exercised.has(variable));
    if (variables.length === 0) continue;
    const before = await page.evaluate((names) => Object.fromEntries(names.map((name) => [
      name,
      document.documentElement.style.getPropertyValue(name).trim()
    ])), variables);
    const input = control.locator('input[type="checkbox"], input[type="radio"], [role="switch"]').first();
    if (await input.count() === 0) continue;
    await input.click();
    toggled.push(input);
    await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
    const after = await page.evaluate((names) => Object.fromEntries(names.map((name) => [
      name,
      document.documentElement.style.getPropertyValue(name).trim()
    ])), variables);
    for (const variable of variables) {
      expect(after[variable], `${variable} did not write through its composite control`).not.toBe(before[variable]);
      exercised.add(variable);
    }
  }
  return toggled;
}
async function exerciseVisibleGradientControls(page, componentAliases, exercised) {
  const group = page.locator(".variant-group:visible");
  const editors = group.locator(".gradient-editor:visible[data-token-variable]");
  for (let index = 0; index < await editors.count(); index++) {
    const editor = editors.nth(index);
    const variable = await editor.getAttribute("data-token-variable");
    if (!variable || !componentAliases.includes(variable) || exercised.has(variable)) continue;
    const before = await page.evaluate((name) => document.documentElement.style.getPropertyValue(name).trim(), variable);
    const solid = editor.getByRole("radio", { name: "Solid" });
    if (await solid.count() && !await solid.isChecked()) await solid.check({ force: true });
    const picker = editor.locator(".picker-slot .ui-token-selector").first();
    await picker.locator(".ui-ts-trigger").click({ force: true });
    const swatch = picker.locator(".static-chip:not(.active):not(:disabled)").first();
    if (await swatch.count() === 0) continue;
    await swatch.click({ force: true });
    await expect.poll(
      () => page.evaluate((name) => document.documentElement.style.getPropertyValue(name).trim(), variable),
      { message: `${variable} did not write through its gradient editor` }
    ).not.toMatch(new RegExp(`^${escapeRegExp(before)}$`));
    exercised.add(variable);
  }
}
function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
async function probeCurrentView(page, componentAliases, forcedVariables = [], provenVariables = []) {
  return page.evaluate(async ({ allAliases, forced, proven }) => {
    const group = Array.from(document.querySelectorAll(".variant-group")).find((element) => element.offsetParent !== null);
    const preview = group?.querySelector(".tabs-preview");
    if (!group || !preview) return { covered: [], unchanged: [] };
    const visibleVariables = /* @__PURE__ */ new Set();
    if (forced.length > 0) {
      for (const variable of forced) {
        if (allAliases.includes(variable)) visibleVariables.add(variable);
      }
    } else {
      for (const element of group.querySelectorAll("[data-token-variable]")) {
        const variable = element.dataset.tokenVariable;
        if (element.offsetParent !== null && variable && allAliases.includes(variable)) {
          visibleVariables.add(variable);
        }
      }
      for (const element of group.querySelectorAll("[data-token-variables]")) {
        if (element.offsetParent === null) continue;
        for (const variable of (element.dataset.tokenVariables ?? "").split(/\s+/)) {
          if (allAliases.includes(variable)) visibleVariables.add(variable);
        }
      }
    }
    for (const variable of [...visibleVariables]) {
      if (!variable.endsWith("-padding")) continue;
      for (const side of ["top", "right", "bottom", "left"]) {
        const sideVariable = `${variable}-${side}`;
        if (allAliases.includes(sideVariable)) visibleVariables.add(sideVariable);
      }
    }
    for (const variable of proven) visibleVariables.delete(variable);
    if (visibleVariables.size === 0) return { covered: [], unchanged: [] };
    const properties = [
      "display",
      "visibility",
      "opacity",
      "position",
      "zIndex",
      "color",
      "background",
      "backgroundColor",
      "backgroundImage",
      "backgroundSize",
      "backgroundPosition",
      "border",
      "borderColor",
      "borderWidth",
      "borderStyle",
      "borderTopColor",
      "borderRightColor",
      "borderBottomColor",
      "borderLeftColor",
      "borderTopWidth",
      "borderRightWidth",
      "borderBottomWidth",
      "borderLeftWidth",
      "borderRadius",
      "borderTopLeftRadius",
      "borderTopRightRadius",
      "borderBottomRightRadius",
      "borderBottomLeftRadius",
      "outline",
      "outlineColor",
      "outlineWidth",
      "boxShadow",
      "filter",
      "backdropFilter",
      "mixBlendMode",
      "fontFamily",
      "fontSize",
      "fontWeight",
      "fontStyle",
      "lineHeight",
      "letterSpacing",
      "textAlign",
      "textDecoration",
      "textTransform",
      "textShadow",
      "whiteSpace",
      "padding",
      "paddingTop",
      "paddingRight",
      "paddingBottom",
      "paddingLeft",
      "margin",
      "marginTop",
      "marginRight",
      "marginBottom",
      "marginLeft",
      "gap",
      "rowGap",
      "columnGap",
      "width",
      "minWidth",
      "maxWidth",
      "height",
      "minHeight",
      "maxHeight",
      "top",
      "right",
      "bottom",
      "left",
      "transform",
      "transformOrigin",
      "translate",
      "rotate",
      "scale",
      "justifyContent",
      "justifyItems",
      "justifySelf",
      "alignContent",
      "alignItems",
      "alignSelf",
      "gridTemplateColumns",
      "gridTemplateRows",
      "gridColumn",
      "gridRow",
      "flex",
      "flexDirection",
      "overflow",
      "overflowX",
      "overflowY",
      "clipPath",
      "objectFit",
      "objectPosition",
      "fill",
      "stroke",
      "strokeWidth",
      "strokeDasharray",
      "strokeDashoffset",
      "cursor",
      "pointerEvents",
      "content",
      "transitionProperty",
      "transitionDuration",
      "transitionTimingFunction",
      "transitionDelay",
      "scrollbarColor",
      "scrollbarWidth"
    ];
    const ignoredAttribute = /^(class|style|data-|aria-)/;
    const stableAttributes = (element) => Array.from(element.attributes).filter((attribute) => !ignoredAttribute.test(attribute.name)).map((attribute) => `${attribute.name}=${attribute.value}`).sort().join(";");
    const pseudoSelectorsFor = (variable) => {
      const pseudoSelectors = ["::before", "::after"];
      if (variable.includes("placeholder")) pseudoSelectors.push("::placeholder");
      if (variable.includes("scrollbar")) {
        pseudoSelectors.push(
          "::-webkit-scrollbar",
          "::-webkit-scrollbar-track",
          "::-webkit-scrollbar-thumb"
        );
      }
      return pseudoSelectors;
    };
    const fingerprintNodes = () => {
      const roots = [preview, ...document.querySelectorAll('[role="dialog"]')];
      return roots.flatMap((root2) => [root2, ...root2.querySelectorAll("*")]);
    };
    const nodeFingerprint = (element, index, pseudoSelectors) => {
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      const values = properties.map((property) => style[property]).join("|");
      const pseudoValues = pseudoSelectors.map((selector) => {
        const pseudo = getComputedStyle(element, selector);
        return properties.map((property) => pseudo[property]).join("|");
      }).join("~");
      return [
        index,
        element.tagName,
        values,
        pseudoValues,
        `${rect.x},${rect.y},${rect.width},${rect.height}`,
        `${element.scrollWidth},${element.scrollHeight}`,
        stableAttributes(element)
      ].join("~");
    };
    const fingerprint = (variable) => {
      const pseudoSelectors = pseudoSelectorsFor(variable);
      return fingerprintNodes().map((element, index) => nodeFingerprint(element, index, pseudoSelectors));
    };
    const movedFrom = (variable, baseline) => {
      const pseudoSelectors = pseudoSelectorsFor(variable);
      const nodes = fingerprintNodes();
      if (nodes.length !== baseline.length) return true;
      for (let index = 0; index < nodes.length; index++) {
        if (nodeFingerprint(nodes[index], index, pseudoSelectors) !== baseline[index]) return true;
      }
      return false;
    };
    const alternateValues = (variable, current) => {
      const values = [];
      const add = (...candidates) => {
        for (const candidate of candidates) {
          if (candidate !== current && !values.includes(candidate)) values.push(candidate);
        }
      };
      if (/(surface|color|text|border)(?!-width)|-icon$|outline-color/.test(variable)) {
        add("rgb(1, 2, 3)", "rgb(253, 127, 3)");
      }
      if (variable.includes("font-family")) add("monospace", "serif");
      if (variable.includes("font-weight")) add("900", "200");
      if (variable.includes("line-height")) add("2.75", "0.75");
      if (variable.includes("letter-spacing")) add("7px", "-2px");
      if (variable.includes("shadow")) add("rgb(1, 2, 3) 7px 9px 0 3px", "none");
      if (variable.includes("blur")) add("blur(7px)", "none");
      if (variable.includes("gradient")) {
        add("linear-gradient(90deg, rgb(1, 2, 3), rgb(253, 127, 3))", "none");
      }
      if (variable.includes("duration") || variable.includes("transition")) add("9s", "0s");
      if (variable.includes("opacity")) add("0.17", "0.83");
      if (variable.includes("display")) add(current === "none" ? "block" : "none", "contents");
      if (variable.includes("align")) add("right", "center", "flex-end");
      if (variable.includes("position")) add("above-label", "below-description", "center");
      if (variable.includes("button-variant")) add("danger", "outline");
      if (variable.includes("shimmer")) {
        add("linear-gradient(90deg, transparent, rgb(255 255 255 / 80%), transparent)", "none");
      }
      if (/(padding|margin|radius|width|height|size|gap|offset|inset|thickness)/.test(variable)) {
        add("37px", "3px");
      }
      if (variable.includes("scale")) add("1.73", "0.53");
      add("__live_tokens_invalid_probe__", "37px", "rgb(1, 2, 3)", "none", "2");
      return values;
    };
    const root = document.documentElement;
    const covered = [];
    const unchanged = [];
    const settle = async () => {
      await new Promise((resolve) => requestAnimationFrame(() => resolve()));
      for (const animation of document.getAnimations()) animation.finish();
    };
    const freeze = document.createElement("style");
    freeze.dataset.reactivityProbe = "true";
    freeze.textContent = "*,*::before,*::after{animation:none!important;caret-color:transparent!important}";
    document.head.appendChild(freeze);
    await document.fonts?.ready;
    await settle();
    for (const variable of visibleVariables) {
      const mutatedVariables = [variable];
      if (variable.endsWith("-padding")) {
        for (const side of ["top", "right", "bottom", "left"]) {
          const sideVariable = `${variable}-${side}`;
          if (allAliases.includes(sideVariable)) mutatedVariables.push(sideVariable);
        }
      }
      const previous = mutatedVariables.map((name) => ({
        name,
        value: root.style.getPropertyValue(name),
        priority: root.style.getPropertyPriority(name)
      }));
      const current = getComputedStyle(root).getPropertyValue(variable).trim();
      const baseline = fingerprint(variable);
      let changed = false;
      for (const candidate of alternateValues(variable, current)) {
        for (const name of mutatedVariables) root.style.setProperty(name, candidate, "important");
        await settle();
        if (movedFrom(variable, baseline)) {
          changed = true;
          break;
        }
      }
      for (const prior of previous) {
        if (prior.value) root.style.setProperty(prior.name, prior.value, prior.priority);
        else root.style.removeProperty(prior.name);
      }
      await settle();
      (changed ? covered : unchanged).push(variable);
    }
    freeze.remove();
    return { covered, unchanged };
  }, { allAliases: componentAliases, forced: forcedVariables, proven: provenVariables });
}
async function selectTab(tab) {
  await tab.click({ force: true });
}
async function selectComponent(page, component) {
  await page.evaluate(async (id) => {
    const editor = window.__liveTokensEditor;
    if (!editor) throw new Error("window.__liveTokensEditor is not present on the components route");
    editor.selectComponent(id);
    await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
  }, component);
  await page.locator(".variant-group").filter({ visible: true }).waitFor();
}
for (const [component, aliases] of aliasesByComponent) {
  test(`${component} repaints every property in its standardized runtime preview`, async ({ page }) => {
    test.setTimeout(6e5);
    await openComponentsEditor(page);
    const covered = /* @__PURE__ */ new Set();
    const seen = /* @__PURE__ */ new Set();
    const unchanged = /* @__PURE__ */ new Set();
    const controlExercised = /* @__PURE__ */ new Set();
    const proof = { tokenWrite: false };
    const probe = async (componentAliases, forced = []) => {
      const remaining = forced.length > 0 ? forced.filter((variable) => !covered.has(variable)) : [];
      if (forced.length > 0 && remaining.length === 0) return;
      if (forced.length > 0) {
        const unchecked = page.locator(
          '.variant-group:visible .tabs-preview input[type="checkbox"]:not(:checked):not(:disabled), .variant-group:visible .properties-header input[type="checkbox"]:not(:checked):not(:disabled)'
        );
        for (let index = 0; index < await unchecked.count(); index++) {
          await unchecked.nth(index).click({ force: true });
        }
      }
      const dialogAction = page.locator('[role="dialog"] button:not(:disabled)').first();
      if (await dialogAction.count()) await dialogAction.hover({ force: true });
      await exerciseVisibleTokenControls(page, componentAliases, controlExercised, proof);
      const gates = await exerciseVisibleCompositeControls(page, componentAliases, controlExercised);
      await exerciseVisibleTokenControls(page, componentAliases, controlExercised, proof);
      await exerciseVisibleSplitPaddingControls(page, componentAliases, controlExercised, proof);
      await exerciseVisibleGradientControls(page, componentAliases, controlExercised);
      const result = await probeCurrentView(page, componentAliases, remaining, [...covered]);
      for (const gate of gates) {
        if (await gate.count()) await gate.click();
      }
      result.covered.forEach((variable) => covered.add(variable));
      result.covered.forEach((variable) => seen.add(variable));
      result.unchanged.forEach((variable) => {
        seen.add(variable);
        if (!covered.has(variable)) unchanged.add(variable);
      });
    };
    const traverseComponent = async (componentId, componentAliases, forced = []) => {
      await selectComponent(page, componentId);
      const visitViews = async () => {
        if (forced.length > 0 && forced.every((variable) => covered.has(variable))) return;
        const sizeSelect = page.locator(".variant-group:visible .preview-actions select").first();
        const sizeValues = await sizeSelect.count() ? await sizeSelect.locator("option").evaluateAll((options) => options.map((option) => option.value)) : [""];
        for (const sizeValue of sizeValues) {
          const currentSizeSelect = page.locator(".variant-group:visible .preview-actions select").first();
          if (sizeValue && await currentSizeSelect.count()) await currentSizeSelect.selectOption(sizeValue);
          const variantTabs = page.locator(".variant-group:visible .variant-tabs .variant-tab-btn");
          const variantLabels = await variantTabs.count() ? await variantTabs.allTextContents() : [""];
          for (let variantIndex = 0; variantIndex < variantLabels.length; variantIndex++) {
            if (variantLabels[variantIndex]) {
              await selectTab(page.locator(".variant-group:visible .variant-tabs .variant-tab-btn").nth(variantIndex));
            }
            await probe(componentAliases, forced);
            const primaryTabs = page.locator(
              ".variant-group:visible .tabs-states-block > .tabs-selectors:first-of-type .state-tab-btn"
            );
            const primaryLabels = await primaryTabs.allTextContents();
            for (let primaryIndex = 0; primaryIndex < primaryLabels.length; primaryIndex++) {
              await selectTab(page.locator(
                ".variant-group:visible .tabs-states-block > .tabs-selectors:first-of-type .state-tab-btn"
              ).nth(primaryIndex));
              await probe(componentAliases, forced);
              const secondaryTabs = page.locator(
                ".variant-group:visible .tabs-states-block > .tabs-selectors.substrip .state-tab-btn"
              );
              const secondaryLabels = await secondaryTabs.allTextContents();
              for (let secondaryIndex = 0; secondaryIndex < secondaryLabels.length; secondaryIndex++) {
                await selectTab(page.locator(
                  ".variant-group:visible .tabs-states-block > .tabs-selectors.substrip .state-tab-btn"
                ).nth(secondaryIndex));
                await probe(componentAliases, forced);
              }
            }
          }
        }
      };
      await visitViews();
      if (forced.length === 0 || forced.every((variable) => covered.has(variable))) return;
      const dialogTrigger = page.locator(
        '.variant-group:visible .tabs-preview [aria-haspopup="dialog"][aria-expanded="false"]'
      ).first();
      if (await dialogTrigger.count()) {
        await dialogTrigger.click({ force: true });
        await page.locator('[role="dialog"]').waitFor();
        await visitViews();
      }
      const canvasSelects = page.locator(".variant-group:visible .tabs-preview .canvas-toolbar select");
      for (let selectIndex = 0; selectIndex < await canvasSelects.count(); selectIndex++) {
        const values = await canvasSelects.nth(selectIndex).locator("option").evaluateAll((options) => options.map((option) => option.value));
        for (const value of values) {
          if (forced.every((variable) => covered.has(variable))) return;
          await canvasSelects.nth(selectIndex).selectOption(value);
          await visitViews();
        }
      }
      const expanders = page.locator(
        '.variant-group:visible .tabs-preview [aria-expanded]:not([aria-haspopup="dialog"])'
      );
      for (let index = 0; index < await expanders.count(); index++) {
        if (forced.every((variable) => covered.has(variable))) return;
        await expanders.nth(index).click({ force: true });
        await visitViews();
      }
      const firstStateTab = page.locator(
        ".variant-group:visible .tabs-states-block > .tabs-selectors:first-of-type .state-tab-btn"
      ).first();
      if (await firstStateTab.count()) await selectTab(firstStateTab);
      const hoverTargets = page.locator(".variant-group:visible .tabs-preview *:visible");
      for (let index = 0; index < await hoverTargets.count(); index++) {
        if (forced.every((variable) => covered.has(variable))) return;
        try {
          await hoverTargets.nth(index).hover({ force: true, timeout: 2e3 });
        } catch {
          continue;
        }
        await probe(componentAliases, forced);
      }
    };
    await traverseComponent(component, aliases);
    const unresolved = aliases.filter((variable) => !covered.has(variable));
    if (unresolved.length > 0) await traverseComponent(component, aliases, unresolved);
    const notExposed = aliases.filter((variable) => !seen.has(variable));
    const notReactive = aliases.filter((variable) => seen.has(variable) && !covered.has(variable));
    const notControlExercised = aliases.filter((variable) => !controlExercised.has(variable));
    expect(notExposed, `Properties not exposed by a standardized component view:
${notExposed.join("\n")}`).toEqual([]);
    expect(notReactive, `Properties whose rendered preview did not change:
${notReactive.join("\n")}`).toEqual([]);
    expect(notControlExercised, `Properties with no rendered editor control offering another value:
${notControlExercised.join("\n")}`).toEqual([]);
    expect(proof.tokenWrite, "no token selector wrote through its dropdown").toBe(true);
    expect(covered.size).toBe(aliases.length);
  });
}
test("component discovery covers every alias exactly once", () => {
  const perComponent = [...aliasesByComponent.values()].reduce((sum, a) => sum + a.length, 0);
  expect(aliasCases.length).toBeGreaterThan(0);
  expect(perComponent).toBe(aliasCases.length);
});
for (const contract of await selectedContracts()) {
  test(`${contract.id} paints each declared property on its declared part`, async ({ page }) => {
    test.setTimeout(18e4);
    const harness = await ContractHarness.open(page, contract);
    expect(await harness.assertProperties()).toBeGreaterThan(0);
  });
}
//# sourceMappingURL=component-render.contract.js.map