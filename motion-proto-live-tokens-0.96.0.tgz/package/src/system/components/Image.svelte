<script module lang="ts">
  import type { CatalogueEntry } from '../../editor/component-editor/scaffolding/types';

  export const catalogue = {
    description: 'A framed picture in the page flow.',
    whenToUse: 'any picture the page shows.',
    whenNotToUse: [
      { when: 'the detail is the point, and the reader opens it to see more.', use: 'imagelightbox' },
    ],
    constraints: ['Page CSS paints decoration.'],
    props: {
      variant:
        '`default` frames the picture with a border and shadow. `bare` drops the frame for pictures that carry their own edge, such as cut-out art or screenshots.',
      size: "`default` keeps the picture's own proportions, `banner` gives it a tall frame, `medium` and `compact` shorter ones.",
    },
  } satisfies CatalogueEntry;
</script>

<script lang="ts">
  interface Props {
    src: string;
    alt: string;
    variant?: 'default' | 'bare';
    size?: 'default' | 'banner' | 'medium' | 'compact';
    height?: string | undefined;
    /** Zoom the contents on hover (frame stays fixed). `undefined` inherits the editor's
        global "Use zoom" default; `true`/`false` force this instance on/off. */
    zoom?: boolean | undefined;
    /** When zoom is active, decide what the hover scale grows. `true` (default) scales the
        content inside the fixed frame, masked by overflow. `false` scales the whole framed
        image so it grows past its layout box. `undefined` inherits the global default.
        Set on its own (without `zoom`) it forces zoom on in the chosen mode. */
    overflowScaling?: boolean | undefined;
    srcset?: string | undefined;
    sizes?: string | undefined;
    /** Content images default to lazy; pass `'eager'` for above-the-fold heroes. */
    loading?: 'lazy' | 'eager';
    decoding?: 'async' | 'sync' | 'auto';
    /** Editor preview hook: paint the hover transform without pointer input. */
    forceHover?: boolean;
  }

  let {
    src,
    alt,
    variant = 'default',
    size = 'default',
    height = undefined,
    zoom = undefined,
    overflowScaling = undefined,
    srcset = undefined,
    sizes = undefined,
    loading = 'lazy',
    decoding = 'async',
    forceHover = false,
  }: Props = $props();

  const sizeHeights: Record<string, string | undefined> = {
    default: undefined,
    banner: '360px',
    medium: '240px',
    compact: '180px',
  };

  let resolvedHeight = $derived(height ?? sizeHeights[size]);

  // Per-instance override of the global zoom intrinsics. `undefined` for a variable leaves
  // :root in charge. Exactly one of the two transforms is ever the scale (the other `none`),
  // so contained and grow can't stack into a double zoom.
  const ZOOM = 'scale(var(--image-zoom-scale))';
  let zoomOff = $derived(zoom === false);
  // Setting either prop forces zoom on; otherwise both inherit the global default.
  let zoomForced = $derived(zoom === true || overflowScaling !== undefined);
  let contained = $derived(overflowScaling !== false);

  let contentHover = $derived(
    zoomOff ? 'none' : zoomForced ? (contained ? ZOOM : 'none') : undefined,
  );
  let frameHover = $derived(
    zoomOff ? 'none' : zoomForced ? (contained ? 'none' : ZOOM) : undefined,
  );
</script>

<div
  class="image"
  class:bare={variant === 'bare'}
  class:force-hover={forceHover}
  style:height={resolvedHeight}
  style:--image-zoom-enabled={contentHover}
  style:--image-grow-enabled={frameHover}
>
  <img {src} {alt} {srcset} {sizes} {loading} {decoding} />
</div>

<style>
  :global(:root) {
    --image-default-radius: var(--radius-2xl);
    --image-default-border: var(--border-neutral);
    --image-default-border-width: var(--border-width-1);
    --image-default-shadow: var(--shadow-md);
    --image-bare-radius: var(--radius-none);
    --image-bare-border: var(--color-transparent);
    --image-bare-border-width: var(--border-width-0);
    --image-bare-shadow: var(--shadow-none);
    --image-zoom-scale: var(--scale-sm);
    /* Hover-scale targets. Contained mode (`overflowScaling`) scales the content within the
       masked frame; grow mode scales the whole frame so it grows past its box. Each is `none`
       (off) or `scale(var(--image-zoom-scale))` (on); only one is ever on at a time. */
    --image-zoom-enabled: none;
    --image-grow-enabled: none;
  }

  .image {
    border-radius: var(--image-default-radius);
    overflow: hidden;
    border: var(--image-default-border-width) solid var(--image-default-border);
    box-shadow: var(--image-default-shadow);
    transform-origin: center;
    transition: transform var(--duration-300) var(--ease-out-cubic);
  }

  .image.bare {
    border-radius: var(--image-bare-radius);
    border: var(--image-bare-border-width) solid var(--image-bare-border);
    box-shadow: var(--image-bare-shadow);
  }

  img {
    width: 100%;
    height: 100%;
    display: block;
    object-fit: cover;
    object-position: center;
    transform-origin: center;
    transition: transform var(--duration-300) var(--ease-out-cubic);
  }

  .image:hover,
  .image.force-hover {
    transform: var(--image-grow-enabled);
  }

  .image:hover img,
  .image.force-hover img {
    transform: var(--image-zoom-enabled);
  }
</style>
