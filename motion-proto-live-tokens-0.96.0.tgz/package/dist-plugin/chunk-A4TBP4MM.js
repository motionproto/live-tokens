import {
  cssColorToOklch,
  gamutClamp,
  oklchToCss
} from "./chunk-7TQQTHI6.js";

// src/editor/core/storage/files/versionedFileResourceClient.ts
function sanitizeFileName(name) {
  return name.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^a-z0-9\-_]/g, "").replace(/-+/g, "-").replace(/^[-_]+|-+$/g, "") || "unnamed";
}

// src/editor/core/themes/parsers/colorOpacity.ts
var COLOR_OPACITY_RE = /^color-mix\(in srgb,\s*var\((--[a-z0-9-]+)\)\s+(\d+)%,\s*transparent\)$/i;
function parseColorOpacity(value) {
  const m = value.trim().match(COLOR_OPACITY_RE);
  if (!m) return null;
  return { name: m[1], opacity: parseInt(m[2], 10) };
}
function formatColorOpacity(name, opacity) {
  return `color-mix(in srgb, var(${name}) ${opacity}%, transparent)`;
}

// src/editor/core/themes/parsers/gradient.ts
var LINEAR_DIRECTIONS = [
  "to top",
  "to top right",
  "to right",
  "to bottom right",
  "to bottom",
  "to bottom left",
  "to left",
  "to top left"
];
var DIRECTION_ANGLES = {
  "to top": 0,
  "to top right": 45,
  "to right": 90,
  "to bottom right": 135,
  "to bottom": 180,
  "to bottom left": 225,
  "to left": 270,
  "to top left": 315
};
function parseDirection(raw) {
  const norm = raw.trim().toLowerCase().replace(/\s+/g, " ");
  return LINEAR_DIRECTIONS.includes(norm) ? norm : null;
}
var RADIAL_BASE_PX = 100;
function formatStopColor(s) {
  const opacity = s.opacity ?? 100;
  if (s.color.startsWith("--")) {
    return opacity >= 100 ? `var(${s.color})` : formatColorOpacity(s.color, opacity);
  }
  return opacity >= 100 ? s.color : `color-mix(in srgb, ${s.color} ${opacity}%, transparent)`;
}
function formatGradientStops(stops) {
  return stops.map((s) => `${formatStopColor(s)} ${s.position}%`).join(", ");
}
function formatRadialShape(v) {
  const ax = v.aspectX ?? 1;
  const ay = v.aspectY ?? 1;
  if (ax === 1 && ay === 1) {
    return v.radius && v.radius > 0 ? `circle ${v.radius}px` : "circle";
  }
  const base = v.radius && v.radius > 0 ? v.radius : RADIAL_BASE_PX;
  return `ellipse ${(base * ax).toFixed(2)}px ${(base * ay).toFixed(2)}px`;
}
function formatGradientValue(v) {
  if (v.type === "none") return "transparent";
  if (v.type === "solid") {
    const first = v.stops[0];
    return first ? formatStopColor(first) : "transparent";
  }
  const stops = formatGradientStops(v.stops);
  if (v.type === "linear") {
    return `linear-gradient(${v.direction ?? `${v.angle}deg`}, ${stops})`;
  }
  return `radial-gradient(${formatRadialShape(v)} at ${v.centerX ?? 50}% 50%, ${stops})`;
}
var NUM = String.raw`-?\d+(?:\.\d+)?`;
var HEADING = String.raw`${NUM}deg|to\s+\w+(?:\s+\w+)?`;
var LINEAR_RE = new RegExp(String.raw`^linear-gradient\(\s*(${HEADING})\s*,\s*(.+)\)$`, "i");
var DEG_RE = new RegExp(String.raw`^(${NUM})deg$`, "i");
var RADIAL_RE = new RegExp(
  String.raw`^radial-gradient\(\s*(circle|circle\s+${NUM}px|ellipse\s+${NUM}px\s+${NUM}px)\s+at\s+(${NUM})%\s+50%\s*,\s*(.+)\)$`,
  "i"
);
var STOP_RE = new RegExp(String.raw`^(.*?)\s+(${NUM})%$`);
var CIRCLE_RADIUS_RE = new RegExp(String.raw`^circle\s+(${NUM})px$`, "i");
var ELLIPSE_RE = new RegExp(String.raw`^ellipse\s+(${NUM})px\s+(${NUM})px$`, "i");
var VAR_RE = /^var\((--[a-z0-9-]+)\)$/i;
function splitTopLevel(s) {
  const parts = [];
  let depth = 0;
  let start = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === "(") depth++;
    else if (c === ")") depth--;
    else if (c === "," && depth === 0) {
      parts.push(s.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(s.slice(start));
  return parts;
}
function parseStop(raw) {
  const m = raw.trim().match(STOP_RE);
  if (!m) return null;
  const position = parseFloat(m[2]);
  const color = m[1].trim();
  const opacity = parseColorOpacity(color);
  if (opacity) return { position, color: opacity.name, opacity: opacity.opacity };
  const token = color.match(VAR_RE);
  return { position, color: token ? token[1] : color };
}
function parseStops(raw) {
  const stops = [];
  for (const part of splitTopLevel(raw)) {
    const stop = parseStop(part);
    if (!stop) return null;
    stops.push(stop);
  }
  return stops.length > 0 ? stops : null;
}
function parseRadialShape(raw) {
  const shape = raw.trim();
  if (/^circle$/i.test(shape)) return {};
  const circle = shape.match(CIRCLE_RADIUS_RE);
  if (circle) return { radius: parseFloat(circle[1]) };
  const ellipse = shape.match(ELLIPSE_RE);
  if (!ellipse) return null;
  const ax = parseFloat(ellipse[1]) / RADIAL_BASE_PX;
  const ay = parseFloat(ellipse[2]) / RADIAL_BASE_PX;
  return { ...ax === 1 ? {} : { aspectX: ax }, ...ay === 1 ? {} : { aspectY: ay } };
}
function parseGradientValue(value) {
  const css = value.trim();
  const linear = css.match(LINEAR_RE);
  if (linear) {
    const deg = linear[1].match(DEG_RE);
    const direction = deg ? null : parseDirection(linear[1]);
    if (!deg && !direction) return null;
    const stops2 = parseStops(linear[2]);
    if (!stops2) return null;
    return deg ? { type: "linear", angle: parseFloat(deg[1]), stops: stops2 } : { type: "linear", angle: 0, direction, stops: stops2 };
  }
  const radial = css.match(RADIAL_RE);
  if (!radial) return null;
  const shape = parseRadialShape(radial[1]);
  const stops = parseStops(radial[3]);
  if (!shape || !stops) return null;
  const centerX = parseFloat(radial[2]);
  return {
    type: "radial",
    angle: 0,
    ...shape,
    ...centerX === 50 ? {} : { centerX },
    stops
  };
}

// src/editor/ui/curveEngine.ts
function makeAnchor(x, y, tangentLen = 15) {
  return { x, y, inDx: -tangentLen, inDy: 0, outDx: tangentLen, outDy: 0 };
}
var HANDLE_SPAN = 1 / 3;
function tangentSlope(prev, x, y, next) {
  const hPrev = prev ? x - prev.x : 0;
  const hNext = next ? next.x - x : 0;
  const dPrev = hPrev > 0 ? (y - prev.y) / hPrev : null;
  const dNext = hNext > 0 ? (next.y - y) / hNext : null;
  if (dPrev === null) return dNext ?? 0;
  if (dNext === null) return dPrev;
  if (dPrev * dNext <= 0) return 0;
  const wPrev = 2 * hNext + hPrev;
  const wNext = hNext + 2 * hPrev;
  return (wPrev + wNext) / (wPrev / dPrev + wNext / dNext);
}
function tangentAnchor(x, y, prev, next) {
  const m = tangentSlope(prev, x, y, next);
  const inDx = prev ? -(x - prev.x) * HANDLE_SPAN : 0;
  const outDx = next ? (next.x - x) * HANDLE_SPAN : 0;
  return { x, y, inDx, inDy: m * inDx, outDx, outDy: m * outDx };
}
function isCornerAnchor(a) {
  return a.inDx === 0 && a.inDy === 0 && a.outDx === 0 && a.outDy === 0;
}
function resmoothAutoCurve(anchors) {
  if (anchors.length < 2) return anchors;
  return anchors.map(
    (a, i) => isCornerAnchor(a) ? a : tangentAnchor(a.x, a.y, anchors[i - 1] ?? null, anchors[i + 1] ?? null)
  );
}
function evalBezier(p0x, p0y, c0x, c0y, c1x, c1y, p1x, p1y, t) {
  const u = 1 - t, u2 = u * u, u3 = u2 * u;
  const t2 = t * t, t3 = t2 * t;
  return {
    x: u3 * p0x + 3 * u2 * t * c0x + 3 * u * t2 * c1x + t3 * p1x,
    y: u3 * p0y + 3 * u2 * t * c0y + 3 * u * t2 * c1y + t3 * p1y
  };
}
function sampleCurve(anchors, xPos) {
  if (anchors.length === 0) return 0;
  if (anchors.length === 1) return anchors[0].y;
  if (xPos <= anchors[0].x) return anchors[0].y;
  if (xPos >= anchors[anchors.length - 1].x) return anchors[anchors.length - 1].y;
  let seg = 0;
  while (seg < anchors.length - 2 && anchors[seg + 1].x < xPos) seg++;
  const a0 = anchors[seg], a1 = anchors[seg + 1];
  const p0x = a0.x, p0y = a0.y;
  const c0x = a0.x + a0.outDx, c0y = a0.y + a0.outDy;
  const c1x = a1.x + a1.inDx, c1y = a1.y + a1.inDy;
  const p1x = a1.x, p1y = a1.y;
  let lo = 0, hi = 1;
  for (let i = 0; i < 20; i++) {
    const mid = (lo + hi) / 2;
    const pt = evalBezier(p0x, p0y, c0x, c0y, c1x, c1y, p1x, p1y, mid);
    if (pt.x < xPos) lo = mid;
    else hi = mid;
  }
  return evalBezier(p0x, p0y, c0x, c0y, c1x, c1y, p1x, p1y, (lo + hi) / 2).y;
}

// src/editor/core/palettes/paletteDerivation.ts
var PALETTE_SPECS = [
  { label: "Brand", cssNamespace: "brand", initialColor: { l: 0.5573, c: 0.1841, h: 25.49 } },
  { label: "Accent", cssNamespace: "accent", initialColor: { l: 0.7674, c: 0.164, h: 70.44 } },
  { label: "Special", cssNamespace: "special", initialColor: { l: 0.6056, c: 0.2189, h: 292.72 } },
  { label: "Canvas", cssNamespace: "canvas", emptySelector: true, initialColor: { l: 0.2284, c: 0.0384, h: 282.93 } },
  { label: "Neutral", cssNamespace: "neutral", neutral: true, initialColor: { l: 0.5679, c: 0.0134, h: 240.07 } },
  { label: "Alternate", cssNamespace: "alternate", neutral: true, displayLabel: "Alternate (neutral)", initialColor: { l: 0.5873, c: 87e-4, h: 48.57 } },
  { label: "Info", cssNamespace: "info", initialColor: { l: 0.5871, c: 0.1855, h: 259.56 } },
  { label: "Success", cssNamespace: "success", initialColor: { l: 0.7198, c: 0.1918, h: 149.52 } },
  { label: "Warning", cssNamespace: "warning", initialColor: { l: 0.6704, c: 0.1716, h: 48.75 } },
  { label: "Danger", cssNamespace: "danger", initialColor: { l: 0.6103, c: 0.2165, h: 18.1 } }
];
var PALETTE_STEPS = [
  { label: "100" },
  { label: "200" },
  { label: "300" },
  { label: "400" },
  { label: "500" },
  { label: "600" },
  { label: "700" },
  { label: "800" },
  { label: "850" },
  { label: "900" },
  { label: "950" }
];
var SCALES = [
  {
    title: "Surfaces",
    isText: false,
    steps: [
      { name: "lowest", position: -1 },
      { name: "lower", position: -2 / 3 },
      { name: "low", position: -1 / 3 },
      { name: "default", position: 0 },
      { name: "high", position: 1 / 3 },
      { name: "higher", position: 2 / 3 },
      { name: "highest", position: 1 }
    ]
  },
  {
    title: "Borders",
    isText: false,
    steps: [
      { name: "faint", position: -1 },
      { name: "subtle", position: -0.5 },
      { name: "default", position: 0 },
      { name: "medium", position: 0.5 },
      { name: "strong", position: 1 }
    ]
  },
  {
    title: "Text",
    isText: true,
    steps: [
      { name: "primary", position: 0 },
      { name: "secondary", position: 0 },
      { name: "tertiary", position: 0 },
      { name: "muted", position: 0 },
      { name: "disabled", position: 0 }
    ]
  }
];
var BW_GUARD_MIN_L = 0.17;
var BW_GUARD_MAX_L = 0.93;
var autoCurve = (...anchors) => resmoothAutoCurve(anchors);
var DEFAULT_PALETTE_LIGHTNESS = () => autoCurve(makeAnchor(0, 95), makeAnchor(100, 8));
var DEFAULT_PALETTE_SATURATION = () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100));
var wrapHue = (h) => (h % 360 + 360) % 360;
function scaleCurveDefaults(scheme = "dark") {
  if (scheme === "light") {
    return {
      Surfaces: {
        lightness: () => autoCurve(makeAnchor(0, 98), makeAnchor(100, 82)),
        saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
      },
      Borders: {
        lightness: () => autoCurve(makeAnchor(0, 92), makeAnchor(100, 45)),
        saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
      },
      Text: {
        lightness: () => autoCurve(makeAnchor(0, 30), makeAnchor(100, 120)),
        saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 15))
      }
    };
  }
  return {
    Surfaces: {
      lightness: () => autoCurve(makeAnchor(0, 15), makeAnchor(100, 47)),
      saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
    },
    Borders: {
      lightness: () => autoCurve(makeAnchor(0, 25), makeAnchor(100, 80)),
      saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
    },
    Text: {
      lightness: () => autoCurve(makeAnchor(0, 120), makeAnchor(100, 55)),
      saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 15))
    }
  };
}
var defaultScaleCurves = scaleCurveDefaults("dark");
function paletteStepKey(label) {
  return `Palette-${label}`;
}
function stepKey(scaleTitle, stepName) {
  return `${scaleTitle}-${stepName}`;
}
function stepIndexToX(index) {
  return index / (PALETTE_STEPS.length - 1) * 100;
}
function scaleStepToX(step, scale) {
  const idx = scale.steps.indexOf(step);
  return scale.steps.length > 1 ? idx / (scale.steps.length - 1) * 100 : 50;
}
function serializeDerivedValue(value) {
  return value.kind === "raw" ? value.css : oklchToCss(value.l, value.c, value.h);
}
function computePaletteOklch(index, base, lightnessCurve, saturationCurve, curveOffset, hueCurve) {
  const { c: baseC } = base;
  const xPos = stepIndexToX(index);
  const targetL = Math.max(0, Math.min(100, sampleCurve(lightnessCurve, xPos) + (curveOffset.lightness ?? 0))) / 100;
  const satMul = Math.max(0, Math.min(2, (sampleCurve(saturationCurve, xPos) + (curveOffset.saturation ?? 0)) / 100));
  const targetC = baseC * satMul;
  const hueDelta = (hueCurve ? sampleCurve(hueCurve, xPos) : 0) + (curveOffset.hue ?? 0);
  const h = hueDelta === 0 ? base.h : wrapHue(base.h + hueDelta);
  return gamutClamp(targetL, targetC, h);
}
function nearestPaletteStep(lightnessCurve, baseL) {
  let best = 0;
  let bestD = Infinity;
  for (let i = 0; i < PALETTE_STEPS.length; i++) {
    const d = Math.abs(sampleCurve(lightnessCurve, stepIndexToX(i)) - baseL * 100);
    if (d < bestD) {
      bestD = d;
      best = i;
    }
  }
  return best;
}
function setCurveAnchor(curve, x, y, smooth = false) {
  if (smooth && curve.length === 2) {
    const [p0, p2] = curve;
    const mid = { x, y, inDx: 0, inDy: 0, outDx: 0, outDy: 0 };
    if (Math.abs(p0.x - x) < 0.5) {
      return {
        curve: [tangentAnchor(x, y, null, p2), tangentAnchor(p2.x, p2.y, mid, null)],
        displacedY: p0.y,
        priorEndpoints: [p0, p2]
      };
    }
    if (Math.abs(p2.x - x) < 0.5) {
      return {
        curve: [tangentAnchor(p0.x, p0.y, null, mid), tangentAnchor(x, y, p0, null)],
        displacedY: p2.y,
        priorEndpoints: [p0, p2]
      };
    }
    return {
      curve: [
        tangentAnchor(p0.x, p0.y, null, mid),
        tangentAnchor(x, y, p0, p2),
        tangentAnchor(p2.x, p2.y, mid, null)
      ],
      priorEndpoints: [p0, p2]
    };
  }
  const existing = curve.findIndex((a) => Math.abs(a.x - x) < 0.5);
  if (existing >= 0) {
    const displacedY = curve[existing].y;
    return { curve: curve.map((a, i) => i === existing ? { ...a, x, y } : a), displacedY };
  }
  let insertAt = curve.findIndex((a) => a.x > x);
  if (insertAt < 0) insertAt = curve.length;
  const prev = curve[insertAt - 1] ?? null;
  const next = curve[insertAt] ?? null;
  const out = [...curve];
  if (prev && next) {
    const span = next.x - prev.x;
    out[insertAt - 1] = scaleOutHandle(prev, (x - prev.x) / span);
    out[insertAt] = scaleInHandle(next, (next.x - x) / span);
  }
  out.splice(insertAt, 0, fitBetween(tangentAnchor(x, y, prev, next), out[insertAt - 1] ?? null, out[insertAt] ?? null));
  return { curve: out };
}
var scaleOutHandle = (a, k) => ({ ...a, outDx: a.outDx * k, outDy: a.outDy * k });
var scaleInHandle = (a, k) => ({ ...a, inDx: a.inDx * k, inDy: a.inDy * k });
function fitBetween(a, prev, next) {
  let out = a;
  if (prev) {
    const room = a.x - (prev.x + prev.outDx);
    if (room < -out.inDx) out = scaleInHandle(out, room <= 0 ? 0 : room / -out.inDx);
  }
  if (next) {
    const room = next.x + next.inDx - a.x;
    if (room < out.outDx) out = scaleOutHandle(out, room <= 0 ? 0 : room / out.outDx);
  }
  return out;
}
function liftCurveAnchor(curve, x, displacedY, priorEndpoints) {
  if (priorEndpoints) return priorEndpoints;
  const idx = curve.findIndex((a) => Math.abs(a.x - x) < 0.5);
  if (idx < 0) return curve;
  if (displacedY !== void 0) return curve.map((a, i) => i === idx ? { ...a, y: displacedY } : a);
  if (idx === 0 || idx === curve.length - 1) return curve;
  const out = curve.filter((_, i) => i !== idx);
  const prev = curve[idx - 1];
  const next = curve[idx + 1];
  if (prev && next) {
    const span = next.x - prev.x;
    out[idx - 1] = scaleOutHandle(prev, span / (curve[idx].x - prev.x));
    out[idx] = scaleInHandle(next, span / (next.x - curve[idx].x));
  }
  return out;
}
function syncBaseAnchor(cfg) {
  if (cfg.anchorToBase === false) return;
  const prev = cfg.anchorPlacement;
  const fresh = prev === void 0;
  let lCurve = cfg.lightnessCurve;
  let sCurve = cfg.saturationCurve;
  let hCurve = cfg.hueCurve;
  if (prev) {
    const prevX = stepIndexToX(prev.step);
    lCurve = liftCurveAnchor(lCurve, prevX, prev.displacedL);
    sCurve = liftCurveAnchor(sCurve, prevX, prev.displacedS);
    if (hCurve) hCurve = liftCurveAnchor(hCurve, prevX, prev.displacedH);
  }
  const step = nearestPaletteStep(lCurve, cfg.baseColor.l);
  const x = stepIndexToX(step);
  const l = setCurveAnchor(lCurve, x, cfg.baseColor.l * 100, fresh);
  const s = setCurveAnchor(sCurve, x, 100, fresh);
  cfg.lightnessCurve = l.curve;
  cfg.saturationCurve = s.curve;
  const h = hCurve ? setCurveAnchor(hCurve, x, 0, fresh) : void 0;
  if (h) cfg.hueCurve = h.curve;
  cfg.anchorPlacement = {
    step,
    displacedL: l.displacedY,
    displacedS: s.displacedY,
    displacedH: h?.displacedY,
    priorLightnessEndpoints: prev?.priorLightnessEndpoints ?? l.priorEndpoints,
    priorSaturationEndpoints: prev?.priorSaturationEndpoints ?? s.priorEndpoints,
    // No else-branch reading `prev?.priorHueEndpoints`: that could only fire
    // if a placed hue curve later went absent, which RJC 7 (reset never
    // deletes) never lets happen.
    priorHueEndpoints: h ? prev?.priorHueEndpoints ?? h.priorEndpoints : void 0
  };
}
function computeDerivedOklch(step, base, scaleTitle, scaleCurves, curveOffset) {
  const scale = SCALES.find((s) => s.title === scaleTitle);
  const xPos = scaleStepToX(step, scale);
  const defs = defaultScaleCurves[scaleTitle];
  const lCurve = scaleCurves[scaleTitle]?.lightness ?? defs.lightness();
  const sCurve = scaleCurves[scaleTitle]?.saturation ?? defs.saturation();
  const hCurve = scaleCurves[scaleTitle]?.hue;
  const lOff = curveOffset[`${scaleTitle}-lightness`] ?? 0;
  const sOff = curveOffset[`${scaleTitle}-saturation`] ?? 0;
  const hOff = curveOffset[`${scaleTitle}-hue`] ?? 0;
  const { l: baseL, c: baseC, h: baseH } = base;
  let targetL;
  if (scale.isText) {
    const lMul = Math.max(0, Math.min(2, (sampleCurve(lCurve, xPos) + lOff) / 100));
    targetL = Math.max(0, Math.min(1, baseL * lMul));
  } else {
    targetL = Math.max(0, Math.min(100, sampleCurve(lCurve, xPos) + lOff)) / 100;
  }
  const satMul = Math.max(0, Math.min(2, (sampleCurve(sCurve, xPos) + sOff) / 100));
  const targetC = baseC * satMul;
  const hueDelta = (hCurve ? sampleCurve(hCurve, xPos) : 0) + hOff;
  const targetH = hueDelta === 0 ? baseH : wrapHue(baseH + hueDelta);
  return gamutClamp(targetL, targetC, targetH);
}
function scaleToCssVar(scaleTitle, stepName, cssNamespace) {
  if (cssNamespace === null) return null;
  if (scaleTitle === "Surfaces") {
    const suffix = stepName === "default" ? "" : `-${stepName}`;
    return cssNamespace === "neutral" ? `--surface-neutral${suffix}` : `--surface-${cssNamespace}${suffix}`;
  }
  if (scaleTitle === "Borders") {
    const suffix = stepName === "default" ? "" : `-${stepName}`;
    return cssNamespace === "neutral" ? `--border-neutral${suffix}` : `--border-${cssNamespace}${suffix}`;
  }
  if (scaleTitle === "Text") {
    if (cssNamespace === "neutral") return `--text-${stepName}`;
    return stepName === "primary" ? `--text-${cssNamespace}` : `--text-${cssNamespace}-${stepName}`;
  }
  return null;
}
function derivePaletteValues(spec, config) {
  const out = {};
  if (!config) return out;
  const baseColor = config.baseColor ?? spec.initialColor;
  const overrides = config.overrides ?? {};
  const curveOffset = config.curveOffset ?? {};
  const scaleCurves = config.scaleCurves ?? {};
  const lightnessCurve = config.lightnessCurve ?? DEFAULT_PALETTE_LIGHTNESS();
  const saturationCurve = config.saturationCurve ?? DEFAULT_PALETTE_SATURATION();
  PALETTE_STEPS.forEach((ps, index) => {
    const k = paletteStepKey(ps.label);
    const value = k in overrides ? { kind: "color", ...overrides[k] } : { kind: "color", ...computePaletteOklch(index, baseColor, lightnessCurve, saturationCurve, curveOffset, config.hueCurve) };
    out[`--color-${spec.cssNamespace}-${ps.label}`] = value;
  });
  for (const scale of SCALES) {
    for (const step of scale.steps) {
      const k = stepKey(scale.title, step.name);
      const value = k in overrides ? { kind: "color", ...overrides[k] } : { kind: "color", ...computeDerivedOklch(step, baseColor, scale.title, scaleCurves, curveOffset) };
      const varName = scaleToCssVar(scale.title, step.name, spec.cssNamespace);
      if (varName) out[varName] = value;
    }
  }
  const textPrimary = out["--text-primary"];
  if (textPrimary?.kind === "color") {
    const mirroredL = Math.max(BW_GUARD_MIN_L, Math.min(BW_GUARD_MAX_L, 1 - textPrimary.l));
    out["--text-inverted"] = { kind: "color", ...gamutClamp(mirroredL, textPrimary.c, textPrimary.h) };
  }
  if (spec.emptySelector) {
    const emptyMode = config.emptyMode ?? "solid";
    const gradientStyle = config.gradientStyle ?? "linear";
    const gradientAngle = config.gradientAngle ?? 180;
    const gradientReverse = config.gradientReverse ?? false;
    const gradientSize = config.gradientSize ?? "page";
    const gradientStops = config.gradientStops ?? [
      { position: 0, paletteLabel: "800" },
      { position: 100, paletteLabel: "950" }
    ];
    if (emptyMode === "solid") {
      out["--page-bg"] = { kind: "color", ...baseColor };
      out["--page-bg-attachment"] = { kind: "raw", css: "scroll" };
    } else {
      const sortedStops = [...gradientStops].sort(
        (a, b) => gradientReverse ? b.position - a.position : a.position - b.position
      );
      const stopsCss = sortedStops.map((s) => {
        const stopValue = out[`--color-${spec.cssNamespace}-${s.paletteLabel}`];
        const css = stopValue ? serializeDerivedValue(stopValue) : "oklch(0 0 0)";
        return `${css} ${s.position}%`;
      }).join(", ");
      let gradient;
      switch (gradientStyle) {
        case "radial":
          gradient = `radial-gradient(circle, ${stopsCss})`;
          break;
        case "conic":
          gradient = `conic-gradient(from ${gradientAngle}deg, ${stopsCss})`;
          break;
        default:
          gradient = `linear-gradient(${gradientAngle}deg, ${stopsCss})`;
      }
      out["--page-bg"] = { kind: "raw", css: gradient };
      out["--page-bg-attachment"] = { kind: "raw", css: gradientSize === "window" ? "fixed" : "scroll" };
    }
  }
  return out;
}
function palettesToValues(palettes) {
  const out = {};
  for (const spec of PALETTE_SPECS) {
    Object.assign(out, derivePaletteValues(spec, palettes[spec.label]));
  }
  return out;
}
function palettesToVars(palettes) {
  const out = {};
  for (const [k, v] of Object.entries(palettesToValues(palettes))) {
    out[k] = serializeDerivedValue(v);
  }
  return out;
}
function reconcilePalettesFromCssVars(palettes, cssVars) {
  const next = structuredClone(palettes);
  const consumed = /* @__PURE__ */ new Set();
  const snapped = /* @__PURE__ */ new Set();
  for (const spec of PALETTE_SPECS) {
    const current = next[spec.label];
    if (current === void 0) continue;
    if (current._imported === true) {
      const anchor = cssVars[`--color-${spec.cssNamespace}-500`];
      const anchorOklch = anchor ? cssColorToOklch(anchor) : null;
      if (anchorOklch) {
        next[spec.label] = { ...current, baseColor: anchorOklch, _imported: false };
        syncBaseAnchor(next[spec.label]);
        snapped.add(spec.label);
      } else {
        next[spec.label] = { ...current, _imported: false };
      }
    }
    for (const k of Object.keys(derivePaletteValues(spec, next[spec.label]))) {
      consumed.add(k);
    }
  }
  return { palettes: next, consumed, snapped };
}

export {
  parseColorOpacity,
  DIRECTION_ANGLES,
  formatGradientValue,
  parseGradientValue,
  sanitizeFileName,
  makeAnchor,
  resmoothAutoCurve,
  PALETTE_SPECS,
  PALETTE_STEPS,
  SCALES,
  DEFAULT_PALETTE_LIGHTNESS,
  DEFAULT_PALETTE_SATURATION,
  scaleCurveDefaults,
  scaleStepToX,
  setCurveAnchor,
  syncBaseAnchor,
  scaleToCssVar,
  palettesToVars,
  reconcilePalettesFromCssVars
};
