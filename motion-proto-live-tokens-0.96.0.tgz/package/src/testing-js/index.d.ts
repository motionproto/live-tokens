import { PlaywrightTestProject, PlaywrightTestConfig } from '@playwright/test';
import { L as LiveTokensTestingConfig } from './vitest-5vWtqwWe.js';
export { C as COMPONENTS_PATH_ENV, a as COMPONENT_ENV, D as DEFAULT_PAGE_VIEWPORTS, P as PAGES_ENV, b as PAGE_VIEWPORTS_ENV, c as PageViewport, R as ResolvedTestingConfig, T as TESTING_CONFIG_FILE, V as VitestConfigOptions, d as createVitestConfig, e as defineTestingConfig, f as devServerCommand, r as resolveTestingConfig } from './vitest-5vWtqwWe.js';
import 'vite';
import 'vitest/config';

interface PlaywrightConfigOptions extends LiveTokensTestingConfig {
    /** Project root the settings resolve against. Default `process.cwd()`. */
    root?: string;
    /** Projects that run beside the contract project. */
    extraProjects?: PlaywrightTestProject[];
    /** Where projects that declare no `testDir` of their own look. */
    testDir?: string;
    /** Bounds the whole run. Default fifteen minutes, the same bound
     *  `check-component --tests` and `check-page --tests` hold their spawned
     *  child to (`LIVE_TOKENS_TESTS_TIMEOUT` in `bin/contractRunner.mjs`), so a
     *  hung run stops here too, for a caller that invokes this factory
     *  directly rather than through the CLI. */
    globalTimeout?: number;
}
/**
 * The contract project, its dev server, and the data isolation the two share.
 *
 * Isolation runs here rather than in a global setup because the config is the
 * first thing every process in the run evaluates: the environment it leaves
 * behind reaches the workers and the dev server, and nothing in the run can
 * observe the state before it.
 */
declare function createPlaywrightConfig(options?: PlaywrightConfigOptions): Promise<PlaywrightTestConfig>;

/**
 * The plugin reads this name ahead of its own options and
 * `live-tokens.config.json`, so setting it redirects every server-side write —
 * the data tree, `tokens.generated.css`, and `fonts.css` — into the copy.
 */
declare const TEST_DATA_DIR_ENV = "LIVE_TOKENS_TEST_DATA_DIR";
/** What the suites and the harness read component configs from in the runner's
 *  own process. It names the same directory and is a separate variable because
 *  it answers a different question: where a reader looks, not where the server
 *  is confined. */
declare const DATA_DIR_ENV = "LIVE_TOKENS_DATA_DIR";
interface IsolatedData {
    dataDir: string;
    /** True when this process made the copy and owns removing it. */
    created: boolean;
}
/**
 * Copy `sourceDataDir` into a unique temporary directory and point both the
 * server and the runner at it. Idempotent across processes: Playwright loads
 * the config again in every worker, and each inherits the parent's environment,
 * so only the first call copies anything.
 */
declare function isolateDataDir(sourceDataDir: string): IsolatedData;

declare const PORT_ENV = "LIVE_TOKENS_TEST_PORT";
/**
 * The port the dev server and `baseURL` share. Cached in the environment so
 * every Playwright worker, which loads the config again in its own process,
 * reads the port the main process settled on.
 */
declare function resolvePort(preferred?: number): number;

type ContractRule = 'contract-listed' | 'contract-render' | 'contract-alias' | 'contract-persist' | 'contract-theme' | 'contract-states' | 'contract-interaction' | 'contract-behavior' | 'contract-sketch' | 'contract-missing';
/**
 * A failed obligation, carrying the rule id the CLI reports it under. A defect
 * fixture names the rule it expects, and `check-component --tests` maps a
 * reporter error onto a finding.
 */
declare class ContractViolation extends Error {
    readonly rule: ContractRule;
    readonly component: string;
    constructor(rule: ContractRule, component: string, message: string);
}
interface Inapplicable {
    applicable: false;
    reason: string;
}
declare function isInapplicable(value: unknown): value is Inapplicable;
interface PartLocator {
    /** Resolved inside the preview stage unless `portal` is set. */
    selector: string;
    /** Read computed style from this pseudo-element of the part, e.g.
     *  `'::after'`. Chromium's `getComputedStyle` only tolerates the bare form
     *  (`'after'`) for `::before`/`::after`; use the full `::` syntax so a
     *  future pseudo-element (`::placeholder`, `::marker`, ...) works the same
     *  way without a silent fallback to the host element's own style. */
    pseudo?: string;
    /** Rendered outside the preview stage. Resolved against the document. */
    portal?: boolean;
}
type PartDeclaration = string | PartLocator;
/**
 * An editor control the preview is gated behind: a canvas-toolbar checkbox, an
 * optional-content switch. `check` sets a checkbox to a state and is safe to
 * repeat; `value` picks a select option; neither clicks once.
 */
interface ControlStep {
    kind: 'control';
    /** Selector inside the visible variant group. */
    selector: string;
    check?: boolean;
    value?: string;
}
type SetupStep = InteractionAction | ControlStep;
/** Which VariantGroup, which state tab, and what has to happen first. */
interface View {
    /** Variant tab label. Omitted when the editor renders one variant. */
    variant?: string;
    /** State tab label. Omitted when the editor renders no state strip. */
    state?: string;
    /** Run after the tabs are selected. Portaled and toolbar-gated parts exist
     *  only once these have run. */
    setup?: SetupStep[];
}
/** Part key -> CSS property -> the design token that must drive it. */
type PaintMap = Record<string, Record<string, string>>;
interface PropertyExpectation extends View {
    paints: PaintMap;
}
interface StateExpectation extends View {
    state: string;
    /** Class the root part carries while the editor previews this state. */
    forceClass?: string;
    /** Part key -> attributes it must carry. A null value requires the absence. */
    attributes?: Record<string, Record<string, string | null>>;
    /** What the state repaints, as computed-value equality against its token. */
    paints?: PaintMap;
}
/**
 * `token` and `opacity` drive the token selector for `variable`. `gradient`
 * drives the gradient editor for `variable`. `literal` drives `control` and
 * reads `variable` back off the root, which is where an intrinsic lands: the
 * editors write those into the alias bucket. `config` drives `control` and
 * reads `configKey` out of the config bucket, which holds editor metadata that
 * never reaches `:root`.
 */
type PersistenceShape = 'token' | 'literal' | 'opacity' | 'gradient' | 'config';
interface PersistenceCase extends View {
    shape: PersistenceShape;
    /** The alias the value is read back from. Omitted for `config`. */
    variable?: string;
    /** Selector inside the visible variant group, for `literal` and `config`. */
    control?: string;
    /** The config-bucket key, for `config`. */
    configKey?: string;
    /** Where the persisted value must land once the page has reloaded. */
    observe: {
        part: string;
        css: string;
    };
}
interface PersistenceExpectation {
    cases: PersistenceCase[];
    /** The alias Reset must return to the value the server holds for it. It has
     *  to be one a case above moves, so the saved value and the value the
     *  component booted with are different and Reset can be seen to choose. */
    resetVariable: string;
}
interface ThemeExpectation extends View {
    /** Theme slug shown in the Theme Picker, e.g. `ocean`. */
    theme: string;
    /** Variables whose root value the theme must move. */
    changed: string[];
    /**
     * Variables the theme must leave exactly as they were. Two theme JSON files
     * can name the identical design token (e.g. both `--border-neutral`) and
     * still resolve to different rendered colors, because many color primitives
     * are computed per theme from a palette/seed even when the alias string is
     * unchanged — comparing the two files' alias *names* does not establish
     * invariance. Pick `unchanged` candidates from token families a theme never
     * recolors: `--shadow-*`, `--icon-size-*`, `--font-size-*`,
     * `--line-height-*`, `--font-family`/`--font-mono`, and the spacing/radius/
     * border-width scale steps (`--space-*`, `--radius-*`, `--border-width-*`)
     * are all fixed constants, not palette-derived — verify a candidate's
     * *resolved* value is identical between the two theme files before trusting
     * it, not just that the alias name matches.
     */
    unchanged: string[];
    /** Variables the theme's own component config aliases, and the design token
     *  each must resolve to under it. */
    aliasedTo: Record<string, string>;
    /** Where the theme's value must land in the rendered preview. */
    observe: {
        part: string;
        css: string;
        variable: string;
    };
}
type InteractionAction = {
    kind: 'press';
    part: string;
    key: string;
} | {
    kind: 'click';
    part: string;
} | {
    kind: 'type';
    part: string;
    text: string;
} | {
    kind: 'dragTo';
    part: string;
    along: string;
    fraction: number;
};
type InteractionOutcome = {
    kind: 'attribute';
    part: string;
    name: string;
    value: string;
} | {
    kind: 'valueMoves';
    part: string;
    direction: 'up' | 'down';
} | {
    kind: 'valueBecomes';
    part: string;
    value: string;
} | {
    kind: 'valueChanges';
    part: string;
} | {
    kind: 'valueHolds';
    part: string;
}
/** Whether the part takes focus. The only outcome a button with no state
 *  attribute has: a disabled one refuses it and an enabled one takes it. */
 | {
    kind: 'focused';
    part: string;
    value: boolean;
};
interface InteractionCase extends View {
    name: string;
    action: InteractionAction;
    expect: InteractionOutcome;
}
interface InteractionExpectation {
    /** The part carrying the interactive role. */
    part: string;
    role: string;
    cases: InteractionCase[];
}
/**
 * One mounted case under happy-dom: props in, a DOM event, one assertion. It
 * carries what a browser cannot reach, the callback a controlled component
 * calls instead of moving its own state.
 */
interface BehaviorCase {
    name: string;
    /** Props the fixture mounts with. A snippet-valued prop is not
     *  expressible; a component whose behavior needs one records that case
     *  as inapplicable with the reason. */
    props?: Record<string, unknown>;
    action?: {
        kind: 'click' | 'keydown' | 'input';
        part: string;
        key?: string;
        value?: string;
    };
    expect: {
        kind: 'callback';
        prop: string;
        args: unknown[];
    } | {
        kind: 'no-callback';
        prop: string;
    } | {
        kind: 'attribute';
        part: string;
        name: string;
        value: string | null;
    } | {
        kind: 'text';
        part: string;
        value: string;
    };
}
interface BehaviorExpectation {
    cases: BehaviorCase[];
}
interface SketchPartExpectation {
    part: string;
    /** The design token `--sketch-fill` must resolve to on this part. */
    fill?: string;
    /** The design token `--sketch-stroke` must resolve to on this part. */
    stroke?: string;
}
interface SketchExpectation extends View {
    /** Sketchstyle id the paint is asserted under. */
    style: string;
    parts: SketchPartExpectation[];
}
interface ComponentContract {
    id: string;
    origin: 'system' | 'custom';
    parts: Record<string, PartDeclaration>;
    /** Part key of the component's own root element in the preview. */
    root: string;
    /** The view every obligation opens with. */
    view?: View;
    states: StateExpectation[] | Inapplicable;
    properties: PropertyExpectation[];
    /**
     * Aliases no paint map can pin, each with the reason. A token consumed
     * inside `calc()` or handed to a gradient function never appears verbatim in
     * a computed style, so the probe cannot read it back — that is the only
     * class this belongs to. A token a sibling alias merely happens to carry
     * the same rendered value through (a base padding token behind four
     * per-side overrides, say) is not in this class: the per-side entries pin
     * their own aliases, not the base one, and a paint map that drives the base
     * token directly and observes the per-side CSS property can pin it too. Put
     * that here and Wave 4's coverage JSON records the base token as covered
     * when nothing asserts the link between it and what actually painted.
     */
    uncovered?: Record<string, string>;
    persistence: PersistenceExpectation;
    theme: ThemeExpectation;
    interaction: InteractionExpectation | Inapplicable;
    /** What the component does when it is driven, proven under happy-dom. */
    behavior: BehaviorExpectation | Inapplicable;
    sketch: SketchExpectation | Inapplicable;
}
declare function requiresInteraction(role: string | null): boolean;
declare function partLocator(contract: ComponentContract, key: string): PartLocator;

declare const shippedContracts: ComponentContract[];
/** Names the module `selectedContracts` loads a custom component's
 *  `ComponentContract[]` from. The suite files are static Playwright entry
 *  points with no argument to receive one through, so an env var plus a
 *  dynamic import is the only route in. */
declare const CONTRACTS_MODULE_ENV = "LIVE_TOKENS_CONTRACTS_MODULE";
/** The shipped list plus whatever `LIVE_TOKENS_CONTRACTS_MODULE` names,
 *  unfiltered — what a "no contract for this id" error lists as declared. */
declare function allContracts(contracts?: ComponentContract[]): Promise<ComponentContract[]>;
/** The contracts a run covers, narrowed by `LIVE_TOKENS_COMPONENT`. */
declare function selectedContracts(contracts?: ComponentContract[]): Promise<ComponentContract[]>;

export { type BehaviorCase, type BehaviorExpectation, CONTRACTS_MODULE_ENV, type ComponentContract, type ContractRule, ContractViolation, type ControlStep, DATA_DIR_ENV, type Inapplicable, type InteractionAction, type InteractionCase, type InteractionExpectation, type InteractionOutcome, type IsolatedData, LiveTokensTestingConfig, PORT_ENV, type PaintMap, type PartDeclaration, type PartLocator, type PersistenceCase, type PersistenceExpectation, type PersistenceShape, type PlaywrightConfigOptions, type PropertyExpectation, type SetupStep, type SketchExpectation, type SketchPartExpectation, type StateExpectation, TEST_DATA_DIR_ENV, type ThemeExpectation, type View, allContracts, createPlaywrightConfig, isInapplicable, isolateDataDir, partLocator, requiresInteraction, resolvePort, selectedContracts, shippedContracts };
