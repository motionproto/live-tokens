// vite-plugin/files/dataPaths.ts
import fs from "fs";
import path from "path";
var DEFAULT_DATA_DIR = "src/live-tokens/data";
var TEST_DATA_DIR_ENV = "LIVE_TOKENS_TEST_DATA_DIR";
function testDataDir() {
  const raw = process.env[TEST_DATA_DIR_ENV];
  return raw && raw.trim() !== "" ? path.resolve(raw.trim()) : void 0;
}
var TEST_PACKAGE_DATA_DIR_ENV = "LIVE_TOKENS_TEST_PACKAGE_DATA_DIR";
function testPackageDataDir() {
  const raw = process.env[TEST_PACKAGE_DATA_DIR_ENV];
  return raw && raw.trim() !== "" ? path.resolve(raw.trim()) : void 0;
}
var KNOWN_CONFIG_KEYS = /* @__PURE__ */ new Set([
  "dataDir",
  "colorsAndTypeDir",
  "componentConfigsDir",
  "themesDir",
  "manifestsDir",
  "tokensCssPath",
  "componentDirs",
  "checks"
]);
var cached = null;
function readLiveTokensConfig() {
  if (cached) return cached;
  try {
    const configPath = path.resolve("live-tokens.config.json");
    if (!fs.existsSync(configPath)) return cached = {};
    const parsed = JSON.parse(fs.readFileSync(configPath, "utf-8"));
    if (!parsed || typeof parsed !== "object") return cached = {};
    const unknown = Object.keys(parsed).filter(
      (k) => k !== "$schema" && !KNOWN_CONFIG_KEYS.has(k)
    );
    if (unknown.length > 0) {
      console.warn(
        `[live-tokens] Unknown key(s) in live-tokens.config.json: ${unknown.join(", ")}. Known keys: ${Array.from(KNOWN_CONFIG_KEYS).join(", ")}.`
      );
    }
    cached = parsed;
    return cached;
  } catch {
    return cached = {};
  }
}
function resolveDataDirs(opts = {}) {
  const isolated = testDataDir();
  if (isolated) {
    return {
      dataDir: isolated,
      colorsAndTypeDir: path.join(isolated, "colors-and-type"),
      componentConfigsDir: path.join(isolated, "component-configs"),
      themesDir: path.join(isolated, "themes"),
      sketchStylesDir: path.join(isolated, "sketch-styles")
    };
  }
  const fileConfig = readLiveTokensConfig();
  const dataDirRaw = opts.dataDir ?? fileConfig.dataDir ?? DEFAULT_DATA_DIR;
  const dataDir = path.resolve(dataDirRaw);
  const sub = (name) => path.resolve(dataDir, name);
  return {
    dataDir,
    colorsAndTypeDir: opts.colorsAndTypeDir ? path.resolve(opts.colorsAndTypeDir) : fileConfig.colorsAndTypeDir ? path.resolve(fileConfig.colorsAndTypeDir) : sub("colors-and-type"),
    componentConfigsDir: opts.componentConfigsDir ? path.resolve(opts.componentConfigsDir) : fileConfig.componentConfigsDir ? path.resolve(fileConfig.componentConfigsDir) : sub("component-configs"),
    themesDir: opts.themesDir ? path.resolve(opts.themesDir) : fileConfig.themesDir ? path.resolve(fileConfig.themesDir) : sub("themes"),
    sketchStylesDir: sub("sketch-styles"),
    legacyManifestsDir: fileConfig.manifestsDir ? path.resolve(fileConfig.manifestsDir) : void 0
  };
}

export {
  testDataDir,
  testPackageDataDir,
  readLiveTokensConfig,
  resolveDataDirs
};
