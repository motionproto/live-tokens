import {
  createVitestConfig
} from "./chunk-GKO27NGN.js";
import {
  defineTestingConfig,
  resolveTestingConfig
} from "./chunk-NB3NZRBM.js";
import "./chunk-SHBYZUPD.js";
export {
  createVitestConfig,
  defineTestingConfig,
  resolveTestingConfig
};
//# sourceMappingURL=vitest.js.map