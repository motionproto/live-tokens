export { r as readLiveTokensConfig, a as resolveDataDirs } from '../dataPaths-BpIK_Obx.js';

interface LegacyRename {
    from: string;
    to: string;
}

interface MigrateDataOptions {
    /** The directory the three below sit under. Locates the pre-0.48
     *  `manifests/` directory, which no config key names any more. */
    dataDir: string;
    colorsAndTypeDir: string;
    componentConfigsDir: string;
    themesDir: string;
    /** The retired `manifestsDir` config key, when the consumer set it. */
    legacyManifestsDir?: string;
    /** The installed package's `src/live-tokens/data`. Its files are read-only:
     *  they resolve names the consumer has no local copy of, and are never
     *  deleted even when their content matches a theme. */
    packageDataDir?: string;
    /** Plan only, write nothing. */
    check?: boolean;
}
interface MigrateDataResult {
    status: 'clean' | 'planned' | 'healed';
    /** Directories moved to the 0.48 layout, old → new, in the order they ran. */
    renames: LegacyRename[];
    /** The theme production resolves to after the heal, and how it was decided. */
    production: {
        slug: string;
        how: 'all-default' | 'matched' | 'recovered';
    } | null;
    /** Path of the theme written to record an unmatched production state. */
    recoveredThemePath: string | null;
    /** Buffers filled because the live state differed from the open theme. */
    workingWritten: string[];
    /** Buffers left as they were: the new server already owns them. */
    workingKept: string[];
    /** Materialised copies removed. */
    deletedFiles: string[];
    /** Retired per-layer pointer files removed. */
    deletedPointers: string[];
    /** Named files matching no theme. Yours, so they stay. */
    keptUserFiles: string[];
    /** Files in the themes directory that are not themes. Read past, never
     *  rewritten. */
    notThemes: string[];
    /** One sentence per reference a theme named that resolved to nothing. The
     *  theme carries the shipped default there now. */
    droppedRefs: string[];
    /** A local `colors-and-type/default.json` whose content differs from the copy
     *  the package ships. It shadows the shipped default. Reported only. */
    shadowedDefaults: string[];
    /** Themes rewritten from the pre-v3 by-reference form, so step 3 cannot
     *  delete a file they still name. */
    upgradedThemes: string[];
}
declare function migrateData(opts: MigrateDataOptions): MigrateDataResult;

export { type MigrateDataOptions, type MigrateDataResult, migrateData };
