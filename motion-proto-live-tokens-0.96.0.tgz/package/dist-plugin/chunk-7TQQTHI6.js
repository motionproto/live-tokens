// src/system/internal/oklch.ts
function srgbToLinear(c) {
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}
function linearToSrgb(c) {
  return c <= 31308e-7 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
}
function hexToLinearRgb(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  return [srgbToLinear(r), srgbToLinear(g), srgbToLinear(b)];
}
function linearRgbToHex(r, g, b) {
  const toHex = (c) => {
    const v = Math.round(Math.max(0, Math.min(1, linearToSrgb(c))) * 255);
    return v.toString(16).padStart(2, "0");
  };
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
function linearRgbToOklab(r, g, b) {
  const l_ = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b;
  const m_ = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b;
  const s_ = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b;
  const l = Math.cbrt(l_);
  const m = Math.cbrt(m_);
  const s = Math.cbrt(s_);
  return [
    0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s
  ];
}
function oklabToLinearRgb(L, a, b) {
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ * l_ * l_;
  const m = m_ * m_ * m_;
  const s = s_ * s_ * s_;
  return [
    4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s
  ];
}
function oklabToOklch(L, a, b) {
  const c = Math.sqrt(a * a + b * b);
  let h = Math.atan2(b, a) * 180 / Math.PI;
  if (h < 0) h += 360;
  return { l: L, c, h };
}
function oklchToOklab(l, c, h) {
  const hRad = h * Math.PI / 180;
  return [l, c * Math.cos(hRad), c * Math.sin(hRad)];
}
function hexToOklch(hex) {
  const [r, g, b] = hexToLinearRgb(hex);
  const [L, a, bVal] = linearRgbToOklab(r, g, b);
  return oklabToOklch(L, a, bVal);
}
function oklchToHex(l, c, h) {
  const [L, a, b] = oklchToOklab(l, c, h);
  const [r, g, bVal] = oklabToLinearRgb(L, a, b);
  return linearRgbToHex(r, g, bVal);
}
function isInGamut(r, g, b) {
  const eps = 1e-4;
  return r >= -eps && r <= 1 + eps && g >= -eps && g <= 1 + eps && b >= -eps && b <= 1 + eps;
}
function oklchToHexClamped(l, c, h) {
  const g = gamutClamp(l, c, h);
  return oklchToHex(g.l, g.c, g.h);
}
function gamutClamp(l, c, h) {
  if (l <= 0) return { l: 0, c: 0, h };
  if (l >= 1) return { l: 1, c: 0, h };
  const [L, a, b] = oklchToOklab(l, c, h);
  const [r, g, bVal] = oklabToLinearRgb(L, a, b);
  if (isInGamut(r, g, bVal)) return { l, c, h };
  let lo = 0;
  let hi = c;
  for (let i = 0; i < 20; i++) {
    const mid = (lo + hi) / 2;
    const [La, aa, ba] = oklchToOklab(l, mid, h);
    const [rr, gg, bb] = oklabToLinearRgb(La, aa, ba);
    if (isInGamut(rr, gg, bb)) {
      lo = mid;
    } else {
      hi = mid;
    }
  }
  return { l, c: lo, h };
}
function trim(value, decimals) {
  return Number(value.toFixed(decimals)).toString();
}
function oklchToCss(l, c, h) {
  const cs = trim(c, 4);
  return `oklch(${trim(l, 4)} ${cs} ${cs === "0" ? "0" : trim(h, 2)})`;
}
var OKLCH_RE = /^oklch\(\s*([\d.]+)(%?)\s+([\d.]+)(%?)\s+([\d.]+)(?:deg)?\s*\)$/i;
var HEX6_RE = /^#[0-9a-f]{6}$/i;
function parseOklchCss(value) {
  const m = OKLCH_RE.exec(value.trim());
  if (!m) return null;
  const l = Number.parseFloat(m[1]) / (m[2] === "%" ? 100 : 1);
  const c = Number.parseFloat(m[3]) * (m[4] === "%" ? 4e-3 : 1);
  return { l, c, h: Number.parseFloat(m[5]) };
}
function cssColorToOklch(value) {
  const raw = value.trim();
  if (HEX6_RE.test(raw)) return hexToOklch(raw);
  return parseOklchCss(raw);
}
function oklchToRgb255(l, c, h) {
  const clamped = gamutClamp(l, c, h);
  const [L, a, bVal] = oklchToOklab(clamped.l, clamped.c, clamped.h);
  const [r, g, b] = oklabToLinearRgb(L, a, bVal);
  const to255 = (channel) => Math.round(Math.max(0, Math.min(1, linearToSrgb(channel))) * 255);
  return { r: to255(r), g: to255(g), b: to255(b) };
}

export {
  hexToOklch,
  oklchToHex,
  oklchToHexClamped,
  gamutClamp,
  oklchToCss,
  parseOklchCss,
  cssColorToOklch,
  oklchToRgb255
};
