import {
  CURRENT_COMPONENT_SCHEMA_VERSION,
  runMigrations
} from "./chunk-QQASYPW7.js";

// vite-plugin/files/versionedFileResourceServer.ts
import fs from "fs";
import path from "path";
function versionedFileResourceServer(opts) {
  const dir = opts.dir;
  const activePath = path.join(dir, "_active.json");
  const productionPath = path.join(dir, "_production.json");
  const workingPath = path.join(dir, "_working.json");
  const defaultName = opts.defaultName ?? "default";
  const resolvedDir = path.resolve(dir);
  const resolvedPackageDir = opts.packageDir ? path.resolve(opts.packageDir) : null;
  function ensureDir() {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
  function ensureMeta() {
    if (!fs.existsSync(activePath)) {
      fs.writeFileSync(activePath, JSON.stringify({ activeFile: defaultName }));
      opts.onWrite?.(activePath);
    }
    if (!fs.existsSync(productionPath)) {
      fs.writeFileSync(productionPath, JSON.stringify({ productionFile: defaultName }));
      opts.onWrite?.(productionPath);
    }
  }
  function filePath(name) {
    return path.join(dir, `${name}.json`);
  }
  function existingPath(name) {
    const local = filePath(name);
    if (fs.existsSync(local)) return local;
    if (resolvedPackageDir) {
      const pkg = path.join(resolvedPackageDir, `${name}.json`);
      if (fs.existsSync(pkg)) return pkg;
    }
    return null;
  }
  function isPackageFile(name) {
    if (!resolvedPackageDir) return false;
    const pkg = path.join(resolvedPackageDir, `${name}.json`);
    if (!fs.existsSync(pkg)) return false;
    const local = path.resolve(filePath(name));
    if (local === pkg) {
      return opts.packageOwnedNames ? opts.packageOwnedNames.includes(name) : true;
    }
    return !fs.existsSync(local);
  }
  function readJson(name) {
    const resolved = existingPath(name);
    if (!resolved) return null;
    return JSON.parse(fs.readFileSync(resolved, "utf-8"));
  }
  function listNames() {
    const names = [];
    const seen = /* @__PURE__ */ new Set();
    const collect = (d) => {
      if (!d || !fs.existsSync(d)) return;
      for (const f of fs.readdirSync(d)) {
        if (!f.endsWith(".json") || f.startsWith("_")) continue;
        const name = f.slice(0, -".json".length);
        if (seen.has(name)) continue;
        seen.add(name);
        names.push(name);
      }
    };
    collect(resolvedDir);
    if (resolvedPackageDir && resolvedPackageDir !== resolvedDir) collect(resolvedPackageDir);
    return names;
  }
  function getActiveName() {
    try {
      const data = JSON.parse(fs.readFileSync(activePath, "utf-8"));
      return data.activeFile || defaultName;
    } catch {
      return defaultName;
    }
  }
  function getProductionName() {
    try {
      const data = JSON.parse(fs.readFileSync(productionPath, "utf-8"));
      return data.productionFile || defaultName;
    } catch {
      return defaultName;
    }
  }
  function setActiveName(name) {
    fs.writeFileSync(activePath, JSON.stringify({ activeFile: name }));
    opts.onWrite?.(activePath);
  }
  function setProductionName(name) {
    fs.writeFileSync(productionPath, JSON.stringify({ productionFile: name }));
    opts.onWrite?.(productionPath);
  }
  function hasWorking() {
    return fs.existsSync(workingPath);
  }
  function readWorking() {
    if (!fs.existsSync(workingPath)) return null;
    const parsed = JSON.parse(fs.readFileSync(workingPath, "utf-8"));
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error(`${workingPath} does not hold a JSON object`);
    }
    return parsed;
  }
  function writeWorking(data) {
    ensureDir();
    fs.writeFileSync(workingPath, JSON.stringify(data, null, 2));
    opts.onWrite?.(workingPath);
  }
  function clearWorking() {
    if (!fs.existsSync(workingPath)) return;
    fs.unlinkSync(workingPath);
    opts.onWrite?.(workingPath);
  }
  return {
    dir,
    activePath,
    productionPath,
    workingPath,
    ensureDir,
    ensureMeta,
    filePath,
    existingPath,
    isPackageFile,
    readJson,
    listNames,
    getActiveName,
    getProductionName,
    setActiveName,
    setProductionName,
    hasWorking,
    readWorking,
    writeWorking,
    clearWorking
  };
}

// src/editor/core/themes/themeTypes.ts
var THEME_SCHEMA_VERSION = 5;

// src/editor/core/themes/migrateComponentConfig.ts
function migrateComponentConfig(component, aliasesIn, rawConfig, fileVersion) {
  const stringPart = {};
  const objectPart = {};
  for (const [k, v] of Object.entries(aliasesIn)) {
    if (typeof v === "string") stringPart[k] = v;
    else objectPart[k] = v;
  }
  const configOut = {};
  for (const [k, v] of Object.entries(rawConfig ?? {})) {
    if (typeof v === "string") stringPart[k] = v;
    else configOut[k] = v;
  }
  if (component === "sectiondivider") {
    synthesizeSectionDividerGradients(stringPart, objectPart);
  }
  const migratedString = runMigrations("component-config", fileVersion, stringPart, { component });
  const migratedObject = component === "sectiondivider" ? renameSectionDividerObjectSlots(objectPart) : objectPart;
  return {
    aliases: { ...migratedString, ...migratedObject },
    config: configOut
  };
}
var FAMILIES = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
var SIZE_VARIANTS = ["lg", "md", "sm"];
function renameSectionDividerObjectSlots(objectPart) {
  const canvasSourceKeys = [
    "--sectiondivider-canvas-background",
    "--sectiondivider-canvas-gradient",
    "--sectiondivider-color-canvas-background"
  ];
  let canvasGradient;
  for (const key of canvasSourceKeys) {
    if (objectPart[key] !== void 0) {
      canvasGradient = objectPart[key];
      break;
    }
  }
  const out = {};
  for (const [key, value] of Object.entries(objectPart)) {
    let isFamilyGradient = false;
    for (const f of FAMILIES) {
      if (key === `--sectiondivider-${f}-background` || key === `--sectiondivider-${f}-gradient` || key === `--sectiondivider-color-${f}-background`) {
        isFamilyGradient = true;
        break;
      }
    }
    if (isFamilyGradient) continue;
    const backgroundVariant = SIZE_VARIANTS.find((v) => key === `--sectiondivider-${v}-background`);
    if (backgroundVariant) {
      out[`--sectiondivider-${backgroundVariant}-surface`] = value;
      continue;
    }
    out[key] = value;
  }
  if (canvasGradient !== void 0) {
    for (const v of SIZE_VARIANTS) {
      out[`--sectiondivider-${v}-surface`] = canvasGradient;
    }
  }
  return out;
}
var SECTIONDIVIDER_VARIANTS = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
function synthesizeSectionDividerGradients(stringPart, objectPart) {
  const GRADIENT_ANGLE_TOKENS = {
    "--gradient-angle-horizontal": 90,
    "--gradient-angle-vertical": 180,
    "--gradient-angle-diagonal": 135,
    "--gradient-angle-counter-diagonal": 45
  };
  const GRADIENT_STOP_POSITIONS = {
    "--gradient-stop-start": 0,
    "--gradient-stop-mid": 50,
    "--gradient-stop-end": 100
  };
  const parseAngle = (raw) => {
    if (!raw) return 135;
    if (raw.startsWith("--")) return GRADIENT_ANGLE_TOKENS[raw] ?? 135;
    const m = raw.match(/^(-?\d+(?:\.\d+)?)\s*deg$/i);
    return m ? parseFloat(m[1]) : 135;
  };
  const parsePosition = (raw, fallback) => {
    if (!raw) return fallback;
    if (raw.startsWith("--")) return GRADIENT_STOP_POSITIONS[raw] ?? fallback;
    const m = raw.match(/^(-?\d+(?:\.\d+)?)\s*%$/);
    return m ? parseFloat(m[1]) : fallback;
  };
  const parseStopColor = (raw) => {
    if (!raw) return null;
    if (raw.startsWith("--")) return { color: raw };
    const mix = raw.match(/^color-mix\(\s*in\s+srgb\s*,\s*var\((--[a-z0-9-]+)\)\s+([\d.]+)%\s*,\s*transparent\s*\)$/i);
    if (mix) return { color: mix[1], opacity: parseFloat(mix[2]) };
    return null;
  };
  for (const v of SECTIONDIVIDER_VARIANTS) {
    const slot = `--sectiondivider-${v}-gradient`;
    if (slot in objectPart) continue;
    const angleKey = `${slot}-angle`;
    const has1 = stringPart[`${slot}-stop-1-color`] !== void 0;
    const has2 = stringPart[`${slot}-stop-2-color`] !== void 0;
    const has3 = stringPart[`${slot}-stop-3-color`] !== void 0;
    if (!has1 && !has2 && !has3) continue;
    const stops = [];
    const positionDefaults = [0, 50, 100];
    for (let i = 1; i <= 3; i++) {
      const c = parseStopColor(stringPart[`${slot}-stop-${i}-color`]);
      if (!c) continue;
      const pos = parsePosition(stringPart[`${slot}-stop-${i}-position`], positionDefaults[i - 1]);
      stops.push({ position: pos, color: c.color, ...c.opacity !== void 0 ? { opacity: c.opacity } : {} });
    }
    if (stops.length < 2) continue;
    objectPart[slot] = {
      kind: "gradient",
      value: {
        type: "linear",
        angle: parseAngle(stringPart[angleKey]),
        stops
      }
    };
  }
}

// src/editor/core/components/componentConfigKeys.ts
var KNOWN_COMPONENT_CONFIG_KEYS = /* @__PURE__ */ new Set([
  "--dialog-confirm-variant",
  "--dialog-cancel-variant",
  // SectionDivider per-variant `color-family` is editor metadata that drives
  // the family-swap rewrite on aliases. It is not a runtime CSS value, so it
  // stays in the config bucket. The other intrinsics (align, hairline,
  // eyebrow/description visibility, eyebrow text-transform) now flow through
  // the alias bucket as cascading CSS vars — see the 2026-05-22 migration.
  "--sectiondivider-lg-color-family",
  "--sectiondivider-md-color-family",
  "--sectiondivider-sm-color-family"
]);

// src/live-tokens/data/sketch-styles/pencil.json
var pencil_default = {
  name: "Pencil",
  settings: {
    label: "Pencil",
    blurb: "Two graphite passes on their own seeds, so the outline disagrees with itself the way a hand coming back round does. The grain is drawn long and on the diagonal, the way a pencil shades.",
    fillTravel: 0.75,
    strokeTravel: 1.25,
    wobble: 30,
    roughness: 3,
    borderWavelength: 1,
    waveform: 1,
    strokeWidth: 1.25,
    doubleStroke: true,
    retraceOffset: 1.5,
    retracePass: "reseeded",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.15,
    pressureMod: 0.3,
    pooling: 0,
    strokeInk: 0.85,
    maskOn: true,
    maskBlobX: 525,
    maskBlobY: 47,
    maskBlobLinked: false,
    maskAngle: 67,
    maskOutputMin: 0.59,
    maskOutputMax: 1,
    maskOctaves: 3,
    maskGrain: "turbulence",
    maskPosterize: 1,
    maskSoftness: 0,
    jitterX: 1.5,
    jitterY: 1.5,
    jitterRot: 0.35,
    jitterScale: 0.022,
    cornerSpread: 6,
    cornerTravel: 4.5,
    iconTravel: 0.75,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 1
  },
  updatedAt: "2026-08-28T14:35:06.291Z",
  createdAt: "2026-08-28T14:35:06.291Z"
};

// src/live-tokens/data/sketch-styles/marker.json
var marker_default = {
  name: "Marker",
  settings: {
    label: "Marker",
    blurb: "Broad translucent nib gone round twice on the same line, so the overlap darkens and the ink pools where it slows.",
    fillTravel: 2,
    strokeTravel: 1.5,
    wobble: 56,
    roughness: 3,
    borderWavelength: 1.3,
    waveform: 1.4,
    strokeWidth: 4,
    doubleStroke: true,
    retraceOffset: 2.2,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.2,
    pressureMod: 0.25,
    pooling: 2,
    strokeInk: 0.52,
    maskOn: true,
    maskBlobX: 230,
    maskBlobY: 230,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.76,
    maskOutputMax: 1,
    maskOctaves: 3,
    maskGrain: "fractal",
    maskPosterize: 4,
    maskSoftness: 0,
    jitterX: 3,
    jitterY: 3,
    jitterRot: 0.8,
    jitterScale: 0.045,
    cornerSpread: 10,
    cornerTravel: 8,
    iconTravel: 1.25,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 4
  },
  updatedAt: "2026-08-28T14:45:04.324Z",
  createdAt: "2026-08-28T14:45:04.324Z"
};

// src/live-tokens/data/sketch-styles/whiteboard.json
var whiteboard_default = {
  name: "Whiteboard",
  settings: {
    label: "Whiteboard",
    blurb: "The fattest nib on glass. One long smooth undulation, and a veined mask that streaks the fill like a half-wiped board.",
    fillTravel: 2.5,
    strokeTravel: 2.5,
    wobble: 90,
    roughness: 1,
    borderWavelength: 1.5,
    waveform: 1,
    strokeWidth: 5.5,
    doubleStroke: true,
    retraceOffset: 3,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.15,
    pressureMod: 0.15,
    pooling: 3.5,
    strokeInk: 0.66,
    maskOn: true,
    maskBlobX: 180,
    maskBlobY: 38,
    maskBlobLinked: false,
    maskAngle: 0,
    maskOutputMin: 0.68,
    maskOutputMax: 1,
    maskOctaves: 3,
    maskGrain: "turbulence",
    maskPosterize: 3,
    maskSoftness: 0,
    jitterX: 4.5,
    jitterY: 4.5,
    jitterRot: 3,
    jitterScale: 0.07,
    cornerSpread: 14,
    cornerTravel: 11,
    iconTravel: 1.75,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 1.5
  },
  updatedAt: "2026-08-28T14:46:58.140Z",
  createdAt: "2026-08-28T14:46:58.140Z"
};

// src/live-tokens/data/sketch-styles/hatched.json
var hatched_default = {
  name: "Hatched",
  settings: {
    label: "Hatched",
    blurb: "An etching. The fill is angled shading, the outline a single hard-edged scratch that chatters along its length. No mask: the hatch is the texture.",
    fillTravel: 1.25,
    strokeTravel: 1.5,
    wobble: 24,
    roughness: 3,
    borderWavelength: 1,
    waveform: 3,
    strokeWidth: 1.5,
    doubleStroke: false,
    retraceOffset: 1.2,
    retracePass: "copy",
    fillStyle: "hatched",
    hatchInk: 0.5,
    strokeStyle: "solid",
    pressure: 0.3,
    pressureMod: 0.45,
    pooling: 0.8,
    strokeInk: 1,
    maskOn: true,
    maskBlobX: 10,
    maskBlobY: 600,
    maskBlobLinked: false,
    maskAngle: 150,
    maskOutputMin: 0.35,
    maskOutputMax: 1,
    maskOctaves: 2,
    maskGrain: "turbulence",
    maskPosterize: 1,
    maskSoftness: 1.5,
    jitterX: 1.5,
    jitterY: 1.5,
    jitterRot: 0.4,
    jitterScale: 0.03,
    cornerSpread: 6,
    cornerTravel: 6,
    iconTravel: 1.25,
    iconWavelength: 0.5,
    iconMaskOn: false,
    iconMaskScale: 1
  },
  updatedAt: "2026-08-28T21:17:18.232Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/live-tokens/data/sketch-styles/dashed.json
var dashed_default = {
  name: "Dashed",
  settings: {
    label: "Dashed",
    blurb: "A drafting outline. One slow drift along the ruler, broken into strokes, with jitter, mask and pressure all off. The clean pole.",
    fillTravel: 0.5,
    strokeTravel: 1,
    wobble: 120,
    roughness: 1,
    borderWavelength: 1,
    waveform: 1,
    strokeWidth: 1.5,
    doubleStroke: false,
    retraceOffset: 1.2,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "dashed",
    pressure: 0,
    pressureMod: 0,
    pooling: 0,
    strokeInk: 1,
    maskOn: false,
    maskBlobX: 100,
    maskBlobY: 100,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.45,
    maskOutputMax: 1,
    maskOctaves: 2,
    maskGrain: "fractal",
    maskPosterize: 1,
    maskSoftness: 1.5,
    jitterX: 0,
    jitterY: 0,
    jitterRot: 0,
    jitterScale: 0,
    cornerSpread: 4,
    cornerTravel: 3,
    iconTravel: 0,
    iconWavelength: 0.625,
    iconMaskOn: false,
    iconMaskScale: 1
  },
  updatedAt: "2026-08-28T15:47:36.934Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/live-tokens/data/sketch-styles/napkin.json
var napkin_default = {
  name: "Napkin",
  settings: {
    label: "Napkin",
    blurb: "Ballpoint in a hurry. Everything loose at once: a square wave sends every edge to full travel, and the second pass lands wherever it lands.",
    fillTravel: 3,
    strokeTravel: 2.25,
    wobble: 50,
    roughness: 3,
    borderWavelength: 1,
    waveform: 2.5,
    strokeWidth: 2.25,
    doubleStroke: true,
    retraceOffset: 4,
    retracePass: "reseeded",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.45,
    pressureMod: 0.6,
    pooling: 2.5,
    strokeInk: 1,
    maskOn: true,
    maskBlobX: 150,
    maskBlobY: 150,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.62,
    maskOutputMax: 1,
    maskOctaves: 2,
    maskGrain: "fractal",
    maskPosterize: 2,
    maskSoftness: 5,
    jitterX: 6,
    jitterY: 6,
    jitterRot: 1.8,
    jitterScale: 0.075,
    cornerSpread: 20,
    cornerTravel: 17,
    iconTravel: 2.25,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 3.6
  },
  updatedAt: "2026-08-28T15:47:36.934Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/live-tokens/data/sketch-styles/dry.json
var dry_default = {
  name: "Dry marker",
  settings: {
    label: "Dry marker",
    blurb: "Ink that ran out. One scratchy pass that breaks up along its length, over a fill the mask has worn nearly through in patches.",
    fillTravel: 2.25,
    strokeTravel: 1.75,
    wobble: 50,
    roughness: 3,
    borderWavelength: 0.5,
    waveform: 2,
    strokeWidth: 3.5,
    doubleStroke: false,
    retraceOffset: 1.2,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.4,
    pressureMod: 0.8,
    pooling: 1.5,
    strokeInk: 0.4,
    maskOn: true,
    maskBlobX: 170,
    maskBlobY: 170,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.57,
    maskOutputMax: 0.91,
    maskOctaves: 2,
    maskGrain: "fractal",
    maskPosterize: 4,
    maskSoftness: 1.75,
    jitterX: 5,
    jitterY: 5,
    jitterRot: 1.4,
    jitterScale: 0.08,
    cornerSpread: 16,
    cornerTravel: 13,
    iconTravel: 1.75,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 3.8
  },
  updatedAt: "2026-08-28T21:19:51.383Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/editor/core/sketch/sketchStyles.ts
var SHIPPED_FILES = { pencil: pencil_default, marker: marker_default, whiteboard: whiteboard_default, hatched: hatched_default, dashed: dashed_default, napkin: napkin_default, dry: dry_default };
var SHIPPED_SKETCH_SETTINGS = Object.fromEntries(
  Object.entries(SHIPPED_FILES).map(([id, file]) => [id, file.settings])
);
var DEFAULT_SKETCH_STYLE = "marker";
function hydrateSketchSettings(raw) {
  const base = SHIPPED_SKETCH_SETTINGS[DEFAULT_SKETCH_STYLE];
  const stored = raw ?? {};
  const out = { ...base };
  for (const key of Object.keys(base)) {
    if (stored[key] !== void 0) out[key] = stored[key];
  }
  if (out.fillStyle === "none") out.fillStyle = base.fillStyle;
  convertTiledMask(stored, out);
  convertCutToLevels(stored, out);
  carryLevelsToOutput(stored, out);
  halveSwingDials(stored, out);
  splitBlobAxes(stored, out);
  convertCyclesToWavelength(stored, out);
  convertIconTileToScale(stored, out);
  restoreDerivedRetrace(stored, out);
  return out;
}
function restoreDerivedRetrace(stored, out) {
  if (stored.retraceOffset === void 0) {
    out.retraceOffset = Number(Math.max(1.2, out.strokeWidth * 0.55).toFixed(2));
  }
}
var SWING_DIALS = {
  fillScale: "fillTravel",
  strokeScale: "strokeTravel",
  iconScale: "iconTravel",
  cornerShift: "cornerTravel"
};
function convertCyclesToWavelength(stored, out) {
  const cycles = stored.frequency;
  if (typeof cycles === "number" && cycles > 0) out.wobble = Math.round(1 / cycles);
  for (const [legacy, key] of [
    ["borderFrequency", "borderWavelength"],
    ["iconFrequency", "iconWavelength"]
  ]) {
    const multiple = stored[legacy];
    if (typeof multiple === "number" && multiple > 0) {
      out[key] = Number((1 / multiple).toFixed(3));
    }
  }
  const layers = stored.octaves;
  if (typeof layers === "number") out.roughness = Math.min(3, Math.max(1, layers));
}
function splitBlobAxes(stored, out) {
  const blob = stored.maskBlob;
  if (typeof blob !== "number") return;
  out.maskBlobX = blob;
  out.maskBlobY = blob;
  out.maskBlobLinked = true;
}
function convertIconTileToScale(stored, out) {
  const tile = stored.iconMaskTile;
  if (typeof tile !== "number") return;
  out.iconMaskScale = Math.min(5, Math.max(0.5, Number((tile / 90).toFixed(2))));
}
function halveSwingDials(stored, out) {
  for (const [legacy, key] of Object.entries(SWING_DIALS)) {
    const value = stored[legacy];
    if (typeof value === "number") out[key] = value / 2;
  }
}
function convertTiledMask(stored, out) {
  const scale = stored.maskScale;
  if (typeof scale !== "number") return;
  const freq = stored.maskFrequency;
  if (typeof freq === "number") {
    out.maskBlobX = Math.round(scale / (freq * LEGACY_TILE));
    out.maskBlobY = out.maskBlobX;
  }
  const soft = stored.maskSoftness;
  if (typeof soft === "number") out.maskSoftness = Number((soft * scale / LEGACY_TILE).toFixed(1));
}
function convertCutToLevels(stored, out) {
  const contrast = stored.maskContrast;
  const coverage = stored.maskCoverage;
  if (typeof contrast !== "number" || typeof coverage !== "number") return;
  const veined = out.maskGrain === "turbulence";
  const [lo, hi] = veined ? LEGACY_RANGE.turbulence : LEGACY_RANGE.fractal;
  const pivot = veined ? 0.55 - 0.5 * coverage : 0.8 - 0.6 * coverage;
  const level = (raw) => Math.min(1, Math.max(0, (raw - lo) / (hi - lo)));
  out.maskOutputMin = Number(level(pivot - 0.5 / contrast).toFixed(2));
  out.maskOutputMax = Number(Math.max(out.maskOutputMin + 0.02, level(pivot + 0.5 / contrast)).toFixed(2));
}
function carryLevelsToOutput(stored, out) {
  if (typeof stored.maskLevelMin === "number") out.maskOutputMin = stored.maskLevelMin;
  if (typeof stored.maskLevelMax === "number") out.maskOutputMax = stored.maskLevelMax;
}
var LEGACY_RANGE = { fractal: [0.24, 0.77], turbulence: [0.02, 0.6] };
var LEGACY_TILE = 600;

// vite-plugin/themes/normalizeTheme.ts
function asObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function isColorsAndTypeShaped(raw) {
  const obj = asObject(raw);
  if (!obj) return false;
  if ("theme" in obj || "colorsAndType" in obj) return false;
  return "cssVariables" in obj || "editorConfigs" in obj;
}
function stripFileMarker(value) {
  if (!("_fileName" in value)) return value;
  const { _fileName, ...rest } = value;
  return rest;
}
function asString(value, fallback) {
  return typeof value === "string" && value ? value : fallback;
}
function migrateEmbeddedKey(src) {
  const { theme, ...rest } = src;
  return { ...rest, colorsAndType: theme };
}
function routeKnownConfigKeys(aliases, config) {
  const outAliases = { ...aliases };
  const outConfig = { ...config };
  for (const key of Object.keys(outAliases)) {
    if (!KNOWN_COMPONENT_CONFIG_KEYS.has(key)) continue;
    if (outConfig[key] === void 0) outConfig[key] = outAliases[key];
    delete outAliases[key];
  }
  return { aliases: outAliases, config: outConfig };
}
function migrateEmbeddedComponentConfig(comp, config, fileVersion) {
  const { schemaVersion: _entryStamp, aliases: rawAliases, config: rawConfig, ...rest } = config;
  const aliasesIn = asObject(rawAliases);
  if (!aliasesIn) {
    return rawConfig !== void 0 ? { ...rest, config: rawConfig } : rest;
  }
  const migratedConfig = migrateComponentConfig(
    comp,
    aliasesIn,
    asObject(rawConfig) ?? void 0,
    fileVersion
  );
  const split = routeKnownConfigKeys(migratedConfig.aliases, migratedConfig.config);
  const out = { ...rest, aliases: split.aliases };
  if (rawConfig !== void 0 || Object.keys(split.config).length > 0) {
    out.config = split.config;
  }
  return out;
}
function normalizeTheme(raw, resolvers) {
  const input = asObject(raw) ?? {};
  const migrated = input.schemaVersion !== THEME_SCHEMA_VERSION;
  const inputVersion = typeof input.schemaVersion === "number" ? input.schemaVersion : 0;
  const src = inputVersion < 3 ? migrateEmbeddedKey(input) : input;
  const componentSchemaVersion = typeof input.componentSchemaVersion === "number" ? input.componentSchemaVersion : 0;
  const dropped = [];
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const embeddedColorsAndType = asObject(src.colorsAndType);
  let colorsAndType = null;
  if (embeddedColorsAndType) {
    colorsAndType = stripFileMarker(embeddedColorsAndType);
  } else {
    const colorsAndTypeName = asString(src.colorsAndType, "default");
    colorsAndType = asObject(resolvers.readColorsAndType(colorsAndTypeName));
    if (!colorsAndType) {
      dropped.push(`colors-and-type:${colorsAndTypeName}`);
      if (colorsAndTypeName !== "default") colorsAndType = asObject(resolvers.readColorsAndType("default"));
    }
    if (colorsAndType) colorsAndType = resolvers.normalizeColorsAndType(stripFileMarker(colorsAndType));
  }
  const componentConfigs = {};
  for (const [comp, value] of Object.entries(asObject(src.componentConfigs) ?? {})) {
    const embedded2 = asObject(value);
    let resolvedConfig;
    if (embedded2) {
      resolvedConfig = stripFileMarker(embedded2);
    } else {
      const configName = asString(value, "default");
      const resolved = asObject(resolvers.readComponentConfig(comp, configName));
      if (!resolved) {
        dropped.push(`${comp}/${configName}`);
        continue;
      }
      resolvedConfig = stripFileMarker(resolved);
    }
    componentConfigs[comp] = migrateEmbeddedComponentConfig(comp, resolvedConfig, componentSchemaVersion);
  }
  const filled = { components: [], aliases: 0, orphans: 0 };
  for (const comp of resolvers.listComponentNames()) {
    const base = asObject(resolvers.readComponentConfig(comp, "default"));
    const baseAliases = base ? asObject(base.aliases) : null;
    if (!base || !baseAliases) continue;
    const entry = componentConfigs[comp];
    if (!entry) {
      const { schemaVersion: _standaloneStamp, ...rest } = stripFileMarker(base);
      componentConfigs[comp] = structuredClone(rest);
      filled.components.push(comp);
      continue;
    }
    const entryAliases = asObject(entry.aliases) ?? {};
    for (const key of Object.keys(baseAliases)) {
      if (key in entryAliases) continue;
      entryAliases[key] = structuredClone(baseAliases[key]);
      filled.aliases++;
    }
    entry.aliases = entryAliases;
    for (const key of Object.keys(entryAliases)) {
      if (!(key in baseAliases)) filled.orphans++;
    }
  }
  const embedded = asObject(src.sketchSettings) ?? asObject(src.sketchStyle);
  const sketchSettings = embedded ? hydrateSketchSettings(embedded) : void 0;
  return {
    theme: {
      name: asString(src.name, "Untitled"),
      createdAt: asString(src.createdAt, now),
      updatedAt: asString(src.updatedAt, now),
      schemaVersion: THEME_SCHEMA_VERSION,
      colorsAndType,
      componentConfigs,
      componentSchemaVersion: CURRENT_COMPONENT_SCHEMA_VERSION,
      ...sketchSettings ? { sketchSettings } : {}
    },
    dropped,
    migrated,
    filled
  };
}

// vite-plugin/files/nameAllocator.ts
function nextAvailableName(exists, baseName, maxAttempts = 1e3) {
  if (!exists(baseName)) return baseName;
  for (let i = 2; i < maxAttempts; i++) {
    const candidate = `${baseName}-${i}`;
    if (!exists(candidate)) return candidate;
  }
  throw new Error(`Could not allocate a non-colliding name for "${baseName}"`);
}

// vite-plugin/files/legacyLayout.ts
import fs2 from "fs";
import path2 from "path";
function jsonFiles(dir) {
  if (!fs2.existsSync(dir)) return [];
  try {
    return fs2.readdirSync(dir).filter((f) => f.endsWith(".json")).map((f) => path2.join(dir, f));
  } catch {
    return [];
  }
}
function isDirectory(dir) {
  try {
    return fs2.statSync(dir).isDirectory();
  } catch {
    return false;
  }
}
function parseJsonFile(file) {
  try {
    return JSON.parse(fs2.readFileSync(file, "utf-8"));
  } catch {
    return null;
  }
}
function holdsATheme(themesDir) {
  return jsonFiles(themesDir).some((file) => {
    if (path2.basename(file).startsWith("_")) return false;
    const raw = parseJsonFile(file);
    if (!raw || typeof raw !== "object") return false;
    return "colorsAndType" in raw || "theme" in raw;
  });
}
function detectLegacyLayout(input) {
  const manifestsDir = input.configuredManifestsDir ?? path2.join(input.dataDir, "manifests");
  const themesHoldAThemeFile = holdsATheme(input.themesDir);
  if (isDirectory(manifestsDir) && !themesHoldAThemeFile) {
    return { manifestsDir, evidence: `${manifestsDir} is the pre-0.48 whole-theme directory` };
  }
  if (jsonFiles(input.colorsAndTypeDir).length > 0) return null;
  for (const file of jsonFiles(input.themesDir)) {
    if (path2.basename(file).startsWith("_")) continue;
    if (isColorsAndTypeShaped(parseJsonFile(file))) {
      return { manifestsDir, evidence: `${file} is a colors-and-type file, not a theme` };
    }
  }
  const pointer = ["_active.json", "_production.json"].map((name) => path2.join(input.themesDir, name)).find((p) => fs2.existsSync(p));
  if (pointer && !themesHoldAThemeFile && !fs2.existsSync(input.colorsAndTypeDir)) {
    return {
      manifestsDir,
      evidence: `${pointer} points at colors and type, and there is no ${path2.basename(input.colorsAndTypeDir)} directory`
    };
  }
  return null;
}
function planLegacyRenames(layout, input) {
  const defaultColorsAndType = path2.join(input.dataDir, "colors-and-type");
  const defaultThemes = path2.join(input.dataDir, "themes");
  if (input.configuredManifestsDir && path2.resolve(input.configuredManifestsDir) !== path2.join(input.dataDir, "manifests")) {
    throw new Error(
      `This project uses the pre-0.48 data layout (${layout.evidence}), and live-tokens.config.json sets the retired "manifestsDir" key to ${input.configuredManifestsDir}. That directory holds the whole themes, which now belong in ${input.themesDir}. Move it there by hand, drop the "manifestsDir" key, then run the migration again.`
    );
  }
  if (path2.resolve(input.colorsAndTypeDir) !== path2.resolve(defaultColorsAndType) || path2.resolve(input.themesDir) !== path2.resolve(defaultThemes)) {
    throw new Error(
      `This project uses the pre-0.48 data layout (${layout.evidence}), and its data directories are configured to custom paths (colorsAndTypeDir=${input.colorsAndTypeDir}, themesDir=${input.themesDir}). The migration cannot tell which directory holds what. Move the old colors-and-type directory to ${input.colorsAndTypeDir} and the old whole-theme directory to ${input.themesDir} by hand, then run the migration again.`
    );
  }
  const renames = [];
  if (fs2.existsSync(input.themesDir)) {
    renames.push({ from: input.themesDir, to: input.colorsAndTypeDir });
  }
  if (fs2.existsSync(layout.manifestsDir)) {
    renames.push({ from: layout.manifestsDir, to: input.themesDir });
  }
  return renames;
}
function applyLegacyRenames(renames) {
  for (const { from, to } of renames) {
    if (fs2.existsSync(to)) {
      const contents = fs2.readdirSync(to);
      if (contents.length > 0) {
        throw new Error(
          `Cannot move ${from} to ${to}: ${to} already exists and holds ${contents.length} file(s). Move or delete it, then run the migration again.`
        );
      }
      fs2.rmdirSync(to);
    }
    fs2.mkdirSync(path2.dirname(to), { recursive: true });
    fs2.renameSync(from, to);
  }
}

export {
  versionedFileResourceServer,
  THEME_SCHEMA_VERSION,
  isColorsAndTypeShaped,
  normalizeTheme,
  nextAvailableName,
  detectLegacyLayout,
  planLegacyRenames,
  applyLegacyRenames
};
