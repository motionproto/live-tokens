<script module lang="ts">
  import { buildTypeGroupTokens, buildTypeGroupShareableContexts } from './scaffolding/buildTypeGroupTokens';
  import type { Token, TypeGroupConfig, IntrinsicSpec } from './scaffolding/types';

  export const component = 'segmentedcontrol';

  // Default-size schema. Non-text tokens per state; typography lives in
  // `typeGroups` below and is rendered via TypeEditor. Per-option shape +
  // icon-size are promoted into "option base" (one source of truth) since
  // they don't vary per state in the runtime.
  const defaultStates: Record<string, Token[]> = {
    'control bar': [
      { label: 'surface color', element: 'frame', groupKey: 'surface', variable: '--segmentedcontrol-bar-surface' },
      { label: 'border color', element: 'frame', groupKey: 'border', variable: '--segmentedcontrol-bar-border' },
      { label: 'border width', element: 'frame', groupKey: 'width', variable: '--segmentedcontrol-bar-border-width' },
      { label: 'color', element: 'hairline', groupKey: 'color', variable: '--segmentedcontrol-hairline-color' },
      { label: 'width', element: 'hairline', groupKey: 'hairline-width', variable: '--segmentedcontrol-hairline-width' },
      { label: 'inset', element: 'hairline', groupKey: 'hairline-inset', variable: '--segmentedcontrol-hairline-inset' },
      { label: 'corner radius', element: 'frame', groupKey: 'radius', variable: '--segmentedcontrol-bar-radius' },
      { label: 'option gap', element: 'frame', groupKey: 'gap', variable: '--segmentedcontrol-bar-gap' },
      { label: 'padding', element: 'frame', variable: '--segmentedcontrol-bar-padding', groupKey: 'bar-padding' },
    ],
    'option base': [
      { label: 'padding', variable: '--segmentedcontrol-option-padding', groupKey: 'option-padding' },
      { label: 'icon gap', groupKey: 'option-gap', variable: '--segmentedcontrol-option-gap' },
      { label: 'icon size', groupKey: 'icon-size', variable: '--segmentedcontrol-option-icon-size' },
    ],
    'default option': [
      { label: 'icon color', groupKey: 'icon', variable: '--segmentedcontrol-option-icon' },
    ],
    'selected option': [
      { label: 'surface color', element: 'frame', groupKey: 'surface', variable: '--segmentedcontrol-selected-surface' },
      { label: 'color', element: 'icon', groupKey: 'icon', variable: '--segmentedcontrol-selected-icon' },
      { label: 'border color', element: 'frame', groupKey: 'border', variable: '--segmentedcontrol-selected-border' },
      { label: 'border width', element: 'frame', groupKey: 'width', variable: '--segmentedcontrol-selected-border-width' },
      { label: 'corner radius', element: 'frame', groupKey: 'radius', variable: '--segmentedcontrol-selected-radius' },
    ],
    'hover option': [
      { label: 'surface color', groupKey: 'surface', variable: '--segmentedcontrol-option-hover-surface' },
      { label: 'icon color', groupKey: 'icon', variable: '--segmentedcontrol-option-hover-icon' },
    ],
    'disabled option': [
      { label: 'surface color', groupKey: 'surface', variable: '--segmentedcontrol-disabled-surface' },
      { label: 'icon color', groupKey: 'icon', variable: '--segmentedcontrol-disabled-icon' },
    ],
  };

  // Small-size schema. Thin delta layer — only the size-driven properties.
  // Per-state colors, borders, font-family/weight stay shared with default.
  // States with no small overrides are omitted entirely so they don't render
  // empty fieldsets. Typography is regular rows (no typeGroups at small)
  // since family/weight/color don't differ.
  const smallStates: Record<string, Token[]> = {
    'control bar': [
      { label: 'corner radius', element: 'frame', groupKey: 'small-radius', variable: '--segmentedcontrol-bar-small-radius' },
      { label: 'padding', element: 'frame', variable: '--segmentedcontrol-bar-small-padding', groupKey: 'bar-small-padding' },
      { label: 'inset', element: 'hairline', groupKey: 'small-hairline-inset', variable: '--segmentedcontrol-small-hairline-inset' },
      { label: 'width', element: 'hairline', groupKey: 'small-hairline-width', variable: '--segmentedcontrol-small-hairline-width' },
    ],
    'option base': [
      { label: 'icon size', groupKey: 'small-icon-size', variable: '--segmentedcontrol-option-small-icon-size' },
      { label: 'font size', groupKey: 'small-text-font-size', variable: '--segmentedcontrol-option-small-text-font-size' },
      { label: 'line height', groupKey: 'small-text-line-height', variable: '--segmentedcontrol-option-small-text-line-height' },
      { label: 'padding', variable: '--segmentedcontrol-option-small-padding', groupKey: 'option-small-padding' },
      { label: 'icon gap', groupKey: 'option-small-gap', variable: '--segmentedcontrol-option-small-gap' },
    ],
    'selected option': [
      { label: 'corner radius', groupKey: 'small-radius', variable: '--segmentedcontrol-selected-small-radius' },
    ],
  };

  // Per-state typography groups (default size only).
  const typeGroups: Record<string, TypeGroupConfig[]> = {
    'default option': [{
      legend: 'option text',
      colorVariable: '--segmentedcontrol-option-text',
      familyVariable: '--segmentedcontrol-option-text-font-family',
      sizeVariable: '--segmentedcontrol-option-text-font-size',
      weightVariable: '--segmentedcontrol-option-text-font-weight',
      lineHeightVariable: '--segmentedcontrol-option-text-line-height',
    }],
    'selected option': [{
      legend: '',
      element: 'text',
      colorVariable: '--segmentedcontrol-selected-text',
      familyVariable: '--segmentedcontrol-selected-text-font-family',
      sizeVariable: '--segmentedcontrol-selected-text-font-size',
      weightVariable: '--segmentedcontrol-selected-text-font-weight',
      lineHeightVariable: '--segmentedcontrol-selected-text-line-height',
    }],
    'hover option': [{
      legend: 'option text',
      colorVariable: '--segmentedcontrol-option-hover-text',
      familyVariable: '--segmentedcontrol-option-hover-text-font-family',
      sizeVariable: '--segmentedcontrol-option-hover-text-font-size',
      weightVariable: '--segmentedcontrol-option-hover-text-font-weight',
      lineHeightVariable: '--segmentedcontrol-option-hover-text-line-height',
    }],
    'disabled option': [{
      legend: 'option text',
      colorVariable: '--segmentedcontrol-disabled-text',
      familyVariable: '--segmentedcontrol-disabled-text-font-family',
      sizeVariable: '--segmentedcontrol-disabled-text-font-size',
      weightVariable: '--segmentedcontrol-disabled-text-font-weight',
      lineHeightVariable: '--segmentedcontrol-disabled-text-line-height',
    }],
  };

  const emptyTypeGroups: Record<string, TypeGroupConfig[]> = {};

  // allTokens unions BOTH sizes so the store registers every editable variable.
  // The visibleStates filter is purely UI (which subset to render now).
  // option-hover precedes option: the stripper removes the first match and
  // would otherwise leave hover-text behind.
  const typeGroupTokens: Token[] = buildTypeGroupTokens(typeGroups, {
    component,
    variants: ['option-hover', 'option', 'selected', 'disabled'],
  });
  export const allTokens: Token[] = [
    ...Object.values(defaultStates).flat(),
    ...Object.values(smallStates).flat(),
    ...typeGroupTokens,
  ];

  // Cross-size linkage is intentionally not declared: small lives in its own
  // namespace. The per-state icon-size links are gone now that icon-size is a
  // single source-of-truth token in "option base".
  const linkableContexts = new Map<string, string>(
    buildTypeGroupShareableContexts(typeGroups),
  );

  // The hover tint is off unless a project turns it on: the gate holds a
  // transparent layer, a no-op, until it holds the tint itself.
  export const intrinsics: IntrinsicSpec[] = [
    {
      key: 'hover-tint',
      variants: ['default'],
      variable: () => '--segmentedcontrol-hover-tint-enabled',
      values: ['var(--color-transparent)', 'var(--segmentedcontrol-hover-tint)'],
      default: { default: 'var(--color-transparent)' },
    },
  ];
</script>

<script lang="ts">
  import SegmentedControl from '../../system/components/SegmentedControl.svelte';
  import VariantGroup from './scaffolding/VariantGroup.svelte';
  import ComponentEditorBase from './scaffolding/ComponentEditorBase.svelte';
  import { editorState, setComponentAlias, clearComponentAlias } from '../core/store/editorStore';
  import { computeLinkedBlock, withLinkedDisabled } from './scaffolding/linkedBlock';
  import Toggle from '../ui/Toggle.svelte';
  import UIPaletteSelector from '../ui/UIPaletteSelector.svelte';

  // One switch. Turning the tint on also stands each hover surface down to its
  // own base, so hover is the tint alone rather than a swap wearing a wash.
  // Written as aliases rather than gated in CSS: a component token's value is
  // substituted at :root, so it can never name a per-variant private var.
  // Off clears the overrides, returning each surface to its shipped default.
  const HOVER_SWAPS: readonly (readonly [hover: string, base: string])[] = [
    ['--segmentedcontrol-option-hover-surface', '--color-transparent'],
  ];
  const TINT_ON = 'var(--segmentedcontrol-hover-tint)';
  const TINT_OFF = 'var(--color-transparent)';

  let tintOn = $derived.by(() => {
    const ref = $editorState.components.segmentedcontrol?.aliases['--segmentedcontrol-hover-tint-enabled'];
    return (ref?.kind === 'literal' ? ref.value : TINT_OFF) === TINT_ON;
  });

  function setTintOn(checked: boolean) {
    setComponentAlias('segmentedcontrol', '--segmentedcontrol-hover-tint-enabled', {
      kind: 'literal',
      value: checked ? TINT_ON : TINT_OFF,
    });
    for (const [hover, base] of HOVER_SWAPS) {
      if (checked) setComponentAlias('segmentedcontrol', hover, { kind: 'token', name: base });
      else clearComponentAlias('segmentedcontrol', hover);
    }
  }

  type Segment = { value: string; label: string; icon?: string; disabled?: boolean };
  const segments: Segment[] = [
    { value: 'option-1', label: 'Option 1', icon: 'fas fa-star' },
    { value: 'option-2', label: 'Option 2', icon: 'fas fa-check' },
    { value: 'option-3', label: 'Option 3', icon: 'fas fa-heart' },
  ];
  let showIcons = $state(true);
  let previewSize = $state<'default' | 'small'>('default');
  let previewSegments = $derived(showIcons ? segments : segments.map((s) => ({ ...s, icon: undefined })));

  let linked = $derived(computeLinkedBlock(component, linkableContexts, allTokens, $editorState));

  let activeStates = $derived(previewSize === 'small' ? smallStates : defaultStates);
  let activeTypeGroups = $derived(previewSize === 'small' ? emptyTypeGroups : typeGroups);

  let visibleStates = $derived(Object.fromEntries(
    Object.entries(activeStates).map(([name, list]) => [
      name,
      withLinkedDisabled(list, linked.varSet).map((t) =>
        tintOn && t.variable.endsWith('-hover-surface') ? { ...t, disabled: true } : t,
      ),
    ]),
  ) as Record<string, Token[]>);
</script>

<ComponentEditorBase {component} title="Segmented Control" description="A connected set of buttons for toggling between mutually exclusive options." tokens={allTokens} {linked}>
  <VariantGroup
    name="segmentedcontrol"
    title="Segmented Control"
    states={visibleStates}
    typeGroups={activeTypeGroups}
    {component}
  >
    {#snippet extraPropertyRows(stateName)}
      {#if stateName === 'hover option'}
        <div class="property-row" data-token-variables="--segmentedcontrol-hover-tint-enabled">
          <span class="property-label">tint layer</span>
          <Toggle checked={tintOn} onchange={setTintOn} />
        </div>
        {#if tintOn}
          <div class="property-row">
            <span class="property-label">tint color</span>
            <UIPaletteSelector variable="--segmentedcontrol-hover-tint" {component} showNone={false} />
          </div>
        {/if}
      {/if}
    {/snippet}
    {#snippet previewActions()}
      <label>
        <span>Size</span>
        <select bind:value={previewSize}>
          <option value="default">Default</option>
          <option value="small">Small</option>
        </select>
      </label>
    {/snippet}
    {#snippet canvasToolbarExtras()}
      <hr class="canvas-toolbar-divider" />
      <label class="sc-preview-check">
        <input type="checkbox" bind:checked={showIcons} />
        <span>Show icons</span>
      </label>
    {/snippet}
    {#snippet children({ activeState })}
      {@const previewValue = activeState === 'selected option' ? 'option-2' : ''}
      {@const previewForceHover = activeState === 'hover option' ? 'option-1' : null}
      {@const previewDisabled = activeState === 'disabled option'}
      <div>
        <SegmentedControl
          segments={previewSegments}
          value={previewValue}
          forceHoverValue={previewForceHover}
          disabled={previewDisabled}
          size={previewSize}
        />
      </div>
    {/snippet}
  </VariantGroup>
</ComponentEditorBase>

<style>
  .sc-preview-check {
    display: inline-flex;
    align-items: center;
    gap: var(--ui-space-6);
    font-size: var(--ui-font-size-sm);
    color: var(--ui-text-secondary);
  }
</style>
