export { r as readLiveTokensConfig } from '../dataPaths-BpIK_Obx.js';

/**
 * A `tokens-css` migration: a pure, idempotent transform on the text of a
 * consumer's `tokens.css`.
 *
 * Sibling to the in-browser data-file migrations in
 * `src/editor/core/themes/migrations/` (which transform theme and
 * component-config JSON as the editor loads them). Those run in the browser on
 * `Record<string,string>` maps; these run in Node — from the `live-tokens
 * migrate` CLI and the dev-plugin guardrail — on the Layer-1 CSS file the data
 * migrations deliberately never touch.
 *
 * There is no `schemaVersion` here: CSS carries no version stamp, so migrations
 * must be idempotent by presence (see `cssTokenOps`). Re-running the full set is
 * always safe, which is what the CLI relies on.
 */
interface TokensCssMigration {
    /** Unique id; convention: `YYYY-MM-DD-<short-name>`. */
    id: string;
    /**
     * Whether this migration is backward-compatible.
     *
     * Token names are public API (see TOKENS.md). `'additive'` only ever inserts
     * new names, so it is safe to auto-apply to a consumer's vendored `tokens.css`
     * (the dev plugin's `autoMigrate`). `'breaking'` renames or removes a name a
     * consumer may reference, so it ships only with a major version (post-1.0) and
     * is never auto-applied — it rides an explicit `live-tokens migrate`.
     */
    kind: 'additive' | 'breaking';
    /** One-line summary shown by the CLI when the migration applies. */
    description: string;
    /** Pure, idempotent transform on the `tokens.css` source. */
    apply(css: string): string;
}

/**
 * Pure, idempotent text operations on a `tokens.css` declaration set.
 *
 * `tokens.css` is the consumer's developer-authored Layer-1 source (palettes,
 * type/space/radius scales, motion). When the package evolves the Layer-1
 * vocabulary — adding a scale, renaming a step — consumers' forked `tokens.css`
 * drifts. `tokens-css` migrations reconcile that drift; these helpers are the
 * primitives they compose.
 *
 * Operations are text-level (not parse-and-reserialize) so the file's comments,
 * sectioning, and formatting survive untouched. They are idempotent **by
 * presence**: `ensure` skips a token that already exists, `rename` only fires
 * when the old name is present and the new one is absent, `remove` is a no-op
 * when the name is gone, `set` writes nothing when the value already matches,
 * and `appendMediaBlock` skips a name the block declares. Re-running a migration therefore never double-applies,
 * which is what lets the CLI run safely without a schema-version stamp.
 */
/** Names declared as custom properties (`--x: …;`) anywhere in the source. */
declare function collectDefinedTokens(css: string): Set<string>;
/**
 * Declared name → top-level value, last declaration winning. Declarations
 * inside `@media` are breakpoint re-points and never count.
 */
declare function collectTokenValues(css: string): Map<string, string>;
/** Names referenced via `var(--x)` anywhere in the source. */
declare function collectReferencedTokens(css: string): Set<string>;
interface ScaleEntry {
    name: string;
    value: string;
}
interface EnsureScaleOptions {
    /** Tokens to guarantee exist, in the order they should appear. */
    entries: ScaleEntry[];
    /**
     * Comment emitted once above the first inserted token of the group (only when
     * at least one token is actually inserted). Written without the `/​* *​/`.
     */
    sectionComment?: string;
    /**
     * Prefixes, in priority order, used to find where to insert. The block is
     * placed after the last declaration whose name starts with one of these.
     * Falls back to just before the closing brace of the first `:root` block.
     */
    anchorPrefixes?: string[];
}
/**
 * Insert any missing tokens from `entries` as one contiguous block. Tokens that
 * already exist (by name) are left as-is. Returns the source unchanged when
 * every entry is already present.
 */
declare function ensureScale(css: string, opts: EnsureScaleOptions): string;
/**
 * Rename a token: rewrites its declaration and every `var()` reference to it.
 * No-op unless the old name is present and the new name is absent (so a
 * half-applied rename, or a re-run, leaves the file alone).
 */
declare function renameToken(css: string, oldName: string, newName: string): string;
/** Remove a token's declaration line. No-op when the name isn't declared. */
declare function removeToken(css: string, name: string): string;
/**
 * Remove every custom-property declaration whose name satisfies `predicate`.
 * Operates line-by-line (tokens.css is one declaration per line), so only the
 * matched declarations are dropped — surrounding comments and structure stay.
 * No-op when nothing matches. Use for retiring a whole retired namespace.
 */
declare function removeTokensMatching(css: string, predicate: (name: string) => boolean): string;
interface SetTokenValueOptions {
    /** Rewrite only when the current value equals this one, so a consumer's edit stays. */
    from?: string;
}
/**
 * Rewrite the value of `name` where the top-level `:root` declares it. A
 * re-declaration inside `@media` keeps its value. No-op when the top-level
 * `:root` does not declare `name`.
 */
declare function setTokenValue(css: string, name: string, value: string, opts?: SetTokenValueOptions): string;
interface AppendMediaBlockOptions {
    /**
     * A query whose first top-level block a new block goes before. A block that
     * overlaps a narrower one has to precede it, or it wins the cascade there.
     */
    before?: string;
}
/**
 * Append each entry that no top-level `@media <query>` block declares yet to
 * that block's `:root`. The query must match exactly. With no such block, a new
 * one goes before the first `opts.before` block, or else at the end of the file.
 */
declare function appendMediaBlock(css: string, query: string, entries: ScaleEntry[], opts?: AppendMediaBlockOptions): string;

/**
 * Registered tokens-css migrations, applied in array order. Unlike the
 * versioned data-file migrations, ordering here is explicit (chronological) and
 * every migration is idempotent, so the runner simply folds them left-to-right.
 */
declare const TOKENS_CSS_MIGRATIONS: TokensCssMigration[];
interface RunResult {
    /** The migrated source (identical to input when nothing changed). */
    css: string;
    /** ids of migrations whose `apply` actually changed the source. */
    applied: string[];
    /** True when `css` differs from the input. */
    changed: boolean;
}
/** Fold every registered migration over `css`. Pure and idempotent. */
declare function runTokensCssMigrations(css: string): RunResult;
/**
 * Fold only the `additive` migrations. Additive changes only insert new token
 * names, so applying them to a consumer's vendored `tokens.css` is always
 * backward-compatible — this is what the dev plugin's `autoMigrate` runs. The
 * `breaking` migrations (rename/remove) are deliberately skipped; they ride an
 * explicit `live-tokens migrate` during a major upgrade.
 */
declare function runAdditiveTokensCssMigrations(css: string): RunResult;
interface ContractViolation {
    id: string;
    /** Token names the migration removed or renamed away despite declaring `additive`. */
    removed: string[];
    /** Token names whose value the migration rewrote despite declaring `additive`. */
    changed: string[];
}
/**
 * Guardrail for the token-as-API contract: an `additive` migration must only
 * ever insert new names — it must never remove or rename a token, and never
 * rewrite the value of one a consumer already references. We verify
 * behaviorally rather than trusting the label: apply each additive migration to
 * the package's own canonical `tokens.css` (which defines the full current
 * vocabulary) and flag any token that disappears or changes value. A rename
 * surfaces as the removal of its old name, so it is caught too.
 *
 * The value half is what makes a value-rewriting migration (hex → `oklch()`)
 * impossible to mislabel: it renames nothing, so a name-only guard would wave
 * it through as additive and the dev plugin would auto-apply a breaking change
 * to a consumer's vendored file.
 *
 * This catches the dangerous direction only. (Over-labeling a no-op as
 * `breaking` is harmless and not checked.)
 */
declare function findContractViolations(canonicalCss: string): ContractViolation[];
type SemverBump = 'major' | 'minor' | 'patch' | 'none';
/** Classify the bump from `prev` to `next` (leading `v` and pre-release tags ignored). */
declare function semverBumpType(prev: string, next: string): SemverBump;
interface BreakingGateResult {
    level: 'ok' | 'warn' | 'error';
    breakingIds: string[];
    bump: SemverBump;
    message: string;
}
/**
 * The version side of the token contract: a `breaking` migration introduced in a
 * release requires a major version bump. Pre-1.0 (next major is 0) this is only
 * a warning, since semver permits breaking changes in 0.x minors; from 1.0.0 on
 * it is an error. Pure so the release check and its tests share one rule.
 */
declare function enforceBreakingRequiresMajor(args: {
    newMigrations: TokensCssMigration[];
    prevVersion: string;
    nextVersion: string;
}): BreakingGateResult;
interface ComponentSource {
    name: string;
    source: string;
}
interface MissingToken {
    /** The undefined `--token` a component references. */
    token: string;
    /** Component names whose `:global(:root)` block references it. */
    referencedBy: string[];
}
interface ValidateInput {
    /** Contents of the consumer's developer-authored `tokens.css`. */
    tokensCss: string;
    /** Contents of the editor-owned `tokens.generated.css`, if present. */
    generatedCss?: string;
    /** Component `.svelte` sources to scan for `:global(:root)` references. */
    componentSources: ComponentSource[];
}
/**
 * Find primitives that components reference but the runtime never defines.
 *
 * "Defined" is the union of: tokens declared in `tokens.css`, in the generated
 * sidecar, and in any component's own `:global(:root)` block (so component →
 * component references don't false-positive). Anything referenced but not in
 * that union is drift — the symptom the consumer sees as blank editor slots.
 */
declare function validateTokensCss(input: ValidateInput): MissingToken[];

export { type BreakingGateResult, type ComponentSource, type ContractViolation, type MissingToken, type RunResult, type SemverBump, TOKENS_CSS_MIGRATIONS, type TokensCssMigration, type ValidateInput, appendMediaBlock, collectDefinedTokens, collectReferencedTokens, collectTokenValues, enforceBreakingRequiresMajor, ensureScale, findContractViolations, removeToken, removeTokensMatching, renameToken, runAdditiveTokensCssMigrations, runTokensCssMigrations, semverBumpType, setTokenValue, validateTokensCss };
