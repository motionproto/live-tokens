/**
 * Shared scale definitions consumed by `UIVariantSelector`. Each entry pairs
 * a CSS-var prefix with the option list that drives its dropdown. Spread the
 * entry into the selector at the call site:
 *
 *   <UIVariantSelector {variable} {component} {canBeLinked} {...BLUR} on:change />
 *
 * Replaces the per-scale wrappers (UIBlurSelector / UIRadiusSelector / etc.)
 * that were 35–50 lines of identical glue around the same data.
 */

export interface VariantScaleOption {
  key: string;
  label: string;
  /** Resolved value shown in the option's `meta` column. Omit for label-only scales. */
  value?: string;
}

export interface VariantScaleEntry {
  varPrefix: string;
  options: ReadonlyArray<VariantScaleOption>;
}

/**
 * The option key a value selects: the whole value is `var(<varPrefix><key>)`
 * and `key` is one of `validKeys`. A `var()` inside an expression such as
 * `calc(var(--x) * 2)` selects nothing.
 */
export function parseVariantRef(
  value: string,
  varPrefix: string,
  validKeys: ReadonlySet<string>,
): string | null {
  const name = value.trim().match(/^var\(\s*(--[a-z0-9-]+)\s*\)$/i)?.[1];
  if (!name?.startsWith(varPrefix)) return null;
  const key = name.slice(varPrefix.length);
  return validKeys.has(key) ? key : null;
}

export const BLUR: VariantScaleEntry = {
  varPrefix: '--blur-',
  options: [
    { key: 'none', label: 'None', value: '0' },
    { key: 'sm', label: 'Small', value: '4px' },
    { key: 'md', label: 'Medium', value: '8px' },
    { key: 'lg', label: 'Large', value: '16px' },
    { key: 'xl', label: 'X-Large', value: '24px' },
    { key: '2xl', label: '2X-Large', value: '32px' },
  ],
};

/** Transform-scale multipliers (e.g. image zoom-on-hover). 5% per step. */
export const SCALE: VariantScaleEntry = {
  varPrefix: '--scale-',
  options: [
    { key: 'sm', label: 'Small', value: '1.05' },
    { key: 'md', label: 'Medium', value: '1.1' },
    { key: 'lg', label: 'Large', value: '1.15' },
    { key: 'xl', label: 'X-Large', value: '1.2' },
    { key: '2xl', label: '2X-Large', value: '1.25' },
  ],
};

export const BORDER_WIDTH: VariantScaleEntry = {
  varPrefix: '--border-width-',
  options: [
    { key: '0', label: '0', value: '0' },
    { key: '1', label: '1', value: '1px' },
    { key: '2', label: '2', value: '2px' },
    { key: '3', label: '3', value: '3px' },
    { key: '4', label: '4', value: '4px' },
    { key: '5', label: '5', value: '5px' },
    { key: '6', label: '6', value: '6px' },
    { key: '8', label: '8', value: '8px' },
    { key: '10', label: '10', value: '10px' },
    { key: '12', label: '12', value: '12px' },
    { key: '16', label: '16', value: '16px' },
    { key: '20', label: '20', value: '20px' },
    { key: '24', label: '24', value: '24px' },
  ],
};

export const DOT_SIZE: VariantScaleEntry = {
  varPrefix: '--dot-size-',
  options: [
    { key: '0', label: 'None', value: '0%' },
    { key: '25', label: '25%', value: '25%' },
    { key: '50', label: '50%', value: '50%' },
    { key: '75', label: '75%', value: '75%' },
    { key: '100', label: '100%', value: '100%' },
  ],
};

export const RADIUS: VariantScaleEntry = {
  varPrefix: '--radius-',
  options: [
    { key: 'none', label: 'None', value: '0' },
    { key: 'sm', label: 'Small', value: '0.125rem' },
    { key: 'md', label: 'Medium', value: '0.25rem' },
    { key: 'lg', label: 'Large', value: '0.375rem' },
    { key: 'xl', label: 'X-Large', value: '0.5rem' },
    { key: '2xl', label: '2X-Large', value: '0.625rem' },
    { key: '3xl', label: '3X-Large', value: '0.75rem' },
    { key: '4xl', label: '4X-Large', value: '1.25rem' },
    { key: 'full', label: 'Full', value: '9999px' },
  ],
};

export const SHADOW: VariantScaleEntry = {
  varPrefix: '--shadow-',
  options: [
    { key: 'none', label: 'None' },
    { key: 'sm', label: 'Small' },
    { key: 'md', label: 'Medium' },
    { key: 'lg', label: 'Large' },
    { key: 'xl', label: 'X-Large' },
    { key: '2xl', label: '2X-Large' },
  ],
};

/** Used by `*-track-height` variables; values come from the `--space-*` scale,
 *  not a dedicated height scale. The label-set differs from BORDER_WIDTH so a
 *  track can pick from larger heights (up to 100%). */
export const TRACK_HEIGHT: VariantScaleEntry = {
  varPrefix: '--space-',
  options: [
    { key: '0', label: 'None', value: '0px' },
    { key: '8', label: 'XS', value: '0.5rem' },
    { key: '10', label: 'Small', value: '0.625rem' },
    { key: '12', label: 'Medium', value: '0.75rem' },
    { key: '16', label: 'Large', value: '1rem' },
    { key: '20', label: 'XL', value: '1.25rem' },
    { key: '24', label: '2XL', value: '1.5rem' },
    { key: 'full', label: 'Full', value: '100%' },
  ],
};

/** Used by `*-duration` variables (CSS transition timing). Pulls keys directly
 *  from the shared `--duration-*` scale in tokens.css — labels mirror the token
 *  slugs so the picker reflects the utility token namespace, no synthetic names. */
export const DURATION: VariantScaleEntry = {
  varPrefix: '--duration-',
  options: [
    { key: '75',   label: '75',   value: '75ms' },
    { key: '150',  label: '150',  value: '150ms' },
    { key: '200',  label: '200',  value: '200ms' },
    { key: '300',  label: '300',  value: '300ms' },
    { key: '500',  label: '500',  value: '500ms' },
    { key: '750',  label: '750',  value: '750ms' },
    { key: '1000', label: '1000', value: '1000ms' },
  ],
};

/** Used by `*-hairline-inset` variables (margin-block trimmed off a stretched
 *  hairline). Labels describe the resulting line, not the inset value: 0
 *  inset = bar-height line ("Full"); larger insets = shorter line.
 *  Replaces the percentage-height approach that collapsed to 0 in
 *  auto-height flex parents. */
export const HAIRLINE_INSET: VariantScaleEntry = {
  varPrefix: '--space-',
  options: [
    { key: '0', label: 'Full', value: '0px' },
    { key: '2', label: 'Tall', value: '0.125rem' },
    { key: '4', label: 'Large', value: '0.25rem' },
    { key: '6', label: 'Medium', value: '0.375rem' },
    { key: '8', label: 'Short', value: '0.5rem' },
    { key: '12', label: 'XS', value: '0.75rem' },
    { key: '16', label: 'Tiny', value: '1rem' },
  ],
};
