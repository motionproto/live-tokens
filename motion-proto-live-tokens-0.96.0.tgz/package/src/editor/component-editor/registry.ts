import type { Component } from 'svelte';
import type { CatalogueEntry, Token, IntrinsicSpec } from './scaffolding/types';
import { registerComponentSchema } from '../core/store/editorStore';
import { attachRegistry } from './registration';

export { registerComponent } from './registration';

import BadgeEditor, { allTokens as badgeTokens } from './BadgeEditor.svelte';
import { catalogue as badgeCatalogue } from '../../system/components/Badge.svelte';
import CalloutEditor, { allTokens as calloutTokens } from './CalloutEditor.svelte';
import { catalogue as calloutCatalogue } from '../../system/components/Callout.svelte';
import CornerBadgeEditor, { allTokens as cornerBadgeTokens } from './CornerBadgeEditor.svelte';
import { catalogue as cornerBadgeCatalogue } from '../../system/components/CornerBadge.svelte';
import ButtonEditor, { allTokens as buttonTokens } from './ButtonEditor.svelte';
import { catalogue as buttonCatalogue } from '../../system/components/Button.svelte';
import IconButtonEditor, { allTokens as iconButtonTokens } from './IconButtonEditor.svelte';
import { catalogue as iconButtonCatalogue } from '../../system/components/IconButton.svelte';
import CardEditor, { allTokens as cardTokens, intrinsics as cardIntrinsics } from './CardEditor.svelte';
import { catalogue as cardCatalogue } from '../../system/components/Card.svelte';
import CodeSnippetEditor, { allTokens as codeSnippetTokens } from './CodeSnippetEditor.svelte';
import { catalogue as codeSnippetCatalogue } from '../../system/components/CodeSnippet.svelte';
import CollapsibleSectionEditor, { allTokens as collapsibleSectionTokens } from './CollapsibleSectionEditor.svelte';
import { catalogue as collapsibleSectionCatalogue } from '../../system/components/CollapsibleSection.svelte';
import DialogEditor, { allTokens as dialogTokens } from './DialogEditor.svelte';
import { catalogue as dialogCatalogue } from '../../system/components/Dialog.svelte';
import ImageEditor, { allTokens as imageTokens, intrinsics as imageIntrinsics } from './ImageEditor.svelte';
import { catalogue as imageCatalogue } from '../../system/components/Image.svelte';
import ImageLightboxEditor, { allTokens as imageLightboxTokens } from './ImageLightboxEditor.svelte';
import { catalogue as imageLightboxCatalogue } from '../../system/components/ImageLightbox.svelte';
import VideoLightboxEditor, { allTokens as videoLightboxTokens } from './VideoLightboxEditor.svelte';
import VideoFrameEditor, { allTokens as videoFrameTokens } from './VideoFrameEditor.svelte';
import { catalogue as videoFrameCatalogue } from '../../system/components/VideoFrame.svelte';
import SlidePagerEditor, { allTokens as slidePagerTokens } from './SlidePagerEditor.svelte';
import { catalogue as slidePagerCatalogue } from '../../system/components/SlidePager.svelte';
import { catalogue as videoLightboxCatalogue } from '../../system/components/VideoLightbox.svelte';
import InlineEditActionsEditor, { allTokens as inlineEditActionsTokens } from './InlineEditActionsEditor.svelte';
import { catalogue as inlineEditActionsCatalogue } from '../../system/components/InlineEditActions.svelte';
import InputEditor, { allTokens as inputTokens } from './InputEditor.svelte';
import { catalogue as inputCatalogue } from '../../system/components/Input.svelte';
import MenuSelectEditor, { allTokens as menuSelectTokens } from './MenuSelectEditor.svelte';
import { catalogue as menuSelectCatalogue } from '../../system/components/MenuSelect.svelte';
import NotificationEditor, { allTokens as notificationTokens } from './NotificationEditor.svelte';
import { catalogue as notificationCatalogue } from '../../system/components/Notification.svelte';
import PanelEditor, { allTokens as panelTokens } from './PanelEditor.svelte';
import { catalogue as panelCatalogue } from '../../system/components/Panel.svelte';
import ProgressBarEditor, { allTokens as progressBarTokens } from './ProgressBarEditor.svelte';
import { catalogue as progressBarCatalogue } from '../../system/components/ProgressBar.svelte';
import SliderEditor, { allTokens as sliderTokens } from './SliderEditor.svelte';
import { catalogue as sliderCatalogue } from '../../system/components/Slider.svelte';
import RadioButtonEditor, { allTokens as radioButtonTokens } from './RadioButtonEditor.svelte';
import { catalogue as radioButtonCatalogue } from '../../system/components/RadioButton.svelte';
import SectionDividerEditor, { allTokens as sectionDividerTokens, intrinsics as sectionDividerIntrinsics } from './SectionDividerEditor.svelte';
import { catalogue as sectionDividerCatalogue } from '../../system/components/SectionDivider.svelte';
import SegmentedControlEditor, { allTokens as segmentedControlTokens } from './SegmentedControlEditor.svelte';
import { catalogue as segmentedControlCatalogue } from '../../system/components/SegmentedControl.svelte';
import SideNavigationEditor, { allTokens as sideNavigationTokens } from './SideNavigationEditor.svelte';
import { catalogue as sideNavigationCatalogue } from '../../system/components/SideNavigation.svelte';
import TableEditor, { allTokens as tableTokens } from './TableEditor.svelte';
import { catalogue as tableCatalogue } from '../../system/components/Table.svelte';
import TabBarEditor, { allTokens as tabBarTokens } from './TabBarEditor.svelte';
import { catalogue as tabBarCatalogue } from '../../system/components/TabBar.svelte';
import ToggleEditor, { allTokens as toggleTokens } from './ToggleEditor.svelte';
import { catalogue as toggleCatalogue } from '../../system/components/Toggle.svelte';
import TooltipEditor, { allTokens as tooltipTokens } from './TooltipEditor.svelte';
import { catalogue as tooltipCatalogue } from '../../system/components/Tooltip.svelte';

/** Internal narrowed union of the first-party component ids. Not exposed publicly. */
type BuiltInComponentId =
  | 'segmentedcontrol'
  | 'button'
  | 'iconbutton'
  | 'notification'
  | 'dialog'
  | 'radiobutton'
  | 'card'
  | 'badge'
  | 'callout'
  | 'codesnippet'
  | 'cornerbadge'
  | 'image'
  | 'imagelightbox'
  | 'inlineeditactions'
  | 'input'
  | 'menuselect'
  | 'panel'
  | 'sectiondivider'
  | 'collapsiblesection'
  | 'sidenavigation'
  | 'table'
  | 'tabbar'
  | 'toggle'
  | 'tooltip'
  | 'progressbar'
  | 'videolightbox'
  | 'videoframe'
  | 'slidepager';

/**
 * Public component id type. Widened to `string` because consumers can register
 * their own components at runtime via `registerComponent()`. Internal code that
 * needs to narrow to first-party ids can reference `BuiltInComponentId`.
 */
export type ComponentId = string;

export interface RegistryEntry {
  /** Canonical id — lowercase, matches the runtime component filename + server scan + `setComponentAlias` key. */
  id: ComponentId;
  /** Human-readable label for nav and section headers. */
  label: string;
  /** FontAwesome icon class for the nav rail. */
  icon: string;
  /** Path to the runtime component, relative to repo root. */
  sourceFile: string;
  /** The Svelte editor component to mount in the page. */
  editorComponent: Component<any, any, any>;
  /** Flat token list — the editor's declarative description of its token surface. */
  schema: Token[];
  /** Structural/display properties controlled outside the token grid. Optional —
      most components have none. When present, each spec's per-variant default is
      pinned to the runtime `:global(:root)` by intrinsicsContract.test. */
  intrinsics?: IntrinsicSpec[];
  /** What the component is, what to use it for, and what not to use it for.
      Imported from the runtime file's own `catalogue` export — never copied —
      so registryContract.test's identity check pins it to that one source. */
  catalogue: CatalogueEntry;
  /** `'system'` for first-party entries; `'custom'` for entries added via `registerComponent()`. */
  origin: 'system' | 'custom';
}

/**
 * First-party registry. Frozen; runtime additions go in `customRegistry`.
 * Adding a first-party component:
 *   1. Author `src/system/components/<Name>.svelte` (declares CSS vars in `:global(:root)`)
 *   2. Author `src/editor/component-editor/<Name>Editor.svelte` (exports `allTokens`)
 *   3. Add an entry below.
 */
const builtInRegistry: Readonly<Record<BuiltInComponentId, RegistryEntry>> = Object.freeze({
  segmentedcontrol: {
    id: 'segmentedcontrol',
    label: 'Segmented Control',
    icon: 'fas fa-hand-pointer',
    sourceFile: 'src/system/components/SegmentedControl.svelte',
    editorComponent: SegmentedControlEditor,
    schema: segmentedControlTokens,
    catalogue: segmentedControlCatalogue,
    origin: 'system',
  },
  button: {
    id: 'button',
    label: 'Button',
    icon: 'fas fa-square',
    sourceFile: 'src/system/components/Button.svelte',
    editorComponent: ButtonEditor,
    schema: buttonTokens,
    catalogue: buttonCatalogue,
    origin: 'system',
  },
  iconbutton: {
    id: 'iconbutton',
    label: 'Icon Button',
    icon: 'fas fa-square-plus',
    sourceFile: 'src/system/components/IconButton.svelte',
    editorComponent: IconButtonEditor,
    schema: iconButtonTokens,
    catalogue: iconButtonCatalogue,
    origin: 'system',
  },
  notification: {
    id: 'notification',
    label: 'Notification',
    icon: 'fas fa-bell',
    sourceFile: 'src/system/components/Notification.svelte',
    editorComponent: NotificationEditor,
    schema: notificationTokens,
    catalogue: notificationCatalogue,
    origin: 'system',
  },
  dialog: {
    id: 'dialog',
    label: 'Dialog',
    icon: 'fas fa-window-restore',
    sourceFile: 'src/system/components/Dialog.svelte',
    editorComponent: DialogEditor,
    schema: dialogTokens,
    catalogue: dialogCatalogue,
    origin: 'system',
  },
  radiobutton: {
    id: 'radiobutton',
    label: 'Radio Button',
    icon: 'fas fa-dot-circle',
    sourceFile: 'src/system/components/RadioButton.svelte',
    editorComponent: RadioButtonEditor,
    schema: radioButtonTokens,
    catalogue: radioButtonCatalogue,
    origin: 'system',
  },
  card: {
    id: 'card',
    label: 'Card',
    icon: 'fas fa-id-card',
    sourceFile: 'src/system/components/Card.svelte',
    editorComponent: CardEditor,
    schema: cardTokens,
    intrinsics: cardIntrinsics,
    catalogue: cardCatalogue,
    origin: 'system',
  },
  badge: {
    id: 'badge',
    label: 'Badge',
    icon: 'fas fa-tag',
    sourceFile: 'src/system/components/Badge.svelte',
    editorComponent: BadgeEditor,
    schema: badgeTokens,
    catalogue: badgeCatalogue,
    origin: 'system',
  },
  callout: {
    id: 'callout',
    label: 'Callout',
    icon: 'fas fa-quote-left',
    sourceFile: 'src/system/components/Callout.svelte',
    editorComponent: CalloutEditor,
    schema: calloutTokens,
    catalogue: calloutCatalogue,
    origin: 'system',
  },
  codesnippet: {
    id: 'codesnippet',
    label: 'Code Snippet',
    icon: 'fas fa-code',
    sourceFile: 'src/system/components/CodeSnippet.svelte',
    editorComponent: CodeSnippetEditor,
    schema: codeSnippetTokens,
    catalogue: codeSnippetCatalogue,
    origin: 'system',
  },
  cornerbadge: {
    id: 'cornerbadge',
    label: 'Corner Badge',
    icon: 'fas fa-tags',
    sourceFile: 'src/system/components/CornerBadge.svelte',
    editorComponent: CornerBadgeEditor,
    schema: cornerBadgeTokens,
    catalogue: cornerBadgeCatalogue,
    origin: 'system',
  },
  image: {
    id: 'image',
    label: 'Image',
    icon: 'fas fa-image',
    sourceFile: 'src/system/components/Image.svelte',
    editorComponent: ImageEditor,
    schema: imageTokens,
    intrinsics: imageIntrinsics,
    catalogue: imageCatalogue,
    origin: 'system',
  },
  imagelightbox: {
    id: 'imagelightbox',
    label: 'Image Lightbox',
    icon: 'fas fa-expand',
    sourceFile: 'src/system/components/ImageLightbox.svelte',
    editorComponent: ImageLightboxEditor,
    schema: imageLightboxTokens,
    catalogue: imageLightboxCatalogue,
    origin: 'system',
  },
  videolightbox: {
    id: 'videolightbox',
    label: 'Video Lightbox',
    icon: 'fas fa-circle-play',
    sourceFile: 'src/system/components/VideoLightbox.svelte',
    editorComponent: VideoLightboxEditor,
    schema: videoLightboxTokens,
    catalogue: videoLightboxCatalogue,
    origin: 'system',
  },
  videoframe: {
    id: 'videoframe',
    label: 'Video Frame',
    icon: 'fas fa-film',
    sourceFile: 'src/system/components/VideoFrame.svelte',
    editorComponent: VideoFrameEditor,
    schema: videoFrameTokens,
    catalogue: videoFrameCatalogue,
    origin: 'system',
  },
  slidepager: {
    id: 'slidepager',
    label: 'Slide Pager',
    icon: 'fas fa-images',
    sourceFile: 'src/system/components/SlidePager.svelte',
    editorComponent: SlidePagerEditor,
    schema: slidePagerTokens,
    catalogue: slidePagerCatalogue,
    origin: 'system',
  },
  inlineeditactions: {
    id: 'inlineeditactions',
    label: 'Inline Edit Actions',
    icon: 'fas fa-pen',
    sourceFile: 'src/system/components/InlineEditActions.svelte',
    editorComponent: InlineEditActionsEditor,
    schema: inlineEditActionsTokens,
    catalogue: inlineEditActionsCatalogue,
    origin: 'system',
  },
  input: {
    id: 'input',
    label: 'Input',
    icon: 'fas fa-i-cursor',
    sourceFile: 'src/system/components/Input.svelte',
    editorComponent: InputEditor,
    schema: inputTokens,
    catalogue: inputCatalogue,
    origin: 'system',
  },
  menuselect: {
    id: 'menuselect',
    label: 'Menu Select',
    icon: 'fas fa-list',
    sourceFile: 'src/system/components/MenuSelect.svelte',
    editorComponent: MenuSelectEditor,
    schema: menuSelectTokens,
    catalogue: menuSelectCatalogue,
    origin: 'system',
  },
  panel: {
    id: 'panel',
    label: 'Panel',
    icon: 'fas fa-window-maximize',
    sourceFile: 'src/system/components/Panel.svelte',
    editorComponent: PanelEditor,
    schema: panelTokens,
    catalogue: panelCatalogue,
    origin: 'system',
  },
  sectiondivider: {
    id: 'sectiondivider',
    label: 'Section Divider',
    icon: 'fas fa-minus',
    sourceFile: 'src/system/components/SectionDivider.svelte',
    editorComponent: SectionDividerEditor,
    schema: sectionDividerTokens,
    intrinsics: sectionDividerIntrinsics,
    catalogue: sectionDividerCatalogue,
    origin: 'system',
  },
  collapsiblesection: {
    id: 'collapsiblesection',
    label: 'Collapsible Section',
    icon: 'fas fa-chevron-down',
    sourceFile: 'src/system/components/CollapsibleSection.svelte',
    editorComponent: CollapsibleSectionEditor,
    schema: collapsibleSectionTokens,
    catalogue: collapsibleSectionCatalogue,
    origin: 'system',
  },
  sidenavigation: {
    id: 'sidenavigation',
    label: 'Side Navigation',
    icon: 'fas fa-bars-staggered',
    sourceFile: 'src/system/components/SideNavigation.svelte',
    editorComponent: SideNavigationEditor,
    schema: sideNavigationTokens,
    catalogue: sideNavigationCatalogue,
    origin: 'system',
  },
  table: {
    id: 'table',
    label: 'Table',
    icon: 'fas fa-table',
    sourceFile: 'src/system/components/Table.svelte',
    editorComponent: TableEditor,
    schema: tableTokens,
    catalogue: tableCatalogue,
    origin: 'system',
  },
  tabbar: {
    id: 'tabbar',
    label: 'Tab Bar',
    icon: 'fas fa-columns',
    sourceFile: 'src/system/components/TabBar.svelte',
    editorComponent: TabBarEditor,
    schema: tabBarTokens,
    catalogue: tabBarCatalogue,
    origin: 'system',
  },
  toggle: {
    id: 'toggle',
    label: 'Toggle',
    icon: 'fas fa-toggle-on',
    sourceFile: 'src/system/components/Toggle.svelte',
    editorComponent: ToggleEditor,
    schema: toggleTokens,
    catalogue: toggleCatalogue,
    origin: 'system',
  },
  tooltip: {
    id: 'tooltip',
    label: 'Tooltip',
    icon: 'fas fa-comment-dots',
    sourceFile: 'src/system/components/Tooltip.svelte',
    editorComponent: TooltipEditor,
    schema: tooltipTokens,
    catalogue: tooltipCatalogue,
    origin: 'system',
  },
  progressbar: {
    id: 'progressbar',
    label: 'Progress Bar',
    icon: 'fas fa-tasks',
    sourceFile: 'src/system/components/ProgressBar.svelte',
    editorComponent: ProgressBarEditor,
    schema: progressBarTokens,
    catalogue: progressBarCatalogue,
    origin: 'system',
  },
  slider: {
    id: 'slider',
    label: 'Slider',
    icon: 'fas fa-sliders',
    sourceFile: 'src/system/components/Slider.svelte',
    editorComponent: SliderEditor,
    schema: sliderTokens,
    catalogue: sliderCatalogue,
    origin: 'system',
  },
});

/** Mutable map of consumer-registered components, populated by `registerComponent()`. */
const customRegistry = new Map<string, RegistryEntry>();

/** Argument shape for `registerComponent()`. `origin` is set internally to `'custom'`. */
export type RegisterComponentEntry = Omit<RegistryEntry, 'origin'>;

function addCustomComponent(entry: RegisterComponentEntry): void {
  if (entry.id in builtInRegistry) {
    console.warn(
      `[registerComponent] custom component "${entry.id}" overrides a built-in. The custom editor will be used.`,
    );
  }
  const stored: RegistryEntry = { ...entry, origin: 'custom' };
  customRegistry.set(entry.id, stored);
  registerComponentSchema(entry.id, entry.schema);
}

/**
 * Merged registry: built-ins overlaid with customs (custom wins on id collision).
 * Recomputed on each call so callers see runtime registrations made after their
 * own module-load order.
 */
export function getComponentRegistry(): Readonly<Record<string, RegistryEntry>> {
  const merged: Record<string, RegistryEntry> = { ...builtInRegistry };
  for (const [id, entry] of customRegistry) {
    merged[id] = entry;
  }
  return merged;
}

/**
 * Display-ordered entries: system first (alphabetical by label), then custom
 * (alphabetical by label). Iteration order matches the nav rail's grouping.
 * The nav rail renders a divider between the two groups when customs exist.
 */
export function getComponentRegistryEntries(): ReadonlyArray<RegistryEntry> {
  const merged = getComponentRegistry();
  const system: RegistryEntry[] = [];
  const custom: RegistryEntry[] = [];
  for (const entry of Object.values(merged)) {
    (entry.origin === 'system' ? system : custom).push(entry);
  }
  system.sort((a, b) => a.label.localeCompare(b.label));
  custom.sort((a, b) => a.label.localeCompare(b.label));
  return [...system, ...custom];
}

/** All component ids, in display order. */
export function getComponentIds(): ReadonlyArray<string> {
  return getComponentRegistryEntries().map((e) => e.id);
}

// Eager schema registration for built-ins. Customs register lazily inside
// `registerComponent()` so the store knows about every component before any
// editor instance mounts.
for (const entry of Object.values(builtInRegistry)) {
  registerComponentSchema(entry.id, entry.schema);
}
attachRegistry(addCustomComponent);

/**
 * Validate that the server's filesystem scan matches the merged registry's id list.
 * Logs a warning when ids drift. Called at boot from the editor page.
 */
export function validateRegistryAgainstServerScan(serverIds: ReadonlyArray<string>): void {
  const ids = getComponentIds();
  const registrySet = new Set<string>(ids);
  const serverSet = new Set<string>(serverIds);
  const missingOnServer = ids.filter((id) => !serverSet.has(id));
  const extraOnServer = serverIds.filter((id) => !registrySet.has(id));
  if (missingOnServer.length > 0) {
    console.warn(
      '[componentRegistry] registered components missing from server scan:',
      missingOnServer.join(', '),
    );
  }
  if (extraOnServer.length > 0) {
    console.warn(
      '[componentRegistry] components on disk not in registry (will be ignored by editor):',
      extraOnServer.join(', '),
    );
  }
}
