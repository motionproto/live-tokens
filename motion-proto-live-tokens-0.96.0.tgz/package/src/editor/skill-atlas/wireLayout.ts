import type { Edge } from './types';

/** A card's laid-out rectangle, relative to the canvas. */
export interface Box {
  left: number;
  right: number;
  top: number;
  bottom: number;
  midX: number;
  midY: number;
}

export interface Wire {
  d: string;
  back: boolean;
  lit: boolean;
  /** Trunks and buses carry no arrowhead; only the segment that arrives does. */
  arrow: boolean;
}

export interface Label {
  x: number;
  y: number;
  /** One entry per answer sharing the wire. */
  lines: string[];
  lit: boolean;
  /** Lane labels run along the lane; branch labels sit across the drop. */
  rotate: boolean;
}

export interface Drawing {
  wires: Wire[];
  labels: Label[];
}

/** Clearance between a card border and the wire, so the arrowhead reads as
 *  an arrival rather than as part of the card outline. */
const STANDOFF = 6;
const CORNER = 12;
/** How far outside the cards a lane sits, and how far one lane nests
 *  inside the next when two share a stretch of gutter. */
const LANE_INSET = 40;
const LANE_STEP = 16;
/** A comb rides inside the loop lanes, which start at LANE_INSET. */
const COMB_INSET = 20;

/** Cards laid out in one row share a top to within a pixel; cards pushed onto
 *  a second wrapped line do not, and a single bus cannot serve both. */
function aligned(values: number[]): boolean {
  return Math.max(...values) - Math.min(...values) < 4;
}

function push<T>(map: Map<string, T[]>, key: string, value: T) {
  const list = map.get(key);
  if (list) list.push(value);
  else map.set(key, [value]);
}

function label(out: Drawing, text: string | undefined, x: number, y: number, lit: boolean, rotate = false) {
  if (text) out.labels.push({ x, y, lines: text.split('\n'), lit, rotate });
}

/** One trunk down from the parent, one bus across, one drop into each child —
 *  so a split reads as a single decision rather than as N crossing curves.
 *  Each answer sits on its own drop. */
function fanOut(out: Drawing, a: Box, kids: Box[], edges: Edge[], lit: (i: number) => boolean) {
  const top = kids[0].top;
  const busY = (a.bottom + top) / 2;
  const xs = kids.map((k) => k.midX);
  const r = Math.max(
    0,
    Math.min(CORNER, (Math.max(...xs) - Math.min(...xs)) / 2, (busY - a.bottom) / 2, (top - busY) / 2),
  );
  const turns = xs.map((x) => (x < a.midX ? x + r : x > a.midX ? x - r : x));
  const busLeft = Math.min(...turns, a.midX);
  const busRight = Math.max(...turns, a.midX);
  const anyLit = kids.some((_, i) => lit(i));

  out.wires.push({
    back: false,
    arrow: false,
    lit: anyLit,
    d: `M ${a.midX} ${a.bottom + STANDOFF} L ${a.midX} ${busY} M ${busLeft} ${busY} L ${busRight} ${busY}`,
  });
  kids.forEach((k, i) => {
    const x = k.midX;
    const turn = turns[i];
    out.wires.push({
      back: false,
      arrow: true,
      lit: lit(i),
      d:
        turn === x
          ? `M ${x} ${busY} L ${x} ${top - STANDOFF}`
          : `M ${turn} ${busY} Q ${x} ${busY}, ${x} ${busY + r} L ${x} ${top - STANDOFF}`,
    });
    label(out, edges[i].label, x, (busY + r + top - STANDOFF) / 2, lit(i));
  });
}

/** The mirror of `fanOut`: risers up to a shared bus, one trunk into the child,
 *  so several outcomes converging land as one arrow instead of a pile. */
function fanIn(out: Drawing, parents: Box[], b: Box, edges: Edge[], lit: (i: number) => boolean) {
  const bottom = parents[0].bottom;
  const busY = (bottom + b.top) / 2;
  const xs = parents.map((p) => p.midX);
  const r = Math.max(
    0,
    Math.min(CORNER, (Math.max(...xs) - Math.min(...xs)) / 2, (busY - bottom) / 2, (b.top - busY) / 2),
  );
  const turns = xs.map((x) => (x < b.midX ? x + r : x > b.midX ? x - r : x));
  const anyLit = parents.some((_, i) => lit(i));

  parents.forEach((p, i) => {
    const x = p.midX;
    const turn = turns[i];
    out.wires.push({
      back: false,
      arrow: false,
      lit: lit(i),
      d:
        turn === x
          ? `M ${x} ${bottom + STANDOFF} L ${x} ${busY}`
          : `M ${x} ${bottom + STANDOFF} L ${x} ${busY - r} Q ${x} ${busY}, ${turn} ${busY}`,
    });
    label(out, edges[i].label, x, (bottom + STANDOFF + busY - r) / 2, lit(i));
  });
  out.wires.push({
    back: false,
    arrow: true,
    lit: anyLit,
    d:
      `M ${Math.min(...turns, b.midX)} ${busY} L ${Math.max(...turns, b.midX)} ${busY}` +
      ` M ${b.midX} ${busY} L ${b.midX} ${b.top - STANDOFF}`,
  });
}

/** A branch row wrapped to one card per line, as on a phone: the cards share
 *  a column and stand one under the next. */
function stacked(group: Box[]): boolean {
  return group.length > 1 && !aligned(group.map((g) => g.top)) && group.every((g) => group.every((h) => g.left < h.right && h.left < g.right));
}

/** `fanOut` for a stacked row: one comb down the right of the stack and a
 *  tick into each card, instead of a lane per card nesting off the canvas. */
function combOut(out: Drawing, a: Box, kids: Box[], edges: Edge[], lit: (i: number) => boolean) {
  const lane = Math.max(a.right, ...kids.map((k) => k.right)) + COMB_INSET;
  const last = kids[kids.length - 1];
  const r = Math.max(0, Math.min(CORNER, (lane - a.right - STANDOFF) / 2, (last.midY - a.midY) / 2));
  out.wires.push({
    back: false,
    arrow: false,
    lit: kids.some((_, i) => lit(i)),
    d:
      `M ${a.right + STANDOFF} ${a.midY} L ${lane - r} ${a.midY}` +
      ` Q ${lane} ${a.midY}, ${lane} ${a.midY + r} L ${lane} ${last.midY}`,
  });
  kids.forEach((k, i) => {
    out.wires.push({ back: false, arrow: true, lit: lit(i), d: `M ${lane} ${k.midY} L ${k.right + STANDOFF} ${k.midY}` });
    label(out, edges[i].label, lane, ((i === 0 ? a.midY : kids[i - 1].midY) + k.midY) / 2, lit(i), true);
  });
}

/** `fanIn` for a stacked row: each card ties into one comb down the left of
 *  the stack, which turns into the child. */
function combIn(out: Drawing, parents: Box[], b: Box, edges: Edge[], lit: (i: number) => boolean) {
  const lane = Math.min(b.left, ...parents.map((p) => p.left)) - COMB_INSET;
  const first = parents[0];
  const r = Math.max(0, Math.min(CORNER, (b.left - STANDOFF - lane) / 2, (b.midY - first.midY) / 2));
  parents.forEach((p, i) => {
    out.wires.push({ back: false, arrow: false, lit: lit(i), d: `M ${p.left - STANDOFF} ${p.midY} L ${lane} ${p.midY}` });
    label(out, edges[i].label, lane, (p.midY + (parents[i + 1]?.midY ?? b.midY)) / 2, lit(i), true);
  });
  out.wires.push({
    back: false,
    arrow: true,
    lit: parents.some((_, i) => lit(i)),
    d:
      `M ${lane} ${first.midY} L ${lane} ${b.midY - r}` +
      ` Q ${lane} ${b.midY}, ${lane + r} ${b.midY} L ${b.left - STANDOFF} ${b.midY}`,
  });
}

/** A plain parent-to-child curve, and the fallback wherever a bus would have
 *  to cross a card: children wrapped onto a second line, or parents staggered
 *  across rows. */
function curve(out: Drawing, a: Box, b: Box, edge: Edge, lit: boolean) {
  const y1 = a.bottom + STANDOFF;
  const y2 = b.top - STANDOFF;
  const bend = Math.max(16, (y2 - y1) * 0.55);
  out.wires.push({
    back: false,
    arrow: true,
    lit,
    d: `M ${a.midX} ${y1} C ${a.midX} ${y1 + bend}, ${b.midX} ${y2 - bend}, ${b.midX} ${y2}`,
  });
  label(out, edge.label, (a.midX + b.midX) / 2, (y1 + y2) / 2, lit);
}

/** Every card the span passes between, not just the two it joins. */
function crossed(a: Box, b: Box, all: Box[]): Box[] {
  const top = Math.min(a.midY, b.midY);
  const bottom = Math.max(a.midY, b.midY);
  return all.filter((x) => x !== a && x !== b && x.bottom > top && x.top < bottom);
}

/** On the spine: no other card shares its row. A wrapped branch row also
 *  "crosses" cards on its way down, and those stay curves. */
function alone(box: Box, all: Box[]): boolean {
  return all.every((x) => x === box || !aligned([x.top, box.top]));
}

/** Re-run loops ride a lane in the left gutter the centred spine opens up,
 *  rather than bulging around the card they leave. A card with siblings to
 *  its left leaves from its bottom and runs under the row, so the wire never
 *  passes through the cards beside it. */
function backEdge(out: Drawing, a: Box, b: Box, lane: number, edge: Edge, lit: boolean, under?: number) {
  const dir = Math.sign(b.midY - a.midY) || -1;
  const r = Math.max(0, Math.min(CORNER, (a.left - STANDOFF - lane) / 2, Math.abs(a.midY - b.midY) / 2));
  const d =
    under === undefined
      ? `M ${a.left - STANDOFF} ${a.midY} L ${lane + r} ${a.midY}` +
        ` Q ${lane} ${a.midY}, ${lane} ${a.midY + dir * r}`
      : `M ${a.midX} ${a.bottom + STANDOFF} L ${a.midX} ${under - r}` +
        ` Q ${a.midX} ${under}, ${a.midX - r} ${under} L ${lane + r} ${under}` +
        ` Q ${lane} ${under}, ${lane} ${under - r}`;
  out.wires.push({
    back: true,
    arrow: true,
    lit,
    d:
      d +
      ` L ${lane} ${b.midY - dir * r} Q ${lane} ${b.midY}, ${lane + r} ${b.midY}` +
      ` L ${b.left - STANDOFF} ${b.midY}`,
  });
  label(out, edge.label, lane, (a.midY + b.midY) / 2, lit, true);
}

/** A branch that skips a row rides the right gutter, the mirror of a loop,
 *  so a "no" never has to be drawn through the card the "yes" leads to. */
function skipEdge(out: Drawing, a: Box, b: Box, lane: number, edge: Edge, lit: boolean) {
  const r = Math.max(0, Math.min(CORNER, (lane - a.right - STANDOFF) / 2, Math.abs(a.midY - b.midY) / 2));
  out.wires.push({
    back: false,
    arrow: true,
    lit,
    d:
      `M ${a.right + STANDOFF} ${a.midY} L ${lane - r} ${a.midY}` +
      ` Q ${lane} ${a.midY}, ${lane} ${a.midY + r}` +
      ` L ${lane} ${b.midY - r} Q ${lane} ${b.midY}, ${lane - r} ${b.midY}` +
      ` L ${b.right + STANDOFF} ${b.midY}`,
  });
  label(out, edge.label, lane, (a.midY + b.midY) / 2, lit, true);
}

/**
 * Routes every edge between the measured cards. `lit` answers whether a wire
 * joining the given node ids belongs to the current selection.
 */
export function routeWires(boxes: Map<string, Box>, edges: Edge[], lit: (edge: Edge) => boolean): Drawing {
  const all = [...boxes.values()];
  const children = new Map<string, Edge[]>();
  const parents = new Map<string, Edge[]>();
  for (const edge of edges) {
    if (edge.back) continue;
    push(children, edge.from, edge);
    push(parents, edge.to, edge);
  }

  const out: Drawing = { wires: [], labels: [] };
  const claimed = new Set<Edge>();

  for (const [from, kidEdges] of children) {
    const a = boxes.get(from);
    const kids = kidEdges.map((e) => boxes.get(e.to));
    if (!a || kidEdges.length < 2 || kids.some((k) => !k)) continue;
    const kept = kids as Box[];
    if (stacked(kept)) {
      const order = kept.map((_, i) => i).sort((i, j) => kept[i].top - kept[j].top);
      const sortedEdges = order.map((i) => kidEdges[i]);
      sortedEdges.forEach((e) => claimed.add(e));
      combOut(out, a, order.map((i) => kept[i]), sortedEdges, (i) => lit(sortedEdges[i]));
      continue;
    }
    if (!aligned(kept.map((k) => k.top))) continue;
    kidEdges.forEach((e) => claimed.add(e));
    fanOut(out, a, kept, kidEdges, (i) => lit(kidEdges[i]));
  }

  for (const [to, parentEdges] of parents) {
    const open = parentEdges.filter((e) => !claimed.has(e));
    const b = boxes.get(to);
    const ups = open.map((e) => boxes.get(e.from));
    if (!b || open.length < 2 || ups.some((u) => !u)) continue;
    const kept = ups as Box[];
    if (stacked(kept)) {
      const order = kept.map((_, i) => i).sort((i, j) => kept[i].top - kept[j].top);
      const sortedEdges = order.map((i) => open[i]);
      sortedEdges.forEach((e) => claimed.add(e));
      combIn(out, order.map((i) => kept[i]), b, sortedEdges, (i) => lit(sortedEdges[i]));
      continue;
    }
    if (!aligned(kept.map((u) => u.bottom))) continue;
    open.forEach((e) => claimed.add(e));
    fanIn(out, kept, b, open, (i) => lit(open[i]));
  }

  // Longest skip first, so a long one always rides outside the skips it spans.
  const skips: { edge: Edge; a: Box; b: Box; over: Box[] }[] = [];
  for (const edge of edges) {
    if (edge.back || claimed.has(edge)) continue;
    const a = boxes.get(edge.from);
    const b = boxes.get(edge.to);
    if (!a || !b) continue;
    const over = alone(a, all) && alone(b, all) ? crossed(a, b, all) : [];
    if (over.length > 0) skips.push({ edge, a, b, over });
    else curve(out, a, b, edge, lit(edge));
  }
  skips.sort((x, y) => Math.abs(y.a.midY - y.b.midY) - Math.abs(x.a.midY - x.b.midY));
  let outer = -Infinity;
  for (const { edge, a, b, over } of skips) {
    const lane = Math.max(...over.map((x) => x.right), a.right, b.right) + LANE_INSET;
    const placed = Math.max(lane, outer + LANE_STEP);
    outer = placed;
    skipEdge(out, a, b, placed, edge, lit(edge));
  }

  // Shortest loop first, so a long one always nests outside the loops it spans.
  const loops = edges
    .filter((e) => e.back)
    .map((edge) => ({ edge, a: boxes.get(edge.from), b: boxes.get(edge.to) }))
    .filter((e): e is { edge: Edge; a: Box; b: Box } => !!e.a && !!e.b)
    .sort((x, y) => Math.abs(x.a.midY - x.b.midY) - Math.abs(y.a.midY - y.b.midY));

  let inner = Infinity;
  let unders = 0;
  for (const { edge, a, b } of loops) {
    const beside = all.filter((x) => x !== a && x.right <= a.left && x.bottom > a.midY && x.top < a.midY);
    const clear = Math.min(...crossed(a, b, all).map((x) => x.left), ...beside.map((x) => x.left), a.left, b.left) - LANE_INSET;
    const lane = Math.max(4, Math.min(clear, inner - LANE_STEP));
    inner = lane;
    // Each wire under the row takes its own height, in step with its lane, so
    // the loops nest instead of sharing one line.
    const under = beside.length ? a.bottom + STANDOFF + CORNER + LANE_STEP * unders++ : undefined;
    backEdge(out, a, b, lane, edge, lit(edge), under);
  }

  return out;
}
