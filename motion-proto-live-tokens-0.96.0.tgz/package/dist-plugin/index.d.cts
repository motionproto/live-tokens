import { Plugin } from 'vite';
export { ComponentSource, MissingToken, RunResult, TOKENS_CSS_MIGRATIONS, TokensCssMigration, ValidateInput, runTokensCssMigrations, validateTokensCss } from './tokensCssMigrations/index.cjs';
import './dataPaths-BpIK_Obx.cjs';

interface ProductionCssOptions {
    /** default: true. With false the build removes unreached properties only and keeps every `var()`. */
    substitute?: boolean;
    /** Names a script sets or reads under a name it assembles at runtime. */
    keep?: string[];
}

interface ThemeFileApiOptions {
    tokensCssPath: string;
    tokensGeneratedCssPath?: string;
    fontsCssPath?: string;
    apiBase?: string;
    dataDir?: string;
    colorsAndTypeDir?: string;
    componentConfigsDir?: string;
    themesDir?: string;
    componentsSrcDir?: string;
    autoMigrate?: boolean;
    checks?: boolean;
    productionCss?: false | ProductionCssOptions;
}
declare function themeFileApi(opts: ThemeFileApiOptions): Plugin;

export { type ProductionCssOptions, type ThemeFileApiOptions, themeFileApi };
