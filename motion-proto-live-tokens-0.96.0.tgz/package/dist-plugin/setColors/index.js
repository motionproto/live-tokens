import {
  DEFAULT_PALETTE_LIGHTNESS,
  DEFAULT_PALETTE_SATURATION,
  DIRECTION_ANGLES,
  PALETTE_SPECS,
  PALETTE_STEPS,
  SCALES,
  formatGradientValue,
  makeAnchor,
  palettesToVars,
  resmoothAutoCurve,
  sanitizeFileName,
  scaleCurveDefaults,
  scaleStepToX,
  scaleToCssVar,
  setCurveAnchor,
  syncBaseAnchor
} from "../chunk-A4TBP4MM.js";
import {
  cssColorToOklch,
  gamutClamp,
  hexToOklch,
  oklchToHex,
  oklchToHexClamped
} from "../chunk-7TQQTHI6.js";
import {
  CURRENT_COMPONENT_SCHEMA_VERSION
} from "../chunk-QQASYPW7.js";
import {
  readLiveTokensConfig,
  resolveDataDirs
} from "../chunk-6WGFOJXO.js";

// src/editor/core/themes/slices/gradients.ts
function makeDefaultGradients() {
  return [
    {
      variable: "--gradient-1",
      type: "linear",
      angle: DIRECTION_ANGLES["to right"],
      direction: "to right",
      stops: [
        { position: 0, color: "--color-brand-500" },
        { position: 100, color: "--color-accent-500" }
      ]
    },
    {
      variable: "--gradient-2",
      type: "linear",
      angle: 135,
      stops: [
        { position: 0, color: "--color-brand-500" },
        { position: 100, color: "--color-special-500" }
      ]
    },
    {
      variable: "--gradient-3",
      type: "linear",
      angle: DIRECTION_ANGLES["to right"],
      direction: "to right",
      stops: [
        { position: 0, color: "--color-success-500" },
        { position: 100, color: "--color-info-500" }
      ]
    },
    {
      variable: "--gradient-4",
      type: "linear",
      angle: 45,
      stops: [
        { position: 0, color: "--color-danger-500" },
        { position: 100, color: "--color-warning-500" }
      ]
    }
  ];
}

// src/editor/core/themes/parsers/shadow.ts
var SHADOW_VAR_NAMES = [
  "--shadow-sm",
  "--shadow-md",
  "--shadow-lg",
  "--shadow-xl",
  "--shadow-2xl"
];
function computeAngleDistance(x, y) {
  const distance = Math.round(Math.sqrt(x * x + y * y));
  if (distance === 0) return { angle: 135, distance: 0 };
  let angle = Math.atan2(y, -x) * (180 / Math.PI);
  if (angle < 0) angle += 360;
  return { angle: Math.round(angle), distance };
}
function shadowTokenCss(t) {
  const spread = t.spread ? `${t.spread}px ` : "";
  return `${t.x}px ${t.y}px ${t.blur}px ${spread}hsla(${t.hue}, ${t.saturation}%, ${t.lightness}%, ${t.opacity})`;
}
function parseShadowCss(variable, raw) {
  const m = raw.trim().match(/^(-?\d+)px\s+(-?\d+)px\s+(\d+)px\s+(?:(-?\d+)px\s+)?hsla\(([\d.]+),\s*([\d.]+)%,\s*([\d.]+)%,\s*([\d.]+)\)$/);
  if (!m) return null;
  const x = parseInt(m[1], 10);
  const y = parseInt(m[2], 10);
  const blur = parseInt(m[3], 10);
  const spread = m[4] === void 0 ? 0 : parseInt(m[4], 10);
  const hue = Math.round(parseFloat(m[5]));
  const saturation = Math.round(parseFloat(m[6]));
  const lightness = Math.round(parseFloat(m[7]));
  const opacity = parseFloat(m[8]);
  const { angle, distance } = computeAngleDistance(x, y);
  return { variable, x, y, blur, spread, opacity, hue, saturation, lightness, angle, distance };
}

// src/editor/core/palettes/contrast.ts
var AA_BODY = 4.5;
var AA_LARGE = 3;
function linearizeChannel(v8) {
  const s = v8 / 255;
  return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
}
function relativeLuminance(hex) {
  const r = linearizeChannel(parseInt(hex.slice(1, 3), 16));
  const g = linearizeChannel(parseInt(hex.slice(3, 5), 16));
  const b = linearizeChannel(parseInt(hex.slice(5, 7), 16));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function contrastRatio(a, b) {
  const la = relativeLuminance(a);
  const lb = relativeLuminance(b);
  const hi = Math.max(la, lb);
  const lo = Math.min(la, lb);
  return (hi + 0.05) / (lo + 0.05);
}
function findLForContrast(opts) {
  const { against, ratio, direction, c, h } = opts;
  const margin = opts.margin ?? 0.05;
  const lMin = opts.lMin ?? 0;
  const lMax = opts.lMax ?? 1;
  const target = ratio + margin;
  const againstL = hexToOklch(against).l;
  const evalAt = (l2, cc) => {
    const g = gamutClamp(l2, cc, h);
    const hex2 = oklchToHex(g.l, g.c, g.h);
    return { hex: hex2, chroma: g.c, ratio: contrastRatio(hex2, against) };
  };
  const solveAtChroma = (cc) => {
    const lighter = direction === "lighter";
    const lo0 = lighter ? Math.max(lMin, againstL) : lMin;
    const hi0 = lighter ? lMax : Math.min(lMax, againstL);
    if (lo0 >= hi0) return null;
    const extreme = lighter ? hi0 : lo0;
    if (evalAt(extreme, cc).ratio < target) return null;
    let lo = lo0;
    let hi = hi0;
    for (let i = 0; i < 24; i++) {
      const mid = (lo + hi) / 2;
      const meets = evalAt(mid, cc).ratio >= target;
      if (lighter ? meets : !meets) hi = mid;
      else lo = mid;
    }
    const at = lighter ? hi : lo;
    const e = evalAt(at, cc);
    return { l: at, hex: e.hex, chroma: e.chroma };
  };
  let sol = solveAtChroma(c);
  if (!sol) {
    if (!solveAtChroma(0)) {
      const extremeL = direction === "lighter" ? lMax : lMin;
      const e = evalAt(extremeL, 0);
      return { l: extremeL, c: 0, hex: e.hex };
    }
    let lo = 0;
    let hi = c;
    for (let i = 0; i < 24; i++) {
      const mid = (lo + hi) / 2;
      if (solveAtChroma(mid)) lo = mid;
      else hi = mid;
    }
    sol = solveAtChroma(lo);
  }
  let { l, hex, chroma } = sol;
  const step = direction === "lighter" ? 4e-3 : -4e-3;
  for (let k = 0; k < 12 && contrastRatio(hex, against) < ratio; k++) {
    l = Math.min(lMax, Math.max(lMin, l + step));
    const g = gamutClamp(l, chroma, h);
    l = g.l;
    chroma = g.c;
    hex = oklchToHex(g.l, g.c, g.h);
  }
  return { l, c: chroma, hex };
}

// src/editor/ui/palette/paletteMath.ts
var DEFAULT_NEUTRAL_LIGHTNESS = () => resmoothAutoCurve([makeAnchor(0, 92), makeAnchor(100, 3)]);
function defaultPaletteConfig(opts) {
  const cfg = {
    baseColor: opts.baseColor,
    lightnessCurve: opts.neutral ? DEFAULT_NEUTRAL_LIGHTNESS() : DEFAULT_PALETTE_LIGHTNESS(),
    saturationCurve: DEFAULT_PALETTE_SATURATION(),
    scaleCurves: defaultScaleCurvesObject(opts.scheme ?? "dark"),
    curveOffset: { lightness: 0, saturation: 0 },
    overrides: {},
    snappedScales: [],
    anchorToBase: true
  };
  syncBaseAnchor(cfg);
  return cfg;
}
function defaultScaleCurvesObject(scheme = "dark") {
  const defs = scaleCurveDefaults(scheme);
  return {
    Surfaces: { lightness: defs.Surfaces.lightness(), saturation: defs.Surfaces.saturation() },
    Borders: { lightness: defs.Borders.lightness(), saturation: defs.Borders.saturation() },
    Text: { lightness: defs.Text.lightness(), saturation: defs.Text.saturation() }
  };
}

// src/editor/core/themes/buildColors.ts
var HEX_RE = /^#[0-9a-f]{6}$/i;
var HARMONY_MODES = [
  "complementary",
  "split-complementary",
  "triadic",
  "tetradic",
  "compound",
  "square",
  "analogous",
  "monochromatic",
  "custom"
];
var TEXT_SCALE = SCALES.find((s) => s.title === "Text");
var SURFACE_SCALE = SCALES.find((s) => s.title === "Surfaces");
var NEUTRAL_TEXT_FLOORS = [
  ["primary", AA_BODY, 7],
  ["secondary", AA_BODY, 5.5],
  ["tertiary", AA_LARGE, 3.5]
];
var FUNCTIONAL_TEXT_TARGET = 3.5;
var FUNCTIONAL_TEXT_LABELS = PALETTE_SPECS.filter((s) => s.label !== "Neutral" && s.label !== "Canvas").map((s) => s.label);
var norm = (h) => h >= 0 && h < 360 ? h : (h % 360 + 360) % 360;
function parseBaseColor(label, raw, problems) {
  if (typeof raw === "string") {
    if (!HEX_RE.test(raw.trim())) {
      problems.push(`${label}: "${raw}" is not a #rrggbb hex color`);
      return null;
    }
    return hexToOklch(raw.trim());
  }
  const { l, c, h } = raw ?? {};
  if (typeof l !== "number" || l <= 0 || l >= 1) problems.push(`${label}: l must be in (0, 1), got ${l}`);
  if (typeof c !== "number" || c < 0 || c > 0.4) problems.push(`${label}: c must be in [0, 0.4], got ${c}`);
  if (typeof h !== "number" || !Number.isFinite(h)) problems.push(`${label}: h must be a finite number, got ${h}`);
  if (problems.length > 0) return null;
  return { l, c, h: norm(h) };
}
function validateInput(input) {
  const problems = [];
  if (input.scheme !== "light" && input.scheme !== "dark") {
    problems.push(`scheme: must be "light" or "dark", got ${JSON.stringify(input.scheme)}`);
  }
  if (input.harmony && !HARMONY_MODES.includes(input.harmony.mode)) {
    problems.push(`harmony.mode: unknown mode ${JSON.stringify(input.harmony.mode)}`);
  }
  if (input.canvasGradient !== void 0 && typeof input.canvasGradient !== "boolean") {
    problems.push(`canvasGradient: must be a boolean, got ${JSON.stringify(input.canvasGradient)}`);
  }
  const baseColors = {};
  const given = input.baseColors ?? {};
  for (const spec of PALETTE_SPECS) {
    if (!(spec.label in given)) {
      problems.push(`baseColors.${spec.label}: missing`);
      continue;
    }
    const parsed = parseBaseColor(spec.label, given[spec.label], problems);
    if (parsed) baseColors[spec.label] = parsed;
  }
  const known = new Set(PALETTE_SPECS.map((s) => s.label));
  for (const label of Object.keys(given)) {
    if (!known.has(label)) problems.push(`baseColors.${label}: unknown palette (expected ${[...known].join(", ")})`);
  }
  if (problems.length > 0) {
    throw new Error(`Invalid base color file:
  ${problems.join("\n  ")}`);
  }
  return baseColors;
}
function checkDefs() {
  const defs = [];
  for (const [stepName, floor, target] of NEUTRAL_TEXT_FLOORS) {
    defs.push({
      paletteLabel: "Neutral",
      step: TEXT_SCALE.steps.find((s) => s.name === stepName),
      textVar: scaleToCssVar("Text", stepName, "neutral"),
      floor,
      target
    });
  }
  const primary = TEXT_SCALE.steps.find((s) => s.name === "primary");
  for (const label of FUNCTIONAL_TEXT_LABELS) {
    const ns = PALETTE_SPECS.find((s) => s.label === label).cssNamespace;
    defs.push({
      paletteLabel: label,
      step: primary,
      textVar: scaleToCssVar("Text", "primary", ns),
      floor: AA_LARGE,
      target: FUNCTIONAL_TEXT_TARGET
    });
  }
  return defs;
}
function surfaceVars() {
  return [
    ...SURFACE_SCALE.steps.map((s) => scaleToCssVar("Surfaces", s.name, "neutral")),
    "--page-bg"
  ];
}
function varToHex(value) {
  const parsed = value ? cssColorToOklch(value) : null;
  return parsed ? oklchToHexClamped(parsed.l, parsed.c, parsed.h) : null;
}
function worstSurface(textHex, vars) {
  let against = "";
  let ratio = Infinity;
  for (const surfVar of surfaceVars()) {
    const surfHex = varToHex(vars[surfVar]);
    if (!surfHex) continue;
    const r = contrastRatio(textHex, surfHex);
    if (r < ratio) {
      ratio = r;
      against = surfVar;
    }
  }
  return { against, ratio };
}
function pinTextStep(cfg, step, solved) {
  const x = scaleStepToX(step, TEXT_SCALE);
  const base = cfg.baseColor;
  const yL = Math.max(0, Math.min(200, solved.l / base.l * 100));
  cfg.scaleCurves.Text.lightness = setCurveAnchor(cfg.scaleCurves.Text.lightness, x, yL).curve;
  if (base.c > 0) {
    const yC = Math.max(0, Math.min(200, solved.c / base.c * 100));
    cfg.scaleCurves.Text.saturation = setCurveAnchor(cfg.scaleCurves.Text.saturation, x, yC).curve;
  }
}
var MAX_CORRECTION_ROUNDS = 3;
function runContrastGate(configs, scheme) {
  const defs = checkDefs();
  const direction = scheme === "light" ? "darker" : "lighter";
  const corrected = /* @__PURE__ */ new Set();
  for (let round = 0; round < MAX_CORRECTION_ROUNDS; round++) {
    const vars = palettesToVars(configs);
    let anyFixed = false;
    for (const def of defs) {
      const text = cssColorToOklch(vars[def.textVar] ?? "");
      if (!text) continue;
      const textHex = oklchToHexClamped(text.l, text.c, text.h);
      const worst = worstSurface(textHex, vars);
      if (worst.ratio >= def.floor) continue;
      const cfg = configs[def.paletteLabel];
      const base = cfg.baseColor;
      const solved = findLForContrast({
        against: varToHex(vars[worst.against]) ?? "#000000",
        ratio: def.target,
        direction,
        c: text.c,
        h: base.h,
        lMax: Math.min(1, 2 * base.l)
      });
      pinTextStep(cfg, def.step, solved);
      corrected.add(def.textVar);
      anyFixed = true;
    }
    if (!anyFixed) break;
  }
  const finalVars = palettesToVars(configs);
  const checks = defs.map((def) => {
    const worst = worstSurface(varToHex(finalVars[def.textVar]) ?? "#000000", finalVars);
    return {
      textVar: def.textVar,
      floor: def.floor,
      against: worst.against,
      ratio: worst.ratio,
      pass: worst.ratio >= def.floor,
      corrected: corrected.has(def.textVar)
    };
  });
  const failures = checks.filter((c) => !c.pass).map((c) => {
    const label = defs.find((d) => d.textVar === c.textVar).paletteLabel;
    const hint = scheme === "dark" ? `raise the ${label} base color lightness (derived text tops out at 2\xD7 its L)` : `raise the ${label} base color lightness or reduce its chroma`;
    return `${c.textVar} reaches ${c.ratio.toFixed(2)}:1 vs ${c.against} (floor ${c.floor}:1): ${hint}`;
  });
  return { scheme, checks, failures };
}
var ADJACENT_HUE_MAX = 120;
var hueDist = (a, b) => {
  const d = Math.abs(norm(a) - norm(b));
  return Math.min(d, 360 - d);
};
var linear = (variable, angle, from, to) => ({
  variable,
  type: "linear",
  angle,
  stops: [{ position: 0, color: from }, { position: 100, color: to }]
});
function recipeGradients(baseColors, scheme) {
  return [
    linear("--gradient-1", 90, "--color-brand-400", "--color-brand-700"),
    hueDist(baseColors.Special.h, baseColors.Brand.h) <= ADJACENT_HUE_MAX ? linear("--gradient-2", 135, "--color-special-500", "--color-brand-500") : linear("--gradient-2", 135, "--color-special-400", "--color-special-700"),
    hueDist(baseColors.Brand.h, baseColors.Accent.h) <= ADJACENT_HUE_MAX ? linear("--gradient-3", 90, "--color-brand-500", "--color-accent-500") : linear("--gradient-3", 90, "--color-accent-400", "--color-accent-700"),
    scheme === "dark" ? linear("--gradient-4", 180, "--color-canvas-600", "--color-canvas-900") : linear("--gradient-4", 180, "--color-canvas-200", "--color-canvas-500")
  ];
}
function isStockGradients(gradients) {
  return !gradients || gradients.length === 0 || JSON.stringify(gradients) === JSON.stringify(makeDefaultGradients());
}
function applyCanvasGradient(canvas, scheme) {
  const labels = PALETTE_STEPS.map((s) => s.label);
  const anchor = canvas.anchorPlacement.step;
  const sky = scheme === "dark" ? Math.min(anchor + 2, labels.length - 1) : Math.max(anchor - 2, 0);
  if (sky === anchor) {
    return `skipped: the Canvas base color anchors at the ramp edge (${labels[anchor]}), leaving no room for a sky; commit the canvas further from ${scheme === "dark" ? "black" : "white"}`;
  }
  canvas.emptyMode = "gradient";
  canvas.gradientStyle = "linear";
  canvas.gradientAngle = 180;
  canvas.gradientReverse = false;
  canvas.gradientStops = [
    { position: 0, paletteLabel: labels[sky] },
    { position: 100, paletteLabel: labels[anchor] }
  ];
  canvas.gradientSize = "window";
  return `on, ${labels[sky]} to ${labels[anchor]}`;
}
var STOCK_SHADOW_GEOMETRY = {
  "--shadow-sm": [1, 1, 2],
  "--shadow-md": [3, 3, 6],
  "--shadow-lg": [5, 5, 9],
  "--shadow-xl": [6, 7, 13],
  "--shadow-2xl": [8, 9, 16]
};
var STOCK_SHADOW_COLOR = { spread: 0, hue: 237, saturation: 18, lightness: 3, opacity: 0.9 };
var SHADOW_OPACITY_DEEP = 0.9;
var SHADOW_OPACITY_SOFT = 0.2;
var SHADOW_GROUND_DEEP = 0.5;
var SHADOW_GROUND_SOFT = 0.9;
function shadowOpacityForCanvas(canvasL) {
  const t = (canvasL - SHADOW_GROUND_DEEP) / (SHADOW_GROUND_SOFT - SHADOW_GROUND_DEEP);
  const ramp = Math.max(0, Math.min(1, t));
  const opacity = SHADOW_OPACITY_DEEP + ramp * (SHADOW_OPACITY_SOFT - SHADOW_OPACITY_DEEP);
  return Math.round(opacity * 100) / 100;
}
function shadowVars(carried, canvas) {
  const opacity = shadowOpacityForCanvas(canvas.l);
  const out = {};
  for (const variable of SHADOW_VAR_NAMES) {
    const [x, y, blur] = STOCK_SHADOW_GEOMETRY[variable];
    const base = parseShadowCss(variable, carried[variable] ?? "") ?? { x, y, blur, ...STOCK_SHADOW_COLOR };
    out[variable] = shadowTokenCss({ ...base, opacity });
  }
  return out;
}
function buildColors(input, carry = {}) {
  const baseColors = validateInput(input);
  const configs = {};
  for (const spec of PALETTE_SPECS) {
    configs[spec.label] = defaultPaletteConfig({
      baseColor: baseColors[spec.label],
      neutral: spec.neutral,
      scheme: input.scheme
    });
  }
  const report = runContrastGate(configs, input.scheme);
  const canvasGradient = input.canvasGradient ? applyCanvasGradient(configs.Canvas, input.scheme) : void 0;
  const gradients = isStockGradients(carry.gradients) ? recipeGradients(baseColors, input.scheme) : carry.gradients;
  const harmonyAxes = [
    { hue: norm(baseColors.Brand.h), family: "Brand" },
    { hue: norm(baseColors.Accent.h), family: "Accent" },
    { hue: norm(baseColors.Canvas.h), family: "Canvas" },
    { hue: norm(baseColors.Brand.h + 270), family: null }
  ];
  const owned = new Set(Object.keys(palettesToVars(configs)));
  const cssVariables = Object.fromEntries(
    Object.entries(carry.cssVariables ?? {}).filter(([k]) => !owned.has(k))
  );
  for (const t of gradients) cssVariables[t.variable] = formatGradientValue(t);
  Object.assign(cssVariables, shadowVars(carry.cssVariables ?? {}, baseColors.Canvas));
  return {
    colors: { editorConfigs: configs, harmonyAxes, gradients, cssVariables },
    report: {
      ...report,
      gradients: gradients === carry.gradients ? "carried" : "recipes",
      shadows: `opacity ${shadowOpacityForCanvas(baseColors.Canvas.l)} for a canvas at L ${baseColors.Canvas.l.toFixed(2)}`,
      ...canvasGradient ? { canvasGradient } : {}
    }
  };
}
export {
  CURRENT_COMPONENT_SCHEMA_VERSION,
  buildColors,
  readLiveTokensConfig,
  resolveDataDirs,
  sanitizeFileName
};
