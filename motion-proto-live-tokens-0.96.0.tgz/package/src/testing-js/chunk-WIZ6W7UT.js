import {
  COMPONENTS_PATH_ENV,
  DEFAULT_COMPONENTS_PATH
} from "./chunk-NB3NZRBM.js";

// src/testing/support/editor.ts
function componentsPath() {
  return process.env[COMPONENTS_PATH_ENV] || DEFAULT_COMPONENTS_PATH;
}
async function openComponentsEditor(page, path = componentsPath()) {
  await page.goto(path);
  await page.locator(".editor-page").waitFor();
  await page.waitForFunction(
    () => document.documentElement.style.getPropertyValue("--sectiondivider-lg-title-font-size").trim().length > 0
  );
  await page.waitForFunction(() => typeof window.__liveTokensEditor !== "undefined");
  return page;
}

export {
  openComponentsEditor
};
//# sourceMappingURL=chunk-WIZ6W7UT.js.map