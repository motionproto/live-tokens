interface CurveAnchor {
    x: number;
    y: number;
    inDx: number;
    inDy: number;
    outDx: number;
    outDy: number;
}

/** The `to <side-or-corner>` keywords CSS accepts in place of an angle. A
 *  keyword angles the gradient line off the box's own diagonal, so it tracks
 *  the element's aspect ratio where a fixed angle cannot: `to bottom right`
 *  reads as ~95deg across a wide heading and ~111deg once that heading wraps.
 *  That is the whole reason to carry them — a degree cannot express it. */
declare const LINEAR_DIRECTIONS: readonly ["to top", "to top right", "to right", "to bottom right", "to bottom", "to bottom left", "to left", "to top left"];
type LinearDirection = (typeof LINEAR_DIRECTIONS)[number];
interface GradientStop$1 {
    /** 0–100 percentage along the gradient axis. */
    position: number;
    /** A design-token name (`--surface-neutral-low`) or a raw CSS colour. */
    color: string;
    /** 0–100 alpha. Absent means 100. */
    opacity?: number;
    /** `false` marks the stop an explicit off-palette override: the stop picker
     *  opens to any colour rather than the current family, and a family-swap
     *  rewrite skips the stop so its colour survives. Absent means `true`.
     *  It has no CSS form, so `parseGradientValue` never produces it and
     *  `formatGradientValue` ignores it. It lives on the shared stop because
     *  the persisted stop carries it. */
    monochrome?: boolean;
}
interface GradientValue {
    type: 'linear' | 'radial' | 'solid' | 'none';
    angle: number;
    /** Emitted in place of `angle` on a `linear` gradient. `angle` is retained
     *  underneath so clearing the direction restores the user's degrees, the
     *  same way a radial keeps its angle. */
    direction?: LinearDirection;
    radius?: number;
    centerX?: number;
    aspectX?: number;
    aspectY?: number;
    stops: GradientStop$1[];
}

interface Oklch {
    l: number;
    c: number;
    h: number;
}

type HarmonyMode = 'complementary' | 'split-complementary' | 'triadic' | 'tetradic' | 'compound' | 'square' | 'analogous' | 'monochromatic' | 'custom';
interface HarmonyAxis {
    /** Hue in [0, 360). Always present, bound or not. */
    hue: number;
    /** Bound family label (member of HARMONY_ELIGIBLE), or null when the axis is empty. */
    family: string | null;
}

type GradientStyle = 'linear' | 'radial' | 'conic';
interface GradientStop {
    position: number;
    paletteLabel: string;
}
interface PaletteConfig {
    /** Numeric OKLCH intent — the single stored basis. Unclamped: the store holds
     *  what the user meant; gamut clamping is projection-only (derivation output,
     *  swatch/canvas painting, hex/CSS serialization). */
    baseColor: Oklch;
    lightnessCurve: CurveAnchor[];
    saturationCurve: CurveAnchor[];
    /** Signed hue offset in degrees per step, applied on top of the base hue.
     *  Absent means flat zero: the palette holds one hue, which is what every
     *  theme saved before this field did. */
    hueCurve?: CurveAnchor[];
    scaleCurves: Record<string, {
        lightness: CurveAnchor[];
        saturation: CurveAnchor[];
        hue?: CurveAnchor[];
    }>;
    curveOffset: Record<string, number>;
    /** Per curve key: are the tangents derived from the points, or held by hand?
     *  Only an explicit switch-off is recorded. A missing key means the curve's own
     *  shape answers (`isAutoSmoothCurve`), which is what every theme saved before
     *  the flag existed relies on. */
    curveAutoSmooth?: Record<string, boolean>;
    overrides: Record<string, Oklch>;
    snappedScales: string[];
    emptyMode?: 'solid' | 'gradient';
    gradientStyle?: GradientStyle;
    gradientAngle?: number;
    gradientReverse?: boolean;
    gradientStops?: GradientStop[];
    gradientSize?: 'page' | 'window';
    anchorToBase?: boolean;
    /**
     * Where the base color sits in the ramp while `anchorToBase` is on: the
     * PALETTE_STEPS index whose curve anchors are pinned to the base color
     * (lightness = base L, saturation = multiplier 100, hue delta = 0 when a
     * hue curve exists). `displacedL` / `displacedS` / `displacedH` remember
     * the y of a pre-existing anchor (endpoint or user-authored) the placement
     * overwrote at that x, so moving the placement or toggling off restores it
     * instead of deleting it. `priorLightnessEndpoints` /
     * `priorSaturationEndpoints` / `priorHueEndpoints` remember the two
     * endpoints exactly as they stood before the curve's first-ever placement
     * (a smoothed reshape, not algebraically invertible the way a later
     * scaled-handle re-placement is), so a clear can still restore the true
     * original regardless of how many times the anchor has since moved.
     */
    anchorPlacement?: {
        step: number;
        displacedL?: number;
        displacedS?: number;
        displacedH?: number;
        priorLightnessEndpoints?: [CurveAnchor, CurveAnchor];
        priorSaturationEndpoints?: [CurveAnchor, CurveAnchor];
        priorHueEndpoints?: [CurveAnchor, CurveAnchor];
    };
    /**
     * Set to true by importers when they overlay `cssVariables[--color-{ns}-*]`
     * without owning the typed-state curves. The storage-layer reconciler uses
     * it as an opt-in switch: snap `baseColor` to the imported
     * `--color-{ns}-500` anchor and clear the flag. Editor-authored themes
     * never set this, so the reconciler is a strict no-op for them.
     *
     * Persists on disk for first-load reconciliation. After reconcile strips
     * the palette-derived keys from `cssVariables`, subsequent reconciles find
     * no anchor and become idempotent no-ops regardless of the flag's value.
     */
    _imported?: boolean;
}
type FontSourceKind = 'google' | 'typekit' | 'css-url' | 'font-face';
interface FontFamily {
    id: string;
    name: string;
    cssName: string;
    weights?: number[];
    italics?: boolean;
}
interface FontSource {
    id: string;
    kind: FontSourceKind;
    url?: string;
    cssText?: string;
    families: FontFamily[];
    label?: string;
}
type SystemCascadePreset = 'system-ui-sans' | 'system-ui-serif' | 'system-ui-mono';
type GenericFamily = 'sans-serif' | 'serif' | 'monospace' | 'cursive' | 'fantasy';
type FontStackVariable = '--font-display' | '--font-sans' | '--font-serif' | '--font-mono' | '--font-editorial';
type FontStackSlot = {
    kind: 'project';
    familyId: string;
} | {
    kind: 'system';
    preset: SystemCascadePreset;
} | {
    kind: 'generic';
    value: GenericFamily;
};
interface FontStack {
    variable: FontStackVariable;
    slots: FontStackSlot[];
}
/** On-disk shape of one `--gradient-N` library token. Structural mirror of the
 *  store's `GradientToken` (like `AliasDiskValue`'s inline gradient shape) so
 *  the file schema stays independent of store types. The rendered strings in
 *  `cssVariables` are a projection of these for production CSS; this field is
 *  the editable basis. */
interface GradientDiskToken {
    variable: string;
    type: 'linear' | 'radial' | 'solid' | 'none';
    angle: number;
    radius?: number;
    centerX?: number;
    aspectX?: number;
    aspectY?: number;
    stops: {
        position: number;
        color: string;
        opacity?: number;
    }[];
}
/**
 * Where a live component config resolved from: the unsaved `_working`
 * buffer, or the open theme's embedded copy. Every theme carries every
 * component complete, so `working` is the only genuine divergence —
 * anything else is what the open document itself resolves to.
 */
type LiveSource = 'working' | 'theme';
/**
 * Where a live colors-and-type read resolved from. Unlike `LiveSource`, this
 * keeps a third value: colors-and-type resolution is unchanged by the theme
 * completeness work, so `default` still answers the one case completeness
 * can't reach — the open theme's
 * file itself is unreadable (a stale pointer, or deleted mid-session), so
 * there is no document to resolve `working` or `theme` against.
 */
type ColorsAndTypeSource = 'working' | 'theme' | 'default';
interface ColorsAndType {
    name: string;
    createdAt: string;
    updatedAt: string;
    editorConfigs: Record<string, PaletteConfig>;
    cssVariables: Record<string, string>;
    fontSources?: FontSource[];
    fontStacks?: FontStack[];
    /** Absent on files saved before gradients round-tripped; the loader keeps
     *  the stock defaults then, which match what those files rendered. */
    gradients?: GradientDiskToken[];
    /** Four fixed harmony axes, each owning a hue with an optional bound family. */
    harmonyAxes?: HarmonyAxis[];
    /**
     * Server-attached marker naming the open theme — the document this content
     * belongs to, not a colors-and-type file. Set by `themeFileApi`'s GET
     * handlers; read by `themeInit` to seed `openThemeSlug`. Not persisted.
     */
    _fileName?: string;
    /** Server-attached marker: which live layer answered. See `ColorsAndTypeSource`. */
    _source?: ColorsAndTypeSource;
    /**
     * Migration stamp. Absent on legacy files, treated as 0; the loader runs
     * any registered theme migrations whose `fromVersion >= file.schemaVersion`.
     * Save paths stamp the current value so resaved files skip past
     * migrations.
     */
    schemaVersion?: number;
}
/** On-disk shape of a single alias entry. Plain strings carry the bulk of
 *  aliases (token refs like `--surface-canvas-low` or literal CSS like `4px`);
 *  the gradient object shape is the structured payload for component-owned
 *  gradients that can't compress to a single string. */
type AliasDiskValue = string | {
    kind: 'gradient';
    value: GradientValue;
};
interface ComponentConfig {
    name: string;
    component: string;
    createdAt: string;
    updatedAt: string;
    aliases: Record<string, AliasDiskValue>;
    config?: Record<string, unknown>;
    /**
     * Server-attached marker. Same role as `ColorsAndType._fileName`: the open
     * theme, not a config file. Set by the component-configs GET handlers.
     */
    _fileName?: string;
    /** Server-attached marker: which live layer answered — `working` the
     *  buffer, `theme` the open document's embedded copy. No third value:
     *  every theme carries every component, so there is no shipped-default
     *  layer left to report (unlike `ColorsAndTypeSource`). */
    _source?: LiveSource;
    /**
     * Migration stamp. Absent on legacy files, treated as 0. See `ColorsAndType.schemaVersion`.
     */
    schemaVersion?: number;
}

export type { AliasDiskValue as A, ColorsAndType as C, FontSource as F, GradientDiskToken as G, HarmonyAxis as H, Oklch as O, PaletteConfig as P, ComponentConfig as a, FontStack as b, FontStackVariable as c, HarmonyMode as d };
