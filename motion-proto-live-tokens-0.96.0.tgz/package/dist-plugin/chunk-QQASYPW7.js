// src/editor/core/themes/migrations/2026-04-24-legacy-keys-and-bg-to-canvas.ts
var LEGACY_KEY_RENAMES = {
  "--empty": "--page-bg",
  "--empty-attachment": "--page-bg-attachment",
  // Orphan exports dropped from tokens.css; no new home — silently discard.
  "--border-neutral": null,
  // Shadow cleanup: these five tokens were removed (low/zero consumers,
  // aesthetic drift). Dialog migrated onto --shadow-2xl; focus rings moved
  // to their own --ring-focus-* namespace, which themes don't carry by
  // default — tokens.css provides the canonical values.
  "--shadow-app": null,
  "--shadow-card": null,
  "--shadow-overlay": null,
  "--shadow-focus": null,
  "--shadow-glow-green": null
};
var BG_TO_CANVAS_PREFIXES = ["--color-bg-", "--surface-bg", "--border-bg", "--text-bg"];
function migrateBgToCanvas(rawVars) {
  for (const oldKey of Object.keys(rawVars)) {
    for (const prefix of BG_TO_CANVAS_PREFIXES) {
      if (!oldKey.startsWith(prefix)) continue;
      const suffix = oldKey.slice(prefix.length);
      if (suffix && !suffix.startsWith("-")) continue;
      const newKey = prefix.replace("-bg", "-canvas") + suffix;
      if (newKey === oldKey) continue;
      const value = rawVars[oldKey];
      delete rawVars[oldKey];
      if (!(newKey in rawVars)) rawVars[newKey] = value;
      break;
    }
  }
}
function migrateLegacyKeys(rawVars) {
  for (const [oldKey, newKey] of Object.entries(LEGACY_KEY_RENAMES)) {
    if (!(oldKey in rawVars)) continue;
    const value = rawVars[oldKey];
    delete rawVars[oldKey];
    if (newKey && !(newKey in rawVars)) rawVars[newKey] = value;
  }
  migrateBgToCanvas(rawVars);
}
var colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas = {
  id: "2026-04-24-legacy-keys-and-bg-to-canvas",
  fromVersion: 0,
  toVersion: 1,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = { ...rawVars };
    migrateLegacyKeys(out);
    return out;
  }
};

// src/editor/core/themes/migrations/2026-04-24-component-prefix-and-suffix-renames.ts
var COMPONENT_PREFIX_RENAMES = {
  "--segment-": "--segmentedcontrol-",
  "--collapsible-": "--collapsiblesection-",
  "--progress-": "--progressbar-",
  "--section-divider-": "--sectiondivider-",
  "--radio-": "--radiobutton-",
  "--inline-edit-": "--inlineeditactions-"
};
var COMPONENT_SUFFIX_RENAMES = {
  progressbar: [["-track-bg", "-track-surface"]],
  inlineeditactions: [
    ["-bg-hover", "-hover-surface"],
    ["-bg", "-surface"]
  ]
};
var componentMigration_2026_04_24_prefixAndSuffixRenames = {
  id: "2026-04-24-component-prefix-and-suffix-renames",
  fromVersion: 0,
  toVersion: 1,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const component = meta.component ?? "";
    const out = {};
    const suffixRules = COMPONENT_SUFFIX_RENAMES[component] ?? [];
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key === "--detail-nav-bg") key = "--detailnav-surface";
      for (const [oldPrefix, newPrefix] of Object.entries(COMPONENT_PREFIX_RENAMES)) {
        if (key.startsWith(oldPrefix)) {
          key = newPrefix + key.slice(oldPrefix.length);
          break;
        }
      }
      for (const [oldSuffix, newSuffix] of suffixRules) {
        if (key.endsWith(oldSuffix)) {
          key = key.slice(0, -oldSuffix.length) + newSuffix;
          break;
        }
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-04-27-segmentedcontrol-disabled-flatten.ts
var OPTION_DISABLED_PREFIX = "--segmentedcontrol-option-disabled-";
var DISABLED_PREFIX = "--segmentedcontrol-disabled-";
var SELECTED_DISABLED_PREFIX = "--segmentedcontrol-selected-disabled-";
var SELECTED_HOVER_PREFIX = "--segmentedcontrol-selected-hover-";
var componentMigration_2026_04_27_segmentedcontrolDisabledFlatten = {
  id: "2026-04-27-segmentedcontrol-disabled-flatten",
  fromVersion: 1,
  toVersion: 2,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key.startsWith(SELECTED_DISABLED_PREFIX)) continue;
      if (key.startsWith(SELECTED_HOVER_PREFIX)) continue;
      if (key.startsWith(OPTION_DISABLED_PREFIX)) {
        key = DISABLED_PREFIX + key.slice(OPTION_DISABLED_PREFIX.length);
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-08-collapsiblesection-variant-namespace.ts
var PREFIX = "--collapsiblesection-";
var STATE_NAMES = /* @__PURE__ */ new Set(["default", "hover", "active", "expanded"]);
var componentMigration_2026_05_08_collapsiblesectionVariantNamespace = {
  id: "2026-05-08-collapsiblesection-variant-namespace",
  fromVersion: 2,
  toVersion: 3,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "collapsiblesection") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key.startsWith(PREFIX)) {
        const tail = key.slice(PREFIX.length);
        const firstSegment = tail.split("-", 1)[0];
        if (STATE_NAMES.has(firstSegment)) {
          key = `${PREFIX}container-${tail}`;
        }
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-08-collapsiblesection-frame-and-cleanup.ts
var PFX = "--collapsiblesection-";
var componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup = {
  id: "2026-05-08-collapsiblesection-frame-and-cleanup",
  fromVersion: 3,
  toVersion: 4,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "collapsiblesection") return { ...rawVars };
    const out = {};
    for (const prop of ["surface", "border", "border-width", "radius"]) {
      const src = `${PFX}container-default-${prop}`;
      if (src in rawVars) {
        out[`${PFX}container-frame-${prop}`] = rawVars[src];
      }
    }
    for (const [key, value] of Object.entries(rawVars)) {
      if (/^--collapsiblesection-chromeless-(default|hover|active)-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-container-(hover|active)-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-container-default-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-divider-(default|hover|active)-radius$/.test(key)) continue;
      if (/^--collapsiblesection-(chromeless|divider|container)-expanded-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-(chromeless|divider)-expanded-surface$/.test(key)) continue;
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-10-sectiondivider-gradient-stops.ts
var PFX2 = "--sectiondivider-";
var VARIANTS = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
var OLD_STOP_RE = /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-gradient-stop-\d+$/;
var componentMigration_2026_05_10_sectiondividerGradientStops = {
  id: "2026-05-10-sectiondivider-gradient-stops",
  fromVersion: 4,
  toVersion: 5,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (OLD_STOP_RE.test(key)) continue;
      out[key] = value;
    }
    const setIfMissing = (key, fallback) => {
      if (!(key in out)) out[key] = fallback;
    };
    for (const v of VARIANTS) {
      const old1 = rawVars[`${PFX2}${v}-gradient-stop-1`];
      const old2 = rawVars[`${PFX2}${v}-gradient-stop-2`];
      const old4 = rawVars[`${PFX2}${v}-gradient-stop-4`];
      setIfMissing(`${PFX2}${v}-gradient-angle`, "--gradient-angle-diagonal");
      setIfMissing(`${PFX2}${v}-gradient-stop-1-color`, old1 ?? `--surface-${v}-highest`);
      setIfMissing(`${PFX2}${v}-gradient-stop-1-position`, "--gradient-stop-start");
      setIfMissing(`${PFX2}${v}-gradient-stop-2-color`, old2 ?? `--surface-${v}-higher`);
      setIfMissing(`${PFX2}${v}-gradient-stop-2-position`, "--gradient-stop-mid");
      setIfMissing(`${PFX2}${v}-gradient-stop-3-color`, old4 ?? `--surface-${v}`);
      setIfMissing(`${PFX2}${v}-gradient-stop-3-position`, "--gradient-stop-end");
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-13-primary-to-brand.ts
var PALETTE_STEPS = ["100", "200", "300", "400", "500", "600", "700", "800", "850", "900", "950"];
var SURFACE_SUFFIXES = ["lowest", "lower", "low", "high", "higher", "highest"];
var BORDER_SUFFIXES = ["faint", "subtle", "medium", "strong"];
var TEXT_SUFFIXES = ["secondary", "tertiary", "muted", "disabled"];
var RENAME_MAP = (() => {
  const m = {};
  for (const step of PALETTE_STEPS) m[`--color-primary-${step}`] = `--color-brand-${step}`;
  m["--surface-primary"] = "--surface-brand";
  for (const suf of SURFACE_SUFFIXES) m[`--surface-primary-${suf}`] = `--surface-brand-${suf}`;
  m["--border-primary"] = "--border-brand";
  for (const suf of BORDER_SUFFIXES) m[`--border-primary-${suf}`] = `--border-brand-${suf}`;
  m["--text-primary-color"] = "--text-brand";
  for (const suf of TEXT_SUFFIXES) m[`--text-primary-${suf}`] = `--text-brand-${suf}`;
  return m;
})();
function renameToken(name) {
  return RENAME_MAP[name] ?? name;
}
function renameKeys(rawVars) {
  const out = {};
  for (const [k, v] of Object.entries(rawVars)) {
    out[renameToken(k)] = v;
  }
  return out;
}
function renameKeysAndValues(rawVars) {
  const out = {};
  for (const [k, v] of Object.entries(rawVars)) {
    out[renameToken(k)] = renameToken(v);
  }
  return out;
}
var colorsAndTypeMigration_2026_05_13_primaryToBrand = {
  id: "2026-05-13-primary-to-brand-theme",
  fromVersion: 1,
  toVersion: 2,
  appliesTo: "colors-and-type",
  apply: renameKeys
};
var componentMigration_2026_05_13_primaryToBrand = {
  id: "2026-05-13-primary-to-brand-component",
  fromVersion: 5,
  toVersion: 6,
  appliesTo: "component-config",
  apply: renameKeysAndValues
};

// src/editor/core/themes/migrations/2026-05-19-collapsiblesection-drop-frame-surface.ts
function dropFrameSurface(rawVars, meta) {
  if (meta.component !== "collapsiblesection") return rawVars;
  const { "--collapsiblesection-container-frame-surface": _drop, ...rest } = rawVars;
  return rest;
}
var componentMigration_2026_05_19_collapsiblesectionDropFrameSurface = {
  id: "2026-05-19-collapsiblesection-drop-frame-surface",
  fromVersion: 6,
  toVersion: 7,
  appliesTo: "component-config",
  apply: dropFrameSurface
};

// src/editor/core/themes/migrations/2026-05-19-sectiondivider-rich-gradient.ts
var FLAT_RE = /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-gradient-(angle|stop-[123]-(color|position))$/;
var componentMigration_2026_05_19_sectiondividerRichGradient = {
  id: "2026-05-19-sectiondivider-rich-gradient",
  fromVersion: 7,
  toVersion: 8,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (FLAT_RE.test(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-20-sectiondivider-slim-variants.ts
var VARIANTS2 = ["lg", "md", "sm"];
var SUFFIX_RENAMES = [
  [/-title-border-width$/, "-title-outline-width"],
  [/-title-stroke-color$/, "-title-outline-color"],
  [
    /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-padding$/,
    "--sectiondivider-$1-spacing"
  ]
];
function renameKeySuffix(key) {
  for (const [re, repl] of SUFFIX_RENAMES) {
    if (re.test(key)) return key.replace(re, repl);
  }
  return key;
}
function splitFamilyKey(key) {
  const m = key.match(/^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-(.+)$/);
  if (!m) return null;
  return { family: m[1], suffix: m[2] };
}
var componentMigration_2026_05_20_sectiondividerSlimVariants = {
  id: "2026-05-20-sectiondivider-slim-variants",
  fromVersion: 8,
  toVersion: 9,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    const canvasValues = {};
    for (const [rawKey, value] of Object.entries(rawVars)) {
      const key = renameKeySuffix(rawKey);
      const parts = splitFamilyKey(key);
      if (!parts) {
        out[key] = value;
        continue;
      }
      if (parts.family !== "canvas") continue;
      canvasValues[parts.suffix] = value;
    }
    for (const suffix of Object.keys(canvasValues)) {
      for (const v of VARIANTS2) {
        out[`--sectiondivider-${v}-${suffix}`] = canvasValues[suffix];
      }
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-21-sectiondivider-spacing-to-padding.ts
var componentMigration_2026_05_21_sectiondividerSpacingToPadding = {
  id: "2026-05-21-sectiondivider-spacing-to-padding",
  fromVersion: 9,
  toVersion: 10,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const renamed = key.replace(
        /^--sectiondivider-(lg|md|sm)-spacing$/,
        "--sectiondivider-$1-padding"
      );
      out[renamed] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-22-sectiondivider-intrinsics-to-css.ts
var componentMigration_2026_05_22_sectiondividerIntrinsicsToCss = {
  id: "2026-05-22-sectiondivider-intrinsics-to-css",
  fromVersion: 10,
  toVersion: 11,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const VARIANTS4 = ["lg", "md", "sm"];
    const prefix = "--sectiondivider-";
    const dropped = /* @__PURE__ */ new Set();
    for (const v of VARIANTS4) {
      dropped.add(`${prefix}${v}-show-eyebrow`);
      dropped.add(`${prefix}${v}-show-description`);
      dropped.add(`${prefix}${v}-show-hairline`);
      dropped.add(`${prefix}${v}-hairline`);
      dropped.add(`${prefix}${v}-eyebrow-uppercase`);
    }
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (dropped.has(key)) continue;
      out[key] = value;
    }
    for (const v of VARIANTS4) {
      const showEyebrow = rawVars[`${prefix}${v}-show-eyebrow`];
      if (showEyebrow !== void 0) {
        out[`${prefix}${v}-eyebrow-display`] = showEyebrow === "1" ? "block" : "none";
      }
      const showDesc = rawVars[`${prefix}${v}-show-description`];
      if (showDesc !== void 0) {
        out[`${prefix}${v}-description-display`] = showDesc === "1" ? "flex" : "none";
      }
      const showHair = rawVars[`${prefix}${v}-show-hairline`];
      const oldHair = rawVars[`${prefix}${v}-hairline`];
      const oldHairIsPos = typeof oldHair === "string" && oldHair !== "" && oldHair !== "off";
      let newHair;
      if (showHair === "") newHair = "none";
      else if (showHair === "1") newHair = oldHairIsPos ? oldHair : "above-label";
      else if (oldHair !== void 0) newHair = oldHairIsPos ? oldHair : "none";
      if (newHair !== void 0) {
        out[`${prefix}${v}-hairline`] = newHair;
      }
      const upper = rawVars[`${prefix}${v}-eyebrow-uppercase`];
      if (upper !== void 0) {
        out[`${prefix}${v}-eyebrow-text-transform`] = upper === "1" ? "uppercase" : "none";
      }
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-segmentedcontrol-divider-inset.ts
var componentMigration_2026_05_24_segmentedcontrolDividerInset = {
  id: "2026-05-24-segmentedcontrol-divider-inset",
  fromVersion: 11,
  toVersion: 12,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === "--segmentedcontrol-divider-height") continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-promote-state-shared-tokens.ts
var BUTTON_VARIANTS = ["primary", "secondary", "outline", "success", "danger", "warning"];
var BUTTON_STATES = ["hover", "disabled"];
var BUTTON_PROPS = ["padding", "radius", "border-width"];
var buttonDeadKeys = new Set(
  BUTTON_VARIANTS.flatMap(
    (v) => BUTTON_STATES.flatMap(
      (s) => BUTTON_PROPS.map((p) => `--button-${v}-${s}-${p}`)
    )
  )
);
var segmentedcontrolDeadKeys = /* @__PURE__ */ new Set([
  "--segmentedcontrol-selected-icon-size",
  "--segmentedcontrol-option-hover-icon-size",
  "--segmentedcontrol-disabled-icon-size"
]);
var componentMigration_2026_05_24_promoteStateSharedTokens = {
  id: "2026-05-24-promote-state-shared-tokens",
  fromVersion: 12,
  toVersion: 13,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const dead = meta.component === "button" ? buttonDeadKeys : meta.component === "segmentedcontrol" ? segmentedcontrolDeadKeys : null;
    if (!dead) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (dead.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-progressbar-collapse-variants.ts
var PRIMARY_PREFIX = "--progressbar-primary-";
var NEW_PREFIX = "--progressbar-";
var DROP_PREFIXES = [
  "--progressbar-success-",
  "--progressbar-warning-",
  "--progressbar-danger-",
  "--progressbar-info-"
];
var componentMigration_2026_05_24_progressbarCollapseVariants = {
  id: "2026-05-24-progressbar-collapse-variants",
  fromVersion: 13,
  toVersion: 14,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "progressbar") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      if (DROP_PREFIXES.some((p) => oldKey.startsWith(p))) continue;
      const key = oldKey.startsWith(PRIMARY_PREFIX) ? NEW_PREFIX + oldKey.slice(PRIMARY_PREFIX.length) : oldKey;
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-collapsiblesection-drop-active-state.ts
function dropActiveState(rawVars, meta) {
  if (meta.component !== "collapsiblesection") return rawVars;
  const re = /^--collapsiblesection-(chromeless|divider|container)-active-/;
  const out = {};
  for (const [key, value] of Object.entries(rawVars)) {
    if (re.test(key)) continue;
    out[key] = value;
  }
  return out;
}
var componentMigration_2026_05_24_collapsiblesectionDropActiveState = {
  id: "2026-05-24-collapsiblesection-drop-active-state",
  fromVersion: 14,
  toVersion: 15,
  appliesTo: "component-config",
  apply: dropActiveState
};

// src/editor/core/themes/migrations/2026-05-25-cornerbadge-flatten-variants.ts
var VARIANTS3 = ["primary", "accent", "neutral", "alternate", "canvas", "special", "success", "warning", "danger", "info"];
var RE = new RegExp(`^--corner-badge-(${VARIANTS3.join("|")})-(.+)$`);
var CURRENT_COLOR_PROPS = /* @__PURE__ */ new Set(["surface", "border", "text"]);
function flattenVariants(rawVars, meta) {
  if (meta.component !== "cornerbadge") return rawVars;
  const out = {};
  const collected = /* @__PURE__ */ new Map();
  for (const [key, value] of Object.entries(rawVars)) {
    const m = key.match(RE);
    if (m) {
      const prop = m[2];
      if (CURRENT_COLOR_PROPS.has(prop)) {
        out[key] = value;
        continue;
      }
      if (!collected.has(prop)) collected.set(prop, value);
      continue;
    }
    out[key] = value;
  }
  for (const [prop, value] of collected) {
    const flatKey = `--corner-badge-${prop}`;
    if (!(flatKey in out)) out[flatKey] = value;
  }
  return out;
}
var componentMigration_2026_05_25_cornerbadgeFlattenVariants = {
  id: "2026-05-25-cornerbadge-flatten-variants",
  fromVersion: 15,
  toVersion: 16,
  appliesTo: "component-config",
  apply: flattenVariants
};

// src/editor/core/themes/migrations/2026-05-26-drop-overlay-extra-stops.ts
var DROPPED_TO_KEPT = {
  "--overlay-lowest": "--overlay-low",
  "--overlay-lower": "--overlay-low",
  "--overlay-higher": "--overlay-high",
  "--overlay-highest": "--overlay-high"
};
var colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops = {
  id: "2026-05-26-drop-overlay-extra-stops-theme",
  fromVersion: 2,
  toVersion: 3,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key in DROPPED_TO_KEPT) continue;
      out[key] = value;
    }
    return out;
  }
};
var componentMigration_2026_05_26_dropOverlayExtraStops = {
  id: "2026-05-26-drop-overlay-extra-stops-component",
  fromVersion: 16,
  toVersion: 17,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[key] = DROPPED_TO_KEPT[value] ?? value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-tabbar-indicator-thickness-to-per-state-width.ts
var TABBAR_STATES = ["default", "hover", "active", "disabled"];
var OLD_KEY = "--tabbar-bar-indicator-thickness";
var FALLBACK = "--border-width-2";
var componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth = {
  id: "2026-05-29-tabbar-indicator-thickness-to-per-state-width",
  fromVersion: 17,
  toVersion: 18,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "tabbar") return { ...rawVars };
    const seed = rawVars[OLD_KEY] ?? FALLBACK;
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === OLD_KEY) continue;
      out[key] = value;
    }
    for (const state of TABBAR_STATES) {
      const newKey = `--tabbar-${state}-indicator-border-width`;
      if (!(newKey in out)) out[newKey] = seed;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-segmentedcontrol-small-divider-rename.ts
var RENAMES = {
  "--segmentedcontrol-divider-small-thickness": "--segmentedcontrol-small-divider-thickness",
  "--segmentedcontrol-divider-small-inset": "--segmentedcontrol-small-divider-inset"
};
var componentMigration_2026_05_29_segmentedcontrolSmallDividerRename = {
  id: "2026-05-29-segmentedcontrol-small-divider-rename",
  fromVersion: 18,
  toVersion: 19,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMES[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-toggle-derive-track-from-thumb.ts
var componentMigration_2026_05_29_toggleDeriveTrackFromThumb = {
  id: "2026-05-29-toggle-derive-track-from-thumb",
  fromVersion: 19,
  toVersion: 20,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "toggle") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === "--toggle-track-width" || key === "--toggle-track-thickness") continue;
      out[key] = value;
    }
    if (!("--toggle-track-padding" in out)) {
      out["--toggle-track-padding"] = "--space-2";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-08-13-drop-legacy-shape-space-keys.ts
var DROPPED = /* @__PURE__ */ new Set([
  "--badge-trait-radius",
  "--badge-trait-padding",
  "--sectiondivider-padding",
  "--dialog-primary-default-radius",
  "--dialog-primary-default-padding",
  "--dialog-primary-hover-radius",
  "--dialog-primary-hover-padding",
  "--dialog-secondary-default-radius",
  "--dialog-secondary-default-padding",
  "--dialog-secondary-hover-radius",
  "--dialog-secondary-hover-padding"
]);
var colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys = {
  id: "2026-08-13-drop-legacy-shape-space-keys",
  fromVersion: 3,
  toVersion: 4,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-08-15-line-height-scale-rename.ts
var RENAMED = {
  "--line-height-xs": "--line-height-none",
  "--line-height-sm": "--line-height-tighter",
  "--line-height-md": "--line-height-normal",
  "--line-height-lg": "--line-height-relaxed",
  "--line-height-xl": "--line-height-relaxed"
};
var REFERENCE = /--line-height-(?:xs|sm|md|lg|xl)(?![\w-])/g;
function renameValues(rawVars) {
  const out = {};
  for (const [key, value] of Object.entries(rawVars)) {
    out[key] = typeof value === "string" ? value.replace(REFERENCE, (name) => RENAMED[name]) : value;
  }
  return out;
}
var colorsAndTypeMigration_2026_08_15_lineHeightScaleRename = {
  id: "2026-08-15-line-height-scale-rename-colors-and-type",
  fromVersion: 4,
  toVersion: 5,
  appliesTo: "colors-and-type",
  apply: renameValues
};
var componentMigration_2026_08_15_lineHeightScaleRename = {
  id: "2026-08-15-line-height-scale-rename-component",
  fromVersion: 20,
  toVersion: 21,
  appliesTo: "component-config",
  apply: renameValues
};

// src/editor/core/themes/migrations/2026-09-01-scrim-rename.ts
var RENAMED2 = {
  "--overlay-low": "--scrim-low",
  "--overlay": "--scrim",
  "--overlay-high": "--scrim-high"
};
var RENAMED_COMPONENT_KEYS = {
  "--dialog-overlay-surface": "--dialog-scrim-surface"
};
var colorsAndTypeMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename-theme",
  fromVersion: 5,
  toVersion: 6,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMED2[key] ?? key] = value;
    }
    return out;
  }
};
var componentMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename-component",
  fromVersion: 21,
  toVersion: 22,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMED_COMPONENT_KEYS[key] ?? key] = RENAMED2[value] ?? value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-tint-rename.ts
var RENAMED3 = {
  "--hover-low": "--tint-low",
  "--hover": "--tint",
  "--hover-high": "--tint-high"
};
var colorsAndTypeMigration_2026_09_01_tintRename = {
  id: "2026-09-01-tint-rename-theme",
  fromVersion: 6,
  toVersion: 7,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[RENAMED3[key] ?? key] = value;
    return out;
  }
};
var componentMigration_2026_09_01_tintRename = {
  id: "2026-09-01-tint-rename-component",
  fromVersion: 22,
  toVersion: 23,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[key] = RENAMED3[value] ?? value;
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-tabbar-active-tint.ts
var componentMigration_2026_09_01_tabbarActiveTint = {
  id: "2026-09-01-tabbar-active-tint",
  fromVersion: 23,
  toVersion: 24,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "tabbar") return { ...rawVars };
    const out = { ...rawVars };
    if (out["--tabbar-active-surface"] === "--scrim-low") {
      out["--tabbar-active-surface"] = "--tint-low";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-gate-suffix-enabled.ts
var RENAMED4 = {
  "--card-hover-border-active": "--card-hover-border-enabled",
  "--card-hover-shadow-active": "--card-hover-shadow-enabled",
  "--image-zoom-hover": "--image-zoom-enabled",
  "--image-grow-hover": "--image-grow-enabled"
};
var componentMigration_2026_09_01_gateSuffixEnabled = {
  id: "2026-09-01-gate-suffix-enabled",
  fromVersion: 24,
  toVersion: 25,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[RENAMED4[key] ?? key] = value;
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-02-sectiondivider-drop-title-outline.ts
var DROPPED2 = new Set(
  ["lg", "md", "sm"].flatMap((v) => [
    `--sectiondivider-${v}-title-outline-width`,
    `--sectiondivider-${v}-title-outline-color`
  ])
);
var componentMigration_2026_09_02_sectiondividerDropTitleOutline = {
  id: "2026-09-02-sectiondivider-drop-title-outline",
  fromVersion: 25,
  toVersion: 26,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED2.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-03-drop-legacy-component-keys.ts
var DROPPED3 = /* @__PURE__ */ new Set([
  "--badge-trait-surface",
  "--badge-trait-text",
  "--badge-trait-text-font-family",
  "--badge-trait-text-font-size",
  "--badge-trait-text-font-weight",
  "--badge-trait-text-line-height",
  "--badge-trait-border",
  "--badge-trait-border-width",
  "--badge-trait-shadow",
  "--sectiondivider-title",
  "--sectiondivider-title-font-family",
  "--sectiondivider-title-font-size",
  "--sectiondivider-title-font-weight",
  "--sectiondivider-title-line-height",
  "--sectiondivider-title-border-width",
  "--sectiondivider-title-stroke-color",
  "--sectiondivider-description",
  "--sectiondivider-description-font-family",
  "--sectiondivider-description-font-size",
  "--sectiondivider-description-font-weight",
  "--sectiondivider-description-line-height",
  "--dialog-primary-default-surface",
  "--dialog-primary-default-text",
  "--dialog-primary-default-border",
  "--dialog-primary-default-border-width",
  "--dialog-primary-hover-surface",
  "--dialog-primary-hover-text",
  "--dialog-primary-hover-border",
  "--dialog-primary-hover-border-width",
  "--dialog-secondary-default-text",
  "--dialog-secondary-default-border",
  "--dialog-secondary-default-border-width",
  "--dialog-secondary-hover-surface",
  "--dialog-secondary-hover-text",
  "--dialog-secondary-hover-border",
  "--dialog-secondary-hover-border-width"
]);
var colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys = {
  id: "2026-09-03-drop-legacy-component-keys",
  fromVersion: 7,
  toVersion: 8,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED3.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-07-stroke-role-renames.ts
var RENAMES2 = {
  tabbar: Object.fromEntries(
    ["default", "hover", "active", "disabled"].map((s) => [
      `--tabbar-${s}-indicator-border-width`,
      `--tabbar-${s}-indicator-width`
    ])
  ),
  collapsiblesection: Object.fromEntries(
    ["default", "hover"].flatMap((s) => [
      [`--collapsiblesection-divider-${s}-border`, `--collapsiblesection-divider-${s}-hairline-color`],
      [`--collapsiblesection-divider-${s}-border-width`, `--collapsiblesection-divider-${s}-hairline-thickness`]
    ])
  ),
  dialog: Object.fromEntries(
    ["header", "footer"].flatMap((part) => [
      [`--dialog-${part}-border`, `--dialog-${part}-divider`],
      [`--dialog-${part}-border-width`, `--dialog-${part}-divider-width`]
    ])
  ),
  table: {
    "--table-default-header-border": "--table-default-header-divider",
    "--table-default-header-border-width": "--table-default-header-divider-width"
  }
};
var componentMigration_2026_09_07_strokeRoleRenames = {
  id: "2026-09-07-stroke-role-renames",
  fromVersion: 26,
  toVersion: 27,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES2[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-selected-state.ts
var RADIOBUTTON_SUFFIXES = [
  "dot-border-color",
  "dot-border-width",
  "dot-fill",
  "dot-size",
  "label",
  "label-font-family",
  "label-font-size",
  "label-font-weight",
  "label-line-height"
];
var TABBAR_SUFFIXES = [
  "border",
  "icon-size",
  "indicator-width",
  "padding",
  "surface",
  "tab-border-color",
  "tab-border-width",
  "tab-bottom-radius",
  "tab-top-radius",
  "text",
  "text-font-family",
  "text-font-size",
  "text-font-weight",
  "text-line-height"
];
var SIDENAVIGATION_SUFFIXES = {
  title: [
    "accent",
    "accent-width",
    "border",
    "border-width",
    "label",
    "label-font-family",
    "label-font-size",
    "label-font-weight",
    "label-line-height",
    "padding",
    "surface"
  ],
  section: [
    "accent",
    "accent-width",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ],
  item: [
    "accent",
    "accent-width",
    "padding",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ],
  footer: [
    "accent",
    "accent-width",
    "gap",
    "icon",
    "icon-size",
    "padding",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ]
};
var RENAMES3 = {
  radiobutton: Object.fromEntries(
    RADIOBUTTON_SUFFIXES.map((s) => [`--radiobutton-active-${s}`, `--radiobutton-selected-${s}`])
  ),
  tabbar: Object.fromEntries(
    TABBAR_SUFFIXES.map((s) => [`--tabbar-active-${s}`, `--tabbar-selected-${s}`])
  ),
  sidenavigation: Object.fromEntries(
    Object.entries(SIDENAVIGATION_SUFFIXES).flatMap(
      ([part, suffixes]) => suffixes.map((s) => [
        `--sidenavigation-${part}-active-${s}`,
        `--sidenavigation-${part}-selected-${s}`
      ])
    )
  )
};
var componentMigration_2026_09_13_selectedState = {
  id: "2026-09-13-selected-state",
  fromVersion: 27,
  toVersion: 28,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES3[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-hairline.ts
var COLLAPSIBLESECTION_SUFFIXES = [
  "surface",
  "hairline-color",
  "padding",
  "label",
  "label-font-family",
  "label-font-size",
  "label-font-weight",
  "label-line-height",
  "icon",
  "icon-size"
];
var COLLAPSIBLESECTION_STATES = ["default", "hover"];
var RENAMES4 = {
  dialog: {
    "--dialog-header-divider": "--dialog-header-hairline-color",
    "--dialog-header-divider-width": "--dialog-header-hairline-width",
    "--dialog-footer-divider": "--dialog-footer-hairline-color",
    "--dialog-footer-divider-width": "--dialog-footer-hairline-width"
  },
  table: {
    "--table-default-header-divider": "--table-default-header-hairline-color",
    "--table-default-header-divider-width": "--table-default-header-hairline-width",
    "--table-default-row-divider": "--table-default-row-hairline-color",
    "--table-default-row-divider-width": "--table-default-row-hairline-width",
    "--table-default-column-divider": "--table-default-column-hairline-color",
    "--table-default-column-divider-width": "--table-default-column-hairline-width"
  },
  tabbar: {
    "--tabbar-bar-divider": "--tabbar-bar-hairline-color",
    "--tabbar-bar-divider-thickness": "--tabbar-bar-hairline-width"
  },
  segmentedcontrol: {
    "--segmentedcontrol-divider-color": "--segmentedcontrol-hairline-color",
    "--segmentedcontrol-divider-thickness": "--segmentedcontrol-hairline-width",
    "--segmentedcontrol-divider-inset": "--segmentedcontrol-hairline-inset",
    "--segmentedcontrol-small-divider-thickness": "--segmentedcontrol-small-hairline-width",
    "--segmentedcontrol-small-divider-inset": "--segmentedcontrol-small-hairline-inset"
  },
  collapsiblesection: {
    ...Object.fromEntries(
      COLLAPSIBLESECTION_STATES.flatMap((state) => [
        ...COLLAPSIBLESECTION_SUFFIXES.map((s) => [
          `--collapsiblesection-divider-${state}-${s}`,
          `--collapsiblesection-hairline-${state}-${s}`
        ]),
        [
          `--collapsiblesection-divider-${state}-hairline-thickness`,
          `--collapsiblesection-hairline-${state}-hairline-width`
        ]
      ])
    ),
    "--collapsiblesection-divider-expanded-padding": "--collapsiblesection-hairline-expanded-padding"
  },
  sectiondivider: {
    "--sectiondivider-lg-hairline-thickness": "--sectiondivider-lg-hairline-width",
    "--sectiondivider-md-hairline-thickness": "--sectiondivider-md-hairline-width",
    "--sectiondivider-sm-hairline-thickness": "--sectiondivider-sm-hairline-width"
  }
};
var componentMigration_2026_09_13_hairline = {
  id: "2026-09-13-hairline",
  fromVersion: 28,
  toVersion: 29,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES4[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-indicator.ts
var SIDENAVIGATION_PARTS = ["title", "section", "item", "footer"];
var SIDENAVIGATION_STATES = ["default", "hover", "selected"];
var CALLOUT_VARIANTS = ["info", "success", "warning", "danger"];
var RENAMES5 = {
  sidenavigation: Object.fromEntries(
    SIDENAVIGATION_PARTS.flatMap(
      (part) => SIDENAVIGATION_STATES.flatMap((state) => [
        [
          `--sidenavigation-${part}-${state}-accent`,
          `--sidenavigation-${part}-${state}-indicator`
        ],
        [
          `--sidenavigation-${part}-${state}-accent-width`,
          `--sidenavigation-${part}-${state}-indicator-width`
        ]
      ])
    )
  ),
  callout: Object.fromEntries(
    CALLOUT_VARIANTS.map((v) => [
      `--callout-${v}-accent-width`,
      `--callout-${v}-indicator-width`
    ])
  )
};
var componentMigration_2026_09_13_indicator = {
  id: "2026-09-13-indicator",
  fromVersion: 29,
  toVersion: 30,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES5[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-sectiondivider-surface.ts
var SECTIONDIVIDER_VARIANTS = ["lg", "md", "sm"];
var RENAMES6 = {
  sectiondivider: Object.fromEntries(
    SECTIONDIVIDER_VARIANTS.map((v) => [
      `--sectiondivider-${v}-background`,
      `--sectiondivider-${v}-surface`
    ])
  )
};
var componentMigration_2026_09_13_sectiondividerSurface = {
  id: "2026-09-13-sectiondivider-surface",
  fromVersion: 30,
  toVersion: 31,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES6[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-20-imagelightbox-scrim.ts
var RENAMES7 = {
  "--imagelightbox-overlay-surface": "--imagelightbox-scrim-surface"
};
var componentMigration_2026_09_20_imagelightboxScrim = {
  id: "2026-09-20-imagelightbox-scrim",
  fromVersion: 35,
  toVersion: 36,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "imagelightbox") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMES7[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-20-scrim-color-and-opacity.ts
var STOPS = {
  "--scrim-low": "--scrim-opacity-low",
  "--scrim": "--scrim-opacity",
  "--scrim-high": "--scrim-opacity-high"
};
var SURFACE = /^--(imagelightbox|dialog)-scrim-surface$/;
var componentMigration_2026_09_20_scrimColorAndOpacity = {
  id: "2026-09-20-scrim-color-and-opacity",
  fromVersion: 36,
  toVersion: 37,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const match = SURFACE.exec(key);
      if (!match) {
        out[key] = value;
        continue;
      }
      const stem = `--${match[1]}-scrim`;
      const stop = STOPS[value];
      out[`${stem}-color`] = stop ? "--scrim-color" : value;
      out[`${stem}-opacity`] = stop ?? "1";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-21-wash-color-and-opacity.ts
var FAMILIES = ["scrim", "tint"];
var COLOR_MIX_RE = /^color-mix\(in srgb,\s*var\((--[a-z0-9-]+)\)\s+(\d+(?:\.\d+)?)%,\s*transparent\)$/i;
var PLAIN_VAR_RE = /^var\((--[a-z0-9-]+)\)$/i;
function parseFill(raw) {
  const s = raw.trim();
  const mix = s.match(COLOR_MIX_RE);
  if (mix) return { color: mix[1], opacity: Math.min(100, Number(mix[2])) / 100 };
  const plain = s.match(PLAIN_VAR_RE);
  return plain ? { color: plain[1], opacity: 1 } : null;
}
var colorsAndTypeMigration_2026_09_21_washColorAndOpacity = {
  id: "2026-09-21-wash-color-and-opacity",
  fromVersion: 8,
  toVersion: 9,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = { ...rawVars };
    for (const family of FAMILIES) {
      let color = null;
      for (const suffix of ["", "-low", "-high"]) {
        const key = `--${family}${suffix}`;
        const parsed = out[key] === void 0 ? null : parseFill(out[key]);
        if (!parsed) continue;
        color ??= parsed.color;
        out[`--${family}-opacity${suffix}`] = String(parsed.opacity);
        delete out[key];
      }
      if (color) out[`--${family}-color`] = `var(${color})`;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-10-15-responsive-columns.ts
var RENAMES8 = {
  "--columns-gutter": "--columns-desktop-gutter",
  "--columns-margin": "--columns-desktop-margin"
};
var SHIPPED = {
  "--columns-count": ["12"],
  "--columns-gutter": ["32px"],
  "--columns-margin": ["0px", "0"]
};
var colorsAndTypeMigration_2026_10_15_responsiveColumns = {
  id: "2026-10-15-responsive-columns",
  fromVersion: 9,
  toVersion: 10,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    return Object.fromEntries(
      Object.entries(rawVars).filter(([name, value]) => !SHIPPED[name]?.includes(value.trim())).map(([name, value]) => [RENAMES8[name] ?? name, value])
    );
  }
};

// src/editor/core/themes/migrations/2026-09-21-scrim-surface.ts
var STOPS2 = {
  "--scrim-opacity-low": "--scrim-low",
  "--scrim-opacity": "--scrim",
  "--scrim-opacity-high": "--scrim-high"
};
var PAIR = /^--(imagelightbox|dialog)-scrim-(color|opacity)$/;
var ref = (value) => value.startsWith("--") ? `var(${value})` : value;
function fill(color, opacity) {
  if (color === "--scrim-color" && STOPS2[opacity]) return STOPS2[opacity];
  if (opacity === "1") return color;
  const pct = Number.isFinite(Number(opacity)) ? `${Number(opacity) * 100}%` : `calc(${ref(opacity)} * 100%)`;
  return `color-mix(in srgb, ${ref(color)} ${pct}, transparent)`;
}
var componentMigration_2026_09_21_scrimSurface = {
  id: "2026-09-21-scrim-surface",
  fromVersion: 37,
  toVersion: 38,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    const pairs = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const match = PAIR.exec(key);
      if (!match) {
        out[key] = value;
        continue;
      }
      (pairs[match[1]] ??= {})[match[2]] = value;
    }
    for (const [id, { color = "--scrim-color", opacity = "--scrim-opacity-high" }] of Object.entries(pairs)) {
      out[`--${id}-scrim-surface`] = fill(color, opacity);
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-cornerbadge-prefix.ts
var RENAMES9 = {
  cornerbadge: {
    "--corner-badge-margin": "--cornerbadge-margin",
    "--corner-badge-outer-radius": "--cornerbadge-outer-radius",
    "--corner-badge-inner-radius": "--cornerbadge-inner-radius",
    "--corner-badge-h-axis-radius": "--cornerbadge-h-axis-radius",
    "--corner-badge-v-axis-radius": "--cornerbadge-v-axis-radius",
    "--corner-badge-padding": "--cornerbadge-padding",
    "--corner-badge-text-font-family": "--cornerbadge-text-font-family",
    "--corner-badge-text-font-size": "--cornerbadge-text-font-size",
    "--corner-badge-text-font-weight": "--cornerbadge-text-font-weight",
    "--corner-badge-text-line-height": "--cornerbadge-text-line-height",
    "--corner-badge-primary-surface": "--cornerbadge-primary-surface",
    "--corner-badge-primary-border": "--cornerbadge-primary-border",
    "--corner-badge-primary-text": "--cornerbadge-primary-text",
    "--corner-badge-accent-surface": "--cornerbadge-accent-surface",
    "--corner-badge-accent-border": "--cornerbadge-accent-border",
    "--corner-badge-accent-text": "--cornerbadge-accent-text",
    "--corner-badge-neutral-surface": "--cornerbadge-neutral-surface",
    "--corner-badge-neutral-border": "--cornerbadge-neutral-border",
    "--corner-badge-neutral-text": "--cornerbadge-neutral-text",
    "--corner-badge-alternate-surface": "--cornerbadge-alternate-surface",
    "--corner-badge-alternate-border": "--cornerbadge-alternate-border",
    "--corner-badge-alternate-text": "--cornerbadge-alternate-text",
    "--corner-badge-canvas-surface": "--cornerbadge-canvas-surface",
    "--corner-badge-canvas-border": "--cornerbadge-canvas-border",
    "--corner-badge-canvas-text": "--cornerbadge-canvas-text",
    "--corner-badge-special-surface": "--cornerbadge-special-surface",
    "--corner-badge-special-border": "--cornerbadge-special-border",
    "--corner-badge-special-text": "--cornerbadge-special-text",
    "--corner-badge-success-surface": "--cornerbadge-success-surface",
    "--corner-badge-success-border": "--cornerbadge-success-border",
    "--corner-badge-success-text": "--cornerbadge-success-text",
    "--corner-badge-warning-surface": "--cornerbadge-warning-surface",
    "--corner-badge-warning-border": "--cornerbadge-warning-border",
    "--corner-badge-warning-text": "--cornerbadge-warning-text",
    "--corner-badge-danger-surface": "--cornerbadge-danger-surface",
    "--corner-badge-danger-border": "--cornerbadge-danger-border",
    "--corner-badge-danger-text": "--cornerbadge-danger-text",
    "--corner-badge-info-surface": "--cornerbadge-info-surface",
    "--corner-badge-info-border": "--cornerbadge-info-border",
    "--corner-badge-info-text": "--cornerbadge-info-text"
  }
};
var componentMigration_2026_09_13_cornerbadgePrefix = {
  id: "2026-09-13-cornerbadge-prefix",
  fromVersion: 31,
  toVersion: 32,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES9[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-toggle-label.ts
var RENAMES10 = {
  toggle: {
    "--toggle-label-text": "--toggle-label",
    "--toggle-disabled-label-text": "--toggle-disabled-label"
  }
};
var componentMigration_2026_09_13_toggleLabel = {
  id: "2026-09-13-toggle-label",
  fromVersion: 32,
  toVersion: 33,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES10[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-collapsiblesection-open.ts
var RENAMES11 = {
  collapsiblesection: {
    "--collapsiblesection-chromeless-expanded-padding": "--collapsiblesection-chromeless-open-padding",
    "--collapsiblesection-hairline-expanded-padding": "--collapsiblesection-hairline-open-padding",
    "--collapsiblesection-container-expanded-surface": "--collapsiblesection-container-open-surface",
    "--collapsiblesection-container-expanded-padding": "--collapsiblesection-container-open-padding"
  }
};
var componentMigration_2026_09_13_collapsiblesectionOpen = {
  id: "2026-09-13-collapsiblesection-open",
  fromVersion: 33,
  toVersion: 34,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES11[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-badge-brand.ts
var BADGE_SUFFIXES = [
  "surface",
  "text",
  "border",
  "text-font-family",
  "text-font-size",
  "text-font-weight",
  "text-line-height",
  "border-width",
  "radius",
  "padding",
  "shadow",
  "blur",
  "icon-size"
];
var CORNERBADGE_SUFFIXES = ["surface", "border", "text"];
var RENAMES12 = {
  badge: Object.fromEntries(
    BADGE_SUFFIXES.map((s) => [`--badge-primary-${s}`, `--badge-brand-${s}`])
  ),
  cornerbadge: Object.fromEntries(
    CORNERBADGE_SUFFIXES.map((s) => [`--cornerbadge-primary-${s}`, `--cornerbadge-brand-${s}`])
  )
};
var componentMigration_2026_09_13_badgeBrand = {
  id: "2026-09-13-badge-brand",
  fromVersion: 34,
  toVersion: 35,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES12[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/index.ts
var MIGRATIONS = [
  colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas,
  colorsAndTypeMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_04_24_prefixAndSuffixRenames,
  componentMigration_2026_04_27_segmentedcontrolDisabledFlatten,
  componentMigration_2026_05_08_collapsiblesectionVariantNamespace,
  componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup,
  componentMigration_2026_05_10_sectiondividerGradientStops,
  componentMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_05_19_collapsiblesectionDropFrameSurface,
  componentMigration_2026_05_19_sectiondividerRichGradient,
  componentMigration_2026_05_20_sectiondividerSlimVariants,
  componentMigration_2026_05_21_sectiondividerSpacingToPadding,
  componentMigration_2026_05_22_sectiondividerIntrinsicsToCss,
  componentMigration_2026_05_24_segmentedcontrolDividerInset,
  componentMigration_2026_05_24_promoteStateSharedTokens,
  componentMigration_2026_05_24_progressbarCollapseVariants,
  componentMigration_2026_05_24_collapsiblesectionDropActiveState,
  componentMigration_2026_05_25_cornerbadgeFlattenVariants,
  colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth,
  componentMigration_2026_05_29_segmentedcontrolSmallDividerRename,
  componentMigration_2026_05_29_toggleDeriveTrackFromThumb,
  colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys,
  colorsAndTypeMigration_2026_08_15_lineHeightScaleRename,
  componentMigration_2026_08_15_lineHeightScaleRename,
  colorsAndTypeMigration_2026_09_01_scrimRename,
  componentMigration_2026_09_01_scrimRename,
  colorsAndTypeMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tabbarActiveTint,
  componentMigration_2026_09_01_gateSuffixEnabled,
  componentMigration_2026_09_02_sectiondividerDropTitleOutline,
  colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys,
  componentMigration_2026_09_07_strokeRoleRenames,
  componentMigration_2026_09_13_selectedState,
  componentMigration_2026_09_13_hairline,
  componentMigration_2026_09_13_indicator,
  componentMigration_2026_09_13_sectiondividerSurface,
  componentMigration_2026_09_13_cornerbadgePrefix,
  componentMigration_2026_09_13_toggleLabel,
  componentMigration_2026_09_13_collapsiblesectionOpen,
  componentMigration_2026_09_13_badgeBrand,
  componentMigration_2026_09_20_imagelightboxScrim,
  componentMigration_2026_09_20_scrimColorAndOpacity,
  colorsAndTypeMigration_2026_09_21_washColorAndOpacity,
  componentMigration_2026_09_21_scrimSurface,
  colorsAndTypeMigration_2026_10_15_responsiveColumns
];
function countFor(kind) {
  return MIGRATIONS.filter((m) => m.appliesTo === kind).length;
}
var CURRENT_COLORS_AND_TYPE_SCHEMA_VERSION = countFor("colors-and-type");
var CURRENT_COMPONENT_SCHEMA_VERSION = countFor("component-config");
function runMigrations(kind, fileVersion, rawVars, meta = {}) {
  const applicable = MIGRATIONS.filter((m) => m.appliesTo === kind && m.fromVersion >= fileVersion).sort((a, b) => a.toVersion - b.toVersion);
  let out = { ...rawVars };
  for (const m of applicable) {
    out = m.apply(out, meta);
  }
  return out;
}

export {
  CURRENT_COMPONENT_SCHEMA_VERSION,
  runMigrations
};
