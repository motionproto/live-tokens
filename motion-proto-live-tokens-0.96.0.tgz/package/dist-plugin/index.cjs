"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// vite-plugin/index.ts
var index_exports = {};
__export(index_exports, {
  TOKENS_CSS_MIGRATIONS: () => TOKENS_CSS_MIGRATIONS,
  runTokensCssMigrations: () => runTokensCssMigrations,
  themeFileApi: () => themeFileApi,
  validateTokensCss: () => validateTokensCss
});
module.exports = __toCommonJS(index_exports);

// vite-plugin/themeFileApi.ts
var import_fs5 = __toESM(require("fs"), 1);
var import_crypto = require("crypto");
var import_path5 = __toESM(require("path"), 1);

// src/editor/core/themes/parsers/globalRootBlock.ts
function extractGlobalRootBody(source) {
  const re = /:global\(:root\)\s*\{([^}]*)\}/g;
  const bodies = [];
  let m;
  while ((m = re.exec(source)) !== null) {
    bodies.push(m[1]);
  }
  return bodies.join("\n");
}

// src/editor/core/themes/parsers/colorOpacity.ts
var COLOR_OPACITY_RE = /^color-mix\(in srgb,\s*var\((--[a-z0-9-]+)\)\s+(\d+)%,\s*transparent\)$/i;
function parseColorOpacity(value) {
  const m = value.trim().match(COLOR_OPACITY_RE);
  if (!m) return null;
  return { name: m[1], opacity: parseInt(m[2], 10) };
}
function formatColorOpacity(name, opacity) {
  return `color-mix(in srgb, var(${name}) ${opacity}%, transparent)`;
}

// src/editor/core/themes/parsers/gradient.ts
var LINEAR_DIRECTIONS = [
  "to top",
  "to top right",
  "to right",
  "to bottom right",
  "to bottom",
  "to bottom left",
  "to left",
  "to top left"
];
function parseDirection(raw) {
  const norm = raw.trim().toLowerCase().replace(/\s+/g, " ");
  return LINEAR_DIRECTIONS.includes(norm) ? norm : null;
}
var RADIAL_BASE_PX = 100;
function formatStopColor(s) {
  const opacity = s.opacity ?? 100;
  if (s.color.startsWith("--")) {
    return opacity >= 100 ? `var(${s.color})` : formatColorOpacity(s.color, opacity);
  }
  return opacity >= 100 ? s.color : `color-mix(in srgb, ${s.color} ${opacity}%, transparent)`;
}
function formatGradientStops(stops) {
  return stops.map((s) => `${formatStopColor(s)} ${s.position}%`).join(", ");
}
function formatRadialShape(v) {
  const ax = v.aspectX ?? 1;
  const ay = v.aspectY ?? 1;
  if (ax === 1 && ay === 1) {
    return v.radius && v.radius > 0 ? `circle ${v.radius}px` : "circle";
  }
  const base = v.radius && v.radius > 0 ? v.radius : RADIAL_BASE_PX;
  return `ellipse ${(base * ax).toFixed(2)}px ${(base * ay).toFixed(2)}px`;
}
function formatGradientValue(v) {
  if (v.type === "none") return "transparent";
  if (v.type === "solid") {
    const first = v.stops[0];
    return first ? formatStopColor(first) : "transparent";
  }
  const stops = formatGradientStops(v.stops);
  if (v.type === "linear") {
    return `linear-gradient(${v.direction ?? `${v.angle}deg`}, ${stops})`;
  }
  return `radial-gradient(${formatRadialShape(v)} at ${v.centerX ?? 50}% 50%, ${stops})`;
}
var NUM = String.raw`-?\d+(?:\.\d+)?`;
var HEADING = String.raw`${NUM}deg|to\s+\w+(?:\s+\w+)?`;
var LINEAR_RE = new RegExp(String.raw`^linear-gradient\(\s*(${HEADING})\s*,\s*(.+)\)$`, "i");
var DEG_RE = new RegExp(String.raw`^(${NUM})deg$`, "i");
var RADIAL_RE = new RegExp(
  String.raw`^radial-gradient\(\s*(circle|circle\s+${NUM}px|ellipse\s+${NUM}px\s+${NUM}px)\s+at\s+(${NUM})%\s+50%\s*,\s*(.+)\)$`,
  "i"
);
var STOP_RE = new RegExp(String.raw`^(.*?)\s+(${NUM})%$`);
var CIRCLE_RADIUS_RE = new RegExp(String.raw`^circle\s+(${NUM})px$`, "i");
var ELLIPSE_RE = new RegExp(String.raw`^ellipse\s+(${NUM})px\s+(${NUM})px$`, "i");
var VAR_RE = /^var\((--[a-z0-9-]+)\)$/i;
function splitTopLevel(s) {
  const parts = [];
  let depth = 0;
  let start = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === "(") depth++;
    else if (c === ")") depth--;
    else if (c === "," && depth === 0) {
      parts.push(s.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(s.slice(start));
  return parts;
}
function parseStop(raw) {
  const m = raw.trim().match(STOP_RE);
  if (!m) return null;
  const position = parseFloat(m[2]);
  const color = m[1].trim();
  const opacity = parseColorOpacity(color);
  if (opacity) return { position, color: opacity.name, opacity: opacity.opacity };
  const token = color.match(VAR_RE);
  return { position, color: token ? token[1] : color };
}
function parseStops(raw) {
  const stops = [];
  for (const part of splitTopLevel(raw)) {
    const stop = parseStop(part);
    if (!stop) return null;
    stops.push(stop);
  }
  return stops.length > 0 ? stops : null;
}
function parseRadialShape(raw) {
  const shape = raw.trim();
  if (/^circle$/i.test(shape)) return {};
  const circle = shape.match(CIRCLE_RADIUS_RE);
  if (circle) return { radius: parseFloat(circle[1]) };
  const ellipse = shape.match(ELLIPSE_RE);
  if (!ellipse) return null;
  const ax = parseFloat(ellipse[1]) / RADIAL_BASE_PX;
  const ay = parseFloat(ellipse[2]) / RADIAL_BASE_PX;
  return { ...ax === 1 ? {} : { aspectX: ax }, ...ay === 1 ? {} : { aspectY: ay } };
}
function parseGradientValue(value) {
  const css = value.trim();
  const linear = css.match(LINEAR_RE);
  if (linear) {
    const deg = linear[1].match(DEG_RE);
    const direction = deg ? null : parseDirection(linear[1]);
    if (!deg && !direction) return null;
    const stops2 = parseStops(linear[2]);
    if (!stops2) return null;
    return deg ? { type: "linear", angle: parseFloat(deg[1]), stops: stops2 } : { type: "linear", angle: 0, direction, stops: stops2 };
  }
  const radial = css.match(RADIAL_RE);
  if (!radial) return null;
  const shape = parseRadialShape(radial[1]);
  const stops = parseStops(radial[3]);
  if (!shape || !stops) return null;
  const centerX = parseFloat(radial[2]);
  return {
    type: "radial",
    angle: 0,
    ...shape,
    ...centerX === 50 ? {} : { centerX },
    stops
  };
}

// src/editor/core/storage/files/versionedFileResourceClient.ts
function sanitizeFileName(name) {
  return name.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^a-z0-9\-_]/g, "").replace(/-+/g, "-").replace(/^[-_]+|-+$/g, "") || "unnamed";
}

// src/system/internal/oklch.ts
function srgbToLinear(c) {
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}
function linearToSrgb(c) {
  return c <= 31308e-7 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
}
function hexToLinearRgb(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  return [srgbToLinear(r), srgbToLinear(g), srgbToLinear(b)];
}
function linearRgbToOklab(r, g, b) {
  const l_ = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b;
  const m_ = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b;
  const s_ = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b;
  const l = Math.cbrt(l_);
  const m = Math.cbrt(m_);
  const s = Math.cbrt(s_);
  return [
    0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s
  ];
}
function oklabToLinearRgb(L, a, b) {
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ * l_ * l_;
  const m = m_ * m_ * m_;
  const s = s_ * s_ * s_;
  return [
    4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s
  ];
}
function oklabToOklch(L, a, b) {
  const c = Math.sqrt(a * a + b * b);
  let h = Math.atan2(b, a) * 180 / Math.PI;
  if (h < 0) h += 360;
  return { l: L, c, h };
}
function oklchToOklab(l, c, h) {
  const hRad = h * Math.PI / 180;
  return [l, c * Math.cos(hRad), c * Math.sin(hRad)];
}
function hexToOklch(hex) {
  const [r, g, b] = hexToLinearRgb(hex);
  const [L, a, bVal] = linearRgbToOklab(r, g, b);
  return oklabToOklch(L, a, bVal);
}
function isInGamut(r, g, b) {
  const eps = 1e-4;
  return r >= -eps && r <= 1 + eps && g >= -eps && g <= 1 + eps && b >= -eps && b <= 1 + eps;
}
function gamutClamp(l, c, h) {
  if (l <= 0) return { l: 0, c: 0, h };
  if (l >= 1) return { l: 1, c: 0, h };
  const [L, a, b] = oklchToOklab(l, c, h);
  const [r, g, bVal] = oklabToLinearRgb(L, a, b);
  if (isInGamut(r, g, bVal)) return { l, c, h };
  let lo = 0;
  let hi = c;
  for (let i = 0; i < 20; i++) {
    const mid = (lo + hi) / 2;
    const [La, aa, ba] = oklchToOklab(l, mid, h);
    const [rr, gg, bb] = oklabToLinearRgb(La, aa, ba);
    if (isInGamut(rr, gg, bb)) {
      lo = mid;
    } else {
      hi = mid;
    }
  }
  return { l, c: lo, h };
}
function trim(value, decimals) {
  return Number(value.toFixed(decimals)).toString();
}
function oklchToCss(l, c, h) {
  const cs = trim(c, 4);
  return `oklch(${trim(l, 4)} ${cs} ${cs === "0" ? "0" : trim(h, 2)})`;
}
var OKLCH_RE = /^oklch\(\s*([\d.]+)(%?)\s+([\d.]+)(%?)\s+([\d.]+)(?:deg)?\s*\)$/i;
var HEX6_RE = /^#[0-9a-f]{6}$/i;
function parseOklchCss(value) {
  const m = OKLCH_RE.exec(value.trim());
  if (!m) return null;
  const l = Number.parseFloat(m[1]) / (m[2] === "%" ? 100 : 1);
  const c = Number.parseFloat(m[3]) * (m[4] === "%" ? 4e-3 : 1);
  return { l, c, h: Number.parseFloat(m[5]) };
}
function cssColorToOklch(value) {
  const raw = value.trim();
  if (HEX6_RE.test(raw)) return hexToOklch(raw);
  return parseOklchCss(raw);
}
function oklchToRgb255(l, c, h) {
  const clamped = gamutClamp(l, c, h);
  const [L, a, bVal] = oklchToOklab(clamped.l, clamped.c, clamped.h);
  const [r, g, b] = oklabToLinearRgb(L, a, bVal);
  const to255 = (channel2) => Math.round(Math.max(0, Math.min(1, linearToSrgb(channel2))) * 255);
  return { r: to255(r), g: to255(g), b: to255(b) };
}

// src/editor/ui/curveEngine.ts
function makeAnchor(x, y, tangentLen = 15) {
  return { x, y, inDx: -tangentLen, inDy: 0, outDx: tangentLen, outDy: 0 };
}
var HANDLE_SPAN = 1 / 3;
function tangentSlope(prev, x, y, next) {
  const hPrev = prev ? x - prev.x : 0;
  const hNext = next ? next.x - x : 0;
  const dPrev = hPrev > 0 ? (y - prev.y) / hPrev : null;
  const dNext = hNext > 0 ? (next.y - y) / hNext : null;
  if (dPrev === null) return dNext ?? 0;
  if (dNext === null) return dPrev;
  if (dPrev * dNext <= 0) return 0;
  const wPrev = 2 * hNext + hPrev;
  const wNext = hNext + 2 * hPrev;
  return (wPrev + wNext) / (wPrev / dPrev + wNext / dNext);
}
function tangentAnchor(x, y, prev, next) {
  const m = tangentSlope(prev, x, y, next);
  const inDx = prev ? -(x - prev.x) * HANDLE_SPAN : 0;
  const outDx = next ? (next.x - x) * HANDLE_SPAN : 0;
  return { x, y, inDx, inDy: m * inDx, outDx, outDy: m * outDx };
}
function isCornerAnchor(a) {
  return a.inDx === 0 && a.inDy === 0 && a.outDx === 0 && a.outDy === 0;
}
function resmoothAutoCurve(anchors) {
  if (anchors.length < 2) return anchors;
  return anchors.map(
    (a, i) => isCornerAnchor(a) ? a : tangentAnchor(a.x, a.y, anchors[i - 1] ?? null, anchors[i + 1] ?? null)
  );
}
function evalBezier(p0x, p0y, c0x, c0y, c1x, c1y, p1x, p1y, t) {
  const u = 1 - t, u2 = u * u, u3 = u2 * u;
  const t2 = t * t, t3 = t2 * t;
  return {
    x: u3 * p0x + 3 * u2 * t * c0x + 3 * u * t2 * c1x + t3 * p1x,
    y: u3 * p0y + 3 * u2 * t * c0y + 3 * u * t2 * c1y + t3 * p1y
  };
}
function sampleCurve(anchors, xPos) {
  if (anchors.length === 0) return 0;
  if (anchors.length === 1) return anchors[0].y;
  if (xPos <= anchors[0].x) return anchors[0].y;
  if (xPos >= anchors[anchors.length - 1].x) return anchors[anchors.length - 1].y;
  let seg = 0;
  while (seg < anchors.length - 2 && anchors[seg + 1].x < xPos) seg++;
  const a0 = anchors[seg], a1 = anchors[seg + 1];
  const p0x = a0.x, p0y = a0.y;
  const c0x = a0.x + a0.outDx, c0y = a0.y + a0.outDy;
  const c1x = a1.x + a1.inDx, c1y = a1.y + a1.inDy;
  const p1x = a1.x, p1y = a1.y;
  let lo = 0, hi = 1;
  for (let i = 0; i < 20; i++) {
    const mid = (lo + hi) / 2;
    const pt = evalBezier(p0x, p0y, c0x, c0y, c1x, c1y, p1x, p1y, mid);
    if (pt.x < xPos) lo = mid;
    else hi = mid;
  }
  return evalBezier(p0x, p0y, c0x, c0y, c1x, c1y, p1x, p1y, (lo + hi) / 2).y;
}

// src/editor/core/palettes/paletteDerivation.ts
var PALETTE_SPECS = [
  { label: "Brand", cssNamespace: "brand", initialColor: { l: 0.5573, c: 0.1841, h: 25.49 } },
  { label: "Accent", cssNamespace: "accent", initialColor: { l: 0.7674, c: 0.164, h: 70.44 } },
  { label: "Special", cssNamespace: "special", initialColor: { l: 0.6056, c: 0.2189, h: 292.72 } },
  { label: "Canvas", cssNamespace: "canvas", emptySelector: true, initialColor: { l: 0.2284, c: 0.0384, h: 282.93 } },
  { label: "Neutral", cssNamespace: "neutral", neutral: true, initialColor: { l: 0.5679, c: 0.0134, h: 240.07 } },
  { label: "Alternate", cssNamespace: "alternate", neutral: true, displayLabel: "Alternate (neutral)", initialColor: { l: 0.5873, c: 87e-4, h: 48.57 } },
  { label: "Info", cssNamespace: "info", initialColor: { l: 0.5871, c: 0.1855, h: 259.56 } },
  { label: "Success", cssNamespace: "success", initialColor: { l: 0.7198, c: 0.1918, h: 149.52 } },
  { label: "Warning", cssNamespace: "warning", initialColor: { l: 0.6704, c: 0.1716, h: 48.75 } },
  { label: "Danger", cssNamespace: "danger", initialColor: { l: 0.6103, c: 0.2165, h: 18.1 } }
];
var PALETTE_STEPS = [
  { label: "100" },
  { label: "200" },
  { label: "300" },
  { label: "400" },
  { label: "500" },
  { label: "600" },
  { label: "700" },
  { label: "800" },
  { label: "850" },
  { label: "900" },
  { label: "950" }
];
var SCALES = [
  {
    title: "Surfaces",
    isText: false,
    steps: [
      { name: "lowest", position: -1 },
      { name: "lower", position: -2 / 3 },
      { name: "low", position: -1 / 3 },
      { name: "default", position: 0 },
      { name: "high", position: 1 / 3 },
      { name: "higher", position: 2 / 3 },
      { name: "highest", position: 1 }
    ]
  },
  {
    title: "Borders",
    isText: false,
    steps: [
      { name: "faint", position: -1 },
      { name: "subtle", position: -0.5 },
      { name: "default", position: 0 },
      { name: "medium", position: 0.5 },
      { name: "strong", position: 1 }
    ]
  },
  {
    title: "Text",
    isText: true,
    steps: [
      { name: "primary", position: 0 },
      { name: "secondary", position: 0 },
      { name: "tertiary", position: 0 },
      { name: "muted", position: 0 },
      { name: "disabled", position: 0 }
    ]
  }
];
var BW_GUARD_MIN_L = 0.17;
var BW_GUARD_MAX_L = 0.93;
var autoCurve = (...anchors) => resmoothAutoCurve(anchors);
var DEFAULT_PALETTE_LIGHTNESS = () => autoCurve(makeAnchor(0, 95), makeAnchor(100, 8));
var DEFAULT_PALETTE_SATURATION = () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100));
var wrapHue = (h) => (h % 360 + 360) % 360;
function scaleCurveDefaults(scheme = "dark") {
  if (scheme === "light") {
    return {
      Surfaces: {
        lightness: () => autoCurve(makeAnchor(0, 98), makeAnchor(100, 82)),
        saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
      },
      Borders: {
        lightness: () => autoCurve(makeAnchor(0, 92), makeAnchor(100, 45)),
        saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
      },
      Text: {
        lightness: () => autoCurve(makeAnchor(0, 30), makeAnchor(100, 120)),
        saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 15))
      }
    };
  }
  return {
    Surfaces: {
      lightness: () => autoCurve(makeAnchor(0, 15), makeAnchor(100, 47)),
      saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
    },
    Borders: {
      lightness: () => autoCurve(makeAnchor(0, 25), makeAnchor(100, 80)),
      saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
    },
    Text: {
      lightness: () => autoCurve(makeAnchor(0, 120), makeAnchor(100, 55)),
      saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 15))
    }
  };
}
var defaultScaleCurves = scaleCurveDefaults("dark");
function paletteStepKey(label) {
  return `Palette-${label}`;
}
function stepKey(scaleTitle, stepName) {
  return `${scaleTitle}-${stepName}`;
}
function stepIndexToX(index) {
  return index / (PALETTE_STEPS.length - 1) * 100;
}
function scaleStepToX(step, scale) {
  const idx = scale.steps.indexOf(step);
  return scale.steps.length > 1 ? idx / (scale.steps.length - 1) * 100 : 50;
}
function serializeDerivedValue(value) {
  return value.kind === "raw" ? value.css : oklchToCss(value.l, value.c, value.h);
}
function computePaletteOklch(index, base, lightnessCurve, saturationCurve, curveOffset, hueCurve) {
  const { c: baseC } = base;
  const xPos = stepIndexToX(index);
  const targetL = Math.max(0, Math.min(100, sampleCurve(lightnessCurve, xPos) + (curveOffset.lightness ?? 0))) / 100;
  const satMul = Math.max(0, Math.min(2, (sampleCurve(saturationCurve, xPos) + (curveOffset.saturation ?? 0)) / 100));
  const targetC = baseC * satMul;
  const hueDelta = (hueCurve ? sampleCurve(hueCurve, xPos) : 0) + (curveOffset.hue ?? 0);
  const h = hueDelta === 0 ? base.h : wrapHue(base.h + hueDelta);
  return gamutClamp(targetL, targetC, h);
}
function nearestPaletteStep(lightnessCurve, baseL) {
  let best = 0;
  let bestD = Infinity;
  for (let i = 0; i < PALETTE_STEPS.length; i++) {
    const d = Math.abs(sampleCurve(lightnessCurve, stepIndexToX(i)) - baseL * 100);
    if (d < bestD) {
      bestD = d;
      best = i;
    }
  }
  return best;
}
function setCurveAnchor(curve, x, y, smooth = false) {
  if (smooth && curve.length === 2) {
    const [p0, p2] = curve;
    const mid = { x, y, inDx: 0, inDy: 0, outDx: 0, outDy: 0 };
    if (Math.abs(p0.x - x) < 0.5) {
      return {
        curve: [tangentAnchor(x, y, null, p2), tangentAnchor(p2.x, p2.y, mid, null)],
        displacedY: p0.y,
        priorEndpoints: [p0, p2]
      };
    }
    if (Math.abs(p2.x - x) < 0.5) {
      return {
        curve: [tangentAnchor(p0.x, p0.y, null, mid), tangentAnchor(x, y, p0, null)],
        displacedY: p2.y,
        priorEndpoints: [p0, p2]
      };
    }
    return {
      curve: [
        tangentAnchor(p0.x, p0.y, null, mid),
        tangentAnchor(x, y, p0, p2),
        tangentAnchor(p2.x, p2.y, mid, null)
      ],
      priorEndpoints: [p0, p2]
    };
  }
  const existing = curve.findIndex((a) => Math.abs(a.x - x) < 0.5);
  if (existing >= 0) {
    const displacedY = curve[existing].y;
    return { curve: curve.map((a, i) => i === existing ? { ...a, x, y } : a), displacedY };
  }
  let insertAt = curve.findIndex((a) => a.x > x);
  if (insertAt < 0) insertAt = curve.length;
  const prev = curve[insertAt - 1] ?? null;
  const next = curve[insertAt] ?? null;
  const out = [...curve];
  if (prev && next) {
    const span = next.x - prev.x;
    out[insertAt - 1] = scaleOutHandle(prev, (x - prev.x) / span);
    out[insertAt] = scaleInHandle(next, (next.x - x) / span);
  }
  out.splice(insertAt, 0, fitBetween(tangentAnchor(x, y, prev, next), out[insertAt - 1] ?? null, out[insertAt] ?? null));
  return { curve: out };
}
var scaleOutHandle = (a, k) => ({ ...a, outDx: a.outDx * k, outDy: a.outDy * k });
var scaleInHandle = (a, k) => ({ ...a, inDx: a.inDx * k, inDy: a.inDy * k });
function fitBetween(a, prev, next) {
  let out = a;
  if (prev) {
    const room = a.x - (prev.x + prev.outDx);
    if (room < -out.inDx) out = scaleInHandle(out, room <= 0 ? 0 : room / -out.inDx);
  }
  if (next) {
    const room = next.x + next.inDx - a.x;
    if (room < out.outDx) out = scaleOutHandle(out, room <= 0 ? 0 : room / out.outDx);
  }
  return out;
}
function liftCurveAnchor(curve, x, displacedY, priorEndpoints) {
  if (priorEndpoints) return priorEndpoints;
  const idx = curve.findIndex((a) => Math.abs(a.x - x) < 0.5);
  if (idx < 0) return curve;
  if (displacedY !== void 0) return curve.map((a, i) => i === idx ? { ...a, y: displacedY } : a);
  if (idx === 0 || idx === curve.length - 1) return curve;
  const out = curve.filter((_, i) => i !== idx);
  const prev = curve[idx - 1];
  const next = curve[idx + 1];
  if (prev && next) {
    const span = next.x - prev.x;
    out[idx - 1] = scaleOutHandle(prev, span / (curve[idx].x - prev.x));
    out[idx] = scaleInHandle(next, span / (next.x - curve[idx].x));
  }
  return out;
}
function syncBaseAnchor(cfg) {
  if (cfg.anchorToBase === false) return;
  const prev = cfg.anchorPlacement;
  const fresh = prev === void 0;
  let lCurve = cfg.lightnessCurve;
  let sCurve = cfg.saturationCurve;
  let hCurve = cfg.hueCurve;
  if (prev) {
    const prevX = stepIndexToX(prev.step);
    lCurve = liftCurveAnchor(lCurve, prevX, prev.displacedL);
    sCurve = liftCurveAnchor(sCurve, prevX, prev.displacedS);
    if (hCurve) hCurve = liftCurveAnchor(hCurve, prevX, prev.displacedH);
  }
  const step = nearestPaletteStep(lCurve, cfg.baseColor.l);
  const x = stepIndexToX(step);
  const l = setCurveAnchor(lCurve, x, cfg.baseColor.l * 100, fresh);
  const s = setCurveAnchor(sCurve, x, 100, fresh);
  cfg.lightnessCurve = l.curve;
  cfg.saturationCurve = s.curve;
  const h = hCurve ? setCurveAnchor(hCurve, x, 0, fresh) : void 0;
  if (h) cfg.hueCurve = h.curve;
  cfg.anchorPlacement = {
    step,
    displacedL: l.displacedY,
    displacedS: s.displacedY,
    displacedH: h?.displacedY,
    priorLightnessEndpoints: prev?.priorLightnessEndpoints ?? l.priorEndpoints,
    priorSaturationEndpoints: prev?.priorSaturationEndpoints ?? s.priorEndpoints,
    // No else-branch reading `prev?.priorHueEndpoints`: that could only fire
    // if a placed hue curve later went absent, which RJC 7 (reset never
    // deletes) never lets happen.
    priorHueEndpoints: h ? prev?.priorHueEndpoints ?? h.priorEndpoints : void 0
  };
}
function computeDerivedOklch(step, base, scaleTitle, scaleCurves, curveOffset) {
  const scale = SCALES.find((s) => s.title === scaleTitle);
  const xPos = scaleStepToX(step, scale);
  const defs = defaultScaleCurves[scaleTitle];
  const lCurve = scaleCurves[scaleTitle]?.lightness ?? defs.lightness();
  const sCurve = scaleCurves[scaleTitle]?.saturation ?? defs.saturation();
  const hCurve = scaleCurves[scaleTitle]?.hue;
  const lOff = curveOffset[`${scaleTitle}-lightness`] ?? 0;
  const sOff = curveOffset[`${scaleTitle}-saturation`] ?? 0;
  const hOff = curveOffset[`${scaleTitle}-hue`] ?? 0;
  const { l: baseL, c: baseC, h: baseH } = base;
  let targetL;
  if (scale.isText) {
    const lMul = Math.max(0, Math.min(2, (sampleCurve(lCurve, xPos) + lOff) / 100));
    targetL = Math.max(0, Math.min(1, baseL * lMul));
  } else {
    targetL = Math.max(0, Math.min(100, sampleCurve(lCurve, xPos) + lOff)) / 100;
  }
  const satMul = Math.max(0, Math.min(2, (sampleCurve(sCurve, xPos) + sOff) / 100));
  const targetC = baseC * satMul;
  const hueDelta = (hCurve ? sampleCurve(hCurve, xPos) : 0) + hOff;
  const targetH = hueDelta === 0 ? baseH : wrapHue(baseH + hueDelta);
  return gamutClamp(targetL, targetC, targetH);
}
function scaleToCssVar(scaleTitle, stepName, cssNamespace) {
  if (cssNamespace === null) return null;
  if (scaleTitle === "Surfaces") {
    const suffix = stepName === "default" ? "" : `-${stepName}`;
    return cssNamespace === "neutral" ? `--surface-neutral${suffix}` : `--surface-${cssNamespace}${suffix}`;
  }
  if (scaleTitle === "Borders") {
    const suffix = stepName === "default" ? "" : `-${stepName}`;
    return cssNamespace === "neutral" ? `--border-neutral${suffix}` : `--border-${cssNamespace}${suffix}`;
  }
  if (scaleTitle === "Text") {
    if (cssNamespace === "neutral") return `--text-${stepName}`;
    return stepName === "primary" ? `--text-${cssNamespace}` : `--text-${cssNamespace}-${stepName}`;
  }
  return null;
}
function derivePaletteValues(spec, config) {
  const out = {};
  if (!config) return out;
  const baseColor = config.baseColor ?? spec.initialColor;
  const overrides = config.overrides ?? {};
  const curveOffset = config.curveOffset ?? {};
  const scaleCurves = config.scaleCurves ?? {};
  const lightnessCurve = config.lightnessCurve ?? DEFAULT_PALETTE_LIGHTNESS();
  const saturationCurve = config.saturationCurve ?? DEFAULT_PALETTE_SATURATION();
  PALETTE_STEPS.forEach((ps, index) => {
    const k = paletteStepKey(ps.label);
    const value = k in overrides ? { kind: "color", ...overrides[k] } : { kind: "color", ...computePaletteOklch(index, baseColor, lightnessCurve, saturationCurve, curveOffset, config.hueCurve) };
    out[`--color-${spec.cssNamespace}-${ps.label}`] = value;
  });
  for (const scale of SCALES) {
    for (const step of scale.steps) {
      const k = stepKey(scale.title, step.name);
      const value = k in overrides ? { kind: "color", ...overrides[k] } : { kind: "color", ...computeDerivedOklch(step, baseColor, scale.title, scaleCurves, curveOffset) };
      const varName = scaleToCssVar(scale.title, step.name, spec.cssNamespace);
      if (varName) out[varName] = value;
    }
  }
  const textPrimary = out["--text-primary"];
  if (textPrimary?.kind === "color") {
    const mirroredL = Math.max(BW_GUARD_MIN_L, Math.min(BW_GUARD_MAX_L, 1 - textPrimary.l));
    out["--text-inverted"] = { kind: "color", ...gamutClamp(mirroredL, textPrimary.c, textPrimary.h) };
  }
  if (spec.emptySelector) {
    const emptyMode = config.emptyMode ?? "solid";
    const gradientStyle = config.gradientStyle ?? "linear";
    const gradientAngle = config.gradientAngle ?? 180;
    const gradientReverse = config.gradientReverse ?? false;
    const gradientSize = config.gradientSize ?? "page";
    const gradientStops = config.gradientStops ?? [
      { position: 0, paletteLabel: "800" },
      { position: 100, paletteLabel: "950" }
    ];
    if (emptyMode === "solid") {
      out["--page-bg"] = { kind: "color", ...baseColor };
      out["--page-bg-attachment"] = { kind: "raw", css: "scroll" };
    } else {
      const sortedStops = [...gradientStops].sort(
        (a, b) => gradientReverse ? b.position - a.position : a.position - b.position
      );
      const stopsCss = sortedStops.map((s) => {
        const stopValue = out[`--color-${spec.cssNamespace}-${s.paletteLabel}`];
        const css = stopValue ? serializeDerivedValue(stopValue) : "oklch(0 0 0)";
        return `${css} ${s.position}%`;
      }).join(", ");
      let gradient;
      switch (gradientStyle) {
        case "radial":
          gradient = `radial-gradient(circle, ${stopsCss})`;
          break;
        case "conic":
          gradient = `conic-gradient(from ${gradientAngle}deg, ${stopsCss})`;
          break;
        default:
          gradient = `linear-gradient(${gradientAngle}deg, ${stopsCss})`;
      }
      out["--page-bg"] = { kind: "raw", css: gradient };
      out["--page-bg-attachment"] = { kind: "raw", css: gradientSize === "window" ? "fixed" : "scroll" };
    }
  }
  return out;
}
function palettesToValues(palettes) {
  const out = {};
  for (const spec of PALETTE_SPECS) {
    Object.assign(out, derivePaletteValues(spec, palettes[spec.label]));
  }
  return out;
}
function palettesToVars(palettes) {
  const out = {};
  for (const [k, v] of Object.entries(palettesToValues(palettes))) {
    out[k] = serializeDerivedValue(v);
  }
  return out;
}
function reconcilePalettesFromCssVars(palettes, cssVars) {
  const next = structuredClone(palettes);
  const consumed = /* @__PURE__ */ new Set();
  const snapped = /* @__PURE__ */ new Set();
  for (const spec of PALETTE_SPECS) {
    const current = next[spec.label];
    if (current === void 0) continue;
    if (current._imported === true) {
      const anchor = cssVars[`--color-${spec.cssNamespace}-500`];
      const anchorOklch = anchor ? cssColorToOklch(anchor) : null;
      if (anchorOklch) {
        next[spec.label] = { ...current, baseColor: anchorOklch, _imported: false };
        syncBaseAnchor(next[spec.label]);
        snapped.add(spec.label);
      } else {
        next[spec.label] = { ...current, _imported: false };
      }
    }
    for (const k of Object.keys(derivePaletteValues(spec, next[spec.label]))) {
      consumed.add(k);
    }
  }
  return { palettes: next, consumed, snapped };
}

// src/editor/core/themes/migrations/2026-07-21-palette-oklch-basis.ts
var round = (v, dp) => {
  const f = 10 ** dp;
  return Math.round(v * f) / f;
};
function toStoredOklch(value) {
  if (typeof value !== "string") return value;
  const { l, c, h } = hexToOklch(value);
  return { l: round(l, 4), c: round(c, 4), h: round(h, 2) };
}
function migratePaletteColorsToOklch(editorConfigs) {
  const out = {};
  for (const [label, cfg] of Object.entries(editorConfigs)) {
    const overrides = {};
    for (const [k, v] of Object.entries(cfg.overrides ?? {})) overrides[k] = toStoredOklch(v);
    out[label] = { ...cfg, baseColor: toStoredOklch(cfg.baseColor), overrides };
  }
  return out;
}

// src/editor/core/themes/migrations/2026-04-24-legacy-keys-and-bg-to-canvas.ts
var LEGACY_KEY_RENAMES = {
  "--empty": "--page-bg",
  "--empty-attachment": "--page-bg-attachment",
  // Orphan exports dropped from tokens.css; no new home — silently discard.
  "--border-neutral": null,
  // Shadow cleanup: these five tokens were removed (low/zero consumers,
  // aesthetic drift). Dialog migrated onto --shadow-2xl; focus rings moved
  // to their own --ring-focus-* namespace, which themes don't carry by
  // default — tokens.css provides the canonical values.
  "--shadow-app": null,
  "--shadow-card": null,
  "--shadow-overlay": null,
  "--shadow-focus": null,
  "--shadow-glow-green": null
};
var BG_TO_CANVAS_PREFIXES = ["--color-bg-", "--surface-bg", "--border-bg", "--text-bg"];
function migrateBgToCanvas(rawVars) {
  for (const oldKey of Object.keys(rawVars)) {
    for (const prefix of BG_TO_CANVAS_PREFIXES) {
      if (!oldKey.startsWith(prefix)) continue;
      const suffix = oldKey.slice(prefix.length);
      if (suffix && !suffix.startsWith("-")) continue;
      const newKey = prefix.replace("-bg", "-canvas") + suffix;
      if (newKey === oldKey) continue;
      const value = rawVars[oldKey];
      delete rawVars[oldKey];
      if (!(newKey in rawVars)) rawVars[newKey] = value;
      break;
    }
  }
}
function migrateLegacyKeys(rawVars) {
  for (const [oldKey, newKey] of Object.entries(LEGACY_KEY_RENAMES)) {
    if (!(oldKey in rawVars)) continue;
    const value = rawVars[oldKey];
    delete rawVars[oldKey];
    if (newKey && !(newKey in rawVars)) rawVars[newKey] = value;
  }
  migrateBgToCanvas(rawVars);
}
var colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas = {
  id: "2026-04-24-legacy-keys-and-bg-to-canvas",
  fromVersion: 0,
  toVersion: 1,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = { ...rawVars };
    migrateLegacyKeys(out);
    return out;
  }
};

// src/editor/core/themes/migrations/2026-04-24-component-prefix-and-suffix-renames.ts
var COMPONENT_PREFIX_RENAMES = {
  "--segment-": "--segmentedcontrol-",
  "--collapsible-": "--collapsiblesection-",
  "--progress-": "--progressbar-",
  "--section-divider-": "--sectiondivider-",
  "--radio-": "--radiobutton-",
  "--inline-edit-": "--inlineeditactions-"
};
var COMPONENT_SUFFIX_RENAMES = {
  progressbar: [["-track-bg", "-track-surface"]],
  inlineeditactions: [
    ["-bg-hover", "-hover-surface"],
    ["-bg", "-surface"]
  ]
};
var componentMigration_2026_04_24_prefixAndSuffixRenames = {
  id: "2026-04-24-component-prefix-and-suffix-renames",
  fromVersion: 0,
  toVersion: 1,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const component = meta.component ?? "";
    const out = {};
    const suffixRules = COMPONENT_SUFFIX_RENAMES[component] ?? [];
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key === "--detail-nav-bg") key = "--detailnav-surface";
      for (const [oldPrefix, newPrefix] of Object.entries(COMPONENT_PREFIX_RENAMES)) {
        if (key.startsWith(oldPrefix)) {
          key = newPrefix + key.slice(oldPrefix.length);
          break;
        }
      }
      for (const [oldSuffix, newSuffix] of suffixRules) {
        if (key.endsWith(oldSuffix)) {
          key = key.slice(0, -oldSuffix.length) + newSuffix;
          break;
        }
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-04-27-segmentedcontrol-disabled-flatten.ts
var OPTION_DISABLED_PREFIX = "--segmentedcontrol-option-disabled-";
var DISABLED_PREFIX = "--segmentedcontrol-disabled-";
var SELECTED_DISABLED_PREFIX = "--segmentedcontrol-selected-disabled-";
var SELECTED_HOVER_PREFIX = "--segmentedcontrol-selected-hover-";
var componentMigration_2026_04_27_segmentedcontrolDisabledFlatten = {
  id: "2026-04-27-segmentedcontrol-disabled-flatten",
  fromVersion: 1,
  toVersion: 2,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key.startsWith(SELECTED_DISABLED_PREFIX)) continue;
      if (key.startsWith(SELECTED_HOVER_PREFIX)) continue;
      if (key.startsWith(OPTION_DISABLED_PREFIX)) {
        key = DISABLED_PREFIX + key.slice(OPTION_DISABLED_PREFIX.length);
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-08-collapsiblesection-variant-namespace.ts
var PREFIX = "--collapsiblesection-";
var STATE_NAMES = /* @__PURE__ */ new Set(["default", "hover", "active", "expanded"]);
var componentMigration_2026_05_08_collapsiblesectionVariantNamespace = {
  id: "2026-05-08-collapsiblesection-variant-namespace",
  fromVersion: 2,
  toVersion: 3,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "collapsiblesection") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key.startsWith(PREFIX)) {
        const tail = key.slice(PREFIX.length);
        const firstSegment = tail.split("-", 1)[0];
        if (STATE_NAMES.has(firstSegment)) {
          key = `${PREFIX}container-${tail}`;
        }
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-08-collapsiblesection-frame-and-cleanup.ts
var PFX = "--collapsiblesection-";
var componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup = {
  id: "2026-05-08-collapsiblesection-frame-and-cleanup",
  fromVersion: 3,
  toVersion: 4,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "collapsiblesection") return { ...rawVars };
    const out = {};
    for (const prop of ["surface", "border", "border-width", "radius"]) {
      const src = `${PFX}container-default-${prop}`;
      if (src in rawVars) {
        out[`${PFX}container-frame-${prop}`] = rawVars[src];
      }
    }
    for (const [key, value] of Object.entries(rawVars)) {
      if (/^--collapsiblesection-chromeless-(default|hover|active)-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-container-(hover|active)-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-container-default-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-divider-(default|hover|active)-radius$/.test(key)) continue;
      if (/^--collapsiblesection-(chromeless|divider|container)-expanded-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-(chromeless|divider)-expanded-surface$/.test(key)) continue;
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-10-sectiondivider-gradient-stops.ts
var PFX2 = "--sectiondivider-";
var VARIANTS = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
var OLD_STOP_RE = /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-gradient-stop-\d+$/;
var componentMigration_2026_05_10_sectiondividerGradientStops = {
  id: "2026-05-10-sectiondivider-gradient-stops",
  fromVersion: 4,
  toVersion: 5,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (OLD_STOP_RE.test(key)) continue;
      out[key] = value;
    }
    const setIfMissing = (key, fallback) => {
      if (!(key in out)) out[key] = fallback;
    };
    for (const v of VARIANTS) {
      const old1 = rawVars[`${PFX2}${v}-gradient-stop-1`];
      const old2 = rawVars[`${PFX2}${v}-gradient-stop-2`];
      const old4 = rawVars[`${PFX2}${v}-gradient-stop-4`];
      setIfMissing(`${PFX2}${v}-gradient-angle`, "--gradient-angle-diagonal");
      setIfMissing(`${PFX2}${v}-gradient-stop-1-color`, old1 ?? `--surface-${v}-highest`);
      setIfMissing(`${PFX2}${v}-gradient-stop-1-position`, "--gradient-stop-start");
      setIfMissing(`${PFX2}${v}-gradient-stop-2-color`, old2 ?? `--surface-${v}-higher`);
      setIfMissing(`${PFX2}${v}-gradient-stop-2-position`, "--gradient-stop-mid");
      setIfMissing(`${PFX2}${v}-gradient-stop-3-color`, old4 ?? `--surface-${v}`);
      setIfMissing(`${PFX2}${v}-gradient-stop-3-position`, "--gradient-stop-end");
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-13-primary-to-brand.ts
var PALETTE_STEPS2 = ["100", "200", "300", "400", "500", "600", "700", "800", "850", "900", "950"];
var SURFACE_SUFFIXES = ["lowest", "lower", "low", "high", "higher", "highest"];
var BORDER_SUFFIXES = ["faint", "subtle", "medium", "strong"];
var TEXT_SUFFIXES = ["secondary", "tertiary", "muted", "disabled"];
var RENAME_MAP = (() => {
  const m = {};
  for (const step of PALETTE_STEPS2) m[`--color-primary-${step}`] = `--color-brand-${step}`;
  m["--surface-primary"] = "--surface-brand";
  for (const suf of SURFACE_SUFFIXES) m[`--surface-primary-${suf}`] = `--surface-brand-${suf}`;
  m["--border-primary"] = "--border-brand";
  for (const suf of BORDER_SUFFIXES) m[`--border-primary-${suf}`] = `--border-brand-${suf}`;
  m["--text-primary-color"] = "--text-brand";
  for (const suf of TEXT_SUFFIXES) m[`--text-primary-${suf}`] = `--text-brand-${suf}`;
  return m;
})();
function renameToken(name) {
  return RENAME_MAP[name] ?? name;
}
function renameKeys(rawVars) {
  const out = {};
  for (const [k, v] of Object.entries(rawVars)) {
    out[renameToken(k)] = v;
  }
  return out;
}
function renameKeysAndValues(rawVars) {
  const out = {};
  for (const [k, v] of Object.entries(rawVars)) {
    out[renameToken(k)] = renameToken(v);
  }
  return out;
}
var colorsAndTypeMigration_2026_05_13_primaryToBrand = {
  id: "2026-05-13-primary-to-brand-theme",
  fromVersion: 1,
  toVersion: 2,
  appliesTo: "colors-and-type",
  apply: renameKeys
};
var componentMigration_2026_05_13_primaryToBrand = {
  id: "2026-05-13-primary-to-brand-component",
  fromVersion: 5,
  toVersion: 6,
  appliesTo: "component-config",
  apply: renameKeysAndValues
};

// src/editor/core/themes/migrations/2026-05-19-collapsiblesection-drop-frame-surface.ts
function dropFrameSurface(rawVars, meta) {
  if (meta.component !== "collapsiblesection") return rawVars;
  const { "--collapsiblesection-container-frame-surface": _drop, ...rest } = rawVars;
  return rest;
}
var componentMigration_2026_05_19_collapsiblesectionDropFrameSurface = {
  id: "2026-05-19-collapsiblesection-drop-frame-surface",
  fromVersion: 6,
  toVersion: 7,
  appliesTo: "component-config",
  apply: dropFrameSurface
};

// src/editor/core/themes/migrations/2026-05-19-sectiondivider-rich-gradient.ts
var FLAT_RE = /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-gradient-(angle|stop-[123]-(color|position))$/;
var componentMigration_2026_05_19_sectiondividerRichGradient = {
  id: "2026-05-19-sectiondivider-rich-gradient",
  fromVersion: 7,
  toVersion: 8,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (FLAT_RE.test(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-20-sectiondivider-slim-variants.ts
var VARIANTS2 = ["lg", "md", "sm"];
var SUFFIX_RENAMES = [
  [/-title-border-width$/, "-title-outline-width"],
  [/-title-stroke-color$/, "-title-outline-color"],
  [
    /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-padding$/,
    "--sectiondivider-$1-spacing"
  ]
];
function renameKeySuffix(key) {
  for (const [re, repl] of SUFFIX_RENAMES) {
    if (re.test(key)) return key.replace(re, repl);
  }
  return key;
}
function splitFamilyKey(key) {
  const m = key.match(/^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-(.+)$/);
  if (!m) return null;
  return { family: m[1], suffix: m[2] };
}
var componentMigration_2026_05_20_sectiondividerSlimVariants = {
  id: "2026-05-20-sectiondivider-slim-variants",
  fromVersion: 8,
  toVersion: 9,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    const canvasValues = {};
    for (const [rawKey, value] of Object.entries(rawVars)) {
      const key = renameKeySuffix(rawKey);
      const parts = splitFamilyKey(key);
      if (!parts) {
        out[key] = value;
        continue;
      }
      if (parts.family !== "canvas") continue;
      canvasValues[parts.suffix] = value;
    }
    for (const suffix of Object.keys(canvasValues)) {
      for (const v of VARIANTS2) {
        out[`--sectiondivider-${v}-${suffix}`] = canvasValues[suffix];
      }
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-21-sectiondivider-spacing-to-padding.ts
var componentMigration_2026_05_21_sectiondividerSpacingToPadding = {
  id: "2026-05-21-sectiondivider-spacing-to-padding",
  fromVersion: 9,
  toVersion: 10,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const renamed = key.replace(
        /^--sectiondivider-(lg|md|sm)-spacing$/,
        "--sectiondivider-$1-padding"
      );
      out[renamed] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-22-sectiondivider-intrinsics-to-css.ts
var componentMigration_2026_05_22_sectiondividerIntrinsicsToCss = {
  id: "2026-05-22-sectiondivider-intrinsics-to-css",
  fromVersion: 10,
  toVersion: 11,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const VARIANTS4 = ["lg", "md", "sm"];
    const prefix = "--sectiondivider-";
    const dropped = /* @__PURE__ */ new Set();
    for (const v of VARIANTS4) {
      dropped.add(`${prefix}${v}-show-eyebrow`);
      dropped.add(`${prefix}${v}-show-description`);
      dropped.add(`${prefix}${v}-show-hairline`);
      dropped.add(`${prefix}${v}-hairline`);
      dropped.add(`${prefix}${v}-eyebrow-uppercase`);
    }
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (dropped.has(key)) continue;
      out[key] = value;
    }
    for (const v of VARIANTS4) {
      const showEyebrow = rawVars[`${prefix}${v}-show-eyebrow`];
      if (showEyebrow !== void 0) {
        out[`${prefix}${v}-eyebrow-display`] = showEyebrow === "1" ? "block" : "none";
      }
      const showDesc = rawVars[`${prefix}${v}-show-description`];
      if (showDesc !== void 0) {
        out[`${prefix}${v}-description-display`] = showDesc === "1" ? "flex" : "none";
      }
      const showHair = rawVars[`${prefix}${v}-show-hairline`];
      const oldHair = rawVars[`${prefix}${v}-hairline`];
      const oldHairIsPos = typeof oldHair === "string" && oldHair !== "" && oldHair !== "off";
      let newHair;
      if (showHair === "") newHair = "none";
      else if (showHair === "1") newHair = oldHairIsPos ? oldHair : "above-label";
      else if (oldHair !== void 0) newHair = oldHairIsPos ? oldHair : "none";
      if (newHair !== void 0) {
        out[`${prefix}${v}-hairline`] = newHair;
      }
      const upper = rawVars[`${prefix}${v}-eyebrow-uppercase`];
      if (upper !== void 0) {
        out[`${prefix}${v}-eyebrow-text-transform`] = upper === "1" ? "uppercase" : "none";
      }
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-segmentedcontrol-divider-inset.ts
var componentMigration_2026_05_24_segmentedcontrolDividerInset = {
  id: "2026-05-24-segmentedcontrol-divider-inset",
  fromVersion: 11,
  toVersion: 12,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === "--segmentedcontrol-divider-height") continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-promote-state-shared-tokens.ts
var BUTTON_VARIANTS = ["primary", "secondary", "outline", "success", "danger", "warning"];
var BUTTON_STATES = ["hover", "disabled"];
var BUTTON_PROPS = ["padding", "radius", "border-width"];
var buttonDeadKeys = new Set(
  BUTTON_VARIANTS.flatMap(
    (v) => BUTTON_STATES.flatMap(
      (s) => BUTTON_PROPS.map((p) => `--button-${v}-${s}-${p}`)
    )
  )
);
var segmentedcontrolDeadKeys = /* @__PURE__ */ new Set([
  "--segmentedcontrol-selected-icon-size",
  "--segmentedcontrol-option-hover-icon-size",
  "--segmentedcontrol-disabled-icon-size"
]);
var componentMigration_2026_05_24_promoteStateSharedTokens = {
  id: "2026-05-24-promote-state-shared-tokens",
  fromVersion: 12,
  toVersion: 13,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const dead = meta.component === "button" ? buttonDeadKeys : meta.component === "segmentedcontrol" ? segmentedcontrolDeadKeys : null;
    if (!dead) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (dead.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-progressbar-collapse-variants.ts
var PRIMARY_PREFIX = "--progressbar-primary-";
var NEW_PREFIX = "--progressbar-";
var DROP_PREFIXES = [
  "--progressbar-success-",
  "--progressbar-warning-",
  "--progressbar-danger-",
  "--progressbar-info-"
];
var componentMigration_2026_05_24_progressbarCollapseVariants = {
  id: "2026-05-24-progressbar-collapse-variants",
  fromVersion: 13,
  toVersion: 14,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "progressbar") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      if (DROP_PREFIXES.some((p) => oldKey.startsWith(p))) continue;
      const key = oldKey.startsWith(PRIMARY_PREFIX) ? NEW_PREFIX + oldKey.slice(PRIMARY_PREFIX.length) : oldKey;
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-collapsiblesection-drop-active-state.ts
function dropActiveState(rawVars, meta) {
  if (meta.component !== "collapsiblesection") return rawVars;
  const re = /^--collapsiblesection-(chromeless|divider|container)-active-/;
  const out = {};
  for (const [key, value] of Object.entries(rawVars)) {
    if (re.test(key)) continue;
    out[key] = value;
  }
  return out;
}
var componentMigration_2026_05_24_collapsiblesectionDropActiveState = {
  id: "2026-05-24-collapsiblesection-drop-active-state",
  fromVersion: 14,
  toVersion: 15,
  appliesTo: "component-config",
  apply: dropActiveState
};

// src/editor/core/themes/migrations/2026-05-25-cornerbadge-flatten-variants.ts
var VARIANTS3 = ["primary", "accent", "neutral", "alternate", "canvas", "special", "success", "warning", "danger", "info"];
var RE = new RegExp(`^--corner-badge-(${VARIANTS3.join("|")})-(.+)$`);
var CURRENT_COLOR_PROPS = /* @__PURE__ */ new Set(["surface", "border", "text"]);
function flattenVariants(rawVars, meta) {
  if (meta.component !== "cornerbadge") return rawVars;
  const out = {};
  const collected = /* @__PURE__ */ new Map();
  for (const [key, value] of Object.entries(rawVars)) {
    const m = key.match(RE);
    if (m) {
      const prop = m[2];
      if (CURRENT_COLOR_PROPS.has(prop)) {
        out[key] = value;
        continue;
      }
      if (!collected.has(prop)) collected.set(prop, value);
      continue;
    }
    out[key] = value;
  }
  for (const [prop, value] of collected) {
    const flatKey = `--corner-badge-${prop}`;
    if (!(flatKey in out)) out[flatKey] = value;
  }
  return out;
}
var componentMigration_2026_05_25_cornerbadgeFlattenVariants = {
  id: "2026-05-25-cornerbadge-flatten-variants",
  fromVersion: 15,
  toVersion: 16,
  appliesTo: "component-config",
  apply: flattenVariants
};

// src/editor/core/themes/migrations/2026-05-26-drop-overlay-extra-stops.ts
var DROPPED_TO_KEPT = {
  "--overlay-lowest": "--overlay-low",
  "--overlay-lower": "--overlay-low",
  "--overlay-higher": "--overlay-high",
  "--overlay-highest": "--overlay-high"
};
var colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops = {
  id: "2026-05-26-drop-overlay-extra-stops-theme",
  fromVersion: 2,
  toVersion: 3,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key in DROPPED_TO_KEPT) continue;
      out[key] = value;
    }
    return out;
  }
};
var componentMigration_2026_05_26_dropOverlayExtraStops = {
  id: "2026-05-26-drop-overlay-extra-stops-component",
  fromVersion: 16,
  toVersion: 17,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[key] = DROPPED_TO_KEPT[value] ?? value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-tabbar-indicator-thickness-to-per-state-width.ts
var TABBAR_STATES = ["default", "hover", "active", "disabled"];
var OLD_KEY = "--tabbar-bar-indicator-thickness";
var FALLBACK = "--border-width-2";
var componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth = {
  id: "2026-05-29-tabbar-indicator-thickness-to-per-state-width",
  fromVersion: 17,
  toVersion: 18,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "tabbar") return { ...rawVars };
    const seed = rawVars[OLD_KEY] ?? FALLBACK;
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === OLD_KEY) continue;
      out[key] = value;
    }
    for (const state of TABBAR_STATES) {
      const newKey = `--tabbar-${state}-indicator-border-width`;
      if (!(newKey in out)) out[newKey] = seed;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-segmentedcontrol-small-divider-rename.ts
var RENAMES = {
  "--segmentedcontrol-divider-small-thickness": "--segmentedcontrol-small-divider-thickness",
  "--segmentedcontrol-divider-small-inset": "--segmentedcontrol-small-divider-inset"
};
var componentMigration_2026_05_29_segmentedcontrolSmallDividerRename = {
  id: "2026-05-29-segmentedcontrol-small-divider-rename",
  fromVersion: 18,
  toVersion: 19,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMES[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-toggle-derive-track-from-thumb.ts
var componentMigration_2026_05_29_toggleDeriveTrackFromThumb = {
  id: "2026-05-29-toggle-derive-track-from-thumb",
  fromVersion: 19,
  toVersion: 20,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "toggle") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === "--toggle-track-width" || key === "--toggle-track-thickness") continue;
      out[key] = value;
    }
    if (!("--toggle-track-padding" in out)) {
      out["--toggle-track-padding"] = "--space-2";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-08-13-drop-legacy-shape-space-keys.ts
var DROPPED = /* @__PURE__ */ new Set([
  "--badge-trait-radius",
  "--badge-trait-padding",
  "--sectiondivider-padding",
  "--dialog-primary-default-radius",
  "--dialog-primary-default-padding",
  "--dialog-primary-hover-radius",
  "--dialog-primary-hover-padding",
  "--dialog-secondary-default-radius",
  "--dialog-secondary-default-padding",
  "--dialog-secondary-hover-radius",
  "--dialog-secondary-hover-padding"
]);
var colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys = {
  id: "2026-08-13-drop-legacy-shape-space-keys",
  fromVersion: 3,
  toVersion: 4,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-08-15-line-height-scale-rename.ts
var RENAMED = {
  "--line-height-xs": "--line-height-none",
  "--line-height-sm": "--line-height-tighter",
  "--line-height-md": "--line-height-normal",
  "--line-height-lg": "--line-height-relaxed",
  "--line-height-xl": "--line-height-relaxed"
};
var REFERENCE = /--line-height-(?:xs|sm|md|lg|xl)(?![\w-])/g;
function renameValues(rawVars) {
  const out = {};
  for (const [key, value] of Object.entries(rawVars)) {
    out[key] = typeof value === "string" ? value.replace(REFERENCE, (name) => RENAMED[name]) : value;
  }
  return out;
}
var colorsAndTypeMigration_2026_08_15_lineHeightScaleRename = {
  id: "2026-08-15-line-height-scale-rename-colors-and-type",
  fromVersion: 4,
  toVersion: 5,
  appliesTo: "colors-and-type",
  apply: renameValues
};
var componentMigration_2026_08_15_lineHeightScaleRename = {
  id: "2026-08-15-line-height-scale-rename-component",
  fromVersion: 20,
  toVersion: 21,
  appliesTo: "component-config",
  apply: renameValues
};

// src/editor/core/themes/migrations/2026-09-01-scrim-rename.ts
var RENAMED2 = {
  "--overlay-low": "--scrim-low",
  "--overlay": "--scrim",
  "--overlay-high": "--scrim-high"
};
var RENAMED_COMPONENT_KEYS = {
  "--dialog-overlay-surface": "--dialog-scrim-surface"
};
var colorsAndTypeMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename-theme",
  fromVersion: 5,
  toVersion: 6,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMED2[key] ?? key] = value;
    }
    return out;
  }
};
var componentMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename-component",
  fromVersion: 21,
  toVersion: 22,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMED_COMPONENT_KEYS[key] ?? key] = RENAMED2[value] ?? value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-tint-rename.ts
var RENAMED3 = {
  "--hover-low": "--tint-low",
  "--hover": "--tint",
  "--hover-high": "--tint-high"
};
var colorsAndTypeMigration_2026_09_01_tintRename = {
  id: "2026-09-01-tint-rename-theme",
  fromVersion: 6,
  toVersion: 7,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[RENAMED3[key] ?? key] = value;
    return out;
  }
};
var componentMigration_2026_09_01_tintRename = {
  id: "2026-09-01-tint-rename-component",
  fromVersion: 22,
  toVersion: 23,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[key] = RENAMED3[value] ?? value;
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-tabbar-active-tint.ts
var componentMigration_2026_09_01_tabbarActiveTint = {
  id: "2026-09-01-tabbar-active-tint",
  fromVersion: 23,
  toVersion: 24,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "tabbar") return { ...rawVars };
    const out = { ...rawVars };
    if (out["--tabbar-active-surface"] === "--scrim-low") {
      out["--tabbar-active-surface"] = "--tint-low";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-gate-suffix-enabled.ts
var RENAMED4 = {
  "--card-hover-border-active": "--card-hover-border-enabled",
  "--card-hover-shadow-active": "--card-hover-shadow-enabled",
  "--image-zoom-hover": "--image-zoom-enabled",
  "--image-grow-hover": "--image-grow-enabled"
};
var componentMigration_2026_09_01_gateSuffixEnabled = {
  id: "2026-09-01-gate-suffix-enabled",
  fromVersion: 24,
  toVersion: 25,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[RENAMED4[key] ?? key] = value;
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-02-sectiondivider-drop-title-outline.ts
var DROPPED2 = new Set(
  ["lg", "md", "sm"].flatMap((v) => [
    `--sectiondivider-${v}-title-outline-width`,
    `--sectiondivider-${v}-title-outline-color`
  ])
);
var componentMigration_2026_09_02_sectiondividerDropTitleOutline = {
  id: "2026-09-02-sectiondivider-drop-title-outline",
  fromVersion: 25,
  toVersion: 26,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED2.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-03-drop-legacy-component-keys.ts
var DROPPED3 = /* @__PURE__ */ new Set([
  "--badge-trait-surface",
  "--badge-trait-text",
  "--badge-trait-text-font-family",
  "--badge-trait-text-font-size",
  "--badge-trait-text-font-weight",
  "--badge-trait-text-line-height",
  "--badge-trait-border",
  "--badge-trait-border-width",
  "--badge-trait-shadow",
  "--sectiondivider-title",
  "--sectiondivider-title-font-family",
  "--sectiondivider-title-font-size",
  "--sectiondivider-title-font-weight",
  "--sectiondivider-title-line-height",
  "--sectiondivider-title-border-width",
  "--sectiondivider-title-stroke-color",
  "--sectiondivider-description",
  "--sectiondivider-description-font-family",
  "--sectiondivider-description-font-size",
  "--sectiondivider-description-font-weight",
  "--sectiondivider-description-line-height",
  "--dialog-primary-default-surface",
  "--dialog-primary-default-text",
  "--dialog-primary-default-border",
  "--dialog-primary-default-border-width",
  "--dialog-primary-hover-surface",
  "--dialog-primary-hover-text",
  "--dialog-primary-hover-border",
  "--dialog-primary-hover-border-width",
  "--dialog-secondary-default-text",
  "--dialog-secondary-default-border",
  "--dialog-secondary-default-border-width",
  "--dialog-secondary-hover-surface",
  "--dialog-secondary-hover-text",
  "--dialog-secondary-hover-border",
  "--dialog-secondary-hover-border-width"
]);
var colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys = {
  id: "2026-09-03-drop-legacy-component-keys",
  fromVersion: 7,
  toVersion: 8,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED3.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-07-stroke-role-renames.ts
var RENAMES2 = {
  tabbar: Object.fromEntries(
    ["default", "hover", "active", "disabled"].map((s) => [
      `--tabbar-${s}-indicator-border-width`,
      `--tabbar-${s}-indicator-width`
    ])
  ),
  collapsiblesection: Object.fromEntries(
    ["default", "hover"].flatMap((s) => [
      [`--collapsiblesection-divider-${s}-border`, `--collapsiblesection-divider-${s}-hairline-color`],
      [`--collapsiblesection-divider-${s}-border-width`, `--collapsiblesection-divider-${s}-hairline-thickness`]
    ])
  ),
  dialog: Object.fromEntries(
    ["header", "footer"].flatMap((part) => [
      [`--dialog-${part}-border`, `--dialog-${part}-divider`],
      [`--dialog-${part}-border-width`, `--dialog-${part}-divider-width`]
    ])
  ),
  table: {
    "--table-default-header-border": "--table-default-header-divider",
    "--table-default-header-border-width": "--table-default-header-divider-width"
  }
};
var componentMigration_2026_09_07_strokeRoleRenames = {
  id: "2026-09-07-stroke-role-renames",
  fromVersion: 26,
  toVersion: 27,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES2[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-selected-state.ts
var RADIOBUTTON_SUFFIXES = [
  "dot-border-color",
  "dot-border-width",
  "dot-fill",
  "dot-size",
  "label",
  "label-font-family",
  "label-font-size",
  "label-font-weight",
  "label-line-height"
];
var TABBAR_SUFFIXES = [
  "border",
  "icon-size",
  "indicator-width",
  "padding",
  "surface",
  "tab-border-color",
  "tab-border-width",
  "tab-bottom-radius",
  "tab-top-radius",
  "text",
  "text-font-family",
  "text-font-size",
  "text-font-weight",
  "text-line-height"
];
var SIDENAVIGATION_SUFFIXES = {
  title: [
    "accent",
    "accent-width",
    "border",
    "border-width",
    "label",
    "label-font-family",
    "label-font-size",
    "label-font-weight",
    "label-line-height",
    "padding",
    "surface"
  ],
  section: [
    "accent",
    "accent-width",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ],
  item: [
    "accent",
    "accent-width",
    "padding",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ],
  footer: [
    "accent",
    "accent-width",
    "gap",
    "icon",
    "icon-size",
    "padding",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ]
};
var RENAMES3 = {
  radiobutton: Object.fromEntries(
    RADIOBUTTON_SUFFIXES.map((s) => [`--radiobutton-active-${s}`, `--radiobutton-selected-${s}`])
  ),
  tabbar: Object.fromEntries(
    TABBAR_SUFFIXES.map((s) => [`--tabbar-active-${s}`, `--tabbar-selected-${s}`])
  ),
  sidenavigation: Object.fromEntries(
    Object.entries(SIDENAVIGATION_SUFFIXES).flatMap(
      ([part, suffixes]) => suffixes.map((s) => [
        `--sidenavigation-${part}-active-${s}`,
        `--sidenavigation-${part}-selected-${s}`
      ])
    )
  )
};
var componentMigration_2026_09_13_selectedState = {
  id: "2026-09-13-selected-state",
  fromVersion: 27,
  toVersion: 28,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES3[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-hairline.ts
var COLLAPSIBLESECTION_SUFFIXES = [
  "surface",
  "hairline-color",
  "padding",
  "label",
  "label-font-family",
  "label-font-size",
  "label-font-weight",
  "label-line-height",
  "icon",
  "icon-size"
];
var COLLAPSIBLESECTION_STATES = ["default", "hover"];
var RENAMES4 = {
  dialog: {
    "--dialog-header-divider": "--dialog-header-hairline-color",
    "--dialog-header-divider-width": "--dialog-header-hairline-width",
    "--dialog-footer-divider": "--dialog-footer-hairline-color",
    "--dialog-footer-divider-width": "--dialog-footer-hairline-width"
  },
  table: {
    "--table-default-header-divider": "--table-default-header-hairline-color",
    "--table-default-header-divider-width": "--table-default-header-hairline-width",
    "--table-default-row-divider": "--table-default-row-hairline-color",
    "--table-default-row-divider-width": "--table-default-row-hairline-width",
    "--table-default-column-divider": "--table-default-column-hairline-color",
    "--table-default-column-divider-width": "--table-default-column-hairline-width"
  },
  tabbar: {
    "--tabbar-bar-divider": "--tabbar-bar-hairline-color",
    "--tabbar-bar-divider-thickness": "--tabbar-bar-hairline-width"
  },
  segmentedcontrol: {
    "--segmentedcontrol-divider-color": "--segmentedcontrol-hairline-color",
    "--segmentedcontrol-divider-thickness": "--segmentedcontrol-hairline-width",
    "--segmentedcontrol-divider-inset": "--segmentedcontrol-hairline-inset",
    "--segmentedcontrol-small-divider-thickness": "--segmentedcontrol-small-hairline-width",
    "--segmentedcontrol-small-divider-inset": "--segmentedcontrol-small-hairline-inset"
  },
  collapsiblesection: {
    ...Object.fromEntries(
      COLLAPSIBLESECTION_STATES.flatMap((state) => [
        ...COLLAPSIBLESECTION_SUFFIXES.map((s) => [
          `--collapsiblesection-divider-${state}-${s}`,
          `--collapsiblesection-hairline-${state}-${s}`
        ]),
        [
          `--collapsiblesection-divider-${state}-hairline-thickness`,
          `--collapsiblesection-hairline-${state}-hairline-width`
        ]
      ])
    ),
    "--collapsiblesection-divider-expanded-padding": "--collapsiblesection-hairline-expanded-padding"
  },
  sectiondivider: {
    "--sectiondivider-lg-hairline-thickness": "--sectiondivider-lg-hairline-width",
    "--sectiondivider-md-hairline-thickness": "--sectiondivider-md-hairline-width",
    "--sectiondivider-sm-hairline-thickness": "--sectiondivider-sm-hairline-width"
  }
};
var componentMigration_2026_09_13_hairline = {
  id: "2026-09-13-hairline",
  fromVersion: 28,
  toVersion: 29,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES4[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-indicator.ts
var SIDENAVIGATION_PARTS = ["title", "section", "item", "footer"];
var SIDENAVIGATION_STATES = ["default", "hover", "selected"];
var CALLOUT_VARIANTS = ["info", "success", "warning", "danger"];
var RENAMES5 = {
  sidenavigation: Object.fromEntries(
    SIDENAVIGATION_PARTS.flatMap(
      (part) => SIDENAVIGATION_STATES.flatMap((state) => [
        [
          `--sidenavigation-${part}-${state}-accent`,
          `--sidenavigation-${part}-${state}-indicator`
        ],
        [
          `--sidenavigation-${part}-${state}-accent-width`,
          `--sidenavigation-${part}-${state}-indicator-width`
        ]
      ])
    )
  ),
  callout: Object.fromEntries(
    CALLOUT_VARIANTS.map((v) => [
      `--callout-${v}-accent-width`,
      `--callout-${v}-indicator-width`
    ])
  )
};
var componentMigration_2026_09_13_indicator = {
  id: "2026-09-13-indicator",
  fromVersion: 29,
  toVersion: 30,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES5[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-sectiondivider-surface.ts
var SECTIONDIVIDER_VARIANTS = ["lg", "md", "sm"];
var RENAMES6 = {
  sectiondivider: Object.fromEntries(
    SECTIONDIVIDER_VARIANTS.map((v) => [
      `--sectiondivider-${v}-background`,
      `--sectiondivider-${v}-surface`
    ])
  )
};
var componentMigration_2026_09_13_sectiondividerSurface = {
  id: "2026-09-13-sectiondivider-surface",
  fromVersion: 30,
  toVersion: 31,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES6[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-20-imagelightbox-scrim.ts
var RENAMES7 = {
  "--imagelightbox-overlay-surface": "--imagelightbox-scrim-surface"
};
var componentMigration_2026_09_20_imagelightboxScrim = {
  id: "2026-09-20-imagelightbox-scrim",
  fromVersion: 35,
  toVersion: 36,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "imagelightbox") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMES7[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-20-scrim-color-and-opacity.ts
var STOPS = {
  "--scrim-low": "--scrim-opacity-low",
  "--scrim": "--scrim-opacity",
  "--scrim-high": "--scrim-opacity-high"
};
var SURFACE = /^--(imagelightbox|dialog)-scrim-surface$/;
var componentMigration_2026_09_20_scrimColorAndOpacity = {
  id: "2026-09-20-scrim-color-and-opacity",
  fromVersion: 36,
  toVersion: 37,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const match = SURFACE.exec(key);
      if (!match) {
        out[key] = value;
        continue;
      }
      const stem = `--${match[1]}-scrim`;
      const stop = STOPS[value];
      out[`${stem}-color`] = stop ? "--scrim-color" : value;
      out[`${stem}-opacity`] = stop ?? "1";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-21-wash-color-and-opacity.ts
var FAMILIES = ["scrim", "tint"];
var COLOR_MIX_RE = /^color-mix\(in srgb,\s*var\((--[a-z0-9-]+)\)\s+(\d+(?:\.\d+)?)%,\s*transparent\)$/i;
var PLAIN_VAR_RE = /^var\((--[a-z0-9-]+)\)$/i;
function parseFill(raw) {
  const s = raw.trim();
  const mix = s.match(COLOR_MIX_RE);
  if (mix) return { color: mix[1], opacity: Math.min(100, Number(mix[2])) / 100 };
  const plain = s.match(PLAIN_VAR_RE);
  return plain ? { color: plain[1], opacity: 1 } : null;
}
var colorsAndTypeMigration_2026_09_21_washColorAndOpacity = {
  id: "2026-09-21-wash-color-and-opacity",
  fromVersion: 8,
  toVersion: 9,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = { ...rawVars };
    for (const family of FAMILIES) {
      let color = null;
      for (const suffix of ["", "-low", "-high"]) {
        const key = `--${family}${suffix}`;
        const parsed = out[key] === void 0 ? null : parseFill(out[key]);
        if (!parsed) continue;
        color ??= parsed.color;
        out[`--${family}-opacity${suffix}`] = String(parsed.opacity);
        delete out[key];
      }
      if (color) out[`--${family}-color`] = `var(${color})`;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-10-15-responsive-columns.ts
var RENAMES8 = {
  "--columns-gutter": "--columns-desktop-gutter",
  "--columns-margin": "--columns-desktop-margin"
};
var SHIPPED = {
  "--columns-count": ["12"],
  "--columns-gutter": ["32px"],
  "--columns-margin": ["0px", "0"]
};
var colorsAndTypeMigration_2026_10_15_responsiveColumns = {
  id: "2026-10-15-responsive-columns",
  fromVersion: 9,
  toVersion: 10,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    return Object.fromEntries(
      Object.entries(rawVars).filter(([name, value]) => !SHIPPED[name]?.includes(value.trim())).map(([name, value]) => [RENAMES8[name] ?? name, value])
    );
  }
};

// src/editor/core/themes/migrations/2026-09-21-scrim-surface.ts
var STOPS2 = {
  "--scrim-opacity-low": "--scrim-low",
  "--scrim-opacity": "--scrim",
  "--scrim-opacity-high": "--scrim-high"
};
var PAIR = /^--(imagelightbox|dialog)-scrim-(color|opacity)$/;
var ref = (value) => value.startsWith("--") ? `var(${value})` : value;
function fill(color, opacity) {
  if (color === "--scrim-color" && STOPS2[opacity]) return STOPS2[opacity];
  if (opacity === "1") return color;
  const pct = Number.isFinite(Number(opacity)) ? `${Number(opacity) * 100}%` : `calc(${ref(opacity)} * 100%)`;
  return `color-mix(in srgb, ${ref(color)} ${pct}, transparent)`;
}
var componentMigration_2026_09_21_scrimSurface = {
  id: "2026-09-21-scrim-surface",
  fromVersion: 37,
  toVersion: 38,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    const pairs = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const match = PAIR.exec(key);
      if (!match) {
        out[key] = value;
        continue;
      }
      (pairs[match[1]] ??= {})[match[2]] = value;
    }
    for (const [id, { color = "--scrim-color", opacity = "--scrim-opacity-high" }] of Object.entries(pairs)) {
      out[`--${id}-scrim-surface`] = fill(color, opacity);
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-cornerbadge-prefix.ts
var RENAMES9 = {
  cornerbadge: {
    "--corner-badge-margin": "--cornerbadge-margin",
    "--corner-badge-outer-radius": "--cornerbadge-outer-radius",
    "--corner-badge-inner-radius": "--cornerbadge-inner-radius",
    "--corner-badge-h-axis-radius": "--cornerbadge-h-axis-radius",
    "--corner-badge-v-axis-radius": "--cornerbadge-v-axis-radius",
    "--corner-badge-padding": "--cornerbadge-padding",
    "--corner-badge-text-font-family": "--cornerbadge-text-font-family",
    "--corner-badge-text-font-size": "--cornerbadge-text-font-size",
    "--corner-badge-text-font-weight": "--cornerbadge-text-font-weight",
    "--corner-badge-text-line-height": "--cornerbadge-text-line-height",
    "--corner-badge-primary-surface": "--cornerbadge-primary-surface",
    "--corner-badge-primary-border": "--cornerbadge-primary-border",
    "--corner-badge-primary-text": "--cornerbadge-primary-text",
    "--corner-badge-accent-surface": "--cornerbadge-accent-surface",
    "--corner-badge-accent-border": "--cornerbadge-accent-border",
    "--corner-badge-accent-text": "--cornerbadge-accent-text",
    "--corner-badge-neutral-surface": "--cornerbadge-neutral-surface",
    "--corner-badge-neutral-border": "--cornerbadge-neutral-border",
    "--corner-badge-neutral-text": "--cornerbadge-neutral-text",
    "--corner-badge-alternate-surface": "--cornerbadge-alternate-surface",
    "--corner-badge-alternate-border": "--cornerbadge-alternate-border",
    "--corner-badge-alternate-text": "--cornerbadge-alternate-text",
    "--corner-badge-canvas-surface": "--cornerbadge-canvas-surface",
    "--corner-badge-canvas-border": "--cornerbadge-canvas-border",
    "--corner-badge-canvas-text": "--cornerbadge-canvas-text",
    "--corner-badge-special-surface": "--cornerbadge-special-surface",
    "--corner-badge-special-border": "--cornerbadge-special-border",
    "--corner-badge-special-text": "--cornerbadge-special-text",
    "--corner-badge-success-surface": "--cornerbadge-success-surface",
    "--corner-badge-success-border": "--cornerbadge-success-border",
    "--corner-badge-success-text": "--cornerbadge-success-text",
    "--corner-badge-warning-surface": "--cornerbadge-warning-surface",
    "--corner-badge-warning-border": "--cornerbadge-warning-border",
    "--corner-badge-warning-text": "--cornerbadge-warning-text",
    "--corner-badge-danger-surface": "--cornerbadge-danger-surface",
    "--corner-badge-danger-border": "--cornerbadge-danger-border",
    "--corner-badge-danger-text": "--cornerbadge-danger-text",
    "--corner-badge-info-surface": "--cornerbadge-info-surface",
    "--corner-badge-info-border": "--cornerbadge-info-border",
    "--corner-badge-info-text": "--cornerbadge-info-text"
  }
};
var componentMigration_2026_09_13_cornerbadgePrefix = {
  id: "2026-09-13-cornerbadge-prefix",
  fromVersion: 31,
  toVersion: 32,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES9[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-toggle-label.ts
var RENAMES10 = {
  toggle: {
    "--toggle-label-text": "--toggle-label",
    "--toggle-disabled-label-text": "--toggle-disabled-label"
  }
};
var componentMigration_2026_09_13_toggleLabel = {
  id: "2026-09-13-toggle-label",
  fromVersion: 32,
  toVersion: 33,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES10[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-collapsiblesection-open.ts
var RENAMES11 = {
  collapsiblesection: {
    "--collapsiblesection-chromeless-expanded-padding": "--collapsiblesection-chromeless-open-padding",
    "--collapsiblesection-hairline-expanded-padding": "--collapsiblesection-hairline-open-padding",
    "--collapsiblesection-container-expanded-surface": "--collapsiblesection-container-open-surface",
    "--collapsiblesection-container-expanded-padding": "--collapsiblesection-container-open-padding"
  }
};
var componentMigration_2026_09_13_collapsiblesectionOpen = {
  id: "2026-09-13-collapsiblesection-open",
  fromVersion: 33,
  toVersion: 34,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES11[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-badge-brand.ts
var BADGE_SUFFIXES = [
  "surface",
  "text",
  "border",
  "text-font-family",
  "text-font-size",
  "text-font-weight",
  "text-line-height",
  "border-width",
  "radius",
  "padding",
  "shadow",
  "blur",
  "icon-size"
];
var CORNERBADGE_SUFFIXES = ["surface", "border", "text"];
var RENAMES12 = {
  badge: Object.fromEntries(
    BADGE_SUFFIXES.map((s) => [`--badge-primary-${s}`, `--badge-brand-${s}`])
  ),
  cornerbadge: Object.fromEntries(
    CORNERBADGE_SUFFIXES.map((s) => [`--cornerbadge-primary-${s}`, `--cornerbadge-brand-${s}`])
  )
};
var componentMigration_2026_09_13_badgeBrand = {
  id: "2026-09-13-badge-brand",
  fromVersion: 34,
  toVersion: 35,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES12[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/index.ts
var MIGRATIONS = [
  colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas,
  colorsAndTypeMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_04_24_prefixAndSuffixRenames,
  componentMigration_2026_04_27_segmentedcontrolDisabledFlatten,
  componentMigration_2026_05_08_collapsiblesectionVariantNamespace,
  componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup,
  componentMigration_2026_05_10_sectiondividerGradientStops,
  componentMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_05_19_collapsiblesectionDropFrameSurface,
  componentMigration_2026_05_19_sectiondividerRichGradient,
  componentMigration_2026_05_20_sectiondividerSlimVariants,
  componentMigration_2026_05_21_sectiondividerSpacingToPadding,
  componentMigration_2026_05_22_sectiondividerIntrinsicsToCss,
  componentMigration_2026_05_24_segmentedcontrolDividerInset,
  componentMigration_2026_05_24_promoteStateSharedTokens,
  componentMigration_2026_05_24_progressbarCollapseVariants,
  componentMigration_2026_05_24_collapsiblesectionDropActiveState,
  componentMigration_2026_05_25_cornerbadgeFlattenVariants,
  colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth,
  componentMigration_2026_05_29_segmentedcontrolSmallDividerRename,
  componentMigration_2026_05_29_toggleDeriveTrackFromThumb,
  colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys,
  colorsAndTypeMigration_2026_08_15_lineHeightScaleRename,
  componentMigration_2026_08_15_lineHeightScaleRename,
  colorsAndTypeMigration_2026_09_01_scrimRename,
  componentMigration_2026_09_01_scrimRename,
  colorsAndTypeMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tabbarActiveTint,
  componentMigration_2026_09_01_gateSuffixEnabled,
  componentMigration_2026_09_02_sectiondividerDropTitleOutline,
  colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys,
  componentMigration_2026_09_07_strokeRoleRenames,
  componentMigration_2026_09_13_selectedState,
  componentMigration_2026_09_13_hairline,
  componentMigration_2026_09_13_indicator,
  componentMigration_2026_09_13_sectiondividerSurface,
  componentMigration_2026_09_13_cornerbadgePrefix,
  componentMigration_2026_09_13_toggleLabel,
  componentMigration_2026_09_13_collapsiblesectionOpen,
  componentMigration_2026_09_13_badgeBrand,
  componentMigration_2026_09_20_imagelightboxScrim,
  componentMigration_2026_09_20_scrimColorAndOpacity,
  colorsAndTypeMigration_2026_09_21_washColorAndOpacity,
  componentMigration_2026_09_21_scrimSurface,
  colorsAndTypeMigration_2026_10_15_responsiveColumns
];
function countFor(kind) {
  return MIGRATIONS.filter((m) => m.appliesTo === kind).length;
}
var CURRENT_COLORS_AND_TYPE_SCHEMA_VERSION = countFor("colors-and-type");
var CURRENT_COMPONENT_SCHEMA_VERSION = countFor("component-config");
function runMigrations(kind, fileVersion, rawVars, meta = {}) {
  const applicable = MIGRATIONS.filter((m) => m.appliesTo === kind && m.fromVersion >= fileVersion).sort((a, b) => a.toVersion - b.toVersion);
  let out = { ...rawVars };
  for (const m of applicable) {
    out = m.apply(out, meta);
  }
  return out;
}

// src/system/backdrop/backdrop.ts
var LIGHT_BACKDROP = 0.2;
var OPAQUE = 0.98;
var HEX_RE = /#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})\b/gi;
var OKLCH_RE2 = /oklch\(\s*[\d.]+%?\s+[\d.]+%?\s+[\d.]+(?:deg)?\s*(?:\/\s*([\d.]+%?)\s*)?\)/gi;
var RGB_RE = /rgba?\(\s*([\d.]+%?)\s*[, ]\s*([\d.]+%?)\s*[, ]\s*([\d.]+%?)(?:\s*[,/]\s*([\d.]+%?))?\s*\)/gi;
var EXOTIC_RE = /\b(?:color-mix|hwb|lab|lch|oklab|color)\([^()]*\)/gi;
function channel(value) {
  const parsed = Number.parseFloat(value);
  return value.endsWith("%") ? parsed * 2.55 : parsed;
}
function alpha(value) {
  if (value === void 0) return 1;
  const parsed = Number.parseFloat(value);
  return value.endsWith("%") ? parsed / 100 : parsed;
}
function parseHex(hex) {
  const digits = hex.slice(1);
  const full = digits.length <= 4 ? digits.split("").map((part) => part + part).join("") : digits;
  return {
    r: Number.parseInt(full.slice(0, 2), 16),
    g: Number.parseInt(full.slice(2, 4), 16),
    b: Number.parseInt(full.slice(4, 6), 16),
    a: full.length >= 8 ? Number.parseInt(full.slice(6, 8), 16) / 255 : 1
  };
}
function colorsIn(background) {
  const colors = [];
  for (const match of background.matchAll(HEX_RE)) colors.push(parseHex(match[0]));
  for (const match of background.matchAll(OKLCH_RE2)) {
    const parsed = parseOklchCss(match[0]);
    if (parsed) colors.push({ ...oklchToRgb255(parsed.l, parsed.c, parsed.h), a: alpha(match[1]) });
  }
  for (const match of background.matchAll(RGB_RE)) {
    colors.push({
      r: channel(match[1]),
      g: channel(match[2]),
      b: channel(match[3]),
      a: alpha(match[4])
    });
  }
  for (const match of background.matchAll(EXOTIC_RE)) {
    const resolved = viaCanvas(match[0]);
    if (resolved) colors.push(resolved);
  }
  return colors;
}
function linearChannel(value) {
  const srgb = Math.max(0, Math.min(255, value)) / 255;
  return srgb <= 0.04045 ? srgb / 12.92 : ((srgb + 0.055) / 1.055) ** 2.4;
}
function luminance({ r, g, b }) {
  return 0.2126 * linearChannel(r) + 0.7152 * linearChannel(g) + 0.0722 * linearChannel(b);
}
var SEED = "#010203";
var probe;
function viaCanvas(value) {
  if (typeof document === "undefined") return null;
  if (probe === void 0) {
    probe = document.createElement("canvas").getContext?.("2d", { willReadFrequently: true }) ?? null;
  }
  if (!probe) return null;
  probe.fillStyle = SEED;
  probe.fillStyle = value;
  if (probe.fillStyle === SEED) return null;
  probe.clearRect(0, 0, 1, 1);
  probe.fillRect(0, 0, 1, 1);
  const [r, g, b, a] = probe.getImageData(0, 0, 1, 1).data;
  return { r, g, b, a: a / 255 };
}
function backgroundLuminance(background) {
  const opaque = colorsIn(background).filter((color) => color.a >= OPAQUE);
  if (!opaque.length) return null;
  return opaque.reduce((total, color) => total + luminance(color), 0) / opaque.length;
}
function polarityOfBackground(background) {
  const measured = backgroundLuminance(background);
  if (measured === null) return null;
  return measured >= LIGHT_BACKDROP ? "light" : "dark";
}

// vite-plugin/files/versionedFileResourceServer.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
function versionedFileResourceServer(opts) {
  const dir = opts.dir;
  const activePath = import_path.default.join(dir, "_active.json");
  const productionPath = import_path.default.join(dir, "_production.json");
  const workingPath = import_path.default.join(dir, "_working.json");
  const defaultName = opts.defaultName ?? "default";
  const resolvedDir = import_path.default.resolve(dir);
  const resolvedPackageDir = opts.packageDir ? import_path.default.resolve(opts.packageDir) : null;
  function ensureDir() {
    if (!import_fs.default.existsSync(dir)) {
      import_fs.default.mkdirSync(dir, { recursive: true });
    }
  }
  function ensureMeta() {
    if (!import_fs.default.existsSync(activePath)) {
      import_fs.default.writeFileSync(activePath, JSON.stringify({ activeFile: defaultName }));
      opts.onWrite?.(activePath);
    }
    if (!import_fs.default.existsSync(productionPath)) {
      import_fs.default.writeFileSync(productionPath, JSON.stringify({ productionFile: defaultName }));
      opts.onWrite?.(productionPath);
    }
  }
  function filePath(name) {
    return import_path.default.join(dir, `${name}.json`);
  }
  function existingPath(name) {
    const local = filePath(name);
    if (import_fs.default.existsSync(local)) return local;
    if (resolvedPackageDir) {
      const pkg = import_path.default.join(resolvedPackageDir, `${name}.json`);
      if (import_fs.default.existsSync(pkg)) return pkg;
    }
    return null;
  }
  function isPackageFile(name) {
    if (!resolvedPackageDir) return false;
    const pkg = import_path.default.join(resolvedPackageDir, `${name}.json`);
    if (!import_fs.default.existsSync(pkg)) return false;
    const local = import_path.default.resolve(filePath(name));
    if (local === pkg) {
      return opts.packageOwnedNames ? opts.packageOwnedNames.includes(name) : true;
    }
    return !import_fs.default.existsSync(local);
  }
  function readJson(name) {
    const resolved = existingPath(name);
    if (!resolved) return null;
    return JSON.parse(import_fs.default.readFileSync(resolved, "utf-8"));
  }
  function listNames() {
    const names = [];
    const seen = /* @__PURE__ */ new Set();
    const collect = (d) => {
      if (!d || !import_fs.default.existsSync(d)) return;
      for (const f of import_fs.default.readdirSync(d)) {
        if (!f.endsWith(".json") || f.startsWith("_")) continue;
        const name = f.slice(0, -".json".length);
        if (seen.has(name)) continue;
        seen.add(name);
        names.push(name);
      }
    };
    collect(resolvedDir);
    if (resolvedPackageDir && resolvedPackageDir !== resolvedDir) collect(resolvedPackageDir);
    return names;
  }
  function getActiveName() {
    try {
      const data = JSON.parse(import_fs.default.readFileSync(activePath, "utf-8"));
      return data.activeFile || defaultName;
    } catch {
      return defaultName;
    }
  }
  function getProductionName() {
    try {
      const data = JSON.parse(import_fs.default.readFileSync(productionPath, "utf-8"));
      return data.productionFile || defaultName;
    } catch {
      return defaultName;
    }
  }
  function setActiveName(name) {
    import_fs.default.writeFileSync(activePath, JSON.stringify({ activeFile: name }));
    opts.onWrite?.(activePath);
  }
  function setProductionName(name) {
    import_fs.default.writeFileSync(productionPath, JSON.stringify({ productionFile: name }));
    opts.onWrite?.(productionPath);
  }
  function hasWorking() {
    return import_fs.default.existsSync(workingPath);
  }
  function readWorking() {
    if (!import_fs.default.existsSync(workingPath)) return null;
    const parsed = JSON.parse(import_fs.default.readFileSync(workingPath, "utf-8"));
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error(`${workingPath} does not hold a JSON object`);
    }
    return parsed;
  }
  function writeWorking(data) {
    ensureDir();
    import_fs.default.writeFileSync(workingPath, JSON.stringify(data, null, 2));
    opts.onWrite?.(workingPath);
  }
  function clearWorking() {
    if (!import_fs.default.existsSync(workingPath)) return;
    import_fs.default.unlinkSync(workingPath);
    opts.onWrite?.(workingPath);
  }
  return {
    dir,
    activePath,
    productionPath,
    workingPath,
    ensureDir,
    ensureMeta,
    filePath,
    existingPath,
    isPackageFile,
    readJson,
    listNames,
    getActiveName,
    getProductionName,
    setActiveName,
    setProductionName,
    hasWorking,
    readWorking,
    writeWorking,
    clearWorking
  };
}

// vite-plugin/files/routeTable.ts
async function dispatch(req, res, routes) {
  const url = req.url || "";
  const method = req.method || "GET";
  for (const route of routes) {
    if (route.method !== method) continue;
    let params = [];
    if (typeof route.pattern === "string") {
      if (url !== route.pattern) continue;
    } else {
      const m = url.match(route.pattern);
      if (!m) continue;
      params = m.slice(1);
    }
    try {
      await route.handler({ url, params, req, res });
    } catch (err) {
      if (!res.writableEnded) {
        res.statusCode = 500;
        res.setHeader("Content-Type", "application/json");
        res.end(JSON.stringify({ error: err?.message ?? "Internal error" }));
      }
    }
    return true;
  }
  return false;
}

// vite-plugin/files/dataTreeWatch.ts
var import_fs2 = __toESM(require("fs"), 1);
var import_path2 = __toESM(require("path"), 1);
function fingerprint(file) {
  try {
    return import_fs2.default.readFileSync(file, "utf-8");
  } catch {
    return null;
  }
}
function dataTreeWatch(opts) {
  const debounceMs = opts.debounceMs ?? 100;
  const ownWrites = /* @__PURE__ */ new Map();
  const listeners = /* @__PURE__ */ new Set();
  let watchers = [];
  let timer = null;
  function noteOwnWrite(file) {
    const resolved = import_path2.default.resolve(file);
    ownWrites.set(resolved, fingerprint(resolved));
  }
  function onEvent(dir, filename) {
    if (!filename) return;
    const file = import_path2.default.resolve(dir, filename.toString());
    if (!opts.isLive(file)) return;
    if (ownWrites.has(file) && ownWrites.get(file) === fingerprint(file)) return;
    ownWrites.delete(file);
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      for (const listener of listeners) listener();
    }, debounceMs);
  }
  function start() {
    for (const dir of opts.dirs) {
      if (!import_fs2.default.existsSync(dir)) continue;
      const watcher = import_fs2.default.watch(
        dir,
        { recursive: true, persistent: false },
        (_event, filename) => onEvent(dir, filename)
      );
      watcher.on("error", () => watcher.close());
      watchers.push(watcher);
    }
  }
  function stop() {
    for (const watcher of watchers) watcher.close();
    watchers = [];
    if (timer) clearTimeout(timer);
    timer = null;
  }
  function subscribe(listener) {
    if (listeners.size === 0) start();
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
      if (listeners.size === 0) stop();
    };
  }
  return { noteOwnWrite, subscribe };
}

// src/editor/core/themes/migrateComponentConfig.ts
function migrateComponentConfig(component, aliasesIn, rawConfig, fileVersion) {
  const stringPart = {};
  const objectPart = {};
  for (const [k, v] of Object.entries(aliasesIn)) {
    if (typeof v === "string") stringPart[k] = v;
    else objectPart[k] = v;
  }
  const configOut = {};
  for (const [k, v] of Object.entries(rawConfig ?? {})) {
    if (typeof v === "string") stringPart[k] = v;
    else configOut[k] = v;
  }
  if (component === "sectiondivider") {
    synthesizeSectionDividerGradients(stringPart, objectPart);
  }
  const migratedString = runMigrations("component-config", fileVersion, stringPart, { component });
  const migratedObject = component === "sectiondivider" ? renameSectionDividerObjectSlots(objectPart) : objectPart;
  return {
    aliases: { ...migratedString, ...migratedObject },
    config: configOut
  };
}
var FAMILIES2 = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
var SIZE_VARIANTS = ["lg", "md", "sm"];
function renameSectionDividerObjectSlots(objectPart) {
  const canvasSourceKeys = [
    "--sectiondivider-canvas-background",
    "--sectiondivider-canvas-gradient",
    "--sectiondivider-color-canvas-background"
  ];
  let canvasGradient;
  for (const key of canvasSourceKeys) {
    if (objectPart[key] !== void 0) {
      canvasGradient = objectPart[key];
      break;
    }
  }
  const out = {};
  for (const [key, value] of Object.entries(objectPart)) {
    let isFamilyGradient = false;
    for (const f of FAMILIES2) {
      if (key === `--sectiondivider-${f}-background` || key === `--sectiondivider-${f}-gradient` || key === `--sectiondivider-color-${f}-background`) {
        isFamilyGradient = true;
        break;
      }
    }
    if (isFamilyGradient) continue;
    const backgroundVariant = SIZE_VARIANTS.find((v) => key === `--sectiondivider-${v}-background`);
    if (backgroundVariant) {
      out[`--sectiondivider-${backgroundVariant}-surface`] = value;
      continue;
    }
    out[key] = value;
  }
  if (canvasGradient !== void 0) {
    for (const v of SIZE_VARIANTS) {
      out[`--sectiondivider-${v}-surface`] = canvasGradient;
    }
  }
  return out;
}
var SECTIONDIVIDER_VARIANTS2 = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
function synthesizeSectionDividerGradients(stringPart, objectPart) {
  const GRADIENT_ANGLE_TOKENS = {
    "--gradient-angle-horizontal": 90,
    "--gradient-angle-vertical": 180,
    "--gradient-angle-diagonal": 135,
    "--gradient-angle-counter-diagonal": 45
  };
  const GRADIENT_STOP_POSITIONS = {
    "--gradient-stop-start": 0,
    "--gradient-stop-mid": 50,
    "--gradient-stop-end": 100
  };
  const parseAngle = (raw) => {
    if (!raw) return 135;
    if (raw.startsWith("--")) return GRADIENT_ANGLE_TOKENS[raw] ?? 135;
    const m = raw.match(/^(-?\d+(?:\.\d+)?)\s*deg$/i);
    return m ? parseFloat(m[1]) : 135;
  };
  const parsePosition = (raw, fallback) => {
    if (!raw) return fallback;
    if (raw.startsWith("--")) return GRADIENT_STOP_POSITIONS[raw] ?? fallback;
    const m = raw.match(/^(-?\d+(?:\.\d+)?)\s*%$/);
    return m ? parseFloat(m[1]) : fallback;
  };
  const parseStopColor = (raw) => {
    if (!raw) return null;
    if (raw.startsWith("--")) return { color: raw };
    const mix = raw.match(/^color-mix\(\s*in\s+srgb\s*,\s*var\((--[a-z0-9-]+)\)\s+([\d.]+)%\s*,\s*transparent\s*\)$/i);
    if (mix) return { color: mix[1], opacity: parseFloat(mix[2]) };
    return null;
  };
  for (const v of SECTIONDIVIDER_VARIANTS2) {
    const slot = `--sectiondivider-${v}-gradient`;
    if (slot in objectPart) continue;
    const angleKey = `${slot}-angle`;
    const has1 = stringPart[`${slot}-stop-1-color`] !== void 0;
    const has2 = stringPart[`${slot}-stop-2-color`] !== void 0;
    const has3 = stringPart[`${slot}-stop-3-color`] !== void 0;
    if (!has1 && !has2 && !has3) continue;
    const stops = [];
    const positionDefaults = [0, 50, 100];
    for (let i = 1; i <= 3; i++) {
      const c = parseStopColor(stringPart[`${slot}-stop-${i}-color`]);
      if (!c) continue;
      const pos = parsePosition(stringPart[`${slot}-stop-${i}-position`], positionDefaults[i - 1]);
      stops.push({ position: pos, color: c.color, ...c.opacity !== void 0 ? { opacity: c.opacity } : {} });
    }
    if (stops.length < 2) continue;
    objectPart[slot] = {
      kind: "gradient",
      value: {
        type: "linear",
        angle: parseAngle(stringPart[angleKey]),
        stops
      }
    };
  }
}

// src/editor/core/themes/themeTypes.ts
var THEME_SCHEMA_VERSION = 5;

// src/editor/core/components/componentConfigKeys.ts
var KNOWN_COMPONENT_CONFIG_KEYS = /* @__PURE__ */ new Set([
  "--dialog-confirm-variant",
  "--dialog-cancel-variant",
  // SectionDivider per-variant `color-family` is editor metadata that drives
  // the family-swap rewrite on aliases. It is not a runtime CSS value, so it
  // stays in the config bucket. The other intrinsics (align, hairline,
  // eyebrow/description visibility, eyebrow text-transform) now flow through
  // the alias bucket as cascading CSS vars — see the 2026-05-22 migration.
  "--sectiondivider-lg-color-family",
  "--sectiondivider-md-color-family",
  "--sectiondivider-sm-color-family"
]);

// src/live-tokens/data/sketch-styles/pencil.json
var pencil_default = {
  name: "Pencil",
  settings: {
    label: "Pencil",
    blurb: "Two graphite passes on their own seeds, so the outline disagrees with itself the way a hand coming back round does. The grain is drawn long and on the diagonal, the way a pencil shades.",
    fillTravel: 0.75,
    strokeTravel: 1.25,
    wobble: 30,
    roughness: 3,
    borderWavelength: 1,
    waveform: 1,
    strokeWidth: 1.25,
    doubleStroke: true,
    retraceOffset: 1.5,
    retracePass: "reseeded",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.15,
    pressureMod: 0.3,
    pooling: 0,
    strokeInk: 0.85,
    maskOn: true,
    maskBlobX: 525,
    maskBlobY: 47,
    maskBlobLinked: false,
    maskAngle: 67,
    maskOutputMin: 0.59,
    maskOutputMax: 1,
    maskOctaves: 3,
    maskGrain: "turbulence",
    maskPosterize: 1,
    maskSoftness: 0,
    jitterX: 1.5,
    jitterY: 1.5,
    jitterRot: 0.35,
    jitterScale: 0.022,
    cornerSpread: 6,
    cornerTravel: 4.5,
    iconTravel: 0.75,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 1
  },
  updatedAt: "2026-08-28T14:35:06.291Z",
  createdAt: "2026-08-28T14:35:06.291Z"
};

// src/live-tokens/data/sketch-styles/marker.json
var marker_default = {
  name: "Marker",
  settings: {
    label: "Marker",
    blurb: "Broad translucent nib gone round twice on the same line, so the overlap darkens and the ink pools where it slows.",
    fillTravel: 2,
    strokeTravel: 1.5,
    wobble: 56,
    roughness: 3,
    borderWavelength: 1.3,
    waveform: 1.4,
    strokeWidth: 4,
    doubleStroke: true,
    retraceOffset: 2.2,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.2,
    pressureMod: 0.25,
    pooling: 2,
    strokeInk: 0.52,
    maskOn: true,
    maskBlobX: 230,
    maskBlobY: 230,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.76,
    maskOutputMax: 1,
    maskOctaves: 3,
    maskGrain: "fractal",
    maskPosterize: 4,
    maskSoftness: 0,
    jitterX: 3,
    jitterY: 3,
    jitterRot: 0.8,
    jitterScale: 0.045,
    cornerSpread: 10,
    cornerTravel: 8,
    iconTravel: 1.25,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 4
  },
  updatedAt: "2026-08-28T14:45:04.324Z",
  createdAt: "2026-08-28T14:45:04.324Z"
};

// src/live-tokens/data/sketch-styles/whiteboard.json
var whiteboard_default = {
  name: "Whiteboard",
  settings: {
    label: "Whiteboard",
    blurb: "The fattest nib on glass. One long smooth undulation, and a veined mask that streaks the fill like a half-wiped board.",
    fillTravel: 2.5,
    strokeTravel: 2.5,
    wobble: 90,
    roughness: 1,
    borderWavelength: 1.5,
    waveform: 1,
    strokeWidth: 5.5,
    doubleStroke: true,
    retraceOffset: 3,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.15,
    pressureMod: 0.15,
    pooling: 3.5,
    strokeInk: 0.66,
    maskOn: true,
    maskBlobX: 180,
    maskBlobY: 38,
    maskBlobLinked: false,
    maskAngle: 0,
    maskOutputMin: 0.68,
    maskOutputMax: 1,
    maskOctaves: 3,
    maskGrain: "turbulence",
    maskPosterize: 3,
    maskSoftness: 0,
    jitterX: 4.5,
    jitterY: 4.5,
    jitterRot: 3,
    jitterScale: 0.07,
    cornerSpread: 14,
    cornerTravel: 11,
    iconTravel: 1.75,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 1.5
  },
  updatedAt: "2026-08-28T14:46:58.140Z",
  createdAt: "2026-08-28T14:46:58.140Z"
};

// src/live-tokens/data/sketch-styles/hatched.json
var hatched_default = {
  name: "Hatched",
  settings: {
    label: "Hatched",
    blurb: "An etching. The fill is angled shading, the outline a single hard-edged scratch that chatters along its length. No mask: the hatch is the texture.",
    fillTravel: 1.25,
    strokeTravel: 1.5,
    wobble: 24,
    roughness: 3,
    borderWavelength: 1,
    waveform: 3,
    strokeWidth: 1.5,
    doubleStroke: false,
    retraceOffset: 1.2,
    retracePass: "copy",
    fillStyle: "hatched",
    hatchInk: 0.5,
    strokeStyle: "solid",
    pressure: 0.3,
    pressureMod: 0.45,
    pooling: 0.8,
    strokeInk: 1,
    maskOn: true,
    maskBlobX: 10,
    maskBlobY: 600,
    maskBlobLinked: false,
    maskAngle: 150,
    maskOutputMin: 0.35,
    maskOutputMax: 1,
    maskOctaves: 2,
    maskGrain: "turbulence",
    maskPosterize: 1,
    maskSoftness: 1.5,
    jitterX: 1.5,
    jitterY: 1.5,
    jitterRot: 0.4,
    jitterScale: 0.03,
    cornerSpread: 6,
    cornerTravel: 6,
    iconTravel: 1.25,
    iconWavelength: 0.5,
    iconMaskOn: false,
    iconMaskScale: 1
  },
  updatedAt: "2026-08-28T21:17:18.232Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/live-tokens/data/sketch-styles/dashed.json
var dashed_default = {
  name: "Dashed",
  settings: {
    label: "Dashed",
    blurb: "A drafting outline. One slow drift along the ruler, broken into strokes, with jitter, mask and pressure all off. The clean pole.",
    fillTravel: 0.5,
    strokeTravel: 1,
    wobble: 120,
    roughness: 1,
    borderWavelength: 1,
    waveform: 1,
    strokeWidth: 1.5,
    doubleStroke: false,
    retraceOffset: 1.2,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "dashed",
    pressure: 0,
    pressureMod: 0,
    pooling: 0,
    strokeInk: 1,
    maskOn: false,
    maskBlobX: 100,
    maskBlobY: 100,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.45,
    maskOutputMax: 1,
    maskOctaves: 2,
    maskGrain: "fractal",
    maskPosterize: 1,
    maskSoftness: 1.5,
    jitterX: 0,
    jitterY: 0,
    jitterRot: 0,
    jitterScale: 0,
    cornerSpread: 4,
    cornerTravel: 3,
    iconTravel: 0,
    iconWavelength: 0.625,
    iconMaskOn: false,
    iconMaskScale: 1
  },
  updatedAt: "2026-08-28T15:47:36.934Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/live-tokens/data/sketch-styles/napkin.json
var napkin_default = {
  name: "Napkin",
  settings: {
    label: "Napkin",
    blurb: "Ballpoint in a hurry. Everything loose at once: a square wave sends every edge to full travel, and the second pass lands wherever it lands.",
    fillTravel: 3,
    strokeTravel: 2.25,
    wobble: 50,
    roughness: 3,
    borderWavelength: 1,
    waveform: 2.5,
    strokeWidth: 2.25,
    doubleStroke: true,
    retraceOffset: 4,
    retracePass: "reseeded",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.45,
    pressureMod: 0.6,
    pooling: 2.5,
    strokeInk: 1,
    maskOn: true,
    maskBlobX: 150,
    maskBlobY: 150,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.62,
    maskOutputMax: 1,
    maskOctaves: 2,
    maskGrain: "fractal",
    maskPosterize: 2,
    maskSoftness: 5,
    jitterX: 6,
    jitterY: 6,
    jitterRot: 1.8,
    jitterScale: 0.075,
    cornerSpread: 20,
    cornerTravel: 17,
    iconTravel: 2.25,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 3.6
  },
  updatedAt: "2026-08-28T15:47:36.934Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/live-tokens/data/sketch-styles/dry.json
var dry_default = {
  name: "Dry marker",
  settings: {
    label: "Dry marker",
    blurb: "Ink that ran out. One scratchy pass that breaks up along its length, over a fill the mask has worn nearly through in patches.",
    fillTravel: 2.25,
    strokeTravel: 1.75,
    wobble: 50,
    roughness: 3,
    borderWavelength: 0.5,
    waveform: 2,
    strokeWidth: 3.5,
    doubleStroke: false,
    retraceOffset: 1.2,
    retracePass: "copy",
    fillStyle: "solid",
    hatchInk: 0.4,
    strokeStyle: "solid",
    pressure: 0.4,
    pressureMod: 0.8,
    pooling: 1.5,
    strokeInk: 0.4,
    maskOn: true,
    maskBlobX: 170,
    maskBlobY: 170,
    maskBlobLinked: true,
    maskAngle: 0,
    maskOutputMin: 0.57,
    maskOutputMax: 0.91,
    maskOctaves: 2,
    maskGrain: "fractal",
    maskPosterize: 4,
    maskSoftness: 1.75,
    jitterX: 5,
    jitterY: 5,
    jitterRot: 1.4,
    jitterScale: 0.08,
    cornerSpread: 16,
    cornerTravel: 13,
    iconTravel: 1.75,
    iconWavelength: 0.625,
    iconMaskOn: true,
    iconMaskScale: 3.8
  },
  updatedAt: "2026-08-28T21:19:51.383Z",
  createdAt: "2026-08-28T15:47:36.934Z"
};

// src/editor/core/sketch/sketchStyles.ts
var SHIPPED_FILES = { pencil: pencil_default, marker: marker_default, whiteboard: whiteboard_default, hatched: hatched_default, dashed: dashed_default, napkin: napkin_default, dry: dry_default };
var SHIPPED_SKETCH_SETTINGS = Object.fromEntries(
  Object.entries(SHIPPED_FILES).map(([id, file]) => [id, file.settings])
);
var DEFAULT_SKETCH_STYLE = "marker";
function hydrateSketchSettings(raw) {
  const base = SHIPPED_SKETCH_SETTINGS[DEFAULT_SKETCH_STYLE];
  const stored = raw ?? {};
  const out = { ...base };
  for (const key of Object.keys(base)) {
    if (stored[key] !== void 0) out[key] = stored[key];
  }
  if (out.fillStyle === "none") out.fillStyle = base.fillStyle;
  convertTiledMask(stored, out);
  convertCutToLevels(stored, out);
  carryLevelsToOutput(stored, out);
  halveSwingDials(stored, out);
  splitBlobAxes(stored, out);
  convertCyclesToWavelength(stored, out);
  convertIconTileToScale(stored, out);
  restoreDerivedRetrace(stored, out);
  return out;
}
function restoreDerivedRetrace(stored, out) {
  if (stored.retraceOffset === void 0) {
    out.retraceOffset = Number(Math.max(1.2, out.strokeWidth * 0.55).toFixed(2));
  }
}
var SWING_DIALS = {
  fillScale: "fillTravel",
  strokeScale: "strokeTravel",
  iconScale: "iconTravel",
  cornerShift: "cornerTravel"
};
function convertCyclesToWavelength(stored, out) {
  const cycles = stored.frequency;
  if (typeof cycles === "number" && cycles > 0) out.wobble = Math.round(1 / cycles);
  for (const [legacy, key] of [
    ["borderFrequency", "borderWavelength"],
    ["iconFrequency", "iconWavelength"]
  ]) {
    const multiple = stored[legacy];
    if (typeof multiple === "number" && multiple > 0) {
      out[key] = Number((1 / multiple).toFixed(3));
    }
  }
  const layers = stored.octaves;
  if (typeof layers === "number") out.roughness = Math.min(3, Math.max(1, layers));
}
function splitBlobAxes(stored, out) {
  const blob = stored.maskBlob;
  if (typeof blob !== "number") return;
  out.maskBlobX = blob;
  out.maskBlobY = blob;
  out.maskBlobLinked = true;
}
function convertIconTileToScale(stored, out) {
  const tile = stored.iconMaskTile;
  if (typeof tile !== "number") return;
  out.iconMaskScale = Math.min(5, Math.max(0.5, Number((tile / 90).toFixed(2))));
}
function halveSwingDials(stored, out) {
  for (const [legacy, key] of Object.entries(SWING_DIALS)) {
    const value = stored[legacy];
    if (typeof value === "number") out[key] = value / 2;
  }
}
function convertTiledMask(stored, out) {
  const scale = stored.maskScale;
  if (typeof scale !== "number") return;
  const freq = stored.maskFrequency;
  if (typeof freq === "number") {
    out.maskBlobX = Math.round(scale / (freq * LEGACY_TILE));
    out.maskBlobY = out.maskBlobX;
  }
  const soft = stored.maskSoftness;
  if (typeof soft === "number") out.maskSoftness = Number((soft * scale / LEGACY_TILE).toFixed(1));
}
function convertCutToLevels(stored, out) {
  const contrast = stored.maskContrast;
  const coverage = stored.maskCoverage;
  if (typeof contrast !== "number" || typeof coverage !== "number") return;
  const veined = out.maskGrain === "turbulence";
  const [lo, hi] = veined ? LEGACY_RANGE.turbulence : LEGACY_RANGE.fractal;
  const pivot = veined ? 0.55 - 0.5 * coverage : 0.8 - 0.6 * coverage;
  const level = (raw) => Math.min(1, Math.max(0, (raw - lo) / (hi - lo)));
  out.maskOutputMin = Number(level(pivot - 0.5 / contrast).toFixed(2));
  out.maskOutputMax = Number(Math.max(out.maskOutputMin + 0.02, level(pivot + 0.5 / contrast)).toFixed(2));
}
function carryLevelsToOutput(stored, out) {
  if (typeof stored.maskLevelMin === "number") out.maskOutputMin = stored.maskLevelMin;
  if (typeof stored.maskLevelMax === "number") out.maskOutputMax = stored.maskLevelMax;
}
var LEGACY_RANGE = { fractal: [0.24, 0.77], turbulence: [0.02, 0.6] };
var LEGACY_TILE = 600;

// vite-plugin/themes/normalizeTheme.ts
function asObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function isColorsAndTypeShaped(raw) {
  const obj = asObject(raw);
  if (!obj) return false;
  if ("theme" in obj || "colorsAndType" in obj) return false;
  return "cssVariables" in obj || "editorConfigs" in obj;
}
function stripFileMarker(value) {
  if (!("_fileName" in value)) return value;
  const { _fileName, ...rest } = value;
  return rest;
}
function asString(value, fallback) {
  return typeof value === "string" && value ? value : fallback;
}
function migrateEmbeddedKey(src) {
  const { theme, ...rest } = src;
  return { ...rest, colorsAndType: theme };
}
function routeKnownConfigKeys(aliases, config) {
  const outAliases = { ...aliases };
  const outConfig = { ...config };
  for (const key of Object.keys(outAliases)) {
    if (!KNOWN_COMPONENT_CONFIG_KEYS.has(key)) continue;
    if (outConfig[key] === void 0) outConfig[key] = outAliases[key];
    delete outAliases[key];
  }
  return { aliases: outAliases, config: outConfig };
}
function migrateEmbeddedComponentConfig(comp, config, fileVersion) {
  const { schemaVersion: _entryStamp, aliases: rawAliases, config: rawConfig, ...rest } = config;
  const aliasesIn = asObject(rawAliases);
  if (!aliasesIn) {
    return rawConfig !== void 0 ? { ...rest, config: rawConfig } : rest;
  }
  const migratedConfig = migrateComponentConfig(
    comp,
    aliasesIn,
    asObject(rawConfig) ?? void 0,
    fileVersion
  );
  const split = routeKnownConfigKeys(migratedConfig.aliases, migratedConfig.config);
  const out = { ...rest, aliases: split.aliases };
  if (rawConfig !== void 0 || Object.keys(split.config).length > 0) {
    out.config = split.config;
  }
  return out;
}
function normalizeTheme(raw, resolvers) {
  const input = asObject(raw) ?? {};
  const migrated = input.schemaVersion !== THEME_SCHEMA_VERSION;
  const inputVersion = typeof input.schemaVersion === "number" ? input.schemaVersion : 0;
  const src = inputVersion < 3 ? migrateEmbeddedKey(input) : input;
  const componentSchemaVersion = typeof input.componentSchemaVersion === "number" ? input.componentSchemaVersion : 0;
  const dropped = [];
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const embeddedColorsAndType = asObject(src.colorsAndType);
  let colorsAndType = null;
  if (embeddedColorsAndType) {
    colorsAndType = stripFileMarker(embeddedColorsAndType);
  } else {
    const colorsAndTypeName = asString(src.colorsAndType, "default");
    colorsAndType = asObject(resolvers.readColorsAndType(colorsAndTypeName));
    if (!colorsAndType) {
      dropped.push(`colors-and-type:${colorsAndTypeName}`);
      if (colorsAndTypeName !== "default") colorsAndType = asObject(resolvers.readColorsAndType("default"));
    }
    if (colorsAndType) colorsAndType = resolvers.normalizeColorsAndType(stripFileMarker(colorsAndType));
  }
  const componentConfigs = {};
  for (const [comp, value] of Object.entries(asObject(src.componentConfigs) ?? {})) {
    const embedded2 = asObject(value);
    let resolvedConfig;
    if (embedded2) {
      resolvedConfig = stripFileMarker(embedded2);
    } else {
      const configName = asString(value, "default");
      const resolved = asObject(resolvers.readComponentConfig(comp, configName));
      if (!resolved) {
        dropped.push(`${comp}/${configName}`);
        continue;
      }
      resolvedConfig = stripFileMarker(resolved);
    }
    componentConfigs[comp] = migrateEmbeddedComponentConfig(comp, resolvedConfig, componentSchemaVersion);
  }
  const filled = { components: [], aliases: 0, orphans: 0 };
  for (const comp of resolvers.listComponentNames()) {
    const base = asObject(resolvers.readComponentConfig(comp, "default"));
    const baseAliases = base ? asObject(base.aliases) : null;
    if (!base || !baseAliases) continue;
    const entry = componentConfigs[comp];
    if (!entry) {
      const { schemaVersion: _standaloneStamp, ...rest } = stripFileMarker(base);
      componentConfigs[comp] = structuredClone(rest);
      filled.components.push(comp);
      continue;
    }
    const entryAliases = asObject(entry.aliases) ?? {};
    for (const key of Object.keys(baseAliases)) {
      if (key in entryAliases) continue;
      entryAliases[key] = structuredClone(baseAliases[key]);
      filled.aliases++;
    }
    entry.aliases = entryAliases;
    for (const key of Object.keys(entryAliases)) {
      if (!(key in baseAliases)) filled.orphans++;
    }
  }
  const embedded = asObject(src.sketchSettings) ?? asObject(src.sketchStyle);
  const sketchSettings = embedded ? hydrateSketchSettings(embedded) : void 0;
  return {
    theme: {
      name: asString(src.name, "Untitled"),
      createdAt: asString(src.createdAt, now),
      updatedAt: asString(src.updatedAt, now),
      schemaVersion: THEME_SCHEMA_VERSION,
      colorsAndType,
      componentConfigs,
      componentSchemaVersion: CURRENT_COMPONENT_SCHEMA_VERSION,
      ...sketchSettings ? { sketchSettings } : {}
    },
    dropped,
    migrated,
    filled
  };
}

// vite-plugin/files/nameAllocator.ts
function nextAvailableName(exists, baseName, maxAttempts = 1e3) {
  if (!exists(baseName)) return baseName;
  for (let i = 2; i < maxAttempts; i++) {
    const candidate = `${baseName}-${i}`;
    if (!exists(candidate)) return candidate;
  }
  throw new Error(`Could not allocate a non-colliding name for "${baseName}"`);
}

// vite-plugin/files/dataPaths.ts
var import_fs3 = __toESM(require("fs"), 1);
var import_path3 = __toESM(require("path"), 1);
var DEFAULT_DATA_DIR = "src/live-tokens/data";
var TEST_DATA_DIR_ENV = "LIVE_TOKENS_TEST_DATA_DIR";
function testDataDir() {
  const raw = process.env[TEST_DATA_DIR_ENV];
  return raw && raw.trim() !== "" ? import_path3.default.resolve(raw.trim()) : void 0;
}
var TEST_PACKAGE_DATA_DIR_ENV = "LIVE_TOKENS_TEST_PACKAGE_DATA_DIR";
function testPackageDataDir() {
  const raw = process.env[TEST_PACKAGE_DATA_DIR_ENV];
  return raw && raw.trim() !== "" ? import_path3.default.resolve(raw.trim()) : void 0;
}
var KNOWN_CONFIG_KEYS = /* @__PURE__ */ new Set([
  "dataDir",
  "colorsAndTypeDir",
  "componentConfigsDir",
  "themesDir",
  "manifestsDir",
  "tokensCssPath",
  "componentDirs",
  "checks"
]);
var cached = null;
function readLiveTokensConfig() {
  if (cached) return cached;
  try {
    const configPath = import_path3.default.resolve("live-tokens.config.json");
    if (!import_fs3.default.existsSync(configPath)) return cached = {};
    const parsed = JSON.parse(import_fs3.default.readFileSync(configPath, "utf-8"));
    if (!parsed || typeof parsed !== "object") return cached = {};
    const unknown = Object.keys(parsed).filter(
      (k) => k !== "$schema" && !KNOWN_CONFIG_KEYS.has(k)
    );
    if (unknown.length > 0) {
      console.warn(
        `[live-tokens] Unknown key(s) in live-tokens.config.json: ${unknown.join(", ")}. Known keys: ${Array.from(KNOWN_CONFIG_KEYS).join(", ")}.`
      );
    }
    cached = parsed;
    return cached;
  } catch {
    return cached = {};
  }
}
function resolveDataDirs(opts = {}) {
  const isolated = testDataDir();
  if (isolated) {
    return {
      dataDir: isolated,
      colorsAndTypeDir: import_path3.default.join(isolated, "colors-and-type"),
      componentConfigsDir: import_path3.default.join(isolated, "component-configs"),
      themesDir: import_path3.default.join(isolated, "themes"),
      sketchStylesDir: import_path3.default.join(isolated, "sketch-styles")
    };
  }
  const fileConfig = readLiveTokensConfig();
  const dataDirRaw = opts.dataDir ?? fileConfig.dataDir ?? DEFAULT_DATA_DIR;
  const dataDir = import_path3.default.resolve(dataDirRaw);
  const sub = (name) => import_path3.default.resolve(dataDir, name);
  return {
    dataDir,
    colorsAndTypeDir: opts.colorsAndTypeDir ? import_path3.default.resolve(opts.colorsAndTypeDir) : fileConfig.colorsAndTypeDir ? import_path3.default.resolve(fileConfig.colorsAndTypeDir) : sub("colors-and-type"),
    componentConfigsDir: opts.componentConfigsDir ? import_path3.default.resolve(opts.componentConfigsDir) : fileConfig.componentConfigsDir ? import_path3.default.resolve(fileConfig.componentConfigsDir) : sub("component-configs"),
    themesDir: opts.themesDir ? import_path3.default.resolve(opts.themesDir) : fileConfig.themesDir ? import_path3.default.resolve(fileConfig.themesDir) : sub("themes"),
    sketchStylesDir: sub("sketch-styles"),
    legacyManifestsDir: fileConfig.manifestsDir ? import_path3.default.resolve(fileConfig.manifestsDir) : void 0
  };
}

// vite-plugin/files/legacyLayout.ts
var import_fs4 = __toESM(require("fs"), 1);
var import_path4 = __toESM(require("path"), 1);
function jsonFiles(dir) {
  if (!import_fs4.default.existsSync(dir)) return [];
  try {
    return import_fs4.default.readdirSync(dir).filter((f) => f.endsWith(".json")).map((f) => import_path4.default.join(dir, f));
  } catch {
    return [];
  }
}
function isDirectory(dir) {
  try {
    return import_fs4.default.statSync(dir).isDirectory();
  } catch {
    return false;
  }
}
function parseJsonFile(file) {
  try {
    return JSON.parse(import_fs4.default.readFileSync(file, "utf-8"));
  } catch {
    return null;
  }
}
function holdsATheme(themesDir) {
  return jsonFiles(themesDir).some((file) => {
    if (import_path4.default.basename(file).startsWith("_")) return false;
    const raw = parseJsonFile(file);
    if (!raw || typeof raw !== "object") return false;
    return "colorsAndType" in raw || "theme" in raw;
  });
}
function detectLegacyLayout(input) {
  const manifestsDir = input.configuredManifestsDir ?? import_path4.default.join(input.dataDir, "manifests");
  const themesHoldAThemeFile = holdsATheme(input.themesDir);
  if (isDirectory(manifestsDir) && !themesHoldAThemeFile) {
    return { manifestsDir, evidence: `${manifestsDir} is the pre-0.48 whole-theme directory` };
  }
  if (jsonFiles(input.colorsAndTypeDir).length > 0) return null;
  for (const file of jsonFiles(input.themesDir)) {
    if (import_path4.default.basename(file).startsWith("_")) continue;
    if (isColorsAndTypeShaped(parseJsonFile(file))) {
      return { manifestsDir, evidence: `${file} is a colors-and-type file, not a theme` };
    }
  }
  const pointer = ["_active.json", "_production.json"].map((name) => import_path4.default.join(input.themesDir, name)).find((p) => import_fs4.default.existsSync(p));
  if (pointer && !themesHoldAThemeFile && !import_fs4.default.existsSync(input.colorsAndTypeDir)) {
    return {
      manifestsDir,
      evidence: `${pointer} points at colors and type, and there is no ${import_path4.default.basename(input.colorsAndTypeDir)} directory`
    };
  }
  return null;
}

// src/editor/core/themes/parsers/mediaBlocks.ts
function stripMediaBlocks(css) {
  const kept = [];
  let from = 0;
  let i = 0;
  while (i < css.length) {
    if (css.startsWith("/*", i)) {
      i = commentEnd(css, i);
    } else if (css[i] === "@" && /^@media\b/i.test(css.slice(i, i + 7))) {
      kept.push(css.slice(from, i));
      i = from = blockEnd(css, i);
    } else {
      i++;
    }
  }
  kept.push(css.slice(from));
  return kept.join("");
}
function commentEnd(css, start) {
  const end = css.indexOf("*/", start + 2);
  return end === -1 ? css.length : end + 2;
}
function blockEnd(css, start) {
  let depth = 0;
  let i = start;
  while (i < css.length) {
    if (css.startsWith("/*", i)) {
      i = commentEnd(css, i);
      continue;
    }
    const c = css[i++];
    if (c === "{") depth++;
    else if (c === "}" && --depth === 0) return i;
  }
  return css.length;
}

// vite-plugin/tokensCssMigrations/cssTokenOps.ts
var DECL_RE = /(^|[\s;{])(--[a-z0-9-]+)\s*:/gi;
var REF_RE = /var\(\s*(--[a-z0-9-]+)/gi;
var DECL_VALUE_RE = /(^|[\s;{])(--[a-z0-9-]+)\s*:([^;}]*)/gi;
function collectDefinedTokens(css) {
  const out = /* @__PURE__ */ new Set();
  for (const m of css.matchAll(DECL_RE)) out.add(m[2]);
  return out;
}
function collectTokenValues(css) {
  const out = /* @__PURE__ */ new Map();
  for (const m of stripMediaBlocks(css).matchAll(DECL_VALUE_RE)) out.set(m[2], m[3].trim());
  return out;
}
function collectReferencedTokens(css) {
  const out = /* @__PURE__ */ new Set();
  for (const m of css.matchAll(REF_RE)) out.add(m[1]);
  return out;
}
function ensureScale(css, opts) {
  const defined = collectDefinedTokens(css);
  const missing = opts.entries.filter((e) => !defined.has(e.name));
  if (missing.length === 0) return css;
  const lines = css.split("\n");
  const { indent, insertAfter } = findInsertionPoint(lines, opts.anchorPrefixes ?? []);
  const block = [];
  if (opts.sectionComment) block.push(`${indent}/* ${opts.sectionComment} */`);
  for (const e of missing) block.push(`${indent}${e.name}: ${e.value};`);
  lines.splice(insertAfter + 1, 0, ...block);
  return lines.join("\n");
}
function renameToken2(css, oldName, newName) {
  const defined = collectDefinedTokens(css);
  if (!defined.has(oldName) || defined.has(newName)) return css;
  const re = new RegExp(escapeRe(oldName) + "(?![a-z0-9-])", "gi");
  return css.replace(re, newName);
}
function removeToken(css, name) {
  const lines = css.split("\n");
  const declRe = new RegExp("(^|[\\s;{])" + escapeRe(name) + "\\s*:");
  const kept = lines.filter((line) => !declRe.test(line));
  if (kept.length === lines.length) return css;
  return kept.join("\n");
}
function removeTokensMatching(css, predicate) {
  const lines = css.split("\n");
  const declRe = /^\s*(--[a-z0-9-]+)\s*:/;
  const kept = lines.filter((line) => {
    const m = line.match(declRe);
    return !(m && predicate(m[1]));
  });
  if (kept.length === lines.length) return css;
  return kept.join("\n");
}
function setTokenValue(css, name, value, opts = {}) {
  const lines = css.split("\n");
  const declRe = new RegExp("(^|[\\s;{])(" + escapeRe(name) + ")(\\s*:)([^;}]*)");
  let changed = false;
  for (const root of findTopLevelRoots(lines)) {
    let depth = 1;
    for (let i = root.start + 1; i < root.end; i++) {
      if (depth === 1) {
        const m = lines[i].match(declRe);
        const current = m?.[4].trim();
        if (m && current !== value && (opts.from === void 0 || current === opts.from.trim())) {
          const at = m.index + m[1].length + m[2].length + m[3].length;
          lines[i] = lines[i].slice(0, at) + " " + value + lines[i].slice(at + m[4].length);
          changed = true;
        }
      }
      depth += braceDelta(lines[i]);
    }
  }
  return changed ? lines.join("\n") : css;
}
function appendMediaBlock(css, query, entries, opts = {}) {
  const lines = css.split("\n");
  const at = query.trim();
  const blocks = findTopLevelBlocks(lines, (line) => mediaQueryOf(line) === at);
  const declared = collectDefinedTokens(
    blocks.map((b) => lines.slice(b.start, b.end + 1).join("\n")).join("\n")
  );
  const missing = entries.filter((e) => !declared.has(e.name));
  if (missing.length === 0) return css;
  const media = blocks.find((b) => b.end > b.start);
  if (!media) {
    const block = [`@media ${at} {`, "  :root {", ...declarationLines(missing, "    "), "  }", "}", ""];
    const before = opts.before?.trim();
    const next = before === void 0 ? void 0 : findTopLevelBlocks(lines, (line) => mediaQueryOf(line) === before)[0];
    if (next) {
      lines.splice(next.start, 0, ...block);
      return lines.join("\n");
    }
    while (lines.length > 0 && lines[lines.length - 1].trim() === "") lines.pop();
    return [...lines, "", ...block].join("\n");
  }
  const root = findNestedRoot(lines, media);
  if (!root) {
    lines.splice(media.end, 0, "  :root {", ...declarationLines(missing, "    "), "  }");
    return lines.join("\n");
  }
  let indent = (lines[root.end].match(/^\s*/)?.[0] ?? "") + "  ";
  for (let i = root.start + 1; i < root.end; i++) {
    const m = lines[i].match(/^(\s*)--[a-z0-9-]+\s*:/i);
    if (m) indent = m[1];
  }
  lines.splice(root.end, 0, ...declarationLines(missing, indent));
  return lines.join("\n");
}
function declarationLines(entries, indent) {
  return entries.map((e) => `${indent}${e.name}: ${e.value};`);
}
function findInsertionPoint(lines, anchorPrefixes) {
  const root = findTopLevelRoot(lines);
  if (!root) return { indent: "  ", insertAfter: lines.length - 1 };
  const lastByPrefix = /* @__PURE__ */ new Map();
  let lastDecl = null;
  let depth = 1;
  for (let i = root.start + 1; i < root.end; i++) {
    const line = lines[i];
    if (depth === 1) {
      const m = line.match(/^(\s*)(--[a-z0-9-]+)\s*:/);
      if (m) {
        const hit = { index: i, indent: m[1] || "  " };
        lastDecl = hit;
        for (const prefix of anchorPrefixes) {
          if (m[2].startsWith(prefix)) lastByPrefix.set(prefix, hit);
        }
      }
    }
    depth += braceDelta(line);
  }
  for (const prefix of anchorPrefixes) {
    const hit = lastByPrefix.get(prefix);
    if (hit) return { indent: hit.indent, insertAfter: hit.index };
  }
  return { indent: lastDecl?.indent ?? "  ", insertAfter: root.end - 1 };
}
var ROOT_OPEN_RE = /(^|[\s,]):root[^{]*\{/;
function findTopLevelRoot(lines) {
  return findTopLevelRoots(lines)[0] ?? null;
}
function findTopLevelRoots(lines) {
  return findTopLevelBlocks(lines, (line) => ROOT_OPEN_RE.test(line));
}
function findTopLevelBlocks(lines, opens) {
  const blocks = [];
  let depth = 0;
  for (let i = 0; i < lines.length; i++) {
    if (depth === 0 && opens(lines[i])) {
      const end = blockEnd2(lines, i);
      blocks.push({ start: i, end });
      i = end;
      continue;
    }
    depth += braceDelta(lines[i]);
  }
  return blocks;
}
function findNestedRoot(lines, parent) {
  let depth = 1;
  for (let i = parent.start + 1; i < parent.end; i++) {
    if (depth === 1 && ROOT_OPEN_RE.test(lines[i])) {
      const end = blockEnd2(lines, i);
      if (end > i && end < parent.end) return { start: i, end };
    }
    depth += braceDelta(lines[i]);
  }
  return null;
}
function blockEnd2(lines, start) {
  let depth = 0;
  for (let j = start; j < lines.length; j++) {
    depth += braceDelta(lines[j]);
    if (depth === 0) return j;
  }
  return lines.length - 1;
}
function mediaQueryOf(line) {
  return line.match(/^\s*@media\s+([^{]*?)\s*\{/i)?.[1] ?? null;
}
function braceDelta(line) {
  return (line.match(/\{/g)?.length ?? 0) - (line.match(/\}/g)?.length ?? 0);
}
function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// vite-plugin/tokensCssMigrations/migrations/2026-05-29-typography-scale-additions.ts
var tokensCssMigration_2026_05_29_typographyScaleAdditions = {
  id: "2026-05-29-typography-scale-additions",
  kind: "additive",
  description: "Add --letter-spacing-* and --ease-out-quart scales",
  apply(css) {
    let out = css;
    out = ensureScale(out, {
      sectionComment: "Letter spacing",
      anchorPrefixes: ["--letter-spacing-", "--line-height-", "--font-size-", "--font-"],
      entries: [
        { name: "--letter-spacing-tighter", value: "-0.04em" },
        { name: "--letter-spacing-tight", value: "-0.02em" },
        { name: "--letter-spacing-normal", value: "0" },
        { name: "--letter-spacing-wide", value: "0.04em" },
        { name: "--letter-spacing-wider", value: "0.08em" }
      ]
    });
    out = ensureScale(out, {
      sectionComment: "Easing",
      anchorPrefixes: ["--ease-", "--transition-", "--duration-"],
      entries: [{ name: "--ease-out-quart", value: "cubic-bezier(0.25, 1, 0.5, 1)" }]
    });
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-05-29-sectiondivider-legacy-axis-cleanup.ts
var KEEP_SEGMENTS = /* @__PURE__ */ new Set(["lg", "md", "sm"]);
var tokensCssMigration_2026_05_29_sectiondividerLegacyAxisCleanup = {
  id: "2026-05-29-sectiondivider-legacy-axis-cleanup",
  kind: "breaking",
  description: "Remove legacy --sectiondivider-* tokens not on the lg/md/sm axis",
  apply(css) {
    return removeTokensMatching(css, (name) => {
      if (!name.startsWith("--sectiondivider-")) return false;
      const segment = name.slice("--sectiondivider-".length).split("-")[0];
      return !KEEP_SEGMENTS.has(segment);
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-06-03-transform-scale-additions.ts
var tokensCssMigration_2026_06_03_transformScaleAdditions = {
  id: "2026-06-03-transform-scale-additions",
  kind: "additive",
  description: "Add the --scale-{sm..2xl} transform-multiplier scale",
  apply(css) {
    return ensureScale(css, {
      sectionComment: "Transform-scale multipliers (e.g. hover zoom). 5% per step.",
      anchorPrefixes: ["--blur-", "--shadow-", "--radius-"],
      entries: [
        { name: "--scale-sm", value: "1.05" },
        { name: "--scale-md", value: "1.1" },
        { name: "--scale-lg", value: "1.15" },
        { name: "--scale-xl", value: "1.2" },
        { name: "--scale-2xl", value: "1.25" }
      ]
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-06-04-remove-dead-size-icon-scale.ts
var tokensCssMigration_2026_06_04_removeDeadSizeIconScale = {
  id: "2026-06-04-remove-dead-size-icon-scale",
  kind: "breaking",
  description: "Remove the unused --size-icon-* scale (live scale is --icon-size-*)",
  apply(css) {
    return removeTokensMatching(css, (name) => name.startsWith("--size-icon-"));
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-06-04-easing-color-and-typescale-additions.ts
var tokensCssMigration_2026_06_04_easingColorAndTypescaleAdditions = {
  id: "2026-06-04-easing-color-and-typescale-additions",
  kind: "additive",
  description: "Add the full --ease-* scale, --color-white/black, and --font-size-7xl",
  apply(css) {
    let out = css;
    out = ensureScale(out, {
      anchorPrefixes: ["--ease-", "--transition-", "--duration-"],
      entries: [
        { name: "--ease-linear", value: "linear" },
        { name: "--ease-in-sine", value: "cubic-bezier(0.12, 0, 0.39, 0)" },
        { name: "--ease-out-sine", value: "cubic-bezier(0.61, 1, 0.88, 1)" },
        { name: "--ease-in-out-sine", value: "cubic-bezier(0.37, 0, 0.63, 1)" },
        { name: "--ease-in-quad", value: "cubic-bezier(0.11, 0, 0.5, 0)" },
        { name: "--ease-out-quad", value: "cubic-bezier(0.5, 1, 0.89, 1)" },
        { name: "--ease-in-out-quad", value: "cubic-bezier(0.45, 0, 0.55, 1)" },
        { name: "--ease-in-cubic", value: "cubic-bezier(0.32, 0, 0.67, 0)" },
        { name: "--ease-out-cubic", value: "cubic-bezier(0.33, 1, 0.68, 1)" },
        { name: "--ease-in-out-cubic", value: "cubic-bezier(0.65, 0, 0.35, 1)" },
        { name: "--ease-in-quart", value: "cubic-bezier(0.5, 0, 0.75, 0)" },
        { name: "--ease-out-quart", value: "cubic-bezier(0.25, 1, 0.5, 1)" },
        { name: "--ease-in-out-quart", value: "cubic-bezier(0.76, 0, 0.24, 1)" },
        { name: "--ease-in-quint", value: "cubic-bezier(0.64, 0, 0.78, 0)" },
        { name: "--ease-out-quint", value: "cubic-bezier(0.22, 1, 0.36, 1)" },
        { name: "--ease-in-out-quint", value: "cubic-bezier(0.83, 0, 0.17, 1)" },
        { name: "--ease-in-expo", value: "cubic-bezier(0.7, 0, 0.84, 0)" },
        { name: "--ease-out-expo", value: "cubic-bezier(0.16, 1, 0.3, 1)" },
        { name: "--ease-in-out-expo", value: "cubic-bezier(0.87, 0, 0.13, 1)" },
        { name: "--ease-in-circ", value: "cubic-bezier(0.55, 0, 1, 0.45)" },
        { name: "--ease-out-circ", value: "cubic-bezier(0, 0.55, 0.45, 1)" },
        { name: "--ease-in-out-circ", value: "cubic-bezier(0.85, 0, 0.15, 1)" },
        { name: "--ease-in-back", value: "cubic-bezier(0.36, 0, 0.66, -0.56)" },
        { name: "--ease-out-back", value: "cubic-bezier(0.34, 1.56, 0.64, 1)" },
        { name: "--ease-in-out-back", value: "cubic-bezier(0.68, -0.6, 0.32, 1.6)" },
        {
          name: "--ease-in-elastic",
          value: "linear(0, 0.0007 8.1%, 0.0019 12.1%, 0.0027 13.7%, 0.0046 15.7%, -0.0046 18.7%, -0.0202 22.1%, -0.0234 23.6%, -0.0224 24.9%, -0.0156 26.7%, 0.0091 29.4%, 0.0666 33.4%, 0.0848 34.9%, 0.0916 36.4%, 0.0837 38.1%, 0.0581 40.1%, -0.0204 43.7%, -0.221 51.3%, -0.2825 53.6%, -0.317 55.4%, -0.3253 57.1%, -0.3071 58.8%, -0.2554 60.9%, -0.1295 63.7%, 0.4515 73.1%, 0.7257 78.4%, 0.834 81.2%, 0.9221 84.1%, 0.9817 87.1%, 1.0144 90.4%, 1.026 94.6%, 1)"
        },
        {
          name: "--ease-out-elastic",
          value: "linear(0, 0.974 4.6%, 1.026 5.4%, 1.018 6.9%, 0.952 12.9%, 0.876 15.9%, 0.751 18.8%, 0.557 22.4%, -0.451 36.3%, -0.722 42.9%, -0.832 46.6%, -0.918 51.3%, -0.916 54.8%, -0.832 59.4%, -0.665 64.6%, 0.221 78%, 0.317 81.2%, 0.317 84.4%, 0.281 87.6%, 0.232 91.1%, 0.058 100%)"
        },
        {
          name: "--ease-in-out-elastic",
          value: "linear(0, 0.0001 7.7%, -0.0048 12.7%, -0.0064 14.6%, -0.0064 16.5%, -0.0026 18.5%, 0.0179 21.4%, 0.0617 24.1%, 0.0617 26.5%, 0.0309 29%, -0.0589 32.7%, -0.3 38.1%, -0.4307 40.6%, -0.4844 43%, -0.4844 48%, -0.4307 50.4%, -0.3 52.9%, 0.3 60.5%, 0.4307 63%, 0.4844 65.4%, 0.4844 70.4%, 0.4307 72.8%, 0.3 75.3%, 0.0589 80.7%, -0.0309 84.4%, -0.0617 86.9%, -0.0617 89.3%, -0.0179 92%, 0.0026 94.9%, 0.0064 96.8%, 0.0064 98.7%, 0.0048 100%, 1)"
        },
        {
          name: "--ease-in-bounce",
          value: "linear(0, 0.005, 0.018, 0.039, 0.069, 0.108, 0.156, 0.213, 0.281, 0.36, 0.451, 0.555, 0.674, 0.81, 0.967, 0.881, 0.838, 0.838, 0.881, 0.97, 0.952, 0.95, 0.969, 0.999, 0.984, 0.982, 0.989, 1)"
        },
        {
          name: "--ease-out-bounce",
          value: "linear(0, 0.011, 0.031, 0.018, 0.05, 0.151, 0.301, 0.5, 0.747, 0.945, 0.997, 1, 0.969, 0.954, 0.969, 0.952, 0.952, 0.969, 1, 0.984, 0.982, 0.984, 0.997, 0.984, 0.989, 1)"
        },
        {
          name: "--ease-in-out-bounce",
          value: "linear(0, 0.003, 0.009, 0.019, 0.034, 0.054, 0.078, 0.107, 0.141, 0.18, 0.226, 0.278, 0.337, 0.405, 0.483, 0.471, 0.42, 0.419, 0.46, 0.494, 0.5, 0.506, 0.54, 0.581, 0.58, 0.529, 0.517, 0.595, 0.663, 0.722, 0.774, 0.819, 0.859, 0.893, 0.922, 0.946, 0.966, 0.981, 0.991, 0.997, 1)"
        }
      ]
    });
    out = ensureScale(out, {
      sectionComment: "Invariants \u2014 never themed, not part of any ramp.",
      anchorPrefixes: ["--color-"],
      entries: [
        { name: "--color-white", value: "#ffffff" },
        { name: "--color-black", value: "#000000" }
      ]
    });
    out = ensureScale(out, {
      anchorPrefixes: ["--font-size-", "--font-"],
      entries: [{ name: "--font-size-7xl", value: "4.5rem" }]
    });
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-07-20-line-height-rename.ts
var RENAMES13 = [
  ["--line-height-xs", "--line-height-none"],
  ["--line-height-sm", "--line-height-tighter"],
  ["--line-height-md", "--line-height-normal"],
  ["--line-height-lg", "--line-height-relaxed"]
];
var SCALE = [
  { name: "--line-height-none", value: "1" },
  { name: "--line-height-tightest", value: "1.1" },
  { name: "--line-height-tighter", value: "1.25" },
  { name: "--line-height-tight", value: "1.35" },
  { name: "--line-height-normal", value: "1.5" },
  { name: "--line-height-relaxed", value: "1.75" }
];
var tokensCssMigration_2026_07_20_lineHeightRename = {
  id: "2026-07-20-line-height-rename",
  kind: "breaking",
  description: "Reshape --line-height-{xs..xl} to leading vocabulary (none/tightest/tighter/tight/normal/relaxed); retire the 2.0 slot",
  apply(css) {
    let out = css;
    for (const [oldName, newName] of RENAMES13) out = renameToken2(out, oldName, newName);
    out = removeToken(out, "--line-height-xl");
    out = ensureScale(out, {
      anchorPrefixes: ["--line-height-", "--font-size-", "--font-weight-", "--font-"],
      entries: SCALE
    });
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-07-20-semantic-text-styles.ts
var BUNDLE = [
  { name: "--heading-xl-font-family", value: "var(--font-display)" },
  { name: "--heading-xl-font-size", value: "var(--font-size-4xl)" },
  { name: "--heading-xl-font-weight", value: "var(--font-weight-semibold)" },
  { name: "--heading-xl-line-height", value: "var(--line-height-tightest)" },
  { name: "--heading-xl-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--heading-lg-font-family", value: "var(--font-display)" },
  { name: "--heading-lg-font-size", value: "var(--font-size-2xl)" },
  { name: "--heading-lg-font-weight", value: "var(--font-weight-semibold)" },
  { name: "--heading-lg-line-height", value: "var(--line-height-tightest)" },
  { name: "--heading-lg-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--heading-md-font-family", value: "var(--font-display)" },
  { name: "--heading-md-font-size", value: "var(--font-size-xl)" },
  { name: "--heading-md-font-weight", value: "var(--font-weight-semibold)" },
  { name: "--heading-md-line-height", value: "var(--line-height-tighter)" },
  { name: "--heading-md-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--heading-sm-font-family", value: "var(--font-sans)" },
  { name: "--heading-sm-font-size", value: "var(--font-size-lg)" },
  { name: "--heading-sm-font-weight", value: "var(--font-weight-semibold)" },
  { name: "--heading-sm-line-height", value: "var(--line-height-tighter)" },
  { name: "--heading-sm-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--body-md-font-family", value: "var(--font-sans)" },
  { name: "--body-md-font-size", value: "var(--font-size-md)" },
  { name: "--body-md-font-weight", value: "var(--font-weight-normal)" },
  { name: "--body-md-line-height", value: "var(--line-height-normal)" },
  { name: "--body-md-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--body-sm-font-family", value: "var(--font-sans)" },
  { name: "--body-sm-font-size", value: "var(--font-size-sm)" },
  { name: "--body-sm-font-weight", value: "var(--font-weight-normal)" },
  { name: "--body-sm-line-height", value: "var(--line-height-tight)" },
  { name: "--body-sm-letter-spacing", value: "var(--letter-spacing-normal)" },
  // The code bundle's size, leading and tracking belong to 2026-10-08-type-scales,
  // which renames them to `--code-md-*`. An additive migration must not re-add
  // names a later breaking rename removes, or re-running the fold loses
  // idempotency.
  { name: "--code-font-family", value: "var(--font-mono)" },
  { name: "--code-font-weight", value: "var(--font-weight-normal)" },
  { name: "--eyebrow-font-family", value: "var(--font-sans)" },
  { name: "--eyebrow-font-size", value: "var(--font-size-sm)" },
  { name: "--eyebrow-font-weight", value: "var(--font-weight-normal)" },
  { name: "--eyebrow-line-height", value: "var(--line-height-normal)" },
  { name: "--eyebrow-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--eyebrow-text-transform", value: "none" }
];
var tokensCssMigration_2026_07_20_semanticTextStyles = {
  id: "2026-07-20-semantic-text-styles",
  kind: "additive",
  description: "Add the semantic text-style bundles (--heading-*/--body-*/--code-*/--eyebrow-*)",
  apply(css) {
    return ensureScale(css, {
      sectionComment: "Text styles \u2014 semantic typography roles",
      anchorPrefixes: [
        "--eyebrow-",
        "--code-",
        "--body-",
        "--heading-",
        "--letter-spacing-",
        "--line-height-",
        "--font-weight-",
        "--font-size-",
        "--font-"
      ],
      entries: BUNDLE
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-19-oklch-color-values.ts
var HEX_DECLARATION_RE = /(--[a-z0-9-]+:\s*)#([0-9a-f]{6})(?=\s*[;}])/gi;
var tokensCssMigration_2026_08_19_oklchColorValues = {
  id: "2026-08-19-oklch-color-values",
  kind: "breaking",
  description: "Rewrite hex token values as oklch()",
  apply(css) {
    return css.replace(HEX_DECLARATION_RE, (_match, prefix, hex) => {
      const { l, c, h } = hexToOklch(`#${hex}`);
      return `${prefix}${oklchToCss(l, c, h)}`;
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-25-editorial-type-role.ts
var STACK = [{ name: "--font-editorial", value: "var(--font-sans)" }];
var tokensCssMigration_2026_08_25_editorialTypeRole = {
  id: "2026-08-25-editorial-type-role",
  kind: "additive",
  description: "Add the editorial type role (--font-editorial)",
  apply(css) {
    return ensureScale(css, {
      anchorPrefixes: ["--font-mono", "--font-serif", "--font-sans", "--font-display"],
      entries: STACK
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-26-gradient-stops.ts
var STOPS_RE = /^(?:linear|radial)-gradient\(\s*[^,]+,\s*(.+)\)$/i;
var tokensCssMigration_2026_08_26_gradientStops = {
  id: "2026-08-26-gradient-stops",
  kind: "additive",
  description: "Add --gradient-N-stops companions to the gradient slots",
  apply(css) {
    const values = collectTokenValues(css);
    const entries = [];
    for (const [name, value] of values) {
      if (!/^--gradient-\d+$/.test(name)) continue;
      const stops = value.match(STOPS_RE);
      if (stops) entries.push({ name: `${name}-stops`, value: stops[1].trim() });
    }
    if (entries.length === 0) return css;
    return ensureScale(css, { anchorPrefixes: ["--gradient-"], entries });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-27-backdrop-polarity.ts
var MARKER = "[data-backdrop='dark']";
var RULES = `/* BACKDROP POLARITY \u2014 one attribute says which way a surface leans. State it
   in markup (\`<section data-backdrop="dark">\`) or let \`use:backdrop\` measure
   and stamp it. Either way \`light-dark()\` inside resolves the right half, and
   a rule can key on the attribute for what colour alone cannot carry. */

[data-backdrop='light'] {
  color-scheme: light;
}

[data-backdrop='dark'] {
  color-scheme: dark;
}
`;
var tokensCssMigration_2026_08_27_backdropPolarity = {
  id: "2026-08-27-backdrop-polarity",
  kind: "additive",
  description: "Add the [data-backdrop] \u2192 color-scheme rules",
  apply(css) {
    if (css.includes(MARKER)) return css;
    const at = css.indexOf(":root");
    if (at === -1) return `${css.trimEnd()}

${RULES}`;
    return `${css.slice(0, at)}${RULES}
${css.slice(at)}`;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-27-editorial-size-steps.ts
var AXES = ["font-family", "font-size", "font-weight", "line-height", "letter-spacing"];
var BUNDLE2 = [
  { name: "--editorial-md-font-family", value: "var(--font-editorial)" },
  { name: "--editorial-md-font-size", value: "var(--font-size-md)" },
  { name: "--editorial-md-font-weight", value: "var(--font-weight-normal)" },
  { name: "--editorial-md-line-height", value: "var(--line-height-normal)" },
  { name: "--editorial-md-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--editorial-sm-font-family", value: "var(--font-editorial)" },
  { name: "--editorial-sm-font-size", value: "var(--font-size-sm)" },
  { name: "--editorial-sm-font-weight", value: "var(--font-weight-normal)" },
  { name: "--editorial-sm-line-height", value: "var(--line-height-tight)" },
  { name: "--editorial-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
];
var tokensCssMigration_2026_08_27_editorialSizeSteps = {
  id: "2026-08-27-editorial-size-steps",
  kind: "breaking",
  description: "Split the editorial bundle into --editorial-md-* and --editorial-sm-* steps",
  apply(css) {
    let out = css;
    for (const axis of AXES) {
      out = renameToken2(out, `--editorial-${axis}`, `--editorial-md-${axis}`);
    }
    return ensureScale(out, {
      sectionComment: "Editorial \u2014 the long-reading role, body face until repointed",
      anchorPrefixes: [
        "--eyebrow-",
        "--code-",
        "--body-",
        "--heading-",
        "--letter-spacing-",
        "--line-height-",
        "--font-weight-",
        "--font-size-",
        "--font-"
      ],
      entries: BUNDLE2
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-08-27-editorial-large-steps.ts
var BUNDLE3 = [
  { name: "--editorial-xl-font-family", value: "var(--font-editorial)" },
  { name: "--editorial-xl-font-size", value: "var(--font-size-xl)" },
  { name: "--editorial-xl-font-weight", value: "var(--font-weight-normal)" },
  { name: "--editorial-xl-line-height", value: "var(--line-height-tighter)" },
  { name: "--editorial-xl-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--editorial-lg-font-family", value: "var(--font-editorial)" },
  { name: "--editorial-lg-font-size", value: "var(--font-size-lg)" },
  { name: "--editorial-lg-font-weight", value: "var(--font-weight-normal)" },
  { name: "--editorial-lg-line-height", value: "var(--line-height-tight)" },
  { name: "--editorial-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
];
var tokensCssMigration_2026_08_27_editorialLargeSteps = {
  id: "2026-08-27-editorial-large-steps",
  kind: "additive",
  description: "Add the --editorial-lg-* and --editorial-xl-* steps above the reading size",
  apply(css) {
    return ensureScale(css, {
      sectionComment: "Editorial \u2014 the steps above the reading size",
      anchorPrefixes: [
        "--editorial-",
        "--eyebrow-",
        "--code-",
        "--body-",
        "--heading-",
        "--letter-spacing-",
        "--line-height-",
        "--font-weight-",
        "--font-size-",
        "--font-"
      ],
      entries: BUNDLE3
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-09-01-scrim-rename.ts
var RENAMES14 = [
  ["--overlay-low", "--scrim-low"],
  ["--overlay-high", "--scrim-high"],
  ["--overlay", "--scrim"]
];
var tokensCssMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename",
  kind: "breaking",
  description: "Rename --overlay-{low,base,high} to --scrim-*; a scrim dims what is behind it",
  apply(css) {
    let out = css;
    for (const [oldName, newName] of RENAMES14) out = renameToken2(out, oldName, newName);
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-09-01-tint-scale.ts
var ENTRIES = [
  { name: "--tint-low", value: "rgba(255, 255, 255, 0.05)" },
  { name: "--tint", value: "rgba(255, 255, 255, 0.1)" },
  { name: "--tint-high", value: "rgba(255, 255, 255, 0.15)" }
];
var tokensCssMigration_2026_09_01_tintScale = {
  id: "2026-09-01-tint-scale",
  kind: "additive",
  description: "Add the --tint-* scale; a tint shades the surface it sits on",
  apply(css) {
    return ensureScale(css, {
      entries: ENTRIES,
      sectionComment: "Tints \u2014 translucent washes that shade the surface they sit on",
      anchorPrefixes: ["--scrim", "--overlay"]
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-09-20-scrim-color-and-opacity.ts
var ENTRIES2 = [
  { name: "--scrim-color", value: "rgb(20, 3, 0)" },
  { name: "--scrim-opacity-low", value: "0.38" },
  { name: "--scrim-opacity", value: "0.51" },
  { name: "--scrim-opacity-high", value: "0.64" }
];
var tokensCssMigration_2026_09_20_scrimColorAndOpacity = {
  id: "2026-09-20-scrim-color-and-opacity",
  kind: "additive",
  description: "Add --scrim-color and --scrim-opacity-*; a scrim's colour and strength are separate tokens",
  apply(css) {
    return ensureScale(css, {
      entries: ENTRIES2,
      sectionComment: "Scrim colour and strength, which each screen mixes where it paints",
      anchorPrefixes: ["--scrim"]
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-09-21-tint-color-and-opacity.ts
var ENTRIES3 = [
  { name: "--tint-color", value: "rgb(255, 255, 255)" },
  { name: "--tint-opacity-low", value: "0.05" },
  { name: "--tint-opacity", value: "0.1" },
  { name: "--tint-opacity-high", value: "0.15" }
];
var tokensCssMigration_2026_09_21_tintColorAndOpacity = {
  id: "2026-09-21-tint-color-and-opacity",
  kind: "additive",
  description: "Add --tint-color and --tint-opacity-*; a tint's colour and strength are separate tokens",
  apply(css) {
    return ensureScale(css, {
      entries: ENTRIES3,
      sectionComment: "Tint colour and strength, which the --tint-* stops compose",
      anchorPrefixes: ["--tint"]
    });
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-10-08-type-scales.ts
var RENAMES15 = [
  ["--code-font-size", "--code-md-font-size"],
  ["--code-line-height", "--code-md-line-height"],
  ["--code-letter-spacing", "--code-md-letter-spacing"]
];
var CARRIED = [
  {
    prefix: "--heading-xl",
    size: "var(--font-size-4xl)",
    links: [
      { name: "--heading-xl-font-family", from: "var(--font-display)", to: "var(--heading-font-family)" },
      { name: "--heading-xl-font-weight", from: "var(--font-weight-semibold)", to: "var(--heading-font-weight)" }
    ]
  },
  {
    prefix: "--heading-lg",
    size: "var(--font-size-2xl)",
    links: [
      { name: "--heading-lg-font-family", from: "var(--font-display)", to: "var(--heading-font-family)" },
      { name: "--heading-lg-font-weight", from: "var(--font-weight-semibold)", to: "var(--heading-font-weight)" }
    ]
  },
  {
    prefix: "--heading-md",
    size: "var(--font-size-xl)",
    links: [
      { name: "--heading-md-font-family", from: "var(--font-display)", to: "var(--heading-font-family)" },
      { name: "--heading-md-font-weight", from: "var(--font-weight-semibold)", to: "var(--heading-font-weight)" }
    ]
  },
  {
    // heading-sm keeps the sans face it shipped with, so only its weight links.
    prefix: "--heading-sm",
    size: "var(--font-size-lg)",
    links: [
      { name: "--heading-sm-font-weight", from: "var(--font-weight-semibold)", to: "var(--heading-font-weight)" }
    ]
  },
  {
    prefix: "--body-md",
    size: "var(--font-size-md)",
    links: [
      { name: "--body-md-font-family", from: "var(--font-sans)", to: "var(--body-font-family)" },
      { name: "--body-md-font-weight", from: "var(--font-weight-normal)", to: "var(--body-font-weight)" }
    ]
  },
  {
    prefix: "--body-sm",
    size: "var(--font-size-sm)",
    links: [
      { name: "--body-sm-font-family", from: "var(--font-sans)", to: "var(--body-font-family)" },
      { name: "--body-sm-font-weight", from: "var(--font-weight-normal)", to: "var(--body-font-weight)" }
    ]
  },
  {
    // 0.91.2 had no code-md face or weight: `--code-font-family` and
    // `--code-font-weight` keep their names as the code usage's settings.
    prefix: "--code-md",
    size: "var(--font-size-sm)",
    links: []
  },
  {
    prefix: "--editorial-xl",
    size: "var(--font-size-xl)",
    links: [
      { name: "--editorial-xl-font-family", from: "var(--font-editorial)", to: "var(--editorial-font-family)" },
      { name: "--editorial-xl-font-weight", from: "var(--font-weight-normal)", to: "var(--editorial-font-weight)" }
    ]
  },
  {
    prefix: "--editorial-lg",
    size: "var(--font-size-lg)",
    links: [
      { name: "--editorial-lg-font-family", from: "var(--font-editorial)", to: "var(--editorial-font-family)" },
      { name: "--editorial-lg-font-weight", from: "var(--font-weight-normal)", to: "var(--editorial-font-weight)" }
    ]
  },
  {
    prefix: "--editorial-md",
    size: "var(--font-size-md)",
    links: [
      { name: "--editorial-md-font-family", from: "var(--font-editorial)", to: "var(--editorial-font-family)" },
      { name: "--editorial-md-font-weight", from: "var(--font-weight-normal)", to: "var(--editorial-font-weight)" }
    ]
  },
  {
    prefix: "--editorial-sm",
    size: "var(--font-size-sm)",
    links: [
      { name: "--editorial-sm-font-family", from: "var(--font-editorial)", to: "var(--editorial-font-family)" },
      { name: "--editorial-sm-font-weight", from: "var(--font-weight-normal)", to: "var(--editorial-font-weight)" }
    ]
  },
  {
    prefix: "--eyebrow",
    size: "var(--font-size-sm)",
    links: [
      { name: "--eyebrow-font-family", from: "var(--font-sans)", to: "var(--body-font-family)" },
      { name: "--eyebrow-font-weight", from: "var(--font-weight-normal)", to: "var(--body-font-weight)" }
    ]
  }
];
var COMPRESSION = [
  { name: "--type-tablet-scale-compression", value: "0.75" },
  { name: "--type-phone-scale-compression", value: "0.63" }
];
var COMPRESSED_VIEWPORTS = ["tablet", "phone"];
function literalRem(size) {
  const m = /^(-?\d*\.?\d+)(rem|px)$/.exec(size.trim());
  if (!m) return null;
  return m[2] === "rem" ? Number(m[1]) : Number(m[1]) / 16;
}
var ALIAS = /^var\(\s*(--[a-z0-9-]+)\s*\)$/i;
function resolvedRem(size, values) {
  const seen = /* @__PURE__ */ new Set();
  let value = size.trim();
  for (let ref2 = ALIAS.exec(value); ref2; ref2 = ALIAS.exec(value)) {
    const next = values.get(ref2[1]);
    if (next === void 0 || seen.has(ref2[1])) return null;
    seen.add(ref2[1]);
    value = next.trim();
  }
  return literalRem(value);
}
function editedSizes(prefix, rem) {
  const count = String(Number(rem.toFixed(4)));
  return COMPRESSED_VIEWPORTS.map((viewport) => ({
    name: `${prefix}-${viewport}-font-size`,
    value: `min(var(${prefix}-desktop-font-size), calc(pow(${count}, var(--type-${viewport}-scale-compression)) * 1rem))`
  }));
}
var USAGES = [
  {
    usage: "display",
    comment: "Display: type outside the page outline, such as heroes, section titles and big numbers",
    follows: "type",
    settings: [
      { name: "--display-font-family", value: "var(--font-display)" },
      { name: "--display-font-weight", value: "var(--font-weight-semibold)" },
      { name: "--display-scale-base", value: "3" },
      { name: "--display-scale-ratio", value: "1.2" }
    ],
    steps: [
      {
        prefix: "--display-2xl",
        entries: [
          { name: "--display-2xl-font-family", value: "var(--display-font-family)" },
          { name: "--display-2xl-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), 3) * 1rem)" },
          { name: "--display-2xl-tablet-font-size", value: "min(var(--display-2xl-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-2xl-phone-font-size", value: "min(var(--display-2xl-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-2xl-font-size", value: "var(--display-2xl-desktop-font-size)" },
          { name: "--display-2xl-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-2xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--display-2xl-letter-spacing", value: "var(--letter-spacing-tight)" }
        ]
      },
      {
        prefix: "--display-xl",
        entries: [
          { name: "--display-xl-font-family", value: "var(--display-font-family)" },
          { name: "--display-xl-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), 2) * 1rem)" },
          { name: "--display-xl-tablet-font-size", value: "min(var(--display-xl-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-xl-phone-font-size", value: "min(var(--display-xl-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-xl-font-size", value: "var(--display-xl-desktop-font-size)" },
          { name: "--display-xl-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--display-xl-letter-spacing", value: "var(--letter-spacing-tight)" }
        ]
      },
      {
        prefix: "--display-lg",
        entries: [
          { name: "--display-lg-font-family", value: "var(--display-font-family)" },
          { name: "--display-lg-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), 1) * 1rem)" },
          { name: "--display-lg-tablet-font-size", value: "min(var(--display-lg-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-lg-phone-font-size", value: "min(var(--display-lg-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-lg-font-size", value: "var(--display-lg-desktop-font-size)" },
          { name: "--display-lg-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-lg-line-height", value: "var(--line-height-tightest)" },
          { name: "--display-lg-letter-spacing", value: "var(--letter-spacing-tight)" }
        ]
      },
      {
        prefix: "--display-md",
        entries: [
          { name: "--display-md-font-family", value: "var(--display-font-family)" },
          { name: "--display-md-desktop-font-size", value: "calc(var(--display-scale-base) * 1rem)" },
          { name: "--display-md-tablet-font-size", value: "min(var(--display-md-desktop-font-size), calc(pow(var(--display-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-md-phone-font-size", value: "min(var(--display-md-desktop-font-size), calc(pow(var(--display-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-md-font-size", value: "var(--display-md-desktop-font-size)" },
          { name: "--display-md-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-md-line-height", value: "var(--line-height-tightest)" },
          { name: "--display-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--display-sm",
        entries: [
          { name: "--display-sm-font-family", value: "var(--display-font-family)" },
          { name: "--display-sm-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), -1) * 1rem)" },
          { name: "--display-sm-tablet-font-size", value: "min(var(--display-sm-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-sm-phone-font-size", value: "min(var(--display-sm-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-sm-font-size", value: "var(--display-sm-desktop-font-size)" },
          { name: "--display-sm-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-sm-line-height", value: "var(--line-height-tighter)" },
          { name: "--display-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--display-xs",
        entries: [
          { name: "--display-xs-font-family", value: "var(--display-font-family)" },
          { name: "--display-xs-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), -2) * 1rem)" },
          { name: "--display-xs-tablet-font-size", value: "min(var(--display-xs-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-xs-phone-font-size", value: "min(var(--display-xs-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-xs-font-size", value: "var(--display-xs-desktop-font-size)" },
          { name: "--display-xs-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-xs-line-height", value: "var(--line-height-tighter)" },
          { name: "--display-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--display-2xs",
        entries: [
          { name: "--display-2xs-font-family", value: "var(--display-font-family)" },
          { name: "--display-2xs-desktop-font-size", value: "calc(var(--display-scale-base) * pow(var(--display-scale-ratio), -3) * 1rem)" },
          { name: "--display-2xs-tablet-font-size", value: "min(var(--display-2xs-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--display-2xs-phone-font-size", value: "min(var(--display-2xs-desktop-font-size), calc(pow(var(--display-scale-base) * pow(var(--display-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--display-2xs-font-size", value: "var(--display-2xs-desktop-font-size)" },
          { name: "--display-2xs-font-weight", value: "var(--display-font-weight)" },
          { name: "--display-2xs-line-height", value: "var(--line-height-tighter)" },
          { name: "--display-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  },
  {
    usage: "heading",
    comment: "Heading: the page outline, h1 at xl down to h6 at 2xs",
    follows: "display",
    settings: [
      { name: "--heading-font-family", value: "var(--font-display)" },
      { name: "--heading-font-weight", value: "var(--font-weight-semibold)" },
      { name: "--heading-scale-base", value: "1.5" },
      { name: "--heading-scale-ratio", value: "1.25" }
    ],
    steps: [
      {
        prefix: "--heading-2xl",
        entries: [
          { name: "--heading-2xl-font-family", value: "var(--heading-font-family)" },
          { name: "--heading-2xl-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 3) * 1rem)" },
          { name: "--heading-2xl-tablet-font-size", value: "min(var(--heading-2xl-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-2xl-phone-font-size", value: "min(var(--heading-2xl-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-2xl-font-size", value: "var(--heading-2xl-desktop-font-size)" },
          { name: "--heading-2xl-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-2xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--heading-2xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-xl",
        entries: [
          { name: "--heading-xl-font-family", value: "var(--heading-font-family)" },
          { name: "--heading-xl-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 2) * 1rem)" },
          { name: "--heading-xl-tablet-font-size", value: "min(var(--heading-xl-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-xl-phone-font-size", value: "min(var(--heading-xl-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-xl-font-size", value: "var(--heading-xl-desktop-font-size)" },
          { name: "--heading-xl-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--heading-xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-lg",
        entries: [
          { name: "--heading-lg-font-family", value: "var(--heading-font-family)" },
          { name: "--heading-lg-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 1) * 1rem)" },
          { name: "--heading-lg-tablet-font-size", value: "min(var(--heading-lg-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-lg-phone-font-size", value: "min(var(--heading-lg-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-lg-font-size", value: "var(--heading-lg-desktop-font-size)" },
          { name: "--heading-lg-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-lg-line-height", value: "var(--line-height-tightest)" },
          { name: "--heading-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-md",
        entries: [
          { name: "--heading-md-font-family", value: "var(--heading-font-family)" },
          { name: "--heading-md-desktop-font-size", value: "calc(var(--heading-scale-base) * 1rem)" },
          { name: "--heading-md-tablet-font-size", value: "min(var(--heading-md-desktop-font-size), calc(pow(var(--heading-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-md-phone-font-size", value: "min(var(--heading-md-desktop-font-size), calc(pow(var(--heading-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-md-font-size", value: "var(--heading-md-desktop-font-size)" },
          { name: "--heading-md-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-md-line-height", value: "var(--line-height-tighter)" },
          { name: "--heading-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-sm",
        entries: [
          { name: "--heading-sm-font-family", value: "var(--font-sans)" },
          { name: "--heading-sm-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -1) * 1rem)" },
          { name: "--heading-sm-tablet-font-size", value: "min(var(--heading-sm-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-sm-phone-font-size", value: "min(var(--heading-sm-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-sm-font-size", value: "var(--heading-sm-desktop-font-size)" },
          { name: "--heading-sm-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-sm-line-height", value: "var(--line-height-tighter)" },
          { name: "--heading-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-xs",
        entries: [
          { name: "--heading-xs-font-family", value: "var(--font-sans)" },
          { name: "--heading-xs-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -2) * 1rem)" },
          { name: "--heading-xs-tablet-font-size", value: "min(var(--heading-xs-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-xs-phone-font-size", value: "min(var(--heading-xs-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-xs-font-size", value: "var(--heading-xs-desktop-font-size)" },
          { name: "--heading-xs-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-xs-line-height", value: "var(--line-height-tight)" },
          { name: "--heading-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--heading-2xs",
        entries: [
          { name: "--heading-2xs-font-family", value: "var(--font-sans)" },
          { name: "--heading-2xs-desktop-font-size", value: "calc(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -3) * 1rem)" },
          { name: "--heading-2xs-tablet-font-size", value: "min(var(--heading-2xs-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--heading-2xs-phone-font-size", value: "min(var(--heading-2xs-desktop-font-size), calc(pow(var(--heading-scale-base) * pow(var(--heading-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--heading-2xs-font-size", value: "var(--heading-2xs-desktop-font-size)" },
          { name: "--heading-2xs-font-weight", value: "var(--heading-font-weight)" },
          { name: "--heading-2xs-line-height", value: "var(--line-height-tight)" },
          { name: "--heading-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  },
  {
    usage: "body",
    comment: "Body: interface text and short copy",
    follows: "heading",
    settings: [
      { name: "--body-font-family", value: "var(--font-sans)" },
      { name: "--body-font-weight", value: "var(--font-weight-normal)" },
      { name: "--body-scale-base", value: "1" },
      { name: "--body-scale-ratio", value: "1.125" }
    ],
    steps: [
      {
        prefix: "--body-2xl",
        entries: [
          { name: "--body-2xl-font-family", value: "var(--body-font-family)" },
          { name: "--body-2xl-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), 3) * 1rem)" },
          { name: "--body-2xl-tablet-font-size", value: "min(var(--body-2xl-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-2xl-phone-font-size", value: "min(var(--body-2xl-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-2xl-font-size", value: "var(--body-2xl-desktop-font-size)" },
          { name: "--body-2xl-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-2xl-line-height", value: "var(--line-height-tighter)" },
          { name: "--body-2xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-xl",
        entries: [
          { name: "--body-xl-font-family", value: "var(--body-font-family)" },
          { name: "--body-xl-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), 2) * 1rem)" },
          { name: "--body-xl-tablet-font-size", value: "min(var(--body-xl-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-xl-phone-font-size", value: "min(var(--body-xl-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-xl-font-size", value: "var(--body-xl-desktop-font-size)" },
          { name: "--body-xl-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-xl-line-height", value: "var(--line-height-tighter)" },
          { name: "--body-xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-lg",
        entries: [
          { name: "--body-lg-font-family", value: "var(--body-font-family)" },
          { name: "--body-lg-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), 1) * 1rem)" },
          { name: "--body-lg-tablet-font-size", value: "min(var(--body-lg-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-lg-phone-font-size", value: "min(var(--body-lg-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-lg-font-size", value: "var(--body-lg-desktop-font-size)" },
          { name: "--body-lg-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-lg-line-height", value: "var(--line-height-tight)" },
          { name: "--body-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-md",
        entries: [
          { name: "--body-md-font-family", value: "var(--body-font-family)" },
          { name: "--body-md-desktop-font-size", value: "calc(var(--body-scale-base) * 1rem)" },
          { name: "--body-md-tablet-font-size", value: "min(var(--body-md-desktop-font-size), calc(pow(var(--body-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-md-phone-font-size", value: "min(var(--body-md-desktop-font-size), calc(pow(var(--body-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-md-font-size", value: "var(--body-md-desktop-font-size)" },
          { name: "--body-md-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-md-line-height", value: "var(--line-height-normal)" },
          { name: "--body-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-sm",
        entries: [
          { name: "--body-sm-font-family", value: "var(--body-font-family)" },
          { name: "--body-sm-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), -1) * 1rem)" },
          { name: "--body-sm-tablet-font-size", value: "min(var(--body-sm-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-sm-phone-font-size", value: "min(var(--body-sm-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-sm-font-size", value: "var(--body-sm-desktop-font-size)" },
          { name: "--body-sm-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-sm-line-height", value: "var(--line-height-tight)" },
          { name: "--body-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-xs",
        entries: [
          { name: "--body-xs-font-family", value: "var(--body-font-family)" },
          { name: "--body-xs-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), -2) * 1rem)" },
          { name: "--body-xs-tablet-font-size", value: "min(var(--body-xs-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-xs-phone-font-size", value: "min(var(--body-xs-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-xs-font-size", value: "var(--body-xs-desktop-font-size)" },
          { name: "--body-xs-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-xs-line-height", value: "var(--line-height-tight)" },
          { name: "--body-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--body-2xs",
        entries: [
          { name: "--body-2xs-font-family", value: "var(--body-font-family)" },
          { name: "--body-2xs-desktop-font-size", value: "calc(var(--body-scale-base) * pow(var(--body-scale-ratio), -3) * 1rem)" },
          { name: "--body-2xs-tablet-font-size", value: "min(var(--body-2xs-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--body-2xs-phone-font-size", value: "min(var(--body-2xs-desktop-font-size), calc(pow(var(--body-scale-base) * pow(var(--body-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--body-2xs-font-size", value: "var(--body-2xs-desktop-font-size)" },
          { name: "--body-2xs-font-weight", value: "var(--body-font-weight)" },
          { name: "--body-2xs-line-height", value: "var(--line-height-tight)" },
          { name: "--body-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  },
  {
    usage: "code",
    comment: "Code: code blocks and inline code",
    follows: "body",
    settings: [
      { name: "--code-font-family", value: "var(--font-mono)" },
      { name: "--code-font-weight", value: "var(--font-weight-normal)" },
      { name: "--code-scale-base", value: "0.875" },
      { name: "--code-scale-ratio", value: "1.125" }
    ],
    steps: [
      {
        prefix: "--code-2xl",
        entries: [
          { name: "--code-2xl-font-family", value: "var(--code-font-family)" },
          { name: "--code-2xl-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), 3) * 1rem)" },
          { name: "--code-2xl-tablet-font-size", value: "min(var(--code-2xl-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-2xl-phone-font-size", value: "min(var(--code-2xl-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-2xl-font-size", value: "var(--code-2xl-desktop-font-size)" },
          { name: "--code-2xl-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-2xl-line-height", value: "var(--line-height-normal)" },
          { name: "--code-2xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-xl",
        entries: [
          { name: "--code-xl-font-family", value: "var(--code-font-family)" },
          { name: "--code-xl-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), 2) * 1rem)" },
          { name: "--code-xl-tablet-font-size", value: "min(var(--code-xl-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-xl-phone-font-size", value: "min(var(--code-xl-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-xl-font-size", value: "var(--code-xl-desktop-font-size)" },
          { name: "--code-xl-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-xl-line-height", value: "var(--line-height-normal)" },
          { name: "--code-xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-lg",
        entries: [
          { name: "--code-lg-font-family", value: "var(--code-font-family)" },
          { name: "--code-lg-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), 1) * 1rem)" },
          { name: "--code-lg-tablet-font-size", value: "min(var(--code-lg-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-lg-phone-font-size", value: "min(var(--code-lg-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-lg-font-size", value: "var(--code-lg-desktop-font-size)" },
          { name: "--code-lg-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-lg-line-height", value: "var(--line-height-normal)" },
          { name: "--code-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-md",
        entries: [
          { name: "--code-md-font-family", value: "var(--code-font-family)" },
          { name: "--code-md-desktop-font-size", value: "calc(var(--code-scale-base) * 1rem)" },
          { name: "--code-md-tablet-font-size", value: "min(var(--code-md-desktop-font-size), calc(pow(var(--code-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-md-phone-font-size", value: "min(var(--code-md-desktop-font-size), calc(pow(var(--code-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-md-font-size", value: "var(--code-md-desktop-font-size)" },
          { name: "--code-md-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-md-line-height", value: "var(--line-height-normal)" },
          { name: "--code-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-sm",
        entries: [
          { name: "--code-sm-font-family", value: "var(--code-font-family)" },
          { name: "--code-sm-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), -1) * 1rem)" },
          { name: "--code-sm-tablet-font-size", value: "min(var(--code-sm-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-sm-phone-font-size", value: "min(var(--code-sm-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-sm-font-size", value: "var(--code-sm-desktop-font-size)" },
          { name: "--code-sm-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-sm-line-height", value: "var(--line-height-normal)" },
          { name: "--code-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-xs",
        entries: [
          { name: "--code-xs-font-family", value: "var(--code-font-family)" },
          { name: "--code-xs-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), -2) * 1rem)" },
          { name: "--code-xs-tablet-font-size", value: "min(var(--code-xs-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-xs-phone-font-size", value: "min(var(--code-xs-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-xs-font-size", value: "var(--code-xs-desktop-font-size)" },
          { name: "--code-xs-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-xs-line-height", value: "var(--line-height-normal)" },
          { name: "--code-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--code-2xs",
        entries: [
          { name: "--code-2xs-font-family", value: "var(--code-font-family)" },
          { name: "--code-2xs-desktop-font-size", value: "calc(var(--code-scale-base) * pow(var(--code-scale-ratio), -3) * 1rem)" },
          { name: "--code-2xs-tablet-font-size", value: "min(var(--code-2xs-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--code-2xs-phone-font-size", value: "min(var(--code-2xs-desktop-font-size), calc(pow(var(--code-scale-base) * pow(var(--code-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--code-2xs-font-size", value: "var(--code-2xs-desktop-font-size)" },
          { name: "--code-2xs-font-weight", value: "var(--code-font-weight)" },
          { name: "--code-2xs-line-height", value: "var(--line-height-normal)" },
          { name: "--code-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  },
  {
    usage: "editorial",
    comment: "Editorial: the long-reading role",
    follows: "code",
    settings: [
      { name: "--editorial-font-family", value: "var(--font-editorial)" },
      { name: "--editorial-font-weight", value: "var(--font-weight-normal)" },
      { name: "--editorial-scale-base", value: "1" },
      { name: "--editorial-scale-ratio", value: "1.125" }
    ],
    steps: [
      {
        prefix: "--editorial-2xl",
        entries: [
          { name: "--editorial-2xl-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-2xl-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 3) * 1rem)" },
          { name: "--editorial-2xl-tablet-font-size", value: "min(var(--editorial-2xl-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-2xl-phone-font-size", value: "min(var(--editorial-2xl-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-2xl-font-size", value: "var(--editorial-2xl-desktop-font-size)" },
          { name: "--editorial-2xl-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-2xl-line-height", value: "var(--line-height-tightest)" },
          { name: "--editorial-2xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-xl",
        entries: [
          { name: "--editorial-xl-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-xl-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 2) * 1rem)" },
          { name: "--editorial-xl-tablet-font-size", value: "min(var(--editorial-xl-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-xl-phone-font-size", value: "min(var(--editorial-xl-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-xl-font-size", value: "var(--editorial-xl-desktop-font-size)" },
          { name: "--editorial-xl-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-xl-line-height", value: "var(--line-height-tighter)" },
          { name: "--editorial-xl-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-lg",
        entries: [
          { name: "--editorial-lg-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-lg-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 1) * 1rem)" },
          { name: "--editorial-lg-tablet-font-size", value: "min(var(--editorial-lg-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-lg-phone-font-size", value: "min(var(--editorial-lg-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), 1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-lg-font-size", value: "var(--editorial-lg-desktop-font-size)" },
          { name: "--editorial-lg-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-lg-line-height", value: "var(--line-height-tight)" },
          { name: "--editorial-lg-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-md",
        entries: [
          { name: "--editorial-md-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-md-desktop-font-size", value: "calc(var(--editorial-scale-base) * 1rem)" },
          { name: "--editorial-md-tablet-font-size", value: "min(var(--editorial-md-desktop-font-size), calc(pow(var(--editorial-scale-base), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-md-phone-font-size", value: "min(var(--editorial-md-desktop-font-size), calc(pow(var(--editorial-scale-base), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-md-font-size", value: "var(--editorial-md-desktop-font-size)" },
          { name: "--editorial-md-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-md-line-height", value: "var(--line-height-normal)" },
          { name: "--editorial-md-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-sm",
        entries: [
          { name: "--editorial-sm-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-sm-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -1) * 1rem)" },
          { name: "--editorial-sm-tablet-font-size", value: "min(var(--editorial-sm-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -1), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-sm-phone-font-size", value: "min(var(--editorial-sm-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -1), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-sm-font-size", value: "var(--editorial-sm-desktop-font-size)" },
          { name: "--editorial-sm-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-sm-line-height", value: "var(--line-height-tight)" },
          { name: "--editorial-sm-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-xs",
        entries: [
          { name: "--editorial-xs-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-xs-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -2) * 1rem)" },
          { name: "--editorial-xs-tablet-font-size", value: "min(var(--editorial-xs-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -2), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-xs-phone-font-size", value: "min(var(--editorial-xs-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -2), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-xs-font-size", value: "var(--editorial-xs-desktop-font-size)" },
          { name: "--editorial-xs-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-xs-line-height", value: "var(--line-height-tighter)" },
          { name: "--editorial-xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      },
      {
        prefix: "--editorial-2xs",
        entries: [
          { name: "--editorial-2xs-font-family", value: "var(--editorial-font-family)" },
          { name: "--editorial-2xs-desktop-font-size", value: "calc(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -3) * 1rem)" },
          { name: "--editorial-2xs-tablet-font-size", value: "min(var(--editorial-2xs-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -3), var(--type-tablet-scale-compression)) * 1rem))" },
          { name: "--editorial-2xs-phone-font-size", value: "min(var(--editorial-2xs-desktop-font-size), calc(pow(var(--editorial-scale-base) * pow(var(--editorial-scale-ratio), -3), var(--type-phone-scale-compression)) * 1rem))" },
          { name: "--editorial-2xs-font-size", value: "var(--editorial-2xs-desktop-font-size)" },
          { name: "--editorial-2xs-font-weight", value: "var(--editorial-font-weight)" },
          { name: "--editorial-2xs-line-height", value: "var(--line-height-tighter)" },
          { name: "--editorial-2xs-letter-spacing", value: "var(--letter-spacing-normal)" }
        ]
      }
    ]
  }
];
var EYEBROW = [
  { name: "--eyebrow-font-family", value: "var(--body-font-family)" },
  { name: "--eyebrow-desktop-font-size", value: "var(--body-sm-desktop-font-size)" },
  { name: "--eyebrow-tablet-font-size", value: "var(--body-sm-tablet-font-size)" },
  { name: "--eyebrow-phone-font-size", value: "var(--body-sm-phone-font-size)" },
  { name: "--eyebrow-font-size", value: "var(--eyebrow-desktop-font-size)" },
  { name: "--eyebrow-font-weight", value: "var(--body-font-weight)" },
  { name: "--eyebrow-line-height", value: "var(--line-height-normal)" },
  { name: "--eyebrow-letter-spacing", value: "var(--letter-spacing-normal)" },
  { name: "--eyebrow-text-transform", value: "none" }
];
var MEDIA = [
  {
    query: "(max-width: 768px)",
    entries: [
      { name: "--display-2xl-font-size", value: "var(--display-2xl-tablet-font-size)" },
      { name: "--display-xl-font-size", value: "var(--display-xl-tablet-font-size)" },
      { name: "--display-lg-font-size", value: "var(--display-lg-tablet-font-size)" },
      { name: "--display-md-font-size", value: "var(--display-md-tablet-font-size)" },
      { name: "--display-sm-font-size", value: "var(--display-sm-tablet-font-size)" },
      { name: "--display-xs-font-size", value: "var(--display-xs-tablet-font-size)" },
      { name: "--display-2xs-font-size", value: "var(--display-2xs-tablet-font-size)" },
      { name: "--heading-2xl-font-size", value: "var(--heading-2xl-tablet-font-size)" },
      { name: "--heading-xl-font-size", value: "var(--heading-xl-tablet-font-size)" },
      { name: "--heading-lg-font-size", value: "var(--heading-lg-tablet-font-size)" },
      { name: "--heading-md-font-size", value: "var(--heading-md-tablet-font-size)" },
      { name: "--heading-sm-font-size", value: "var(--heading-sm-tablet-font-size)" },
      { name: "--heading-xs-font-size", value: "var(--heading-xs-tablet-font-size)" },
      { name: "--heading-2xs-font-size", value: "var(--heading-2xs-tablet-font-size)" },
      { name: "--body-2xl-font-size", value: "var(--body-2xl-tablet-font-size)" },
      { name: "--body-xl-font-size", value: "var(--body-xl-tablet-font-size)" },
      { name: "--body-lg-font-size", value: "var(--body-lg-tablet-font-size)" },
      { name: "--body-md-font-size", value: "var(--body-md-tablet-font-size)" },
      { name: "--body-sm-font-size", value: "var(--body-sm-tablet-font-size)" },
      { name: "--body-xs-font-size", value: "var(--body-xs-tablet-font-size)" },
      { name: "--body-2xs-font-size", value: "var(--body-2xs-tablet-font-size)" },
      { name: "--editorial-2xl-font-size", value: "var(--editorial-2xl-tablet-font-size)" },
      { name: "--editorial-xl-font-size", value: "var(--editorial-xl-tablet-font-size)" },
      { name: "--editorial-lg-font-size", value: "var(--editorial-lg-tablet-font-size)" },
      { name: "--editorial-md-font-size", value: "var(--editorial-md-tablet-font-size)" },
      { name: "--editorial-sm-font-size", value: "var(--editorial-sm-tablet-font-size)" },
      { name: "--editorial-xs-font-size", value: "var(--editorial-xs-tablet-font-size)" },
      { name: "--editorial-2xs-font-size", value: "var(--editorial-2xs-tablet-font-size)" },
      { name: "--code-2xl-font-size", value: "var(--code-2xl-tablet-font-size)" },
      { name: "--code-xl-font-size", value: "var(--code-xl-tablet-font-size)" },
      { name: "--code-lg-font-size", value: "var(--code-lg-tablet-font-size)" },
      { name: "--code-md-font-size", value: "var(--code-md-tablet-font-size)" },
      { name: "--code-sm-font-size", value: "var(--code-sm-tablet-font-size)" },
      { name: "--code-xs-font-size", value: "var(--code-xs-tablet-font-size)" },
      { name: "--code-2xs-font-size", value: "var(--code-2xs-tablet-font-size)" },
      { name: "--eyebrow-font-size", value: "var(--eyebrow-tablet-font-size)" }
    ]
  },
  {
    query: "(max-width: 480px)",
    entries: [
      { name: "--display-2xl-font-size", value: "var(--display-2xl-phone-font-size)" },
      { name: "--display-xl-font-size", value: "var(--display-xl-phone-font-size)" },
      { name: "--display-lg-font-size", value: "var(--display-lg-phone-font-size)" },
      { name: "--display-md-font-size", value: "var(--display-md-phone-font-size)" },
      { name: "--display-sm-font-size", value: "var(--display-sm-phone-font-size)" },
      { name: "--display-xs-font-size", value: "var(--display-xs-phone-font-size)" },
      { name: "--display-2xs-font-size", value: "var(--display-2xs-phone-font-size)" },
      { name: "--heading-2xl-font-size", value: "var(--heading-2xl-phone-font-size)" },
      { name: "--heading-xl-font-size", value: "var(--heading-xl-phone-font-size)" },
      { name: "--heading-lg-font-size", value: "var(--heading-lg-phone-font-size)" },
      { name: "--heading-md-font-size", value: "var(--heading-md-phone-font-size)" },
      { name: "--heading-sm-font-size", value: "var(--heading-sm-phone-font-size)" },
      { name: "--heading-xs-font-size", value: "var(--heading-xs-phone-font-size)" },
      { name: "--heading-2xs-font-size", value: "var(--heading-2xs-phone-font-size)" },
      { name: "--body-2xl-font-size", value: "var(--body-2xl-phone-font-size)" },
      { name: "--body-xl-font-size", value: "var(--body-xl-phone-font-size)" },
      { name: "--body-lg-font-size", value: "var(--body-lg-phone-font-size)" },
      { name: "--body-md-font-size", value: "var(--body-md-phone-font-size)" },
      { name: "--body-sm-font-size", value: "var(--body-sm-phone-font-size)" },
      { name: "--body-xs-font-size", value: "var(--body-xs-phone-font-size)" },
      { name: "--body-2xs-font-size", value: "var(--body-2xs-phone-font-size)" },
      { name: "--editorial-2xl-font-size", value: "var(--editorial-2xl-phone-font-size)" },
      { name: "--editorial-xl-font-size", value: "var(--editorial-xl-phone-font-size)" },
      { name: "--editorial-lg-font-size", value: "var(--editorial-lg-phone-font-size)" },
      { name: "--editorial-md-font-size", value: "var(--editorial-md-phone-font-size)" },
      { name: "--editorial-sm-font-size", value: "var(--editorial-sm-phone-font-size)" },
      { name: "--editorial-xs-font-size", value: "var(--editorial-xs-phone-font-size)" },
      { name: "--editorial-2xs-font-size", value: "var(--editorial-2xs-phone-font-size)" },
      { name: "--code-2xl-font-size", value: "var(--code-2xl-phone-font-size)" },
      { name: "--code-xl-font-size", value: "var(--code-xl-phone-font-size)" },
      { name: "--code-lg-font-size", value: "var(--code-lg-phone-font-size)" },
      { name: "--code-md-font-size", value: "var(--code-md-phone-font-size)" },
      { name: "--code-sm-font-size", value: "var(--code-sm-phone-font-size)" },
      { name: "--code-xs-font-size", value: "var(--code-xs-phone-font-size)" },
      { name: "--code-2xs-font-size", value: "var(--code-2xs-phone-font-size)" },
      { name: "--eyebrow-font-size", value: "var(--eyebrow-phone-font-size)" }
    ]
  }
];
var DECLARED = new Map(
  USAGES.flatMap((u) => u.steps.flatMap((s) => s.entries)).concat(EYEBROW).map((e) => [e.name, e.value])
);
var TYPE_PRIMITIVES = ["--letter-spacing-", "--line-height-", "--font-weight-", "--font-size-", "--font-"];
var CARRIED_PREFIXES = new Set(CARRIED.map((step) => step.prefix));
function handDeclaredSteps(values) {
  return USAGES.flatMap((u) => u.steps).filter(
    ({ prefix }) => !CARRIED_PREFIXES.has(prefix) && values.has(`${prefix}-font-size`) && !values.has(`${prefix}-desktop-font-size`)
  ).map(({ prefix }) => ({ prefix, links: [] }));
}
var tokensCssMigration_2026_10_08_typeScales = {
  id: "2026-10-08-type-scales",
  kind: "breaking",
  description: "Rebuild the text styles as five type scales with per-viewport sizes, and rename --code-font-size, --code-line-height and --code-letter-spacing to --code-md-*",
  apply(css) {
    let out = css;
    for (const [from, to] of RENAMES15) out = renameToken2(out, from, to);
    const values = collectTokenValues(out);
    for (const step of [...CARRIED, ...handDeclaredSteps(values)]) {
      const size = values.get(`${step.prefix}-font-size`);
      if (size === void 0) continue;
      const desktop = `${step.prefix}-desktop-font-size`;
      const edited = size !== step.size;
      const rem = edited ? resolvedRem(size, values) : null;
      out = ensureScale(out, {
        anchorPrefixes: [`${step.prefix}-font-family`, `${step.prefix}-`],
        entries: [
          { name: desktop, value: edited ? size : DECLARED.get(desktop) },
          ...rem === null ? [] : editedSizes(step.prefix, rem)
        ]
      });
      out = setTokenValue(out, `${step.prefix}-font-size`, `var(${desktop})`);
      for (const link of step.links) out = setTokenValue(out, link.name, link.to, { from: link.from });
    }
    out = ensureScale(out, {
      sectionComment: "Text styles: the compression that sets each tablet and phone size",
      anchorPrefixes: ["--type-", ...TYPE_PRIMITIVES],
      entries: COMPRESSION
    });
    for (const block of USAGES) {
      const fallback = [`--${block.usage}-scale-`, `--${block.follows}-`, "--type-"];
      out = ensureScale(out, { sectionComment: block.comment, anchorPrefixes: fallback, entries: block.settings });
      block.steps.forEach((step, i) => {
        const above = block.steps.slice(0, i).reverse().map((s) => `${s.prefix}-`);
        out = ensureScale(out, {
          anchorPrefixes: [
            `${step.prefix}-desktop-font-size`,
            `${step.prefix}-font-family`,
            `${step.prefix}-`,
            ...above,
            ...fallback
          ],
          entries: step.entries
        });
      });
    }
    out = ensureScale(out, {
      anchorPrefixes: ["--eyebrow-desktop-font-size", "--eyebrow-font-family", "--eyebrow-", "--editorial-"],
      entries: EYEBROW
    });
    for (const media of MEDIA) out = appendMediaBlock(out, media.query, media.entries);
    return out;
  }
};

// vite-plugin/tokensCssMigrations/migrations/2026-10-15-responsive-columns.ts
var DESKTOP = [
  {
    structural: "--columns-gutter",
    desktop: "--columns-desktop-gutter",
    shipped: "clamp(0.5rem, 1.5vw, 1.5rem)",
    value: "32px"
  },
  { structural: "--columns-margin", desktop: "--columns-desktop-margin", shipped: "0", value: "32px" }
];
var SMALLER = [
  { name: "--columns-tablet-gutter", value: "24px" },
  { name: "--columns-tablet-margin", value: "24px" },
  { name: "--columns-phone-gutter", value: "16px" },
  { name: "--columns-phone-margin", value: "16px" }
];
var repoints = (viewport) => DESKTOP.map(({ structural }) => ({
  name: structural,
  value: `var(${structural.replace("--columns-", `--columns-${viewport}-`)})`
}));
var tokensCssMigration_2026_10_15_responsiveColumns = {
  id: "2026-10-15-responsive-columns",
  kind: "breaking",
  description: "Give the column grid a gutter and margin per viewport, and re-point --columns-gutter and --columns-margin at them",
  apply(css) {
    const values = collectTokenValues(css);
    const pending = DESKTOP.filter(({ desktop }) => !values.has(desktop));
    let out = ensureScale(css, {
      anchorPrefixes: ["--columns-"],
      entries: [
        ...pending.map(({ structural, desktop, shipped, value }) => {
          const current = values.get(structural);
          return { name: desktop, value: current === void 0 || current === shipped ? value : current };
        }),
        ...SMALLER
      ]
    });
    for (const { structural, desktop } of pending) out = setTokenValue(out, structural, `var(${desktop})`);
    out = ensureScale(out, { anchorPrefixes: ["--columns-"], entries: repoints("desktop") });
    out = appendMediaBlock(out, "(max-width: 767px)", repoints("tablet"), { before: "(max-width: 480px)" });
    return appendMediaBlock(out, "(max-width: 480px)", repoints("phone"));
  }
};

// vite-plugin/tokensCssMigrations/index.ts
var TOKENS_CSS_MIGRATIONS = [
  tokensCssMigration_2026_05_29_typographyScaleAdditions,
  tokensCssMigration_2026_05_29_sectiondividerLegacyAxisCleanup,
  tokensCssMigration_2026_06_03_transformScaleAdditions,
  tokensCssMigration_2026_06_04_removeDeadSizeIconScale,
  tokensCssMigration_2026_06_04_easingColorAndTypescaleAdditions,
  tokensCssMigration_2026_07_20_lineHeightRename,
  tokensCssMigration_2026_07_20_semanticTextStyles,
  tokensCssMigration_2026_08_19_oklchColorValues,
  tokensCssMigration_2026_08_25_editorialTypeRole,
  tokensCssMigration_2026_08_26_gradientStops,
  tokensCssMigration_2026_08_27_backdropPolarity,
  tokensCssMigration_2026_08_27_editorialSizeSteps,
  tokensCssMigration_2026_08_27_editorialLargeSteps,
  tokensCssMigration_2026_09_01_scrimRename,
  tokensCssMigration_2026_09_01_tintScale,
  tokensCssMigration_2026_09_20_scrimColorAndOpacity,
  tokensCssMigration_2026_09_21_tintColorAndOpacity,
  tokensCssMigration_2026_10_08_typeScales,
  tokensCssMigration_2026_10_15_responsiveColumns
];
function runTokensCssMigrations(css) {
  return foldMigrations(css, () => true);
}
function runAdditiveTokensCssMigrations(css) {
  return foldMigrations(css, (m) => m.kind === "additive");
}
function foldMigrations(css, include) {
  let out = css;
  const applied = [];
  for (const m of TOKENS_CSS_MIGRATIONS) {
    if (!include(m)) continue;
    const next = m.apply(out);
    if (next !== out) {
      applied.push(m.id);
      out = next;
    }
  }
  return { css: out, applied, changed: out !== css };
}
function validateTokensCss(input) {
  const defined = /* @__PURE__ */ new Set([
    ...collectDefinedTokens(input.tokensCss),
    ...collectDefinedTokens(input.generatedCss ?? "")
  ]);
  const referencedBy = /* @__PURE__ */ new Map();
  for (const { name, source } of input.componentSources) {
    const body = extractGlobalRootBody(source);
    if (!body) continue;
    for (const t of collectDefinedTokens(body)) defined.add(t);
    for (const ref2 of collectReferencedTokens(body)) {
      let set = referencedBy.get(ref2);
      if (!set) referencedBy.set(ref2, set = /* @__PURE__ */ new Set());
      set.add(name);
    }
  }
  const missing = [];
  for (const [token, names] of referencedBy) {
    if (!defined.has(token)) {
      missing.push({ token, referencedBy: [...names].sort() });
    }
  }
  return missing.sort((a, b) => a.token.localeCompare(b.token));
}

// vite-plugin/buildChecks.ts
var import_node_path = __toESM(require("path"), 1);
var import_node_url = require("url");
var import_meta = {};
var runPackageChecks = async (root) => {
  const runner = import_node_path.default.resolve(import_node_path.default.dirname((0, import_node_url.fileURLToPath)(import_meta.url)), "..", "bin", "lib", "buildChecks.mjs");
  const { runBuildChecks } = await import((0, import_node_url.pathToFileURL)(runner).href);
  return runBuildChecks({ root });
};
async function checkBeforeBuild({
  root,
  logger,
  run = runPackageChecks
}) {
  const result = await run(root);
  if (result.errors > 0) {
    logger.error(result.report);
    return `live-tokens: the design checks found ${result.errors} error(s). Run the live-tokens-check-compliance skill, or \`npx live-tokens check-page\` and \`npx live-tokens check-component\`, to repair them.`;
  }
  (result.warnings > 0 ? logger.warn : logger.info).call(logger, result.report);
  return null;
}

// vite-plugin/productionCss/index.ts
var import_node_crypto = require("crypto");

// vite-plugin/productionCss/analyze.ts
var import_postcss = __toESM(require("postcss"), 1);
var ROOT_SPECIFICITY = /* @__PURE__ */ new Map([
  [":root", [0, 1, 0]],
  [":root:root", [0, 2, 0]],
  [":where(:root)", [0, 0, 0]],
  ["html", [0, 0, 1]]
]);
var NAME = String.raw`--(?:[\w-]|[^\x00-\x7f])+`;
var VAR_REF = new RegExp(String.raw`var\(\s*(${NAME})`, "gi");
var PRELUDE_NAME = new RegExp(NAME, "g");
var SCRIPT_NAME = new RegExp(String.raw`(?<![\w-])${NAME}`, "g");
var CSS_WIDE_KEYWORD = /^\s*(?:initial|inherit|unset|revert|revert-layer)\s*$/i;
var varRefs = (value) => [...value.matchAll(VAR_REF)].map((m) => m[1]);
function compareSpecificity(a, b) {
  return a[0] - b[0] || a[1] - b[1] || a[2] - b[2];
}
function rootSpecificity(selector) {
  let best = null;
  for (const part of selector.split(",")) {
    const specificity = ROOT_SPECIFICITY.get(part.trim());
    if (!specificity) return null;
    if (!best || compareSpecificity(specificity, best) > 0) best = specificity;
  }
  return best;
}
function outranks(a, b) {
  if (a.important !== b.important) return a.important;
  const bySpecificity = compareSpecificity(a.specificity, b.specificity);
  if (bySpecificity !== 0) return bySpecificity > 0;
  return a.asset !== b.asset ? a.asset > b.asset : a.order > b.order;
}
function winnerOf(declarations) {
  let winner = null;
  for (const d of declarations) if (d.bare && (!winner || outranks(d, winner))) winner = d;
  return winner;
}
function analyze({ css, js, html, keep, entries }) {
  const declarations = /* @__PURE__ */ new Map();
  const regularRefs = /* @__PURE__ */ new Set();
  const preludeNames = /* @__PURE__ */ new Set();
  const registered = /* @__PURE__ */ new Set();
  const reads = css.map(() => /* @__PURE__ */ new Set());
  css.forEach((source, asset) => {
    let order = 0;
    import_postcss.default.parse(source).walk((node) => {
      if (node.type === "atrule") {
        if (node.name.toLowerCase() === "property") registered.add(node.params.trim());
        for (const [name] of node.params.matchAll(PRELUDE_NAME)) preludeNames.add(name);
        return;
      }
      if (node.type !== "decl") return;
      const refs = varRefs(node.value);
      for (const name of refs) reads[asset].add(name);
      if (!node.prop.startsWith("--")) {
        for (const name of refs) regularRefs.add(name);
        return;
      }
      let selector = null;
      let outerRule = false;
      const atRules = [];
      for (let p = node.parent; p && p.type !== "root"; p = p.parent) {
        if (p.type === "atrule") {
          const at = p;
          atRules.unshift(`@${at.name} ${at.params}`.trim());
        } else if (p.type === "rule") {
          if (selector === null) selector = p.selector;
          else outerRule = true;
        }
      }
      const specificity = selector === null ? null : rootSpecificity(selector);
      const declaration = {
        asset,
        order: order++,
        selector,
        atRules,
        value: node.value,
        important: node.important,
        root: specificity !== null,
        bare: specificity !== null && atRules.length === 0 && !outerRule,
        specificity
      };
      const list = declarations.get(node.prop);
      if (list) list.push(declaration);
      else declarations.set(node.prop, [declaration]);
    });
  });
  const scriptNames = /* @__PURE__ */ new Set();
  for (const text2 of [...js, ...html]) {
    for (const [name] of text2.matchAll(SCRIPT_NAME)) scriptNames.add(name);
  }
  const keepNames = new Set(keep);
  const references = /* @__PURE__ */ new Map();
  for (const [name, decls] of declarations) {
    references.set(name, new Set(decls.flatMap((d) => varRefs(d.value))));
  }
  const reached = /* @__PURE__ */ new Set();
  const toReach = [...regularRefs, ...preludeNames, ...scriptNames, ...keepNames];
  while (toReach.length) {
    const name = toReach.pop();
    if (reached.has(name)) continue;
    reached.add(name);
    for (const ref2 of references.get(name) ?? []) toReach.push(ref2);
  }
  const loops = /* @__PURE__ */ new Map();
  const reachesCycle = (name) => {
    const state = loops.get(name);
    if (state !== void 0) return state !== false;
    loops.set(name, "visiting");
    let result2 = false;
    for (const ref2 of references.get(name) ?? []) {
      if (declarations.has(ref2) && reachesCycle(ref2)) result2 = true;
    }
    loops.set(name, result2);
    return result2;
  };
  const setByName = (name) => scriptNames.has(name) || keepNames.has(name) || registered.has(name);
  const entryAssets = new Set(entries);
  const winners = /* @__PURE__ */ new Map();
  const reasons = /* @__PURE__ */ new Map();
  for (const [name, decls] of declarations) {
    const winner = winnerOf(decls);
    winners.set(name, winner);
    const bare = decls.filter((d) => d.bare);
    const why = [];
    if (decls.some((d) => !d.bare)) why.push("scoped");
    if (scriptNames.has(name)) why.push("script");
    if (preludeNames.has(name)) why.push("prelude");
    if (registered.has(name)) why.push("registered");
    if (keepNames.has(name)) why.push("keep");
    if (winner && CSS_WIDE_KEYWORD.test(winner.value)) why.push("keyword");
    if (reachesCycle(name)) why.push("cycle");
    if (new Set(bare.map((d) => d.asset)).size > 1 && new Set(bare.map((d) => d.value)).size > 1) {
      why.push("assets");
    }
    if ([...references.get(name)].some((ref2) => !declarations.has(ref2) && !setByName(ref2))) why.push("undeclared");
    const declaring = new Set(decls.map((d) => d.asset));
    if (![...declaring].some((asset) => entryAssets.has(asset)) && reads.some((names, asset) => !declaring.has(asset) && names.has(name))) {
      why.push("lazy");
    }
    reasons.set(name, why);
  }
  const dependents = /* @__PURE__ */ new Map();
  for (const [name, refs] of references) {
    for (const ref2 of refs) {
      const list = dependents.get(ref2);
      if (list) list.push(name);
      else dependents.set(ref2, [name]);
    }
  }
  const dynamic = /* @__PURE__ */ new Set();
  const toSpread = [
    ...[...reasons].filter(([, why]) => why.length > 0).map(([name]) => name),
    ...scriptNames,
    ...keepNames,
    ...registered
  ];
  while (toSpread.length) {
    const name = toSpread.pop();
    if (dynamic.has(name)) continue;
    dynamic.add(name);
    for (const dependent of dependents.get(name) ?? []) toSpread.push(dependent);
  }
  const result = /* @__PURE__ */ new Map();
  for (const [name, decls] of declarations) {
    const refs = [...references.get(name)];
    const why = reasons.get(name);
    if (refs.some((ref2) => dynamic.has(ref2))) why.push("reference");
    result.set(name, {
      declarations: decls,
      references: refs,
      reached: reached.has(name),
      dynamic: why.length > 0,
      reasons: why,
      winner: winners.get(name)
    });
  }
  return result;
}

// vite-plugin/productionCss/rewrite.ts
var import_postcss2 = __toESM(require("postcss"), 1);
var TOKEN_BEFORE_FUNCTION = /[\w\-#@\\]|[^\x00-\x7f]/;
var VAR_NAME = /^\s*(--(?:[\w-]|[^\x00-\x7f])+)\s*(?:,|$)/;
var JOINS_LEFT = /[\w\-#@.+\\]|[^\x00-\x7f]/;
var JOINS_RIGHT = /[\w\-.+%(\\]|[^\x00-\x7f]/;
var EMPTIED_AT_RULES = /* @__PURE__ */ new Set(["media", "supports", "container"]);
var DESCRIPTOR_AT_RULES = /* @__PURE__ */ new Set(["font-face", "property", "counter-style", "font-palette-values"]);
function skipString(value, start) {
  const quote = value[start];
  let i = start + 1;
  while (i < value.length && value[i] !== quote) i += value[i] === "\\" ? 2 : 1;
  return i + 1;
}
function skipComment(value, start) {
  const end = value.indexOf("*/", start + 2);
  return end < 0 ? value.length : end + 2;
}
function closingParen(value, open) {
  let depth = 0;
  let i = open;
  while (i < value.length) {
    const c = value[i];
    if (c === '"' || c === "'") i = skipString(value, i);
    else if (c === "/" && value[i + 1] === "*") i = skipComment(value, i);
    else {
      if (c === "\\") i += 1;
      else if (c === "(") depth += 1;
      else if (c === ")" && --depth === 0) return i;
      i += 1;
    }
  }
  return -1;
}
function afterUrl(value, start) {
  let i = start;
  while (/\s/.test(value[i] ?? "")) i += 1;
  if (value[i] === '"' || value[i] === "'") {
    const close = closingParen(value, start - 1);
    return close < 0 ? value.length : close + 1;
  }
  while (i < value.length && value[i] !== ")") i += value[i] === "\\" ? 2 : 1;
  return i + 1;
}
function functionAt(value, i, name) {
  return value.slice(i, i + name.length).toLowerCase() === name && (i === 0 || !TOKEN_BEFORE_FUNCTION.test(value[i - 1]));
}
function breaksBetween(left, right) {
  if (!left || !right) return false;
  return JOINS_LEFT.test(left) && JOINS_RIGHT.test(right) || left === "/" && right === "*";
}
function spliced(before, text2, after) {
  if (text2 === "") return breaksBetween(before, after) ? "/**/" : "";
  const head = breaksBetween(before, text2[0]) ? "/**/" : "";
  const tail = breaksBetween(text2[text2.length - 1], after) ? "/**/" : "";
  return head + text2 + tail;
}
function substituteValue(value, valueOf) {
  let out = "";
  let copied = 0;
  let i = 0;
  while (i < value.length) {
    const c = value[i];
    if (c === '"' || c === "'") {
      i = skipString(value, i);
    } else if (c === "/" && value[i + 1] === "*") {
      i = skipComment(value, i);
    } else if (c === "\\") {
      i += 2;
    } else if (functionAt(value, i, "url(")) {
      i = afterUrl(value, i + 4);
    } else if (functionAt(value, i, "var(")) {
      const close = closingParen(value, i + 3);
      if (close < 0) break;
      const args = value.slice(i + 4, close);
      const name = VAR_NAME.exec(args)?.[1];
      const replacement = name === void 0 ? void 0 : valueOf(name);
      out += value.slice(copied, i);
      out += replacement === void 0 ? `${value.slice(i, i + 4)}${substituteValue(args, valueOf)})` : spliced(out[out.length - 1], replacement, value[close + 1]);
      copied = i = close + 1;
    } else {
      i += 1;
    }
  }
  return out + value.slice(copied);
}
function staticValues(analysis) {
  const values = /* @__PURE__ */ new Map();
  const valueOf = (name) => {
    const property = analysis.get(name);
    if (!property || property.dynamic) return void 0;
    let value = values.get(name);
    if (value === void 0) {
      value = substituteValue(property.winner.value.trim(), valueOf);
      values.set(name, value);
    }
    return value;
  };
  for (const [name, property] of analysis) if (property.reached) valueOf(name);
  return values;
}
function droppedDeclarations(analysis, asset, { substitute }) {
  const dropped = /* @__PURE__ */ new Set();
  for (const property of analysis.values()) {
    const own = property.declarations.filter((d) => d.asset === asset);
    if (!property.reached || substitute && !property.dynamic) {
      for (const d of own) dropped.add(d.order);
      continue;
    }
    const winner = winnerOf(own);
    for (const d of own) if (d.bare && d !== winner) dropped.add(d.order);
  }
  return dropped;
}
var isDescriptor = (decl) => decl.parent instanceof import_postcss2.AtRule && DESCRIPTOR_AT_RULES.has(decl.parent.name.toLowerCase());
var removableWhenEmpty = (node) => node instanceof import_postcss2.Rule || node instanceof import_postcss2.AtRule && EMPTIED_AT_RULES.has(node.name.toLowerCase());
function removeEmptied(containers) {
  for (const container of containers) {
    let node = container;
    while (removableWhenEmpty(node) && node.nodes?.length === 0) {
      const parent = node.parent;
      node.remove();
      node = parent;
    }
  }
}
function rewrite(css, asset, analysis, options, values = options.substitute ? staticValues(analysis) : null) {
  const dropped = droppedDeclarations(analysis, asset, options);
  const root = import_postcss2.default.parse(css);
  const emptied = /* @__PURE__ */ new Set();
  let order = 0;
  root.walkDecls((decl) => {
    if (decl.prop.startsWith("--") && dropped.has(order++)) {
      emptied.add(decl.parent);
      decl.remove();
      return;
    }
    if (!values || isDescriptor(decl)) return;
    const value = substituteValue(decl.value, (name) => values.get(name));
    if (value !== decl.value) decl.value = value;
  });
  removeEmptied(emptied);
  return root.toString();
}

// vite-plugin/productionCss/index.ts
var text = (source) => typeof source === "string" ? source : new TextDecoder().decode(source);
var HASH = /\[hash(?::(\d+))?\]/;
var PLACEHOLDER = /\[(name|hash(?::\d+)?|ext|extname|format)\]/g;
var escape = (literal) => literal.replace(/[.*+?^${}()|[\]\\/]/g, "\\$&");
var TEXT_ASSET = /\.(css|html|json|map)$/;
function hashedFileName(fileName, pattern, content) {
  const hash = HASH.exec(pattern);
  if (!hash) return null;
  const length = hash[1] ? Number(hash[1]) : 8;
  let regex = "^";
  let last = 0;
  for (const m of pattern.matchAll(PLACEHOLDER)) {
    regex += escape(pattern.slice(last, m.index));
    if (m.index === hash.index) regex += `([A-Za-z0-9_-]{${length}})`;
    else if (m[1] === "ext") regex += "[^./]*";
    else if (m[1] === "extname") regex += "(?:\\.[^./]*)?";
    else regex += ".*?";
    last = m.index + m[0].length;
  }
  regex += escape(pattern.slice(last)) + "$";
  const match = new RegExp(regex, "d").exec(fileName);
  if (!match?.indices?.[1]) throw new Error(`live-tokens: ${fileName} does not follow the output pattern "${pattern}"`);
  const [start, end] = match.indices[1];
  const digest = (0, import_node_crypto.createHash)("sha256").update(content).digest("base64url").slice(0, length);
  return fileName.slice(0, start) + digest + fileName.slice(end);
}
function tails(from, to) {
  let i = 0;
  while (from[i] === to[i]) i += 1;
  const start = from.lastIndexOf("/", i) + 1;
  return [from.slice(start), to.slice(start)];
}
function repoint(files, renames) {
  const pairs = [...renames].map(([from, to]) => tails(from, to));
  const replace = (s) => {
    for (const [from, to] of pairs) s = s.replaceAll(from, () => to);
    return s;
  };
  const renamed = (names) => names.map((name) => renames.get(name) ?? name);
  const changed = /* @__PURE__ */ new Set();
  for (const file of files) {
    if (file.type === "chunk") {
      const code = replace(file.code);
      if (code !== file.code) {
        file.code = code;
        changed.add(file);
      }
      if (file.imports.some((name) => renames.has(name))) file.imports = renamed(file.imports);
      if (file.dynamicImports.some((name) => renames.has(name))) file.dynamicImports = renamed(file.dynamicImports);
      const map = file.sourcemapFileName && replace(file.sourcemapFileName);
      if (map && map !== file.sourcemapFileName) file.sourcemapFileName = map;
      const imported = file.viteMetadata?.importedCss;
      if (imported && [...imported].some((name) => renames.has(name))) {
        const next = renamed([...imported]);
        imported.clear();
        for (const name of next) imported.add(name);
        changed.add(file);
      }
    } else if (TEXT_ASSET.test(file.fileName)) {
      const before = text(file.source);
      const after = replace(before);
      if (after !== before) file.source = after;
    }
    const fileName = replace(file.fileName);
    if (fileName !== file.fileName) file.fileName = fileName;
  }
  return changed;
}
function renameRewritten(files, sheetRenames, names) {
  const affected = repoint(files, sheetRenames);
  const chunks = files.filter((f) => f.type === "chunk");
  const byName = new Map(chunks.map((c) => [c.fileName, c]));
  const imported = (c) => [...c.imports, ...c.dynamicImports].flatMap((name) => byName.get(name) ?? []);
  for (let grew = true; grew; ) {
    grew = false;
    for (const chunk of chunks) {
      if (!affected.has(chunk) && imported(chunk).some((c) => affected.has(c))) {
        affected.add(chunk);
        grew = true;
      }
    }
  }
  const identity = (c) => [c.code, ...c.viteMetadata?.importedCss ?? []].join("\0");
  const chunkRenames = /* @__PURE__ */ new Map();
  for (const chunk of affected) {
    const reached = /* @__PURE__ */ new Set([chunk]);
    const toVisit = [chunk];
    while (toVisit.length) {
      for (const next of imported(toVisit.pop())) {
        if (!reached.has(next)) {
          reached.add(next);
          toVisit.push(next);
        }
      }
    }
    reached.delete(chunk);
    const others = [...reached].sort((a, b) => a.fileName < b.fileName ? -1 : 1);
    const fileNames = chunk.isEntry ? names.entryFileNames : names.chunkFileNames;
    const pattern = typeof fileNames === "string" ? fileNames : fileNames({
      name: chunk.name,
      isEntry: chunk.isEntry,
      isDynamicEntry: chunk.isDynamicEntry,
      facadeModuleId: chunk.facadeModuleId ?? void 0,
      moduleIds: chunk.moduleIds,
      exports: chunk.exports
    });
    const renamed = hashedFileName(chunk.fileName, pattern, [chunk, ...others].map(identity).join("\0\0"));
    if (renamed !== null && renamed !== chunk.fileName) chunkRenames.set(chunk.fileName, renamed);
  }
  if (chunkRenames.size > 0) repoint(files, chunkRenames);
}
function entrySheets(files) {
  const chunks = new Map(files.flatMap((f) => f.type === "chunk" ? [[f.fileName, f]] : []));
  const sheets = /* @__PURE__ */ new Set();
  const seen = /* @__PURE__ */ new Set();
  const toVisit = [...chunks.values()].filter((c) => c.isEntry);
  while (toVisit.length) {
    const chunk = toVisit.pop();
    if (seen.has(chunk.fileName)) continue;
    seen.add(chunk.fileName);
    for (const sheet of chunk.viteMetadata?.importedCss ?? []) sheets.add(sheet);
    for (const name of chunk.imports) {
      const imported = chunks.get(name);
      if (imported) toVisit.push(imported);
    }
  }
  return sheets;
}
function rewriteBundle(bundle, { substitute = true, keep = [] }, names) {
  const files = Object.values(bundle);
  const assets = files.filter((f) => f.type === "asset");
  const sheets = assets.filter((f) => f.fileName.endsWith(".css"));
  if (sheets.length === 0) return null;
  const css = sheets.map((f) => text(f.source));
  const js = [
    ...files.flatMap((f) => f.type === "chunk" ? [f.code] : []),
    ...assets.filter((f) => /\.[cm]?js$/.test(f.fileName)).map((f) => text(f.source))
  ];
  const html = assets.filter((f) => f.fileName.endsWith(".html")).map((f) => text(f.source));
  const loadedWithPage = entrySheets(files);
  const entries = sheets.flatMap((sheet, i) => loadedWithPage.has(sheet.fileName) ? [i] : []);
  const analysis = analyze({ css, js, html, keep, entries });
  const values = substitute ? staticValues(analysis) : null;
  let bytesSaved = 0;
  const renames = /* @__PURE__ */ new Map();
  const { assetFileNames } = names;
  sheets.forEach((sheet, i) => {
    const rewritten = rewrite(css[i], i, analysis, { substitute }, values);
    bytesSaved += Buffer.byteLength(css[i]) - Buffer.byteLength(rewritten);
    if (rewritten === css[i]) return;
    sheet.source = rewritten;
    const pattern = typeof assetFileNames === "string" ? assetFileNames : assetFileNames({ type: "asset", names: sheet.names, originalFileNames: sheet.originalFileNames, source: rewritten });
    const renamed = hashedFileName(sheet.fileName, pattern, rewritten);
    if (renamed !== null && renamed !== sheet.fileName) renames.set(sheet.fileName, renamed);
  });
  if (renames.size > 0) renameRewritten(files, renames, names);
  let propertiesAfter = 0;
  for (const property of analysis.values()) {
    if (property.reached && (property.dynamic || !substitute)) propertiesAfter += 1;
  }
  return { propertiesBefore: analysis.size, propertiesAfter, bytesSaved };
}
function formatReport({ propertiesBefore, propertiesAfter, bytesSaved }) {
  const kB = (Math.abs(bytesSaved) / 1e3).toFixed(1);
  return `live-tokens: the production CSS declares ${propertiesAfter.toLocaleString("en-US")} of ${propertiesBefore.toLocaleString("en-US")} custom properties and is ${kB} kB ${bytesSaved >= 0 ? "smaller" : "larger"}.`;
}

// vite-plugin/themeFileApi.ts
var import_node_url2 = require("url");
var import_meta2 = {};
var PKG_VERSION = (() => {
  try {
    let dir = import_path5.default.dirname((0, import_node_url2.fileURLToPath)(import_meta2.url));
    for (let i = 0; i < 4; i++) {
      const p = import_path5.default.join(dir, "package.json");
      if (import_fs5.default.existsSync(p)) {
        const json = JSON.parse(import_fs5.default.readFileSync(p, "utf-8"));
        if (json?.name === "@motion-proto/live-tokens") return json.version ?? "";
      }
      const up = import_path5.default.dirname(dir);
      if (up === dir) break;
      dir = up;
    }
  } catch {
  }
  return "";
})();
var BUNDLE_KIND_BY_VERSION = {
  1: "manifest-bundle",
  3: "theme-bundle",
  [THEME_SCHEMA_VERSION]: "theme-bundle"
};
function extractAliasDeclarations(body) {
  const aliases = {};
  const re = /(--[a-z0-9-]+)\s*:\s*([^;]+);/gi;
  let m;
  while ((m = re.exec(body)) !== null) {
    const value = m[2].trim();
    const plain = value.match(/^var\((--[a-z0-9-]+)\)$/i);
    if (plain) {
      aliases[m[1]] = plain[1];
      continue;
    }
    if (parseColorOpacity(value)) {
      aliases[m[1]] = value;
      continue;
    }
    const gradient = parseGradientValue(value);
    if (gradient) aliases[m[1]] = { kind: "gradient", value: gradient };
  }
  return aliases;
}
function themeFileApi(opts) {
  const dataDirs = resolveDataDirs({
    dataDir: opts.dataDir,
    colorsAndTypeDir: opts.colorsAndTypeDir,
    componentConfigsDir: opts.componentConfigsDir,
    themesDir: opts.themesDir
  });
  const COLORS_AND_TYPE_DIR = dataDirs.colorsAndTypeDir;
  const COMPONENT_CONFIGS_DIR = dataDirs.componentConfigsDir;
  const THEMES_DIR = dataDirs.themesDir;
  const SKETCH_STYLES_DIR = dataDirs.sketchStylesDir;
  const CSS_PATH = import_path5.default.resolve(opts.tokensCssPath);
  const ISOLATED_DATA_DIR = testDataDir();
  const GENERATED_CSS_PATH = ISOLATED_DATA_DIR ? import_path5.default.join(ISOLATED_DATA_DIR, "tokens.generated.css") : opts.tokensGeneratedCssPath ? import_path5.default.resolve(opts.tokensGeneratedCssPath) : import_path5.default.join(dataDirs.dataDir, "tokens.generated.css");
  const FONTS_CSS_PATH = ISOLATED_DATA_DIR ? import_path5.default.join(ISOLATED_DATA_DIR, "fonts.css") : opts.fontsCssPath ? import_path5.default.resolve(opts.fontsCssPath) : import_path5.default.join(import_path5.default.dirname(CSS_PATH), "fonts.css");
  const API_BASE = opts.apiBase ?? "/api/live-tokens";
  const consumerComponentDirs = opts.componentsSrcDir ? [import_path5.default.resolve(opts.componentsSrcDir)] : [import_path5.default.resolve("src/components"), import_path5.default.resolve("src/system/components")];
  const packageComponentsDir = import_path5.default.resolve(
    import_path5.default.dirname((0, import_node_url2.fileURLToPath)(import_meta2.url)),
    "..",
    "src",
    "system",
    "components"
  );
  const packageDataDir = testPackageDataDir() ?? import_path5.default.resolve(
    import_path5.default.dirname((0, import_node_url2.fileURLToPath)(import_meta2.url)),
    "..",
    "src",
    "live-tokens",
    "data"
  );
  const packageColorsAndTypeDir = import_path5.default.join(packageDataDir, "colors-and-type");
  const packageThemesDir = import_path5.default.join(packageDataDir, "themes");
  const packageComponentConfigsDir = import_path5.default.join(packageDataDir, "component-configs");
  const packageSketchStylesDir = import_path5.default.join(packageDataDir, "sketch-styles");
  function shippedNames(dataDir, subdir) {
    try {
      const pkgRoot = import_path5.default.resolve(dataDir, "..", "..", "..");
      const pkg = JSON.parse(import_fs5.default.readFileSync(import_path5.default.join(pkgRoot, "package.json"), "utf-8"));
      const files = Array.isArray(pkg.files) ? pkg.files : [];
      const owned = new RegExp(`^src/live-tokens/data/${subdir}/[^/]+\\.json$`);
      return files.filter((f) => owned.test(f)).map((f) => import_path5.default.basename(f, ".json"));
    } catch {
      return [];
    }
  }
  const COMPONENTS_SCAN_DIRS = [...consumerComponentDirs];
  if (!COMPONENTS_SCAN_DIRS.includes(packageComponentsDir) && import_fs5.default.existsSync(packageComponentsDir)) {
    COMPONENTS_SCAN_DIRS.push(packageComponentsDir);
  }
  const isLiveStateFile = (file) => file === import_path5.default.join(THEMES_DIR, "_active.json") || import_path5.default.basename(file) === "_working.json" && (file.startsWith(COLORS_AND_TYPE_DIR + import_path5.default.sep) || file.startsWith(COMPONENT_CONFIGS_DIR + import_path5.default.sep));
  const liveWatch = dataTreeWatch({
    dirs: [COLORS_AND_TYPE_DIR, COMPONENT_CONFIGS_DIR, THEMES_DIR],
    isLive: isLiveStateFile
  });
  const colorsAndTypeResource = versionedFileResourceServer({
    dir: COLORS_AND_TYPE_DIR,
    packageDir: packageColorsAndTypeDir,
    packageOwnedNames: shippedNames(packageDataDir, "colors-and-type"),
    onWrite: liveWatch.noteOwnWrite
  });
  const componentResourceCache = /* @__PURE__ */ new Map();
  function componentResource(comp) {
    let r = componentResourceCache.get(comp);
    if (!r) {
      r = versionedFileResourceServer({
        dir: import_path5.default.join(COMPONENT_CONFIGS_DIR, comp),
        packageDir: import_path5.default.join(packageComponentConfigsDir, comp),
        onWrite: liveWatch.noteOwnWrite
      });
      componentResourceCache.set(comp, r);
    }
    return r;
  }
  const themesResource = versionedFileResourceServer({
    dir: THEMES_DIR,
    packageDir: packageThemesDir,
    onWrite: liveWatch.noteOwnWrite
  });
  const sketchStylesResource = versionedFileResourceServer({
    dir: SKETCH_STYLES_DIR,
    packageDir: packageSketchStylesDir,
    packageOwnedNames: shippedNames(packageDataDir, "sketch-styles")
  });
  function ensureColorsAndTypeDir() {
    colorsAndTypeResource.ensureDir();
  }
  function readBody(req) {
    return new Promise((resolve, reject) => {
      let body = "";
      req.on("data", (chunk) => body += chunk);
      req.on("end", () => resolve(body));
      req.on("error", reject);
    });
  }
  function jsonResponse(res, status, data) {
    res.statusCode = status;
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify(data));
  }
  function rejectReservedName(res, name) {
    if (!name.startsWith("_")) return false;
    jsonResponse(res, 400, {
      error: 'Names starting with "_" are reserved',
      code: "RESERVED_NAME"
    });
    return true;
  }
  function normalizeColorsAndType(colorsAndType) {
    if (!colorsAndType || typeof colorsAndType !== "object") return colorsAndType;
    const palettes = colorsAndType.editorConfigs ?? {};
    const cssVars = colorsAndType.cssVariables ?? {};
    const { palettes: nextPalettes, consumed } = reconcilePalettesFromCssVars(palettes, cssVars);
    const nextCssVars = {};
    for (const [k, v] of Object.entries(cssVars)) {
      if (!consumed.has(k)) nextCssVars[k] = v;
    }
    return { ...colorsAndType, editorConfigs: nextPalettes, cssVariables: nextCssVars };
  }
  const SYSTEM_CASCADES_SSR = {
    "system-ui-sans": 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
    "system-ui-serif": 'Georgia, "Times New Roman", serif',
    "system-ui-mono": 'ui-monospace, "SF Mono", Menlo, Consolas, monospace'
  };
  function resolveFontStacks(colorsAndTypeData) {
    const stacks = colorsAndTypeData.fontStacks;
    const sources = colorsAndTypeData.fontSources;
    if (!stacks || stacks.length === 0) return {};
    const familyById = /* @__PURE__ */ new Map();
    for (const src of sources ?? []) {
      for (const f of src.families) familyById.set(f.id, f.cssName);
    }
    const out = {};
    for (const stack of stacks) {
      const parts = [];
      for (const slot of stack.slots) {
        if (slot.kind === "project") {
          const css = familyById.get(slot.familyId);
          if (css) parts.push(css);
        } else if (slot.kind === "system") {
          const cascade = SYSTEM_CASCADES_SSR[slot.preset];
          if (cascade) parts.push(cascade);
        } else if (slot.kind === "generic") {
          parts.push(slot.value);
        }
      }
      if (parts.length > 0) out[stack.variable] = parts.join(", ");
    }
    return out;
  }
  function renderTokensCss() {
    const lines = [];
    const productionThemeName = themesResource.getProductionName();
    const productionTheme = readTheme(productionThemeName)?.theme ?? null;
    if (themesResource.existingPath(productionThemeName) !== null && !productionTheme?.colorsAndType) {
      const tail = `${import_path5.default.basename(GENERATED_CSS_PATH)} was left as it was.`;
      throw new Error(
        unreadableThemeReason(productionThemeName) === "colors-and-type" ? `[live-tokens] ${notAThemeError(productionThemeName)} ${tail}` : `[live-tokens] Production theme "${productionThemeName}" is unreadable, so ${tail} Repair the theme file or adopt another theme.`
      );
    }
    const colorsAndTypeData = productionTheme?.colorsAndType;
    let colorsAndTypeVarCount = 0;
    let pageBackground = "";
    if (colorsAndTypeData) {
      const cssVars = { ...colorsAndTypeData.cssVariables || {} };
      Object.assign(cssVars, palettesToVars(migratePaletteColorsToOklch(colorsAndTypeData.editorConfigs ?? {})));
      const resolvedFontVars = resolveFontStacks(colorsAndTypeData);
      for (const [name, value] of Object.entries(resolvedFontVars)) {
        cssVars[name] = value;
      }
      pageBackground = cssVars["--page-bg"] ?? "";
      colorsAndTypeVarCount = Object.keys(cssVars).length;
      if (colorsAndTypeVarCount > 0) {
        lines.push(`/* Production theme: ${productionThemeName} */`);
        lines.push(":root:root {");
        for (const [name, value] of Object.entries(cssVars)) {
          lines.push(`  ${name}: ${value};`);
        }
        lines.push("}");
        lines.push("");
      }
    }
    {
      const polarity = pageBackground ? polarityOfBackground(pageBackground) : null;
      if (polarity) {
        lines.push(`/* Page polarity, from --page-bg */`);
        lines.push(":where(:root) {");
        lines.push(`  color-scheme: ${polarity};`);
        lines.push("}");
        lines.push("");
      }
    }
    let componentOverrideCount = 0;
    if (import_fs5.default.existsSync(COMPONENT_CONFIGS_DIR)) {
      const blocks = [];
      for (const comp of listComponentNames()) {
        const prodCfg = productionTheme?.componentConfigs[comp];
        const defaultCfg = readComponentConfig(comp, "default");
        if (!prodCfg || !defaultCfg) continue;
        const overrides = [];
        const defaultAliases = defaultCfg.aliases ?? {};
        for (const [varName, semanticValue] of Object.entries(prodCfg.aliases ?? {})) {
          if (!(varName in defaultAliases)) continue;
          if (!aliasValuesEqual(defaultAliases[varName], semanticValue)) {
            overrides.push([varName, semanticValue]);
          }
        }
        if (overrides.length === 0) continue;
        const block = [`  /* ${comp} */`];
        for (const [varName, semanticValue] of overrides) {
          block.push(`  ${varName}: ${aliasValueToCss(semanticValue)};`);
        }
        blocks.push(block);
        componentOverrideCount += overrides.length;
      }
      if (blocks.length > 0) {
        lines.push("/* Component aliases (production configs differing from defaults) */");
        lines.push(":root:root {");
        for (let i = 0; i < blocks.length; i++) {
          if (i > 0) lines.push("");
          lines.push(...blocks[i]);
        }
        lines.push("}");
        lines.push("");
      }
    }
    return { body: lines.join("\n"), colorsAndTypeVarCount, componentOverrideCount };
  }
  const bakeFingerprint = (body) => (0, import_crypto.createHash)("sha256").update(body).digest("hex").slice(0, 16);
  const BAKE_FINGERPRINT_LINE = /^\/\* Bake fingerprint: ([0-9a-f]+) \*\/$/m;
  function regenerateTokensCss() {
    const { body, colorsAndTypeVarCount, componentOverrideCount } = renderTokensCss();
    const header = [
      "/* Generated by themeFileApi from the production theme. Do not edit. */",
      "/* tokens.css holds developer-authored defaults; this file holds editor overrides. */",
      `/* Bake fingerprint: ${bakeFingerprint(body)} */`,
      ""
    ];
    if (!import_fs5.default.existsSync(import_path5.default.dirname(GENERATED_CSS_PATH))) {
      import_fs5.default.mkdirSync(import_path5.default.dirname(GENERATED_CSS_PATH), { recursive: true });
    }
    import_fs5.default.writeFileSync(GENERATED_CSS_PATH, [...header, body].join("\n"));
    console.log(
      `[regenerateTokensCss] Wrote ${import_path5.default.basename(GENERATED_CSS_PATH)} (${colorsAndTypeVarCount} theme vars, ${componentOverrideCount} component overrides)`
    );
  }
  function bakeIsCurrent() {
    let baked;
    try {
      baked = import_fs5.default.readFileSync(GENERATED_CSS_PATH, "utf-8");
    } catch {
      return false;
    }
    const recorded = BAKE_FINGERPRINT_LINE.exec(baked)?.[1];
    try {
      return recorded === bakeFingerprint(renderTokensCss().body);
    } catch {
      return false;
    }
  }
  function syncFontsToCss(colorsAndTypeData) {
    if (!colorsAndTypeData) return;
    const sources = colorsAndTypeData.fontSources;
    if (!sources) return;
    const lines = [];
    lines.push("/* Generated from the production colors and type by syncFontsToCss. Do not edit. */");
    lines.push("/* Both fonts.css and fonts/ are in dist/, so relative paths work at runtime. */");
    lines.push("");
    const urlSources = sources.filter((s) => s.kind !== "font-face" && s.url);
    const faceSources = sources.filter((s) => s.kind === "font-face" && s.cssText);
    for (const source of urlSources) {
      const familyNames = source.families.map((f) => f.name).join(", ");
      const label = source.label ? `${source.label} \u2014 ${familyNames}` : familyNames;
      lines.push(`/* ${label} */`);
      lines.push(`@import url('${source.url}');`);
      lines.push("");
    }
    for (const source of faceSources) {
      const familyNames = source.families.map((f) => f.name).join(", ");
      const label = source.label ? `${source.label} \u2014 ${familyNames}` : familyNames;
      lines.push(`/* ${label} */`);
      lines.push(source.cssText);
      lines.push("");
    }
    const content = lines.join("\n");
    if (!import_fs5.default.existsSync(import_path5.default.dirname(FONTS_CSS_PATH))) {
      import_fs5.default.mkdirSync(import_path5.default.dirname(FONTS_CSS_PATH), { recursive: true });
    }
    import_fs5.default.writeFileSync(FONTS_CSS_PATH, content);
    console.log(`[syncFontsToCss] Wrote ${sources.length} source(s) into ${import_path5.default.basename(FONTS_CSS_PATH)}`);
  }
  function componentNameFromFile(filePath) {
    return import_path5.default.basename(filePath, ".svelte").toLowerCase();
  }
  function isThemeAwareComponent(filePath) {
    try {
      const source = import_fs5.default.readFileSync(filePath, "utf-8");
      return /:global\(:root\)\s*\{/.test(source);
    } catch {
      return false;
    }
  }
  function listComponentSourcePaths() {
    const byName = /* @__PURE__ */ new Map();
    for (const dir of COMPONENTS_SCAN_DIRS) {
      if (!import_fs5.default.existsSync(dir)) continue;
      for (const f of import_fs5.default.readdirSync(dir)) {
        if (!f.endsWith(".svelte")) continue;
        const full = import_path5.default.join(dir, f);
        if (!isThemeAwareComponent(full)) continue;
        const name = componentNameFromFile(f);
        if (!byName.has(name)) byName.set(name, full);
      }
    }
    return Array.from(byName.values());
  }
  function listComponentNames() {
    return listComponentSourcePaths().map(componentNameFromFile);
  }
  function warnOnTokenDrift(log) {
    let tokensCss = "";
    try {
      tokensCss = import_fs5.default.readFileSync(CSS_PATH, "utf-8");
    } catch {
      return;
    }
    let generatedCss = "";
    try {
      generatedCss = import_fs5.default.readFileSync(GENERATED_CSS_PATH, "utf-8");
    } catch {
    }
    const componentSources = listComponentSourcePaths().map((p) => ({
      name: componentNameFromFile(p),
      source: import_fs5.default.readFileSync(p, "utf-8")
    }));
    const missing = validateTokensCss({ tokensCss, generatedCss, componentSources });
    if (missing.length === 0) return;
    const lines = missing.map(
      (m) => `  ${m.token}  (referenced by ${m.referencedBy.join(", ")})`
    );
    log(
      `[live-tokens] ${missing.length} token(s) referenced by components are not defined in ${import_path5.default.relative(process.cwd(), CSS_PATH)}:
${lines.join("\n")}
  These render as blank/empty editor slots. Run \`npx live-tokens migrate\` to reconcile.`
    );
  }
  function autoMigrateAdditive(log) {
    let before = "";
    try {
      before = import_fs5.default.readFileSync(CSS_PATH, "utf-8");
    } catch {
      return;
    }
    const { css, applied, changed } = runAdditiveTokensCssMigrations(before);
    if (!changed) return;
    import_fs5.default.writeFileSync(CSS_PATH, css);
    log(
      `[live-tokens] autoMigrate applied ${applied.length} additive migration(s) to ${import_path5.default.relative(process.cwd(), CSS_PATH)}: ${applied.join(", ")}. Review the diff in git.`
    );
  }
  function generateDefaultConfig(comp, sourcePath) {
    if (!import_fs5.default.existsSync(sourcePath)) return;
    const r = componentResource(comp);
    r.ensureDir();
    const defaultPath = r.filePath("default");
    const sourceStat = import_fs5.default.statSync(sourcePath);
    let createdAt = (/* @__PURE__ */ new Date()).toISOString();
    let existingUpdatedAt;
    let existingAliases;
    let existingSchemaVersion;
    if (import_fs5.default.existsSync(defaultPath)) {
      try {
        const existing = JSON.parse(import_fs5.default.readFileSync(defaultPath, "utf-8"));
        if (existing.createdAt) createdAt = existing.createdAt;
        if (typeof existing.updatedAt === "string") existingUpdatedAt = existing.updatedAt;
        if (existing.aliases && typeof existing.aliases === "object") {
          existingAliases = existing.aliases;
        }
        if (typeof existing.schemaVersion === "number") existingSchemaVersion = existing.schemaVersion;
      } catch {
      }
      const defaultStat = import_fs5.default.statSync(defaultPath);
      if (defaultStat.mtimeMs >= sourceStat.mtimeMs && existingSchemaVersion === CURRENT_COMPONENT_SCHEMA_VERSION) {
        return;
      }
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const source = import_fs5.default.readFileSync(sourcePath, "utf-8");
    const body = extractGlobalRootBody(source);
    const aliases = extractAliasDeclarations(body);
    const aliasesUnchanged = existingAliases !== void 0 && JSON.stringify(existingAliases) === JSON.stringify(aliases);
    const schemaStampCurrent = existingSchemaVersion === CURRENT_COMPONENT_SCHEMA_VERSION;
    const defaultConfig = {
      name: "default",
      component: comp,
      createdAt,
      updatedAt: aliasesUnchanged && existingUpdatedAt ? existingUpdatedAt : now,
      aliases,
      schemaVersion: CURRENT_COMPONENT_SCHEMA_VERSION
    };
    if (aliasesUnchanged && schemaStampCurrent && existingUpdatedAt) {
      const t = /* @__PURE__ */ new Date();
      import_fs5.default.utimesSync(defaultPath, t, t);
      return;
    }
    import_fs5.default.writeFileSync(defaultPath, JSON.stringify(defaultConfig, null, 2));
  }
  function ensureComponentConfigsDir() {
    if (!import_fs5.default.existsSync(COMPONENT_CONFIGS_DIR)) {
      import_fs5.default.mkdirSync(COMPONENT_CONFIGS_DIR, { recursive: true });
    }
    for (const sourcePath of listComponentSourcePaths()) {
      const comp = componentNameFromFile(sourcePath);
      const r = componentResource(comp);
      r.ensureDir();
      generateDefaultConfig(comp, sourcePath);
    }
  }
  function listLegacyPointers() {
    const legacy = [];
    const check = (dir) => {
      for (const name of ["_active.json", "_production.json"]) {
        const p = import_path5.default.join(dir, name);
        if (import_fs5.default.existsSync(p)) legacy.push(import_path5.default.relative(process.cwd(), p));
      }
    };
    check(COLORS_AND_TYPE_DIR);
    if (import_fs5.default.existsSync(COMPONENT_CONFIGS_DIR)) {
      for (const entry of import_fs5.default.readdirSync(COMPONENT_CONFIGS_DIR, { withFileTypes: true })) {
        if (entry.isDirectory()) check(import_path5.default.join(COMPONENT_CONFIGS_DIR, entry.name));
      }
    }
    return legacy;
  }
  function warnOnLegacyPointers(legacy, bakeHeld, warn) {
    if (legacy.length === 0) return;
    warn(
      `[live-tokens] ${legacy.length} legacy pointer file(s) left from the pre-working-set data model, starting with ${legacy[0]}. They are no longer read. Run \`npx live-tokens migrate\` to heal the tree.` + (bakeHeld ? ` Until then this tree has named no production theme, so ${import_path5.default.basename(GENERATED_CSS_PATH)} is left exactly as it is rather than rebuilt from the default.` : "")
    );
  }
  function warnOnLegacyLayout(evidence, warn) {
    warn(
      `[live-tokens] This project still uses the data layout from 0.47 and earlier: ${evidence}. Since 0.48 the whole-theme theme files live in \`themes/\` and the colors and type live in \`colors-and-type/\`. Nothing in the data directory was written, the editor cannot save, and ${import_path5.default.basename(GENERATED_CSS_PATH)} is left exactly as it is. Run \`npx live-tokens migrate\` to move the directories and heal the tree, then restart the dev server.`
    );
  }
  function warnOnUnmigratedSketchStyles(warn) {
    const legacyDir = import_path5.default.join(dataDirs.dataDir, "sketch-presets");
    if (!import_fs5.default.existsSync(legacyDir)) return;
    warn(
      `[live-tokens] Saved sketchstyles still live under the retired ${import_path5.default.basename(legacyDir)}/ directory name. Run \`npx live-tokens migrate\` to rename it to ${import_path5.default.basename(SKETCH_STYLES_DIR)}/; until then they will not show up in the Sketchstyle view.`
    );
  }
  const diskThemeResolvers = {
    readColorsAndType: (name) => colorsAndTypeResource.readJson(sanitizeFileName(name)),
    readComponentConfig: (comp, name) => readComponentConfig(comp, sanitizeFileName(name)),
    listComponentNames,
    normalizeColorsAndType: (colorsAndType) => normalizeColorsAndType(colorsAndType)
  };
  function readTheme(fileName) {
    let raw;
    try {
      raw = themesResource.readJson(fileName);
    } catch {
      return null;
    }
    if (!raw) return null;
    if (isColorsAndTypeShaped(raw)) return null;
    return normalizeTheme(raw, diskThemeResolvers);
  }
  function unreadableThemeReason(fileName) {
    const resolved = themesResource.existingPath(fileName);
    if (resolved === null) return "missing";
    try {
      if (isColorsAndTypeShaped(JSON.parse(import_fs5.default.readFileSync(resolved, "utf-8")))) {
        return "colors-and-type";
      }
    } catch {
    }
    return "corrupt";
  }
  function notAThemeError(fileName) {
    return `"${fileName}" is a colors-and-type file, not a theme. Before 0.48 those lived in themes/; move it to ${import_path5.default.basename(COLORS_AND_TYPE_DIR)}/ or delete it. To build a theme, use the theme skill "create-theme".`;
  }
  function respondUnreadableTheme(res, fileName, missingError) {
    switch (unreadableThemeReason(fileName)) {
      case "missing":
        jsonResponse(res, 404, { error: missingError });
        return;
      case "colors-and-type":
        jsonResponse(res, 422, { error: notAThemeError(fileName), code: "CORRUPT_THEME" });
        return;
      case "corrupt":
        jsonResponse(res, 422, {
          error: `Theme file "${fileName}" is not valid JSON`,
          code: "CORRUPT_THEME"
        });
    }
  }
  function writeTheme(fileName, theme) {
    themesResource.ensureDir();
    import_fs5.default.writeFileSync(themesResource.filePath(fileName), JSON.stringify(theme, null, 2));
  }
  function migrateLocalThemes(warn) {
    if (import_path5.default.resolve(THEMES_DIR) === import_path5.default.resolve(packageThemesDir)) return;
    if (!import_fs5.default.existsSync(THEMES_DIR)) return;
    for (const file of import_fs5.default.readdirSync(THEMES_DIR)) {
      if (!file.endsWith(".json") || file.startsWith("_")) continue;
      const fileName = file.slice(0, -".json".length);
      if (fileName === "default") continue;
      let raw;
      try {
        raw = JSON.parse(import_fs5.default.readFileSync(import_path5.default.join(THEMES_DIR, file), "utf-8"));
      } catch {
        continue;
      }
      if (isColorsAndTypeShaped(raw)) {
        warn(`[live-tokens] ${notAThemeError(fileName)} It is left untouched.`);
        continue;
      }
      const { theme, dropped, migrated } = normalizeTheme(raw, diskThemeResolvers);
      if (!migrated) continue;
      writeTheme(fileName, theme);
      if (dropped.length > 0) {
        warn(
          `[live-tokens] Theme "${fileName}": ${dropped.join(", ")} no longer exists; those slices now use their defaults.`
        );
      }
    }
  }
  function ensureDefaultTheme(warn) {
    let existing = null;
    try {
      existing = JSON.parse(import_fs5.default.readFileSync(themesResource.filePath("default"), "utf-8"));
    } catch {
    }
    if (isColorsAndTypeShaped(existing)) {
      warn(`[live-tokens] ${notAThemeError("default")} The Default theme was not materialised.`);
      return;
    }
    const colorsAndType = normalizeColorsAndType(colorsAndTypeResource.readJson("default"));
    const componentConfigs = {};
    for (const comp of listComponentNames()) {
      const cfg = readComponentConfig(comp, "default");
      if (cfg) {
        const { schemaVersion: _standaloneStamp, ...rest } = cfg;
        componentConfigs[comp] = rest;
      }
    }
    const contentUnchanged = JSON.stringify(existing?.colorsAndType) === JSON.stringify(colorsAndType) && JSON.stringify(existing?.componentConfigs) === JSON.stringify(componentConfigs);
    if (existing?.schemaVersion === THEME_SCHEMA_VERSION && existing?.componentSchemaVersion === CURRENT_COMPONENT_SCHEMA_VERSION && contentUnchanged) {
      return;
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    writeTheme("default", {
      name: "Motion Proto",
      createdAt: typeof existing?.createdAt === "string" ? existing.createdAt : now,
      // A stamp-only rewrite (componentSchemaVersion catching up) is not a
      // content change, so it doesn't bump this the way a real edit would.
      updatedAt: contentUnchanged && typeof existing?.updatedAt === "string" ? existing.updatedAt : now,
      schemaVersion: THEME_SCHEMA_VERSION,
      colorsAndType,
      componentConfigs,
      componentSchemaVersion: CURRENT_COMPONENT_SCHEMA_VERSION
    });
  }
  function ensureThemesDir(warn) {
    themesResource.ensureDir();
    ensureDefaultTheme(warn);
    migrateLocalThemes(warn);
    const productionPointerHeld = !import_fs5.default.existsSync(themesResource.productionPath) && listLegacyPointers().length > 0;
    if (productionPointerHeld) {
      if (!import_fs5.default.existsSync(themesResource.activePath)) themesResource.setActiveName("default");
    } else {
      themesResource.ensureMeta();
    }
    if (themesResource.existingPath(themesResource.getActiveName()) === null) {
      themesResource.setActiveName("default");
    }
    if (themesResource.existingPath(themesResource.getProductionName()) === null) {
      themesResource.setProductionName("default");
    }
    return { productionPointerHeld };
  }
  function activeTheme() {
    return readTheme(themesResource.getActiveName())?.theme ?? null;
  }
  function resolveLiveColorsAndType(theme) {
    const working = colorsAndTypeResource.readWorking();
    if (working !== null) return { data: normalizeColorsAndType(working), source: "working" };
    if (theme?.colorsAndType) return { data: theme.colorsAndType, source: "theme" };
    const shipped = colorsAndTypeResource.readJson("default");
    if (!shipped) return null;
    return { data: normalizeColorsAndType(shipped), source: "default" };
  }
  const loggedMissingThemeEntries = /* @__PURE__ */ new Set();
  function resolveComponentConfigOrDefault(comp, theme) {
    const embedded = theme?.componentConfigs[comp];
    if (embedded) return { ...embedded, component: comp };
    if (!loggedMissingThemeEntries.has(comp)) {
      loggedMissingThemeEntries.add(comp);
      console.warn(
        `[live-tokens] "${comp}" has no entry in the open theme; resolving from its shipped default.`
      );
    }
    return readComponentConfig(comp, "default");
  }
  function resolveLiveComponentConfig(comp, theme) {
    const working = componentResource(comp).readWorking();
    if (working !== null) return { data: working, source: "working" };
    const cfg = resolveComponentConfigOrDefault(comp, theme);
    if (!cfg) return null;
    return { data: cfg, source: "theme" };
  }
  function resolveSavedColorsAndType(theme) {
    if (theme?.colorsAndType) return theme.colorsAndType;
    const shipped = colorsAndTypeResource.readJson("default");
    return shipped ? normalizeColorsAndType(shipped) : null;
  }
  function resolveSavedComponentConfig(comp, theme) {
    return resolveComponentConfigOrDefault(comp, theme);
  }
  function sameJsonValue(a, b) {
    if (a === null || b === null) return a === b;
    if (typeof a !== typeof b) return false;
    if (typeof a !== "object") return a === b;
    if (Array.isArray(a) || Array.isArray(b)) {
      return Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((value, i) => sameJsonValue(value, b[i]));
    }
    const aRecord = a;
    const bRecord = b;
    const aKeys = Object.keys(aRecord).sort();
    const bKeys = Object.keys(bRecord).sort();
    return aKeys.length === bKeys.length && aKeys.every((key, i) => key === bKeys[i] && sameJsonValue(aRecord[key], bRecord[key]));
  }
  function pruneMatchingWorking(theme) {
    const colorsWorking = colorsAndTypeResource.readWorking();
    const savedColors = resolveSavedColorsAndType(theme);
    if (colorsWorking !== null && savedColors !== null && sameJsonValue(normalizeColorsAndType(colorsWorking), savedColors)) {
      colorsAndTypeResource.clearWorking();
    }
    for (const comp of listComponentNames()) {
      const r = componentResource(comp);
      const working = r.readWorking();
      if (working !== null && sameJsonValue(working, resolveSavedComponentConfig(comp, theme))) {
        r.clearWorking();
      }
    }
  }
  function clearAllWorking() {
    colorsAndTypeResource.clearWorking();
    if (!import_fs5.default.existsSync(COMPONENT_CONFIGS_DIR)) return;
    for (const entry of import_fs5.default.readdirSync(COMPONENT_CONFIGS_DIR, { withFileTypes: true })) {
      if (entry.isDirectory()) componentResource(entry.name).clearWorking();
    }
  }
  function aliasValueToCss(v) {
    if (typeof v === "string") return v.startsWith("--") ? `var(${v})` : v;
    return formatGradientValue(v.value);
  }
  function aliasValuesEqual(a, b) {
    if (a === void 0 || b === void 0) return a === b;
    if (typeof a === "string" && typeof b === "string") return a === b;
    if (typeof a !== typeof b) return false;
    return JSON.stringify(a) === JSON.stringify(b);
  }
  function readComponentConfig(comp, name) {
    try {
      return componentResource(comp).readJson(name);
    } catch {
      return null;
    }
  }
  const escapedBase = API_BASE.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const COLORS_AND_TYPE_ROUTE = `${API_BASE}/colors-and-type`;
  const COLORS_AND_TYPE_ACTIVE_ROUTE = `${API_BASE}/colors-and-type/active`;
  const COLORS_AND_TYPE_PRODUCTION_ROUTE = `${API_BASE}/colors-and-type/production`;
  const COLORS_AND_TYPE_WORKING_ROUTE = `${API_BASE}/colors-and-type/working`;
  const COMPONENT_CONFIGS_ROUTE = `${API_BASE}/component-configs`;
  const THEMES_ROUTE = `${API_BASE}/themes`;
  const THEMES_ACTIVE_ROUTE = `${API_BASE}/themes/active`;
  const THEMES_PRODUCTION_ROUTE = `${API_BASE}/themes/production`;
  const COLORS_AND_TYPE_BY_NAME_REGEX = new RegExp(`^${escapedBase}/colors-and-type/([a-z0-9\\-_]+)$`);
  const COMP_LIST_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)$`);
  const COMP_ACTIVE_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)/active$`);
  const COMP_PRODUCTION_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)/production$`);
  const COMP_WORKING_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)/working$`);
  const COMP_BY_NAME_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)/([a-z0-9\\-_]+)$`);
  const THEME_APPLY_REGEX = new RegExp(`^${escapedBase}/themes/([a-z0-9\\-_]+)/apply$`);
  const THEME_EXPORT_REGEX = new RegExp(`^${escapedBase}/themes/([a-z0-9\\-_]+)/export$`);
  const THEME_IMPORT_ROUTE = `${API_BASE}/themes/import`;
  const THEME_BY_NAME_REGEX = new RegExp(`^${escapedBase}/themes/([a-z0-9\\-_]+)$`);
  const SKETCH_STYLES_ROUTE = `${API_BASE}/sketch-styles`;
  const SKETCH_STYLE_BY_NAME_REGEX = new RegExp(`^${escapedBase}/sketch-styles/([a-z0-9\\-_]+)$`);
  const PRODUCTION_ROUTE = `${API_BASE}/production`;
  const EVENTS_ROUTE = `${API_BASE}/events`;
  async function handleListColorsAndType(_ctx) {
    const files = colorsAndTypeResource.listNames().map((fileName) => {
      const data = colorsAndTypeResource.readJson(fileName);
      return {
        name: data?.name || fileName,
        fileName,
        updatedAt: data?.updatedAt || "",
        // Package-owned rows are the shipped presets and the default. The Load
        // window offers those as whole themes, so it lists only the rows a
        // local file backs — including a local copy of a shipped name, which
        // holds whatever the user did to it.
        isPackage: colorsAndTypeResource.isPackageFile(fileName)
      };
    });
    jsonResponse(_ctx.res, 200, { files });
  }
  async function handleGetActiveColorsAndType({ res }) {
    const resolved = resolveLiveColorsAndType(activeTheme());
    if (!resolved) {
      jsonResponse(res, 404, { error: "Active colors and type not found" });
      return;
    }
    jsonResponse(res, 200, {
      ...resolved.data,
      _fileName: themesResource.getActiveName(),
      _source: resolved.source
    });
  }
  async function readBufferBody(req, res) {
    let parsed;
    try {
      parsed = JSON.parse(await readBody(req));
    } catch {
      parsed = void 0;
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      jsonResponse(res, 400, { error: "Body must be a JSON object", code: "INVALID_BODY" });
      return null;
    }
    return parsed;
  }
  async function handleGetWorkingColorsAndType({ res }) {
    const raw = colorsAndTypeResource.readWorking();
    if (raw === null) {
      jsonResponse(res, 404, { error: "No working colors and type" });
      return;
    }
    jsonResponse(res, 200, normalizeColorsAndType(raw));
  }
  async function handleSetWorkingColorsAndType({ req, res }) {
    const body = await readBufferBody(req, res);
    if (!body) return;
    const normalized = normalizeColorsAndType(body);
    const saved = resolveSavedColorsAndType(activeTheme());
    if (saved !== null && sameJsonValue(normalized, saved)) colorsAndTypeResource.clearWorking();
    else colorsAndTypeResource.writeWorking(body);
    jsonResponse(res, 200, { ok: true });
  }
  async function handleClearWorkingColorsAndType({ res }) {
    colorsAndTypeResource.clearWorking();
    jsonResponse(res, 200, { ok: true });
  }
  async function handleColorsAndTypeByName({ params, req, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const filePath = colorsAndTypeResource.filePath(fileName);
    if (req.method === "GET") {
      const raw = colorsAndTypeResource.readJson(fileName);
      if (!raw) {
        jsonResponse(res, 404, { error: "Not found" });
        return;
      }
      const data = normalizeColorsAndType(raw);
      data._fileName = fileName;
      jsonResponse(res, 200, data);
      return;
    }
    if (req.method === "PUT") {
      if (fileName === "default") {
        jsonResponse(res, 403, { error: "Cannot overwrite the default colors and type (live from package)" });
        return;
      }
      const body = JSON.parse(await readBody(req));
      body.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (import_fs5.default.existsSync(filePath)) {
        try {
          const existing = JSON.parse(import_fs5.default.readFileSync(filePath, "utf-8"));
          if (existing.createdAt) body.createdAt = existing.createdAt;
        } catch {
        }
      }
      if (!body.createdAt) body.createdAt = body.updatedAt;
      import_fs5.default.writeFileSync(filePath, JSON.stringify(body, null, 2));
      jsonResponse(res, 200, { ok: true, fileName });
      return;
    }
    if (req.method === "DELETE") {
      if (fileName === "default") {
        jsonResponse(res, 403, { error: "Cannot delete the default colors and type" });
        return;
      }
      if (import_fs5.default.existsSync(filePath)) {
        import_fs5.default.unlinkSync(filePath);
      } else if (colorsAndTypeResource.existingPath(fileName)) {
        jsonResponse(res, 403, {
          error: "Cannot delete colors and type shipped with the package. Saving it creates a local copy; deleting that copy restores the shipped version.",
          code: "PACKAGE_COLORS_AND_TYPE"
        });
        return;
      }
      jsonResponse(res, 200, { ok: true });
      return;
    }
  }
  async function handleListComponents({ res }) {
    const components = listComponentNames().map((comp) => ({
      name: comp,
      source: componentResource(comp).hasWorking() ? "working" : "theme"
    }));
    jsonResponse(res, 200, { components });
  }
  function rejectUnknownComponent(res, comp) {
    if (listComponentNames().includes(comp)) return false;
    jsonResponse(res, 404, { error: `Unknown component "${comp}"`, code: "UNKNOWN_COMPONENT" });
    return true;
  }
  async function handleGetComponentActive({ params, res }) {
    const [comp] = params;
    if (rejectUnknownComponent(res, comp)) return;
    const resolved = resolveLiveComponentConfig(comp, activeTheme());
    if (!resolved) {
      jsonResponse(res, 404, { error: "Active config not found" });
      return;
    }
    jsonResponse(res, 200, {
      ...resolved.data,
      _fileName: themesResource.getActiveName(),
      _source: resolved.source
    });
  }
  async function handleGetComponentWorking({ params, res }) {
    const [comp] = params;
    const raw = componentResource(comp).readWorking();
    if (raw === null) {
      jsonResponse(res, 404, { error: "No working config" });
      return;
    }
    jsonResponse(res, 200, raw);
  }
  async function handleSetComponentWorking({ params, req, res }) {
    const [comp] = params;
    if (rejectUnknownComponent(res, comp)) return;
    const body = await readBufferBody(req, res);
    if (!body) return;
    const r = componentResource(comp);
    if (sameJsonValue(body, resolveSavedComponentConfig(comp, activeTheme()))) r.clearWorking();
    else r.writeWorking(body);
    jsonResponse(res, 200, { ok: true });
  }
  async function handleClearComponentWorking({ params, res }) {
    const [comp] = params;
    componentResource(comp).clearWorking();
    jsonResponse(res, 200, { ok: true });
  }
  async function handleComponentConfigByName({ params, req, res }) {
    const [comp, name] = params;
    if (rejectReservedName(res, name)) return;
    const r = componentResource(comp);
    const configPath = r.filePath(name);
    if (req.method === "GET") {
      const raw = r.readJson(name);
      if (!raw) {
        jsonResponse(res, 404, { error: "Not found" });
        return;
      }
      const data = raw;
      data._fileName = name;
      jsonResponse(res, 200, data);
      return;
    }
    if (req.method === "PUT") {
      if (name === "default") {
        jsonResponse(res, 403, { error: "Cannot modify default config (regenerated from source)" });
        return;
      }
      const body = JSON.parse(await readBody(req));
      body.component = comp;
      body.name = body.name || name;
      body.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (import_fs5.default.existsSync(configPath)) {
        try {
          const existing = JSON.parse(import_fs5.default.readFileSync(configPath, "utf-8"));
          if (existing.createdAt) body.createdAt = existing.createdAt;
        } catch {
        }
      }
      if (!body.createdAt) body.createdAt = body.updatedAt;
      r.ensureDir();
      import_fs5.default.writeFileSync(configPath, JSON.stringify(body, null, 2));
      jsonResponse(res, 200, { ok: true, fileName: name });
      return;
    }
    if (req.method === "DELETE") {
      if (name === "default") {
        jsonResponse(res, 403, { error: "Cannot delete default config" });
        return;
      }
      if (import_fs5.default.existsSync(configPath)) import_fs5.default.unlinkSync(configPath);
      jsonResponse(res, 200, { ok: true });
      return;
    }
  }
  async function handleListComponentConfigs({ params, res }) {
    const [comp] = params;
    const r = componentResource(comp);
    if (!import_fs5.default.existsSync(r.dir)) {
      jsonResponse(res, 404, { error: "Component not found" });
      return;
    }
    const files = r.listNames().map((fileName) => {
      const data = r.readJson(fileName);
      return {
        name: data?.name || fileName,
        fileName,
        updatedAt: data?.updatedAt || "",
        isPackage: sketchStylesResource.isPackageFile(fileName)
      };
    });
    jsonResponse(res, 200, { component: comp, files });
  }
  async function handleListThemes({ res }) {
    const activeFile = themesResource.getActiveName();
    const productionFile = themesResource.getProductionName();
    const files = [];
    for (const fileName of themesResource.listNames()) {
      const read = readTheme(fileName);
      if (!read) {
        console.warn(
          unreadableThemeReason(fileName) === "colors-and-type" ? `[live-tokens] ${notAThemeError(fileName)} It is left out of the theme list.` : `[live-tokens] Theme "${fileName}" is unreadable and was left out of the list.`
        );
        continue;
      }
      files.push({
        name: read.theme.name,
        fileName,
        updatedAt: read.theme.updatedAt,
        isActive: fileName === activeFile,
        isProduction: fileName === productionFile,
        isProtected: fileName === "default"
      });
    }
    jsonResponse(res, 200, { files, activeFile, productionFile });
  }
  async function handleGetProductionTheme({ res }) {
    const fileName = themesResource.getProductionName();
    const read = readTheme(fileName);
    if (!read) {
      respondUnreadableTheme(res, fileName, "Production theme not found");
      return;
    }
    jsonResponse(res, 200, { ...read.theme, _fileName: fileName, _baked: bakeIsCurrent() });
  }
  async function handleGetActiveTheme({ res }) {
    const activeFile = themesResource.getActiveName();
    const read = readTheme(activeFile);
    if (!read) {
      respondUnreadableTheme(res, activeFile, "Active theme not found");
      return;
    }
    jsonResponse(res, 200, { ...read.theme, _fileName: activeFile });
  }
  async function handleSetActiveTheme({ req, res }) {
    const body = JSON.parse(await readBody(req));
    const fileName = sanitizeFileName(body.name || "default");
    if (themesResource.existingPath(fileName) === null) {
      jsonResponse(res, 404, { error: "Theme not found" });
      return;
    }
    themesResource.setActiveName(fileName);
    pruneMatchingWorking(readTheme(fileName)?.theme ?? null);
    jsonResponse(res, 200, { ok: true, activeFile: fileName });
  }
  async function handleThemeByName({ params, req, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const filePath = themesResource.filePath(fileName);
    if (req.method === "GET") {
      const read = readTheme(fileName);
      if (!read) {
        respondUnreadableTheme(res, fileName, "Not found");
        return;
      }
      jsonResponse(res, 200, { ...read.theme, _fileName: fileName });
      return;
    }
    if (req.method === "PUT") {
      if (fileName === "default") {
        jsonResponse(res, 403, { error: "Cannot overwrite the default theme" });
        return;
      }
      const body = JSON.parse(await readBody(req));
      const { theme } = normalizeTheme(body, diskThemeResolvers);
      theme.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (import_fs5.default.existsSync(filePath)) {
        try {
          const existing = JSON.parse(import_fs5.default.readFileSync(filePath, "utf-8"));
          if (existing.createdAt) theme.createdAt = existing.createdAt;
        } catch {
        }
      }
      writeTheme(fileName, theme);
      if (themesResource.getActiveName() === fileName) pruneMatchingWorking(theme);
      jsonResponse(res, 200, { ok: true, fileName });
      return;
    }
    if (req.method === "DELETE") {
      if (fileName === "default") {
        jsonResponse(res, 403, { error: "Cannot delete the default theme" });
        return;
      }
      if (fileName === themesResource.getProductionName()) {
        jsonResponse(res, 403, {
          error: "Cannot delete the theme that is in production. Adopt another theme first.",
          code: "PRODUCTION_THEME"
        });
        return;
      }
      if (import_fs5.default.existsSync(filePath)) {
        const deletingActive = themesResource.getActiveName() === fileName;
        const liveColors = deletingActive ? resolveLiveColorsAndType(activeTheme()) : null;
        const liveComponents = {};
        if (deletingActive) {
          for (const comp of listComponentNames()) {
            const resolved = resolveLiveComponentConfig(comp, activeTheme());
            if (resolved) liveComponents[comp] = resolved.data;
          }
        }
        import_fs5.default.unlinkSync(filePath);
        if (themesResource.existingPath(fileName) === null && deletingActive) {
          themesResource.setActiveName("default");
        }
        if (deletingActive) {
          const replacement = activeTheme();
          const savedColors = resolveSavedColorsAndType(replacement);
          if (liveColors && !sameJsonValue(liveColors.data, savedColors)) {
            colorsAndTypeResource.writeWorking(liveColors.data);
          } else {
            colorsAndTypeResource.clearWorking();
          }
          for (const comp of listComponentNames()) {
            const r = componentResource(comp);
            const live = liveComponents[comp] ?? null;
            const saved = resolveSavedComponentConfig(comp, replacement);
            if (live !== null && !sameJsonValue(live, saved)) r.writeWorking({ ...live });
            else r.clearWorking();
          }
        }
      } else if (themesResource.existingPath(fileName)) {
        jsonResponse(res, 403, {
          error: "Cannot delete a theme shipped with the package. Saving it creates a local copy; deleting that copy restores the shipped version.",
          code: "PACKAGE_THEME"
        });
        return;
      }
      jsonResponse(res, 200, { ok: true });
      return;
    }
  }
  async function handleApplyTheme({ params, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const read = readTheme(fileName);
    if (!read) {
      respondUnreadableTheme(res, fileName, "Theme not found");
      return;
    }
    const { theme, filled } = read;
    if (!theme.colorsAndType) {
      jsonResponse(res, 422, {
        error: 'This theme carries no colors and type. Build one with the theme skill "create-theme".'
      });
      return;
    }
    clearAllWorking();
    themesResource.setActiveName(fileName);
    const knownComponents = listComponentNames();
    const skippedComponents = Object.keys(theme.componentConfigs).filter(
      (comp) => !knownComponents.includes(comp)
    );
    jsonResponse(res, 200, {
      ok: true,
      ...resolveLiveState(theme, fileName),
      skippedComponents,
      filled
    });
  }
  function resolveLiveState(theme, fileName) {
    const componentConfigs = {};
    for (const comp of listComponentNames()) {
      const resolved = resolveLiveComponentConfig(comp, theme);
      if (resolved) componentConfigs[comp] = { ...resolved.data, _fileName: fileName, _source: resolved.source };
    }
    const colorsAndType = resolveLiveColorsAndType(theme);
    return {
      fileName,
      theme: { ...theme, _fileName: fileName },
      colorsAndType: colorsAndType && { ...colorsAndType.data, _fileName: fileName, _source: colorsAndType.source },
      componentConfigs
    };
  }
  async function handleEvents({ req, res }) {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.write(": connected\n\n");
    const unsubscribe = liveWatch.subscribe(() => {
      const activeFile = themesResource.getActiveName();
      const read = readTheme(activeFile);
      if (!read) return;
      const state = resolveLiveState(read.theme, activeFile);
      res.write(`event: live-state
data: ${JSON.stringify(state)}

`);
    });
    req.on("close", unsubscribe);
  }
  async function handleExportTheme({ params, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const read = readTheme(fileName);
    if (!read) {
      respondUnreadableTheme(res, fileName, "Theme not found");
      return;
    }
    const bundle = {
      kind: "theme-bundle",
      schemaVersion: THEME_SCHEMA_VERSION,
      liveTokensVersion: PKG_VERSION,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      manifest: read.theme
    };
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${fileName}.bundle.json"`
    );
    res.end(JSON.stringify(bundle, null, 2));
  }
  function nextAvailableName2(exists, baseName) {
    return nextAvailableName(exists, sanitizeFileName(baseName));
  }
  async function handleImportTheme({ req, res }) {
    let bundle;
    try {
      bundle = JSON.parse(await readBody(req));
    } catch {
      jsonResponse(res, 400, { error: "Body is not valid JSON" });
      return;
    }
    if (!bundle || !Object.values(BUNDLE_KIND_BY_VERSION).includes(bundle.kind)) {
      jsonResponse(res, 400, {
        error: "Not a theme bundle (kind discriminator missing or wrong)"
      });
      return;
    }
    if (bundle.kind !== BUNDLE_KIND_BY_VERSION[bundle.schemaVersion]) {
      jsonResponse(res, 400, {
        error: `Unsupported bundle: kind "${bundle.kind}" with schemaVersion ${bundle.schemaVersion}`
      });
      return;
    }
    if (!bundle.manifest) {
      jsonResponse(res, 400, { error: "Bundle missing theme" });
      return;
    }
    const bundleResolvers = {
      readColorsAndType: () => bundle.theme,
      // A named ref resolves inside the bundle only — a v1 bundle's
      // `${comp}/${name}` map is itself the sender's data, and a stale name
      // must still land in `dropped` rather than quietly picking up this
      // install's copy. But `'default'` never named a bundled entry; v1
      // spelled "no override" that way (normalizeTheme.ts's pointer-
      // resolution loop treats it identically), so it always meant *this
      // install's* default, not something the bundle carries. The
      // completeness fill relies on that fall-through: without it,
      // `readComponentConfig(comp, 'default')` answers undefined for every
      // component (no bundle ever carries a `<comp>/default` entry), the
      // fill loop no-ops 25 times, and an incomplete bundle stays incomplete
      // forever.
      readComponentConfig: (comp, name) => bundle.componentConfigs?.[`${comp}/${name}`] ?? (name === "default" ? readComponentConfig(comp, "default") : void 0),
      // Installed components are a property of this install, not of the
      // bundle being imported, so the completeness fill uses the
      // same list the disk resolver does.
      listComponentNames,
      normalizeColorsAndType: (colorsAndType) => normalizeColorsAndType(colorsAndType)
    };
    const { theme, dropped, filled } = normalizeTheme(bundle.manifest, bundleResolvers);
    if (theme.colorsAndType) theme.colorsAndType = normalizeColorsAndType(theme.colorsAndType);
    if (!theme.colorsAndType) {
      jsonResponse(res, 400, { error: "Bundle carries no theme" });
      return;
    }
    theme.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const renames = {};
    const originalName = sanitizeFileName(theme.name || "imported");
    const finalName = nextAvailableName2(
      (n) => themesResource.existingPath(n) !== null,
      originalName
    );
    if (finalName !== originalName) {
      renames[`theme:${originalName}`] = finalName;
    }
    writeTheme(finalName, theme);
    jsonResponse(res, 200, {
      ok: true,
      theme: finalName,
      renames,
      dropped,
      filled
    });
  }
  async function handleAdoptTheme({ res }) {
    const activeName = themesResource.getActiveName();
    if (activeName === "default") {
      jsonResponse(res, 409, {
        error: "Active theme is protected. Save As first.",
        code: "ACTIVE_IS_PROTECTED"
      });
      return;
    }
    const read = readTheme(activeName);
    if (!read) {
      respondUnreadableTheme(res, activeName, "Active theme not found");
      return;
    }
    themesResource.setProductionName(activeName);
    regenerateTokensCss();
    syncFontsToCss(read.theme.colorsAndType);
    jsonResponse(res, 200, {
      ok: true,
      productionTheme: {
        fileName: activeName,
        name: read.theme.name,
        updatedAt: read.theme.updatedAt
      }
    });
  }
  async function handleListSketchStyles({ res }) {
    const files = sketchStylesResource.listNames().map((fileName) => {
      let data = null;
      try {
        data = sketchStylesResource.readJson(fileName);
      } catch {
      }
      return {
        name: data?.name || fileName,
        fileName,
        updatedAt: data?.updatedAt || "",
        isPackage: sketchStylesResource.isPackageFile(fileName)
      };
    });
    jsonResponse(res, 200, { files });
  }
  async function handleSketchStyleByName({ params, req, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const filePath = sketchStylesResource.filePath(fileName);
    if (req.method === "GET") {
      const raw = sketchStylesResource.readJson(fileName);
      if (!raw) {
        jsonResponse(res, 404, { error: "Not found" });
        return;
      }
      jsonResponse(res, 200, { ...raw, _fileName: fileName });
      return;
    }
    if (req.method === "PUT") {
      const body = JSON.parse(await readBody(req));
      if (!body || typeof body !== "object" || !body.settings || typeof body.settings !== "object") {
        jsonResponse(res, 400, { error: "A sketchstyle needs a settings object" });
        return;
      }
      body.name = String(body.name || fileName);
      body.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (import_fs5.default.existsSync(filePath)) {
        try {
          const existing = JSON.parse(import_fs5.default.readFileSync(filePath, "utf-8"));
          if (existing.createdAt) body.createdAt = existing.createdAt;
        } catch {
        }
      }
      if (!body.createdAt) body.createdAt = body.updatedAt;
      sketchStylesResource.ensureDir();
      import_fs5.default.writeFileSync(filePath, JSON.stringify(body, null, 2));
      jsonResponse(res, 200, { ok: true, fileName });
      return;
    }
    if (req.method === "DELETE") {
      if (import_fs5.default.existsSync(filePath)) {
        import_fs5.default.unlinkSync(filePath);
      } else if (sketchStylesResource.existingPath(fileName)) {
        jsonResponse(res, 403, {
          error: "Cannot delete a sketchstyle shipped with the package. Saving it creates a local copy; deleting that copy restores the shipped version.",
          code: "PACKAGE_SKETCH_STYLE"
        });
        return;
      }
      jsonResponse(res, 200, { ok: true });
      return;
    }
  }
  function methodNotAllowed({ res }) {
    jsonResponse(res, 405, { error: "Method not allowed" });
  }
  let legacyLayout = null;
  const routes = [
    // Colors and type — list / active / production / working are exact strings;
    // they must run before COLORS_AND_TYPE_BY_NAME_REGEX
    { method: "GET", pattern: COLORS_AND_TYPE_ROUTE, handler: handleListColorsAndType },
    { method: "GET", pattern: COLORS_AND_TYPE_ACTIVE_ROUTE, handler: handleGetActiveColorsAndType },
    { method: "PUT", pattern: COLORS_AND_TYPE_ACTIVE_ROUTE, handler: methodNotAllowed },
    { method: "GET", pattern: COLORS_AND_TYPE_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "PUT", pattern: COLORS_AND_TYPE_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "POST", pattern: COLORS_AND_TYPE_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: COLORS_AND_TYPE_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "GET", pattern: COLORS_AND_TYPE_WORKING_ROUTE, handler: handleGetWorkingColorsAndType },
    { method: "PUT", pattern: COLORS_AND_TYPE_WORKING_ROUTE, handler: handleSetWorkingColorsAndType },
    { method: "DELETE", pattern: COLORS_AND_TYPE_WORKING_ROUTE, handler: handleClearWorkingColorsAndType },
    { method: "POST", pattern: COLORS_AND_TYPE_WORKING_ROUTE, handler: methodNotAllowed },
    // Component configs — list of components
    { method: "GET", pattern: COMPONENT_CONFIGS_ROUTE, handler: handleListComponents },
    // Component configs — :comp/active (must precede :comp/:name)
    { method: "GET", pattern: COMP_ACTIVE_REGEX, handler: handleGetComponentActive },
    { method: "PUT", pattern: COMP_ACTIVE_REGEX, handler: methodNotAllowed },
    { method: "POST", pattern: COMP_ACTIVE_REGEX, handler: methodNotAllowed },
    { method: "DELETE", pattern: COMP_ACTIVE_REGEX, handler: methodNotAllowed },
    // Component configs — :comp/production, retired with the per-layer pointers
    { method: "GET", pattern: COMP_PRODUCTION_REGEX, handler: methodNotAllowed },
    { method: "PUT", pattern: COMP_PRODUCTION_REGEX, handler: methodNotAllowed },
    { method: "POST", pattern: COMP_PRODUCTION_REGEX, handler: methodNotAllowed },
    { method: "DELETE", pattern: COMP_PRODUCTION_REGEX, handler: methodNotAllowed },
    // Component configs — :comp/working (must precede :comp/:name)
    { method: "GET", pattern: COMP_WORKING_REGEX, handler: handleGetComponentWorking },
    { method: "PUT", pattern: COMP_WORKING_REGEX, handler: handleSetComponentWorking },
    { method: "DELETE", pattern: COMP_WORKING_REGEX, handler: handleClearComponentWorking },
    { method: "POST", pattern: COMP_WORKING_REGEX, handler: methodNotAllowed },
    // Component configs — :comp/:name (must precede :comp listing)
    { method: "GET", pattern: COMP_BY_NAME_REGEX, handler: handleComponentConfigByName },
    { method: "PUT", pattern: COMP_BY_NAME_REGEX, handler: handleComponentConfigByName },
    { method: "DELETE", pattern: COMP_BY_NAME_REGEX, handler: handleComponentConfigByName },
    { method: "POST", pattern: COMP_BY_NAME_REGEX, handler: methodNotAllowed },
    // Component configs — list configs for :comp (broadest, runs last among comp routes)
    { method: "GET", pattern: COMP_LIST_REGEX, handler: handleListComponentConfigs },
    // Colors and type — :name CRUD (broadest colors-and-type route, runs last)
    { method: "GET", pattern: COLORS_AND_TYPE_BY_NAME_REGEX, handler: handleColorsAndTypeByName },
    { method: "PUT", pattern: COLORS_AND_TYPE_BY_NAME_REGEX, handler: handleColorsAndTypeByName },
    { method: "DELETE", pattern: COLORS_AND_TYPE_BY_NAME_REGEX, handler: handleColorsAndTypeByName },
    // Themes — list / active / production are exact strings, must run before regexes
    { method: "GET", pattern: THEMES_ROUTE, handler: handleListThemes },
    { method: "GET", pattern: THEMES_ACTIVE_ROUTE, handler: handleGetActiveTheme },
    { method: "PUT", pattern: THEMES_ACTIVE_ROUTE, handler: handleSetActiveTheme },
    { method: "GET", pattern: THEMES_PRODUCTION_ROUTE, handler: handleGetProductionTheme },
    // Adopt is the one door that moves the production pointer; naming a theme
    // here would be a second, silent way to publish.
    { method: "PUT", pattern: THEMES_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "POST", pattern: THEMES_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: THEMES_PRODUCTION_ROUTE, handler: methodNotAllowed },
    // Themes — exact import route runs before :name regexes
    { method: "POST", pattern: THEME_IMPORT_ROUTE, handler: handleImportTheme },
    { method: "PUT", pattern: THEME_IMPORT_ROUTE, handler: methodNotAllowed },
    { method: "GET", pattern: THEME_IMPORT_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: THEME_IMPORT_ROUTE, handler: methodNotAllowed },
    // Themes — :name/apply (more specific than :name)
    { method: "PUT", pattern: THEME_APPLY_REGEX, handler: handleApplyTheme },
    { method: "POST", pattern: THEME_APPLY_REGEX, handler: methodNotAllowed },
    { method: "GET", pattern: THEME_APPLY_REGEX, handler: methodNotAllowed },
    { method: "DELETE", pattern: THEME_APPLY_REGEX, handler: methodNotAllowed },
    // Themes — :name/export (more specific than :name)
    { method: "GET", pattern: THEME_EXPORT_REGEX, handler: handleExportTheme },
    { method: "PUT", pattern: THEME_EXPORT_REGEX, handler: methodNotAllowed },
    { method: "POST", pattern: THEME_EXPORT_REGEX, handler: methodNotAllowed },
    { method: "DELETE", pattern: THEME_EXPORT_REGEX, handler: methodNotAllowed },
    // Themes — :name CRUD (broadest theme route, runs last)
    { method: "GET", pattern: THEME_BY_NAME_REGEX, handler: handleThemeByName },
    { method: "PUT", pattern: THEME_BY_NAME_REGEX, handler: handleThemeByName },
    { method: "DELETE", pattern: THEME_BY_NAME_REGEX, handler: handleThemeByName },
    // Production — the whole-theme adopt door
    { method: "GET", pattern: SKETCH_STYLES_ROUTE, handler: handleListSketchStyles },
    { method: "PUT", pattern: SKETCH_STYLES_ROUTE, handler: methodNotAllowed },
    { method: "POST", pattern: SKETCH_STYLES_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: SKETCH_STYLES_ROUTE, handler: methodNotAllowed },
    { method: "GET", pattern: SKETCH_STYLE_BY_NAME_REGEX, handler: handleSketchStyleByName },
    { method: "PUT", pattern: SKETCH_STYLE_BY_NAME_REGEX, handler: handleSketchStyleByName },
    { method: "DELETE", pattern: SKETCH_STYLE_BY_NAME_REGEX, handler: handleSketchStyleByName },
    { method: "POST", pattern: SKETCH_STYLE_BY_NAME_REGEX, handler: methodNotAllowed },
    { method: "GET", pattern: EVENTS_ROUTE, handler: handleEvents },
    { method: "PUT", pattern: PRODUCTION_ROUTE, handler: handleAdoptTheme },
    { method: "GET", pattern: PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "POST", pattern: PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: PRODUCTION_ROUTE, handler: methodNotAllowed }
  ];
  const isEditorOwnedJson = (file) => file.endsWith(".json") && import_path5.default.resolve(file).startsWith(dataDirs.dataDir + import_path5.default.sep);
  let buildLogger = null;
  let buildChecked = false;
  let productionCssLogger = null;
  return {
    name: "theme-file-api",
    config() {
      return {
        define: {
          __PROJECT_ROOT__: JSON.stringify(process.cwd()),
          __APP_VERSION__: JSON.stringify(PKG_VERSION),
          __LIVE_TOKENS_API_BASE__: JSON.stringify(API_BASE)
        },
        server: { watch: { ignored: [isEditorOwnedJson] } }
      };
    },
    configResolved(config) {
      buildLogger = config.command === "build" && opts.checks !== false ? config.logger : null;
      productionCssLogger = config.command === "build" && opts.productionCss !== false ? config.logger : null;
    },
    async buildStart() {
      if (!buildLogger || buildChecked) return;
      buildChecked = true;
      const failure = await checkBeforeBuild({ root: process.cwd(), logger: buildLogger });
      if (failure) this.error(failure);
    },
    generateBundle: {
      // After Vite's own hooks, so the bundle holds the minified CSS and index.html.
      order: "post",
      handler(output, bundle) {
        if (!productionCssLogger) return;
        const report = rewriteBundle(bundle, opts.productionCss || {}, output);
        if (report) productionCssLogger.info(formatReport(report));
      }
    },
    configureServer(server) {
      legacyLayout = detectLegacyLayout({
        dataDir: dataDirs.dataDir,
        colorsAndTypeDir: COLORS_AND_TYPE_DIR,
        themesDir: THEMES_DIR,
        configuredManifestsDir: dataDirs.legacyManifestsDir
      });
      if (legacyLayout) {
        warnOnLegacyLayout(legacyLayout.evidence, (msg) => server.config.logger.warn(msg));
      } else {
        ensureColorsAndTypeDir();
        ensureComponentConfigsDir();
        const { productionPointerHeld } = ensureThemesDir((msg) => server.config.logger.warn(msg));
        const openTheme = activeTheme();
        if (openTheme) pruneMatchingWorking(openTheme);
        if (!productionPointerHeld || !import_fs5.default.existsSync(GENERATED_CSS_PATH)) regenerateTokensCss();
        if (opts.autoMigrate && !ISOLATED_DATA_DIR) {
          autoMigrateAdditive((msg) => server.config.logger.info(msg));
        }
        warnOnTokenDrift((msg) => server.config.logger.warn(msg));
        warnOnLegacyPointers(
          listLegacyPointers(),
          productionPointerHeld,
          (msg) => server.config.logger.warn(msg)
        );
        warnOnUnmigratedSketchStyles((msg) => server.config.logger.warn(msg));
      }
      server.middlewares.use(async (req, res, next) => {
        if (legacyLayout && req.method !== "GET" && (req.url ?? "").startsWith(API_BASE)) {
          jsonResponse(res, 409, {
            error: "This project still uses the data layout from 0.47 and earlier. Run `npx live-tokens migrate`, then restart the dev server.",
            code: "LEGACY_LAYOUT"
          });
          return;
        }
        const handled = await dispatch(req, res, routes);
        if (!handled) next();
      });
    },
    handleHotUpdate(ctx) {
      if (legacyLayout) return;
      const normalized = import_path5.default.resolve(ctx.file);
      if (!COMPONENTS_SCAN_DIRS.some((d) => normalized.startsWith(d))) return;
      if (!normalized.endsWith(".svelte")) return;
      if (!isThemeAwareComponent(normalized)) return;
      const comp = componentNameFromFile(normalized);
      generateDefaultConfig(comp, normalized);
    }
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  TOKENS_CSS_MIGRATIONS,
  runTokensCssMigrations,
  themeFileApi,
  validateTokensCss
});
