<script module lang="ts">
  import type { Token, IntrinsicSpec } from './scaffolding/types';

  export const component = 'image';

  const variants = ['default', 'bare'] as const;
  type Variant = typeof variants[number];

  function frameTokens(v: Variant): Token[] {
    return [
      { label: 'border color', groupKey: 'border', variable: `--image-${v}-border` },
      { label: 'border width', groupKey: 'width', variable: `--image-${v}-border-width` },
      { label: 'corner radius', groupKey: 'radius', variable: `--image-${v}-radius` },
      { label: 'image shadow', groupKey: 'shadow', variable: `--image-${v}-shadow` },
    ];
  }
  const zoomScale: Token = { label: 'zoom amount', groupKey: 'scale', variable: '--image-zoom-scale' };
  function variantStates(v: Variant): Record<string, Token[]> {
    return { [v]: v === 'default' ? [...frameTokens(v), zoomScale] : frameTokens(v) };
  }

  export const allTokens: Token[] = variants.flatMap((v) => Object.values(variantStates(v)).flat());

  const variantOptions = variants.map((v) => ({ value: v, label: v.charAt(0).toUpperCase() + v.slice(1) }));

  // Global zoom defaults. `none` = off; `scale(...)` = on. `--image-zoom-enabled` scales the
  // content within the masked frame (overflow scaling); `--image-grow-enabled` scales the whole
  // frame so it grows. At most one is ever `scale(...)`.
  const ZOOM_ON = 'scale(var(--image-zoom-scale))';
  export const intrinsics: IntrinsicSpec[] = [
    {
      key: 'zoom',
      variants: ['default'],
      variable: () => '--image-zoom-enabled',
      values: ['none', ZOOM_ON],
      default: { default: 'none' },
    },
    {
      key: 'grow',
      variants: ['default'],
      variable: () => '--image-grow-enabled',
      values: ['none', ZOOM_ON],
      default: { default: 'none' },
    },
  ];
</script>

<script lang="ts">
  import Image from '../../system/components/Image.svelte';
  import VariantGroup from './scaffolding/VariantGroup.svelte';
  import ComponentEditorBase from './scaffolding/ComponentEditorBase.svelte';
  import { buildSiblings } from './scaffolding/siblings';
  import demoImageUrl from '../../system/assets/newspaper.webp';
  import { editorState, setComponentAlias } from '../core/store/editorStore';

  let aliases = $derived(
    ($editorState.components[component]?.aliases ?? {}) as Record<string, import('../core/store/editorTypes').CssVarRef>,
  );
  function aliasValue(variable: string, fallback: string): string {
    const ref = aliases[variable];
    return ref?.kind === 'literal' ? ref.value : fallback;
  }
  let contentOn = $derived(aliasValue('--image-zoom-enabled', intrinsics[0].default.default) === ZOOM_ON);
  let frameOn = $derived(aliasValue('--image-grow-enabled', intrinsics[1].default.default) === ZOOM_ON);
  let useZoom = $derived(contentOn || frameOn);
  // Overflow scaling = mask the zoom to the frame (the content path). Off = grow the frame.
  let overflowScaling = $derived(!frameOn);

  function applyZoom(zoomOn: boolean, masked: boolean) {
    setComponentAlias(component, '--image-zoom-enabled', { kind: 'literal', value: zoomOn && masked ? ZOOM_ON : 'none' });
    setComponentAlias(component, '--image-grow-enabled', { kind: 'literal', value: zoomOn && !masked ? ZOOM_ON : 'none' });
  }
  const setUseZoom = (checked: boolean) => applyZoom(checked, overflowScaling);
  const setOverflowScaling = (checked: boolean) => applyZoom(useZoom, checked);
</script>

<ComponentEditorBase {component} title="Image" description="Picture in the page flow. Default frames it with rounded corners, a border, and a shadow. Bare shows the picture alone." tokens={allTokens} variants={variantOptions}>
  <VariantGroup name="default" title="Default" states={variantStates('default')} {component} siblings={buildSiblings(variants, 'default', variantStates)}>
    {#snippet stateActions()}
      <label class="zoom-enable">
        <input type="checkbox" checked={useZoom} onchange={(e) => setUseZoom(e.currentTarget.checked)} />
        <span>Use zoom on hover</span>
      </label>
      <label class="zoom-enable" class:disabled={!useZoom}>
        <input type="checkbox" checked={overflowScaling} disabled={!useZoom} onchange={(e) => setOverflowScaling(e.currentTarget.checked)} />
        <span>Overflow scaling (mask zoom to frame)</span>
      </label>
    {/snippet}
    <Image src={demoImageUrl} alt="Demo" size="banner" zoom={useZoom ? undefined : false} {overflowScaling} forceHover={useZoom} />
    <p class="zoom-help">
      Use zoom on hover: every image scales on hover (a page can still force it per image with the
      <code>zoom</code> prop). Overflow scaling on (default): the content zooms inside the fixed frame,
      masked by overflow. Off: the whole framed image grows past its box. Override per image with
      <code>overflowScaling</code>.
    </p>
  </VariantGroup>
  <VariantGroup name="bare" title="Bare" states={variantStates('bare')} {component} siblings={buildSiblings(variants, 'bare', variantStates)}>
    <Image src={demoImageUrl} alt="Demo" variant="bare" size="banner" />
  </VariantGroup>
</ComponentEditorBase>

<style>
  .zoom-enable {
    display: inline-flex;
    align-items: center;
    gap: var(--ui-space-4);
    font-size: var(--ui-font-size-sm);
    color: var(--ui-text-secondary);
    cursor: pointer;
  }
  .zoom-enable.disabled {
    opacity: var(--ui-opacity-disabled);
    cursor: not-allowed;
  }
  .zoom-help {
    margin: var(--ui-space-8) 0 0;
    font-size: var(--ui-font-size-sm);
    color: var(--ui-text-tertiary);
  }
  .zoom-help code {
    font-family: var(--ui-font-mono);
  }
</style>
