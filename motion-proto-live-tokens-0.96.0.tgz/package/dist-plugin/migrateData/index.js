import {
  THEME_SCHEMA_VERSION,
  applyLegacyRenames,
  detectLegacyLayout,
  isColorsAndTypeShaped,
  nextAvailableName,
  normalizeTheme,
  planLegacyRenames,
  versionedFileResourceServer
} from "../chunk-GYRULB2X.js";
import {
  CURRENT_COMPONENT_SCHEMA_VERSION
} from "../chunk-QQASYPW7.js";
import {
  readLiveTokensConfig,
  resolveDataDirs
} from "../chunk-6WGFOJXO.js";

// vite-plugin/migrateData/migrateData.ts
import fs from "fs";
import path from "path";
var RECOVERED_SLUG = "recovered-production";
var RECOVERED_NAME = "Recovered production";
var MARKER_KEYS = ["_fileName", "_source"];
var VOLATILE_KEYS = [...MARKER_KEYS, "updatedAt"];
function isObject(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
function sortDeep(value) {
  if (Array.isArray(value)) return value.map(sortDeep);
  if (!isObject(value)) return value;
  const out = {};
  for (const key of Object.keys(value).sort()) out[key] = sortDeep(value[key]);
  return out;
}
function comparable(value) {
  if (!isObject(value)) return JSON.stringify(sortDeep(value));
  const stable = {};
  for (const key of Object.keys(value).sort()) {
    if (VOLATILE_KEYS.includes(key)) continue;
    stable[key] = sortDeep(value[key]);
  }
  return JSON.stringify(stable);
}
function sameContent(a, b) {
  return comparable(a) === comparable(b);
}
function stripMarkers(value) {
  const out = {};
  for (const [key, v] of Object.entries(value)) {
    if (!MARKER_KEYS.includes(key)) out[key] = v;
  }
  return out;
}
function readPointerName(file, key) {
  if (!fs.existsSync(file)) return null;
  try {
    const name = JSON.parse(fs.readFileSync(file, "utf-8"))[key];
    return typeof name === "string" && name ? name : null;
  } catch {
    return null;
  }
}
function localNamedFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter((f) => f.endsWith(".json") && !f.startsWith("_")).map((f) => f.slice(0, -".json".length)).filter((name) => name !== "default");
}
function componentNames(componentConfigsDir) {
  if (!fs.existsSync(componentConfigsDir)) return [];
  return fs.readdirSync(componentConfigsDir, { withFileTypes: true }).filter((e) => e.isDirectory()).map((e) => e.name).sort();
}
function shippedNames(packageDataDir, subdir) {
  try {
    const pkgRoot = path.resolve(packageDataDir, "..", "..", "..");
    const pkg = JSON.parse(fs.readFileSync(path.join(pkgRoot, "package.json"), "utf-8"));
    const files = Array.isArray(pkg.files) ? pkg.files : [];
    const prefix = `src/live-tokens/data/${subdir}/`;
    return files.filter((f) => f.startsWith(prefix) && /^[^/]+\.json$/.test(f.slice(prefix.length))).map((f) => path.basename(f, ".json"));
  } catch {
    return [];
  }
}
function migrateData(opts) {
  const { componentConfigsDir, check = false } = opts;
  const packageDataDir = opts.packageDataDir;
  const layoutInput = {
    dataDir: opts.dataDir,
    colorsAndTypeDir: opts.colorsAndTypeDir,
    themesDir: opts.themesDir,
    configuredManifestsDir: opts.legacyManifestsDir
  };
  const legacyLayout = detectLegacyLayout(layoutInput);
  const legacyRenames = legacyLayout ? planLegacyRenames(legacyLayout, layoutInput) : [];
  const sketchStylesFrom = path.join(opts.dataDir, "sketch-presets");
  const sketchStylesTo = path.join(opts.dataDir, "sketch-styles");
  const sketchStylesRenames = fs.existsSync(sketchStylesFrom) ? [{ from: sketchStylesFrom, to: sketchStylesTo }] : [];
  const renames = [...legacyRenames, ...sketchStylesRenames];
  if (!check) applyLegacyRenames(renames);
  const planningLegacy = legacyLayout !== null && check;
  const colorsAndTypeDir = planningLegacy ? opts.themesDir : opts.colorsAndTypeDir;
  const themesDir = planningLegacy ? legacyLayout.manifestsDir : opts.themesDir;
  const reported = (p) => {
    if (!planningLegacy) return p;
    for (const { from, to } of renames) {
      if (p.startsWith(from + path.sep)) return path.join(to, p.slice(from.length + 1));
    }
    return p;
  };
  const colorsRes = versionedFileResourceServer({
    dir: colorsAndTypeDir,
    packageDir: packageDataDir ? path.join(packageDataDir, "colors-and-type") : void 0,
    packageOwnedNames: packageDataDir ? shippedNames(packageDataDir, "colors-and-type") : void 0
  });
  const themesRes = versionedFileResourceServer({
    dir: themesDir,
    packageDir: packageDataDir ? path.join(packageDataDir, "themes") : void 0
  });
  const componentResources = /* @__PURE__ */ new Map();
  const compRes = (comp) => {
    let r = componentResources.get(comp);
    if (!r) {
      r = versionedFileResourceServer({
        dir: path.join(componentConfigsDir, comp),
        packageDir: packageDataDir ? path.join(packageDataDir, "component-configs", comp) : void 0,
        packageOwnedNames: packageDataDir ? shippedNames(packageDataDir, `component-configs/${comp}`) : void 0
      });
      componentResources.set(comp, r);
    }
    return r;
  };
  const comps = componentNames(componentConfigsDir);
  const legacyPointers = [];
  for (const dir of [colorsAndTypeDir, ...comps.map((c) => path.join(componentConfigsDir, c))]) {
    for (const name of ["_active.json", "_production.json"]) {
      const p = path.join(dir, name);
      if (fs.existsSync(p)) legacyPointers.push(p);
    }
  }
  const empty = {
    status: "clean",
    renames,
    production: null,
    recoveredThemePath: null,
    workingWritten: [],
    workingKept: [],
    deletedFiles: [],
    deletedPointers: [],
    keptUserFiles: [],
    notThemes: [],
    droppedRefs: [],
    shadowedDefaults: [],
    upgradedThemes: []
  };
  if (legacyPointers.length === 0) {
    if (!legacyLayout && renames.length === 0) return empty;
    return { ...empty, status: check ? "planned" : "healed" };
  }
  const resolvers = {
    readColorsAndType: (name) => colorsRes.readJson(name),
    readComponentConfig: (comp, name) => compRes(comp).readJson(name),
    listComponentNames: () => comps,
    normalizeColorsAndType: (colorsAndType) => colorsAndType
  };
  const upgradedThemes = [];
  const notThemes = [];
  const droppedRefs = [];
  const themes = [];
  for (const slug of themesRes.listNames()) {
    let raw;
    try {
      raw = themesRes.readJson(slug);
    } catch {
      continue;
    }
    if (!raw) continue;
    if (isColorsAndTypeShaped(raw)) {
      notThemes.push(themesRes.filePath(slug));
      continue;
    }
    const { theme, migrated, dropped } = normalizeTheme(raw, resolvers);
    themes.push({ slug, theme });
    for (const ref of dropped) {
      droppedRefs.push(
        `theme "${slug}": the reference ${ref} resolved to nothing, so it carries the shipped default instead`
      );
    }
    if (migrated && fs.existsSync(themesRes.filePath(slug))) {
      upgradedThemes.push(themesRes.filePath(slug));
      if (!check) fs.writeFileSync(themesRes.filePath(slug), JSON.stringify(theme, null, 2));
    }
  }
  const themeBySlug = new Map(themes.map((t) => [t.slug, t.theme]));
  const resolveName = (res, dir, file, key) => {
    const name = readPointerName(path.join(dir, file), key);
    if (!name || res.existingPath(name) === null) return "default";
    return name;
  };
  const readPointed = (res, name) => {
    try {
      return res.readJson(name);
    } catch (err) {
      const file = res.existingPath(name) ?? res.filePath(name);
      throw new Error(
        `${file} will not parse (${err instanceof Error ? err.message : String(err)}), and a retired pointer names it. Fix or delete the file, then run the migration again.`
      );
    }
  };
  const defaultConfig = (comp) => compRes(comp).readJson("default");
  const themeConfigFor = (theme, comp) => {
    const embedded = theme.componentConfigs[comp];
    return embedded ? { ...embedded, component: comp } : defaultConfig(comp);
  };
  const prodColorsName = resolveName(colorsRes, colorsAndTypeDir, "_production.json", "productionFile");
  const prodConfigNames = new Map(
    comps.map((comp) => [
      comp,
      resolveName(compRes(comp), path.join(componentConfigsDir, comp), "_production.json", "productionFile")
    ])
  );
  const prodColors = readPointed(colorsRes, prodColorsName);
  const prodConfigs = new Map(
    comps.map((comp) => [comp, readPointed(compRes(comp), prodConfigNames.get(comp))])
  );
  const allDefault = prodColorsName === "default" && [...prodConfigNames.values()].every((n) => n === "default");
  const matchesPointedProduction = (theme) => sameContent(theme.colorsAndType, prodColors) && comps.every((comp) => sameContent(themeConfigFor(theme, comp), prodConfigs.get(comp)));
  let production;
  let recoveredTheme = null;
  let recoveredThemePath = null;
  if (allDefault) {
    production = { slug: "default", how: "all-default" };
  } else {
    const match = themes.find((t) => matchesPointedProduction(t.theme));
    if (match) {
      production = { slug: match.slug, how: "matched" };
    } else {
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const componentConfigs = {};
      for (const comp of comps) {
        const pointed = prodConfigs.get(comp);
        if (!isObject(pointed)) continue;
        componentConfigs[comp] = stripMarkers(pointed);
      }
      recoveredTheme = {
        name: RECOVERED_NAME,
        createdAt: now,
        updatedAt: now,
        schemaVersion: THEME_SCHEMA_VERSION,
        colorsAndType: isObject(prodColors) ? stripMarkers(prodColors) : null,
        componentConfigs,
        // The configs above are what boot just wrote (`prodConfigs`, read off
        // the pointed files), at the current component schema — not 0, which
        // would misdescribe them as unmigrated.
        componentSchemaVersion: CURRENT_COMPONENT_SCHEMA_VERSION
      };
      const slug = nextAvailableName((n) => themesRes.existingPath(n) !== null, RECOVERED_SLUG);
      recoveredThemePath = themesRes.filePath(slug);
      production = { slug, how: "recovered" };
    }
  }
  const activeThemeSlug = themesRes.getActiveName();
  const activeTheme = themeBySlug.get(activeThemeSlug) ?? null;
  const workingWritten = [];
  const workingKept = [];
  const planWorking = (res, live, saved) => {
    if (!isObject(live) || sameContent(live, saved)) return;
    if (res.hasWorking()) {
      workingKept.push(res.workingPath);
      return;
    }
    workingWritten.push(res.workingPath);
    if (!check) res.writeWorking(stripMarkers(live));
  };
  const activeColorsName = resolveName(colorsRes, colorsAndTypeDir, "_active.json", "activeFile");
  planWorking(
    colorsRes,
    readPointed(colorsRes, activeColorsName),
    activeTheme?.colorsAndType ?? colorsRes.readJson("default")
  );
  for (const comp of comps) {
    const activeName = resolveName(
      compRes(comp),
      path.join(componentConfigsDir, comp),
      "_active.json",
      "activeFile"
    );
    planWorking(
      compRes(comp),
      readPointed(compRes(comp), activeName),
      activeTheme ? themeConfigFor(activeTheme, comp) : defaultConfig(comp)
    );
  }
  const deletedFiles = [];
  const keptUserFiles = [];
  const sweep = (res, dir, savedCopies) => {
    for (const name of localNamedFiles(dir)) {
      if (res.isPackageFile(name)) continue;
      let content;
      try {
        content = res.readJson(name);
      } catch {
        keptUserFiles.push(res.filePath(name));
        continue;
      }
      const matched = themes.some((t) => sameContent(savedCopies(t.theme), content));
      if (!matched) {
        keptUserFiles.push(res.filePath(name));
        continue;
      }
      deletedFiles.push(res.filePath(name));
      if (!check) fs.unlinkSync(res.filePath(name));
    }
  };
  sweep(colorsRes, colorsAndTypeDir, (theme) => theme.colorsAndType);
  for (const comp of comps) {
    sweep(compRes(comp), path.join(componentConfigsDir, comp), (theme) => themeConfigFor(theme, comp));
  }
  const shadowedDefaults = [];
  const localDefault = path.join(colorsAndTypeDir, "default.json");
  const packageDefault = packageDataDir ? path.join(packageDataDir, "colors-and-type", "default.json") : null;
  if (packageDefault && fs.existsSync(localDefault) && fs.existsSync(packageDefault) && path.resolve(localDefault) !== path.resolve(packageDefault)) {
    try {
      const local = JSON.parse(fs.readFileSync(localDefault, "utf-8"));
      const shipped = JSON.parse(fs.readFileSync(packageDefault, "utf-8"));
      if (!sameContent(local, shipped)) shadowedDefaults.push(localDefault);
    } catch {
    }
  }
  if (!check) {
    for (const p of legacyPointers) fs.unlinkSync(p);
  }
  if (!check) {
    if (recoveredTheme && recoveredThemePath) {
      themesRes.ensureDir();
      fs.writeFileSync(recoveredThemePath, JSON.stringify(recoveredTheme, null, 2));
    }
    themesRes.ensureDir();
    themesRes.setProductionName(production.slug);
  }
  return {
    status: check ? "planned" : "healed",
    renames,
    production,
    recoveredThemePath: recoveredThemePath && reported(recoveredThemePath),
    workingWritten: workingWritten.map(reported),
    workingKept: workingKept.map(reported),
    deletedFiles: deletedFiles.map(reported),
    deletedPointers: legacyPointers.map(reported),
    keptUserFiles: keptUserFiles.map(reported),
    notThemes: notThemes.map(reported),
    droppedRefs,
    shadowedDefaults: shadowedDefaults.map(reported),
    upgradedThemes: upgradedThemes.map(reported)
  };
}
export {
  migrateData,
  readLiveTokensConfig,
  resolveDataDirs
};
