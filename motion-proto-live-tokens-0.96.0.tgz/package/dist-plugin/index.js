import {
  THEME_SCHEMA_VERSION,
  detectLegacyLayout,
  isColorsAndTypeShaped,
  nextAvailableName,
  normalizeTheme,
  versionedFileResourceServer
} from "./chunk-GYRULB2X.js";
import {
  TOKENS_CSS_MIGRATIONS,
  extractGlobalRootBody,
  runAdditiveTokensCssMigrations,
  runTokensCssMigrations,
  validateTokensCss
} from "./chunk-4J6JPSVS.js";
import {
  formatGradientValue,
  palettesToVars,
  parseColorOpacity,
  parseGradientValue,
  reconcilePalettesFromCssVars,
  sanitizeFileName
} from "./chunk-A4TBP4MM.js";
import {
  hexToOklch,
  oklchToRgb255,
  parseOklchCss
} from "./chunk-7TQQTHI6.js";
import {
  CURRENT_COMPONENT_SCHEMA_VERSION
} from "./chunk-QQASYPW7.js";
import {
  resolveDataDirs,
  testDataDir,
  testPackageDataDir
} from "./chunk-6WGFOJXO.js";

// vite-plugin/themeFileApi.ts
import fs2 from "fs";
import { createHash as createHash2 } from "crypto";
import path3 from "path";

// src/editor/core/themes/migrations/2026-07-21-palette-oklch-basis.ts
var round = (v, dp) => {
  const f = 10 ** dp;
  return Math.round(v * f) / f;
};
function toStoredOklch(value) {
  if (typeof value !== "string") return value;
  const { l, c, h } = hexToOklch(value);
  return { l: round(l, 4), c: round(c, 4), h: round(h, 2) };
}
function migratePaletteColorsToOklch(editorConfigs) {
  const out = {};
  for (const [label, cfg] of Object.entries(editorConfigs)) {
    const overrides = {};
    for (const [k, v] of Object.entries(cfg.overrides ?? {})) overrides[k] = toStoredOklch(v);
    out[label] = { ...cfg, baseColor: toStoredOklch(cfg.baseColor), overrides };
  }
  return out;
}

// src/system/backdrop/backdrop.ts
var LIGHT_BACKDROP = 0.2;
var OPAQUE = 0.98;
var HEX_RE = /#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})\b/gi;
var OKLCH_RE = /oklch\(\s*[\d.]+%?\s+[\d.]+%?\s+[\d.]+(?:deg)?\s*(?:\/\s*([\d.]+%?)\s*)?\)/gi;
var RGB_RE = /rgba?\(\s*([\d.]+%?)\s*[, ]\s*([\d.]+%?)\s*[, ]\s*([\d.]+%?)(?:\s*[,/]\s*([\d.]+%?))?\s*\)/gi;
var EXOTIC_RE = /\b(?:color-mix|hwb|lab|lch|oklab|color)\([^()]*\)/gi;
function channel(value) {
  const parsed = Number.parseFloat(value);
  return value.endsWith("%") ? parsed * 2.55 : parsed;
}
function alpha(value) {
  if (value === void 0) return 1;
  const parsed = Number.parseFloat(value);
  return value.endsWith("%") ? parsed / 100 : parsed;
}
function parseHex(hex) {
  const digits = hex.slice(1);
  const full = digits.length <= 4 ? digits.split("").map((part) => part + part).join("") : digits;
  return {
    r: Number.parseInt(full.slice(0, 2), 16),
    g: Number.parseInt(full.slice(2, 4), 16),
    b: Number.parseInt(full.slice(4, 6), 16),
    a: full.length >= 8 ? Number.parseInt(full.slice(6, 8), 16) / 255 : 1
  };
}
function colorsIn(background) {
  const colors = [];
  for (const match of background.matchAll(HEX_RE)) colors.push(parseHex(match[0]));
  for (const match of background.matchAll(OKLCH_RE)) {
    const parsed = parseOklchCss(match[0]);
    if (parsed) colors.push({ ...oklchToRgb255(parsed.l, parsed.c, parsed.h), a: alpha(match[1]) });
  }
  for (const match of background.matchAll(RGB_RE)) {
    colors.push({
      r: channel(match[1]),
      g: channel(match[2]),
      b: channel(match[3]),
      a: alpha(match[4])
    });
  }
  for (const match of background.matchAll(EXOTIC_RE)) {
    const resolved = viaCanvas(match[0]);
    if (resolved) colors.push(resolved);
  }
  return colors;
}
function linearChannel(value) {
  const srgb = Math.max(0, Math.min(255, value)) / 255;
  return srgb <= 0.04045 ? srgb / 12.92 : ((srgb + 0.055) / 1.055) ** 2.4;
}
function luminance({ r, g, b }) {
  return 0.2126 * linearChannel(r) + 0.7152 * linearChannel(g) + 0.0722 * linearChannel(b);
}
var SEED = "#010203";
var probe;
function viaCanvas(value) {
  if (typeof document === "undefined") return null;
  if (probe === void 0) {
    probe = document.createElement("canvas").getContext?.("2d", { willReadFrequently: true }) ?? null;
  }
  if (!probe) return null;
  probe.fillStyle = SEED;
  probe.fillStyle = value;
  if (probe.fillStyle === SEED) return null;
  probe.clearRect(0, 0, 1, 1);
  probe.fillRect(0, 0, 1, 1);
  const [r, g, b, a] = probe.getImageData(0, 0, 1, 1).data;
  return { r, g, b, a: a / 255 };
}
function backgroundLuminance(background) {
  const opaque = colorsIn(background).filter((color) => color.a >= OPAQUE);
  if (!opaque.length) return null;
  return opaque.reduce((total, color) => total + luminance(color), 0) / opaque.length;
}
function polarityOfBackground(background) {
  const measured = backgroundLuminance(background);
  if (measured === null) return null;
  return measured >= LIGHT_BACKDROP ? "light" : "dark";
}

// vite-plugin/files/routeTable.ts
async function dispatch(req, res, routes) {
  const url = req.url || "";
  const method = req.method || "GET";
  for (const route of routes) {
    if (route.method !== method) continue;
    let params = [];
    if (typeof route.pattern === "string") {
      if (url !== route.pattern) continue;
    } else {
      const m = url.match(route.pattern);
      if (!m) continue;
      params = m.slice(1);
    }
    try {
      await route.handler({ url, params, req, res });
    } catch (err) {
      if (!res.writableEnded) {
        res.statusCode = 500;
        res.setHeader("Content-Type", "application/json");
        res.end(JSON.stringify({ error: err?.message ?? "Internal error" }));
      }
    }
    return true;
  }
  return false;
}

// vite-plugin/files/dataTreeWatch.ts
import fs from "fs";
import path from "path";
function fingerprint(file) {
  try {
    return fs.readFileSync(file, "utf-8");
  } catch {
    return null;
  }
}
function dataTreeWatch(opts) {
  const debounceMs = opts.debounceMs ?? 100;
  const ownWrites = /* @__PURE__ */ new Map();
  const listeners = /* @__PURE__ */ new Set();
  let watchers = [];
  let timer = null;
  function noteOwnWrite(file) {
    const resolved = path.resolve(file);
    ownWrites.set(resolved, fingerprint(resolved));
  }
  function onEvent(dir, filename) {
    if (!filename) return;
    const file = path.resolve(dir, filename.toString());
    if (!opts.isLive(file)) return;
    if (ownWrites.has(file) && ownWrites.get(file) === fingerprint(file)) return;
    ownWrites.delete(file);
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      for (const listener of listeners) listener();
    }, debounceMs);
  }
  function start() {
    for (const dir of opts.dirs) {
      if (!fs.existsSync(dir)) continue;
      const watcher = fs.watch(
        dir,
        { recursive: true, persistent: false },
        (_event, filename) => onEvent(dir, filename)
      );
      watcher.on("error", () => watcher.close());
      watchers.push(watcher);
    }
  }
  function stop() {
    for (const watcher of watchers) watcher.close();
    watchers = [];
    if (timer) clearTimeout(timer);
    timer = null;
  }
  function subscribe(listener) {
    if (listeners.size === 0) start();
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
      if (listeners.size === 0) stop();
    };
  }
  return { noteOwnWrite, subscribe };
}

// vite-plugin/buildChecks.ts
import path2 from "path";
import { fileURLToPath, pathToFileURL } from "url";
var runPackageChecks = async (root) => {
  const runner = path2.resolve(path2.dirname(fileURLToPath(import.meta.url)), "..", "bin", "lib", "buildChecks.mjs");
  const { runBuildChecks } = await import(pathToFileURL(runner).href);
  return runBuildChecks({ root });
};
async function checkBeforeBuild({
  root,
  logger,
  run = runPackageChecks
}) {
  const result = await run(root);
  if (result.errors > 0) {
    logger.error(result.report);
    return `live-tokens: the design checks found ${result.errors} error(s). Run the live-tokens-check-compliance skill, or \`npx live-tokens check-page\` and \`npx live-tokens check-component\`, to repair them.`;
  }
  (result.warnings > 0 ? logger.warn : logger.info).call(logger, result.report);
  return null;
}

// vite-plugin/productionCss/index.ts
import { createHash } from "crypto";

// vite-plugin/productionCss/analyze.ts
import postcss from "postcss";
var ROOT_SPECIFICITY = /* @__PURE__ */ new Map([
  [":root", [0, 1, 0]],
  [":root:root", [0, 2, 0]],
  [":where(:root)", [0, 0, 0]],
  ["html", [0, 0, 1]]
]);
var NAME = String.raw`--(?:[\w-]|[^\x00-\x7f])+`;
var VAR_REF = new RegExp(String.raw`var\(\s*(${NAME})`, "gi");
var PRELUDE_NAME = new RegExp(NAME, "g");
var SCRIPT_NAME = new RegExp(String.raw`(?<![\w-])${NAME}`, "g");
var CSS_WIDE_KEYWORD = /^\s*(?:initial|inherit|unset|revert|revert-layer)\s*$/i;
var varRefs = (value) => [...value.matchAll(VAR_REF)].map((m) => m[1]);
function compareSpecificity(a, b) {
  return a[0] - b[0] || a[1] - b[1] || a[2] - b[2];
}
function rootSpecificity(selector) {
  let best = null;
  for (const part of selector.split(",")) {
    const specificity = ROOT_SPECIFICITY.get(part.trim());
    if (!specificity) return null;
    if (!best || compareSpecificity(specificity, best) > 0) best = specificity;
  }
  return best;
}
function outranks(a, b) {
  if (a.important !== b.important) return a.important;
  const bySpecificity = compareSpecificity(a.specificity, b.specificity);
  if (bySpecificity !== 0) return bySpecificity > 0;
  return a.asset !== b.asset ? a.asset > b.asset : a.order > b.order;
}
function winnerOf(declarations) {
  let winner = null;
  for (const d of declarations) if (d.bare && (!winner || outranks(d, winner))) winner = d;
  return winner;
}
function analyze({ css, js, html, keep, entries }) {
  const declarations = /* @__PURE__ */ new Map();
  const regularRefs = /* @__PURE__ */ new Set();
  const preludeNames = /* @__PURE__ */ new Set();
  const registered = /* @__PURE__ */ new Set();
  const reads = css.map(() => /* @__PURE__ */ new Set());
  css.forEach((source, asset) => {
    let order = 0;
    postcss.parse(source).walk((node) => {
      if (node.type === "atrule") {
        if (node.name.toLowerCase() === "property") registered.add(node.params.trim());
        for (const [name] of node.params.matchAll(PRELUDE_NAME)) preludeNames.add(name);
        return;
      }
      if (node.type !== "decl") return;
      const refs = varRefs(node.value);
      for (const name of refs) reads[asset].add(name);
      if (!node.prop.startsWith("--")) {
        for (const name of refs) regularRefs.add(name);
        return;
      }
      let selector = null;
      let outerRule = false;
      const atRules = [];
      for (let p = node.parent; p && p.type !== "root"; p = p.parent) {
        if (p.type === "atrule") {
          const at = p;
          atRules.unshift(`@${at.name} ${at.params}`.trim());
        } else if (p.type === "rule") {
          if (selector === null) selector = p.selector;
          else outerRule = true;
        }
      }
      const specificity = selector === null ? null : rootSpecificity(selector);
      const declaration = {
        asset,
        order: order++,
        selector,
        atRules,
        value: node.value,
        important: node.important,
        root: specificity !== null,
        bare: specificity !== null && atRules.length === 0 && !outerRule,
        specificity
      };
      const list = declarations.get(node.prop);
      if (list) list.push(declaration);
      else declarations.set(node.prop, [declaration]);
    });
  });
  const scriptNames = /* @__PURE__ */ new Set();
  for (const text2 of [...js, ...html]) {
    for (const [name] of text2.matchAll(SCRIPT_NAME)) scriptNames.add(name);
  }
  const keepNames = new Set(keep);
  const references = /* @__PURE__ */ new Map();
  for (const [name, decls] of declarations) {
    references.set(name, new Set(decls.flatMap((d) => varRefs(d.value))));
  }
  const reached = /* @__PURE__ */ new Set();
  const toReach = [...regularRefs, ...preludeNames, ...scriptNames, ...keepNames];
  while (toReach.length) {
    const name = toReach.pop();
    if (reached.has(name)) continue;
    reached.add(name);
    for (const ref of references.get(name) ?? []) toReach.push(ref);
  }
  const loops = /* @__PURE__ */ new Map();
  const reachesCycle = (name) => {
    const state = loops.get(name);
    if (state !== void 0) return state !== false;
    loops.set(name, "visiting");
    let result2 = false;
    for (const ref of references.get(name) ?? []) {
      if (declarations.has(ref) && reachesCycle(ref)) result2 = true;
    }
    loops.set(name, result2);
    return result2;
  };
  const setByName = (name) => scriptNames.has(name) || keepNames.has(name) || registered.has(name);
  const entryAssets = new Set(entries);
  const winners = /* @__PURE__ */ new Map();
  const reasons = /* @__PURE__ */ new Map();
  for (const [name, decls] of declarations) {
    const winner = winnerOf(decls);
    winners.set(name, winner);
    const bare = decls.filter((d) => d.bare);
    const why = [];
    if (decls.some((d) => !d.bare)) why.push("scoped");
    if (scriptNames.has(name)) why.push("script");
    if (preludeNames.has(name)) why.push("prelude");
    if (registered.has(name)) why.push("registered");
    if (keepNames.has(name)) why.push("keep");
    if (winner && CSS_WIDE_KEYWORD.test(winner.value)) why.push("keyword");
    if (reachesCycle(name)) why.push("cycle");
    if (new Set(bare.map((d) => d.asset)).size > 1 && new Set(bare.map((d) => d.value)).size > 1) {
      why.push("assets");
    }
    if ([...references.get(name)].some((ref) => !declarations.has(ref) && !setByName(ref))) why.push("undeclared");
    const declaring = new Set(decls.map((d) => d.asset));
    if (![...declaring].some((asset) => entryAssets.has(asset)) && reads.some((names, asset) => !declaring.has(asset) && names.has(name))) {
      why.push("lazy");
    }
    reasons.set(name, why);
  }
  const dependents = /* @__PURE__ */ new Map();
  for (const [name, refs] of references) {
    for (const ref of refs) {
      const list = dependents.get(ref);
      if (list) list.push(name);
      else dependents.set(ref, [name]);
    }
  }
  const dynamic = /* @__PURE__ */ new Set();
  const toSpread = [
    ...[...reasons].filter(([, why]) => why.length > 0).map(([name]) => name),
    ...scriptNames,
    ...keepNames,
    ...registered
  ];
  while (toSpread.length) {
    const name = toSpread.pop();
    if (dynamic.has(name)) continue;
    dynamic.add(name);
    for (const dependent of dependents.get(name) ?? []) toSpread.push(dependent);
  }
  const result = /* @__PURE__ */ new Map();
  for (const [name, decls] of declarations) {
    const refs = [...references.get(name)];
    const why = reasons.get(name);
    if (refs.some((ref) => dynamic.has(ref))) why.push("reference");
    result.set(name, {
      declarations: decls,
      references: refs,
      reached: reached.has(name),
      dynamic: why.length > 0,
      reasons: why,
      winner: winners.get(name)
    });
  }
  return result;
}

// vite-plugin/productionCss/rewrite.ts
import postcss2, { AtRule, Rule } from "postcss";
var TOKEN_BEFORE_FUNCTION = /[\w\-#@\\]|[^\x00-\x7f]/;
var VAR_NAME = /^\s*(--(?:[\w-]|[^\x00-\x7f])+)\s*(?:,|$)/;
var JOINS_LEFT = /[\w\-#@.+\\]|[^\x00-\x7f]/;
var JOINS_RIGHT = /[\w\-.+%(\\]|[^\x00-\x7f]/;
var EMPTIED_AT_RULES = /* @__PURE__ */ new Set(["media", "supports", "container"]);
var DESCRIPTOR_AT_RULES = /* @__PURE__ */ new Set(["font-face", "property", "counter-style", "font-palette-values"]);
function skipString(value, start) {
  const quote = value[start];
  let i = start + 1;
  while (i < value.length && value[i] !== quote) i += value[i] === "\\" ? 2 : 1;
  return i + 1;
}
function skipComment(value, start) {
  const end = value.indexOf("*/", start + 2);
  return end < 0 ? value.length : end + 2;
}
function closingParen(value, open) {
  let depth = 0;
  let i = open;
  while (i < value.length) {
    const c = value[i];
    if (c === '"' || c === "'") i = skipString(value, i);
    else if (c === "/" && value[i + 1] === "*") i = skipComment(value, i);
    else {
      if (c === "\\") i += 1;
      else if (c === "(") depth += 1;
      else if (c === ")" && --depth === 0) return i;
      i += 1;
    }
  }
  return -1;
}
function afterUrl(value, start) {
  let i = start;
  while (/\s/.test(value[i] ?? "")) i += 1;
  if (value[i] === '"' || value[i] === "'") {
    const close = closingParen(value, start - 1);
    return close < 0 ? value.length : close + 1;
  }
  while (i < value.length && value[i] !== ")") i += value[i] === "\\" ? 2 : 1;
  return i + 1;
}
function functionAt(value, i, name) {
  return value.slice(i, i + name.length).toLowerCase() === name && (i === 0 || !TOKEN_BEFORE_FUNCTION.test(value[i - 1]));
}
function breaksBetween(left, right) {
  if (!left || !right) return false;
  return JOINS_LEFT.test(left) && JOINS_RIGHT.test(right) || left === "/" && right === "*";
}
function spliced(before, text2, after) {
  if (text2 === "") return breaksBetween(before, after) ? "/**/" : "";
  const head = breaksBetween(before, text2[0]) ? "/**/" : "";
  const tail = breaksBetween(text2[text2.length - 1], after) ? "/**/" : "";
  return head + text2 + tail;
}
function substituteValue(value, valueOf) {
  let out = "";
  let copied = 0;
  let i = 0;
  while (i < value.length) {
    const c = value[i];
    if (c === '"' || c === "'") {
      i = skipString(value, i);
    } else if (c === "/" && value[i + 1] === "*") {
      i = skipComment(value, i);
    } else if (c === "\\") {
      i += 2;
    } else if (functionAt(value, i, "url(")) {
      i = afterUrl(value, i + 4);
    } else if (functionAt(value, i, "var(")) {
      const close = closingParen(value, i + 3);
      if (close < 0) break;
      const args = value.slice(i + 4, close);
      const name = VAR_NAME.exec(args)?.[1];
      const replacement = name === void 0 ? void 0 : valueOf(name);
      out += value.slice(copied, i);
      out += replacement === void 0 ? `${value.slice(i, i + 4)}${substituteValue(args, valueOf)})` : spliced(out[out.length - 1], replacement, value[close + 1]);
      copied = i = close + 1;
    } else {
      i += 1;
    }
  }
  return out + value.slice(copied);
}
function staticValues(analysis) {
  const values = /* @__PURE__ */ new Map();
  const valueOf = (name) => {
    const property = analysis.get(name);
    if (!property || property.dynamic) return void 0;
    let value = values.get(name);
    if (value === void 0) {
      value = substituteValue(property.winner.value.trim(), valueOf);
      values.set(name, value);
    }
    return value;
  };
  for (const [name, property] of analysis) if (property.reached) valueOf(name);
  return values;
}
function droppedDeclarations(analysis, asset, { substitute }) {
  const dropped = /* @__PURE__ */ new Set();
  for (const property of analysis.values()) {
    const own = property.declarations.filter((d) => d.asset === asset);
    if (!property.reached || substitute && !property.dynamic) {
      for (const d of own) dropped.add(d.order);
      continue;
    }
    const winner = winnerOf(own);
    for (const d of own) if (d.bare && d !== winner) dropped.add(d.order);
  }
  return dropped;
}
var isDescriptor = (decl) => decl.parent instanceof AtRule && DESCRIPTOR_AT_RULES.has(decl.parent.name.toLowerCase());
var removableWhenEmpty = (node) => node instanceof Rule || node instanceof AtRule && EMPTIED_AT_RULES.has(node.name.toLowerCase());
function removeEmptied(containers) {
  for (const container of containers) {
    let node = container;
    while (removableWhenEmpty(node) && node.nodes?.length === 0) {
      const parent = node.parent;
      node.remove();
      node = parent;
    }
  }
}
function rewrite(css, asset, analysis, options, values = options.substitute ? staticValues(analysis) : null) {
  const dropped = droppedDeclarations(analysis, asset, options);
  const root = postcss2.parse(css);
  const emptied = /* @__PURE__ */ new Set();
  let order = 0;
  root.walkDecls((decl) => {
    if (decl.prop.startsWith("--") && dropped.has(order++)) {
      emptied.add(decl.parent);
      decl.remove();
      return;
    }
    if (!values || isDescriptor(decl)) return;
    const value = substituteValue(decl.value, (name) => values.get(name));
    if (value !== decl.value) decl.value = value;
  });
  removeEmptied(emptied);
  return root.toString();
}

// vite-plugin/productionCss/index.ts
var text = (source) => typeof source === "string" ? source : new TextDecoder().decode(source);
var HASH = /\[hash(?::(\d+))?\]/;
var PLACEHOLDER = /\[(name|hash(?::\d+)?|ext|extname|format)\]/g;
var escape = (literal) => literal.replace(/[.*+?^${}()|[\]\\/]/g, "\\$&");
var TEXT_ASSET = /\.(css|html|json|map)$/;
function hashedFileName(fileName, pattern, content) {
  const hash = HASH.exec(pattern);
  if (!hash) return null;
  const length = hash[1] ? Number(hash[1]) : 8;
  let regex = "^";
  let last = 0;
  for (const m of pattern.matchAll(PLACEHOLDER)) {
    regex += escape(pattern.slice(last, m.index));
    if (m.index === hash.index) regex += `([A-Za-z0-9_-]{${length}})`;
    else if (m[1] === "ext") regex += "[^./]*";
    else if (m[1] === "extname") regex += "(?:\\.[^./]*)?";
    else regex += ".*?";
    last = m.index + m[0].length;
  }
  regex += escape(pattern.slice(last)) + "$";
  const match = new RegExp(regex, "d").exec(fileName);
  if (!match?.indices?.[1]) throw new Error(`live-tokens: ${fileName} does not follow the output pattern "${pattern}"`);
  const [start, end] = match.indices[1];
  const digest = createHash("sha256").update(content).digest("base64url").slice(0, length);
  return fileName.slice(0, start) + digest + fileName.slice(end);
}
function tails(from, to) {
  let i = 0;
  while (from[i] === to[i]) i += 1;
  const start = from.lastIndexOf("/", i) + 1;
  return [from.slice(start), to.slice(start)];
}
function repoint(files, renames) {
  const pairs = [...renames].map(([from, to]) => tails(from, to));
  const replace = (s) => {
    for (const [from, to] of pairs) s = s.replaceAll(from, () => to);
    return s;
  };
  const renamed = (names) => names.map((name) => renames.get(name) ?? name);
  const changed = /* @__PURE__ */ new Set();
  for (const file of files) {
    if (file.type === "chunk") {
      const code = replace(file.code);
      if (code !== file.code) {
        file.code = code;
        changed.add(file);
      }
      if (file.imports.some((name) => renames.has(name))) file.imports = renamed(file.imports);
      if (file.dynamicImports.some((name) => renames.has(name))) file.dynamicImports = renamed(file.dynamicImports);
      const map = file.sourcemapFileName && replace(file.sourcemapFileName);
      if (map && map !== file.sourcemapFileName) file.sourcemapFileName = map;
      const imported = file.viteMetadata?.importedCss;
      if (imported && [...imported].some((name) => renames.has(name))) {
        const next = renamed([...imported]);
        imported.clear();
        for (const name of next) imported.add(name);
        changed.add(file);
      }
    } else if (TEXT_ASSET.test(file.fileName)) {
      const before = text(file.source);
      const after = replace(before);
      if (after !== before) file.source = after;
    }
    const fileName = replace(file.fileName);
    if (fileName !== file.fileName) file.fileName = fileName;
  }
  return changed;
}
function renameRewritten(files, sheetRenames, names) {
  const affected = repoint(files, sheetRenames);
  const chunks = files.filter((f) => f.type === "chunk");
  const byName = new Map(chunks.map((c) => [c.fileName, c]));
  const imported = (c) => [...c.imports, ...c.dynamicImports].flatMap((name) => byName.get(name) ?? []);
  for (let grew = true; grew; ) {
    grew = false;
    for (const chunk of chunks) {
      if (!affected.has(chunk) && imported(chunk).some((c) => affected.has(c))) {
        affected.add(chunk);
        grew = true;
      }
    }
  }
  const identity = (c) => [c.code, ...c.viteMetadata?.importedCss ?? []].join("\0");
  const chunkRenames = /* @__PURE__ */ new Map();
  for (const chunk of affected) {
    const reached = /* @__PURE__ */ new Set([chunk]);
    const toVisit = [chunk];
    while (toVisit.length) {
      for (const next of imported(toVisit.pop())) {
        if (!reached.has(next)) {
          reached.add(next);
          toVisit.push(next);
        }
      }
    }
    reached.delete(chunk);
    const others = [...reached].sort((a, b) => a.fileName < b.fileName ? -1 : 1);
    const fileNames = chunk.isEntry ? names.entryFileNames : names.chunkFileNames;
    const pattern = typeof fileNames === "string" ? fileNames : fileNames({
      name: chunk.name,
      isEntry: chunk.isEntry,
      isDynamicEntry: chunk.isDynamicEntry,
      facadeModuleId: chunk.facadeModuleId ?? void 0,
      moduleIds: chunk.moduleIds,
      exports: chunk.exports
    });
    const renamed = hashedFileName(chunk.fileName, pattern, [chunk, ...others].map(identity).join("\0\0"));
    if (renamed !== null && renamed !== chunk.fileName) chunkRenames.set(chunk.fileName, renamed);
  }
  if (chunkRenames.size > 0) repoint(files, chunkRenames);
}
function entrySheets(files) {
  const chunks = new Map(files.flatMap((f) => f.type === "chunk" ? [[f.fileName, f]] : []));
  const sheets = /* @__PURE__ */ new Set();
  const seen = /* @__PURE__ */ new Set();
  const toVisit = [...chunks.values()].filter((c) => c.isEntry);
  while (toVisit.length) {
    const chunk = toVisit.pop();
    if (seen.has(chunk.fileName)) continue;
    seen.add(chunk.fileName);
    for (const sheet of chunk.viteMetadata?.importedCss ?? []) sheets.add(sheet);
    for (const name of chunk.imports) {
      const imported = chunks.get(name);
      if (imported) toVisit.push(imported);
    }
  }
  return sheets;
}
function rewriteBundle(bundle, { substitute = true, keep = [] }, names) {
  const files = Object.values(bundle);
  const assets = files.filter((f) => f.type === "asset");
  const sheets = assets.filter((f) => f.fileName.endsWith(".css"));
  if (sheets.length === 0) return null;
  const css = sheets.map((f) => text(f.source));
  const js = [
    ...files.flatMap((f) => f.type === "chunk" ? [f.code] : []),
    ...assets.filter((f) => /\.[cm]?js$/.test(f.fileName)).map((f) => text(f.source))
  ];
  const html = assets.filter((f) => f.fileName.endsWith(".html")).map((f) => text(f.source));
  const loadedWithPage = entrySheets(files);
  const entries = sheets.flatMap((sheet, i) => loadedWithPage.has(sheet.fileName) ? [i] : []);
  const analysis = analyze({ css, js, html, keep, entries });
  const values = substitute ? staticValues(analysis) : null;
  let bytesSaved = 0;
  const renames = /* @__PURE__ */ new Map();
  const { assetFileNames } = names;
  sheets.forEach((sheet, i) => {
    const rewritten = rewrite(css[i], i, analysis, { substitute }, values);
    bytesSaved += Buffer.byteLength(css[i]) - Buffer.byteLength(rewritten);
    if (rewritten === css[i]) return;
    sheet.source = rewritten;
    const pattern = typeof assetFileNames === "string" ? assetFileNames : assetFileNames({ type: "asset", names: sheet.names, originalFileNames: sheet.originalFileNames, source: rewritten });
    const renamed = hashedFileName(sheet.fileName, pattern, rewritten);
    if (renamed !== null && renamed !== sheet.fileName) renames.set(sheet.fileName, renamed);
  });
  if (renames.size > 0) renameRewritten(files, renames, names);
  let propertiesAfter = 0;
  for (const property of analysis.values()) {
    if (property.reached && (property.dynamic || !substitute)) propertiesAfter += 1;
  }
  return { propertiesBefore: analysis.size, propertiesAfter, bytesSaved };
}
function formatReport({ propertiesBefore, propertiesAfter, bytesSaved }) {
  const kB = (Math.abs(bytesSaved) / 1e3).toFixed(1);
  return `live-tokens: the production CSS declares ${propertiesAfter.toLocaleString("en-US")} of ${propertiesBefore.toLocaleString("en-US")} custom properties and is ${kB} kB ${bytesSaved >= 0 ? "smaller" : "larger"}.`;
}

// vite-plugin/themeFileApi.ts
import { fileURLToPath as fileURLToPath2 } from "url";
var PKG_VERSION = (() => {
  try {
    let dir = path3.dirname(fileURLToPath2(import.meta.url));
    for (let i = 0; i < 4; i++) {
      const p = path3.join(dir, "package.json");
      if (fs2.existsSync(p)) {
        const json = JSON.parse(fs2.readFileSync(p, "utf-8"));
        if (json?.name === "@motion-proto/live-tokens") return json.version ?? "";
      }
      const up = path3.dirname(dir);
      if (up === dir) break;
      dir = up;
    }
  } catch {
  }
  return "";
})();
var BUNDLE_KIND_BY_VERSION = {
  1: "manifest-bundle",
  3: "theme-bundle",
  [THEME_SCHEMA_VERSION]: "theme-bundle"
};
function extractAliasDeclarations(body) {
  const aliases = {};
  const re = /(--[a-z0-9-]+)\s*:\s*([^;]+);/gi;
  let m;
  while ((m = re.exec(body)) !== null) {
    const value = m[2].trim();
    const plain = value.match(/^var\((--[a-z0-9-]+)\)$/i);
    if (plain) {
      aliases[m[1]] = plain[1];
      continue;
    }
    if (parseColorOpacity(value)) {
      aliases[m[1]] = value;
      continue;
    }
    const gradient = parseGradientValue(value);
    if (gradient) aliases[m[1]] = { kind: "gradient", value: gradient };
  }
  return aliases;
}
function themeFileApi(opts) {
  const dataDirs = resolveDataDirs({
    dataDir: opts.dataDir,
    colorsAndTypeDir: opts.colorsAndTypeDir,
    componentConfigsDir: opts.componentConfigsDir,
    themesDir: opts.themesDir
  });
  const COLORS_AND_TYPE_DIR = dataDirs.colorsAndTypeDir;
  const COMPONENT_CONFIGS_DIR = dataDirs.componentConfigsDir;
  const THEMES_DIR = dataDirs.themesDir;
  const SKETCH_STYLES_DIR = dataDirs.sketchStylesDir;
  const CSS_PATH = path3.resolve(opts.tokensCssPath);
  const ISOLATED_DATA_DIR = testDataDir();
  const GENERATED_CSS_PATH = ISOLATED_DATA_DIR ? path3.join(ISOLATED_DATA_DIR, "tokens.generated.css") : opts.tokensGeneratedCssPath ? path3.resolve(opts.tokensGeneratedCssPath) : path3.join(dataDirs.dataDir, "tokens.generated.css");
  const FONTS_CSS_PATH = ISOLATED_DATA_DIR ? path3.join(ISOLATED_DATA_DIR, "fonts.css") : opts.fontsCssPath ? path3.resolve(opts.fontsCssPath) : path3.join(path3.dirname(CSS_PATH), "fonts.css");
  const API_BASE = opts.apiBase ?? "/api/live-tokens";
  const consumerComponentDirs = opts.componentsSrcDir ? [path3.resolve(opts.componentsSrcDir)] : [path3.resolve("src/components"), path3.resolve("src/system/components")];
  const packageComponentsDir = path3.resolve(
    path3.dirname(fileURLToPath2(import.meta.url)),
    "..",
    "src",
    "system",
    "components"
  );
  const packageDataDir = testPackageDataDir() ?? path3.resolve(
    path3.dirname(fileURLToPath2(import.meta.url)),
    "..",
    "src",
    "live-tokens",
    "data"
  );
  const packageColorsAndTypeDir = path3.join(packageDataDir, "colors-and-type");
  const packageThemesDir = path3.join(packageDataDir, "themes");
  const packageComponentConfigsDir = path3.join(packageDataDir, "component-configs");
  const packageSketchStylesDir = path3.join(packageDataDir, "sketch-styles");
  function shippedNames(dataDir, subdir) {
    try {
      const pkgRoot = path3.resolve(dataDir, "..", "..", "..");
      const pkg = JSON.parse(fs2.readFileSync(path3.join(pkgRoot, "package.json"), "utf-8"));
      const files = Array.isArray(pkg.files) ? pkg.files : [];
      const owned = new RegExp(`^src/live-tokens/data/${subdir}/[^/]+\\.json$`);
      return files.filter((f) => owned.test(f)).map((f) => path3.basename(f, ".json"));
    } catch {
      return [];
    }
  }
  const COMPONENTS_SCAN_DIRS = [...consumerComponentDirs];
  if (!COMPONENTS_SCAN_DIRS.includes(packageComponentsDir) && fs2.existsSync(packageComponentsDir)) {
    COMPONENTS_SCAN_DIRS.push(packageComponentsDir);
  }
  const isLiveStateFile = (file) => file === path3.join(THEMES_DIR, "_active.json") || path3.basename(file) === "_working.json" && (file.startsWith(COLORS_AND_TYPE_DIR + path3.sep) || file.startsWith(COMPONENT_CONFIGS_DIR + path3.sep));
  const liveWatch = dataTreeWatch({
    dirs: [COLORS_AND_TYPE_DIR, COMPONENT_CONFIGS_DIR, THEMES_DIR],
    isLive: isLiveStateFile
  });
  const colorsAndTypeResource = versionedFileResourceServer({
    dir: COLORS_AND_TYPE_DIR,
    packageDir: packageColorsAndTypeDir,
    packageOwnedNames: shippedNames(packageDataDir, "colors-and-type"),
    onWrite: liveWatch.noteOwnWrite
  });
  const componentResourceCache = /* @__PURE__ */ new Map();
  function componentResource(comp) {
    let r = componentResourceCache.get(comp);
    if (!r) {
      r = versionedFileResourceServer({
        dir: path3.join(COMPONENT_CONFIGS_DIR, comp),
        packageDir: path3.join(packageComponentConfigsDir, comp),
        onWrite: liveWatch.noteOwnWrite
      });
      componentResourceCache.set(comp, r);
    }
    return r;
  }
  const themesResource = versionedFileResourceServer({
    dir: THEMES_DIR,
    packageDir: packageThemesDir,
    onWrite: liveWatch.noteOwnWrite
  });
  const sketchStylesResource = versionedFileResourceServer({
    dir: SKETCH_STYLES_DIR,
    packageDir: packageSketchStylesDir,
    packageOwnedNames: shippedNames(packageDataDir, "sketch-styles")
  });
  function ensureColorsAndTypeDir() {
    colorsAndTypeResource.ensureDir();
  }
  function readBody(req) {
    return new Promise((resolve, reject) => {
      let body = "";
      req.on("data", (chunk) => body += chunk);
      req.on("end", () => resolve(body));
      req.on("error", reject);
    });
  }
  function jsonResponse(res, status, data) {
    res.statusCode = status;
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify(data));
  }
  function rejectReservedName(res, name) {
    if (!name.startsWith("_")) return false;
    jsonResponse(res, 400, {
      error: 'Names starting with "_" are reserved',
      code: "RESERVED_NAME"
    });
    return true;
  }
  function normalizeColorsAndType(colorsAndType) {
    if (!colorsAndType || typeof colorsAndType !== "object") return colorsAndType;
    const palettes = colorsAndType.editorConfigs ?? {};
    const cssVars = colorsAndType.cssVariables ?? {};
    const { palettes: nextPalettes, consumed } = reconcilePalettesFromCssVars(palettes, cssVars);
    const nextCssVars = {};
    for (const [k, v] of Object.entries(cssVars)) {
      if (!consumed.has(k)) nextCssVars[k] = v;
    }
    return { ...colorsAndType, editorConfigs: nextPalettes, cssVariables: nextCssVars };
  }
  const SYSTEM_CASCADES_SSR = {
    "system-ui-sans": 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
    "system-ui-serif": 'Georgia, "Times New Roman", serif',
    "system-ui-mono": 'ui-monospace, "SF Mono", Menlo, Consolas, monospace'
  };
  function resolveFontStacks(colorsAndTypeData) {
    const stacks = colorsAndTypeData.fontStacks;
    const sources = colorsAndTypeData.fontSources;
    if (!stacks || stacks.length === 0) return {};
    const familyById = /* @__PURE__ */ new Map();
    for (const src of sources ?? []) {
      for (const f of src.families) familyById.set(f.id, f.cssName);
    }
    const out = {};
    for (const stack of stacks) {
      const parts = [];
      for (const slot of stack.slots) {
        if (slot.kind === "project") {
          const css = familyById.get(slot.familyId);
          if (css) parts.push(css);
        } else if (slot.kind === "system") {
          const cascade = SYSTEM_CASCADES_SSR[slot.preset];
          if (cascade) parts.push(cascade);
        } else if (slot.kind === "generic") {
          parts.push(slot.value);
        }
      }
      if (parts.length > 0) out[stack.variable] = parts.join(", ");
    }
    return out;
  }
  function renderTokensCss() {
    const lines = [];
    const productionThemeName = themesResource.getProductionName();
    const productionTheme = readTheme(productionThemeName)?.theme ?? null;
    if (themesResource.existingPath(productionThemeName) !== null && !productionTheme?.colorsAndType) {
      const tail = `${path3.basename(GENERATED_CSS_PATH)} was left as it was.`;
      throw new Error(
        unreadableThemeReason(productionThemeName) === "colors-and-type" ? `[live-tokens] ${notAThemeError(productionThemeName)} ${tail}` : `[live-tokens] Production theme "${productionThemeName}" is unreadable, so ${tail} Repair the theme file or adopt another theme.`
      );
    }
    const colorsAndTypeData = productionTheme?.colorsAndType;
    let colorsAndTypeVarCount = 0;
    let pageBackground = "";
    if (colorsAndTypeData) {
      const cssVars = { ...colorsAndTypeData.cssVariables || {} };
      Object.assign(cssVars, palettesToVars(migratePaletteColorsToOklch(colorsAndTypeData.editorConfigs ?? {})));
      const resolvedFontVars = resolveFontStacks(colorsAndTypeData);
      for (const [name, value] of Object.entries(resolvedFontVars)) {
        cssVars[name] = value;
      }
      pageBackground = cssVars["--page-bg"] ?? "";
      colorsAndTypeVarCount = Object.keys(cssVars).length;
      if (colorsAndTypeVarCount > 0) {
        lines.push(`/* Production theme: ${productionThemeName} */`);
        lines.push(":root:root {");
        for (const [name, value] of Object.entries(cssVars)) {
          lines.push(`  ${name}: ${value};`);
        }
        lines.push("}");
        lines.push("");
      }
    }
    {
      const polarity = pageBackground ? polarityOfBackground(pageBackground) : null;
      if (polarity) {
        lines.push(`/* Page polarity, from --page-bg */`);
        lines.push(":where(:root) {");
        lines.push(`  color-scheme: ${polarity};`);
        lines.push("}");
        lines.push("");
      }
    }
    let componentOverrideCount = 0;
    if (fs2.existsSync(COMPONENT_CONFIGS_DIR)) {
      const blocks = [];
      for (const comp of listComponentNames()) {
        const prodCfg = productionTheme?.componentConfigs[comp];
        const defaultCfg = readComponentConfig(comp, "default");
        if (!prodCfg || !defaultCfg) continue;
        const overrides = [];
        const defaultAliases = defaultCfg.aliases ?? {};
        for (const [varName, semanticValue] of Object.entries(prodCfg.aliases ?? {})) {
          if (!(varName in defaultAliases)) continue;
          if (!aliasValuesEqual(defaultAliases[varName], semanticValue)) {
            overrides.push([varName, semanticValue]);
          }
        }
        if (overrides.length === 0) continue;
        const block = [`  /* ${comp} */`];
        for (const [varName, semanticValue] of overrides) {
          block.push(`  ${varName}: ${aliasValueToCss(semanticValue)};`);
        }
        blocks.push(block);
        componentOverrideCount += overrides.length;
      }
      if (blocks.length > 0) {
        lines.push("/* Component aliases (production configs differing from defaults) */");
        lines.push(":root:root {");
        for (let i = 0; i < blocks.length; i++) {
          if (i > 0) lines.push("");
          lines.push(...blocks[i]);
        }
        lines.push("}");
        lines.push("");
      }
    }
    return { body: lines.join("\n"), colorsAndTypeVarCount, componentOverrideCount };
  }
  const bakeFingerprint = (body) => createHash2("sha256").update(body).digest("hex").slice(0, 16);
  const BAKE_FINGERPRINT_LINE = /^\/\* Bake fingerprint: ([0-9a-f]+) \*\/$/m;
  function regenerateTokensCss() {
    const { body, colorsAndTypeVarCount, componentOverrideCount } = renderTokensCss();
    const header = [
      "/* Generated by themeFileApi from the production theme. Do not edit. */",
      "/* tokens.css holds developer-authored defaults; this file holds editor overrides. */",
      `/* Bake fingerprint: ${bakeFingerprint(body)} */`,
      ""
    ];
    if (!fs2.existsSync(path3.dirname(GENERATED_CSS_PATH))) {
      fs2.mkdirSync(path3.dirname(GENERATED_CSS_PATH), { recursive: true });
    }
    fs2.writeFileSync(GENERATED_CSS_PATH, [...header, body].join("\n"));
    console.log(
      `[regenerateTokensCss] Wrote ${path3.basename(GENERATED_CSS_PATH)} (${colorsAndTypeVarCount} theme vars, ${componentOverrideCount} component overrides)`
    );
  }
  function bakeIsCurrent() {
    let baked;
    try {
      baked = fs2.readFileSync(GENERATED_CSS_PATH, "utf-8");
    } catch {
      return false;
    }
    const recorded = BAKE_FINGERPRINT_LINE.exec(baked)?.[1];
    try {
      return recorded === bakeFingerprint(renderTokensCss().body);
    } catch {
      return false;
    }
  }
  function syncFontsToCss(colorsAndTypeData) {
    if (!colorsAndTypeData) return;
    const sources = colorsAndTypeData.fontSources;
    if (!sources) return;
    const lines = [];
    lines.push("/* Generated from the production colors and type by syncFontsToCss. Do not edit. */");
    lines.push("/* Both fonts.css and fonts/ are in dist/, so relative paths work at runtime. */");
    lines.push("");
    const urlSources = sources.filter((s) => s.kind !== "font-face" && s.url);
    const faceSources = sources.filter((s) => s.kind === "font-face" && s.cssText);
    for (const source of urlSources) {
      const familyNames = source.families.map((f) => f.name).join(", ");
      const label = source.label ? `${source.label} \u2014 ${familyNames}` : familyNames;
      lines.push(`/* ${label} */`);
      lines.push(`@import url('${source.url}');`);
      lines.push("");
    }
    for (const source of faceSources) {
      const familyNames = source.families.map((f) => f.name).join(", ");
      const label = source.label ? `${source.label} \u2014 ${familyNames}` : familyNames;
      lines.push(`/* ${label} */`);
      lines.push(source.cssText);
      lines.push("");
    }
    const content = lines.join("\n");
    if (!fs2.existsSync(path3.dirname(FONTS_CSS_PATH))) {
      fs2.mkdirSync(path3.dirname(FONTS_CSS_PATH), { recursive: true });
    }
    fs2.writeFileSync(FONTS_CSS_PATH, content);
    console.log(`[syncFontsToCss] Wrote ${sources.length} source(s) into ${path3.basename(FONTS_CSS_PATH)}`);
  }
  function componentNameFromFile(filePath) {
    return path3.basename(filePath, ".svelte").toLowerCase();
  }
  function isThemeAwareComponent(filePath) {
    try {
      const source = fs2.readFileSync(filePath, "utf-8");
      return /:global\(:root\)\s*\{/.test(source);
    } catch {
      return false;
    }
  }
  function listComponentSourcePaths() {
    const byName = /* @__PURE__ */ new Map();
    for (const dir of COMPONENTS_SCAN_DIRS) {
      if (!fs2.existsSync(dir)) continue;
      for (const f of fs2.readdirSync(dir)) {
        if (!f.endsWith(".svelte")) continue;
        const full = path3.join(dir, f);
        if (!isThemeAwareComponent(full)) continue;
        const name = componentNameFromFile(f);
        if (!byName.has(name)) byName.set(name, full);
      }
    }
    return Array.from(byName.values());
  }
  function listComponentNames() {
    return listComponentSourcePaths().map(componentNameFromFile);
  }
  function warnOnTokenDrift(log) {
    let tokensCss = "";
    try {
      tokensCss = fs2.readFileSync(CSS_PATH, "utf-8");
    } catch {
      return;
    }
    let generatedCss = "";
    try {
      generatedCss = fs2.readFileSync(GENERATED_CSS_PATH, "utf-8");
    } catch {
    }
    const componentSources = listComponentSourcePaths().map((p) => ({
      name: componentNameFromFile(p),
      source: fs2.readFileSync(p, "utf-8")
    }));
    const missing = validateTokensCss({ tokensCss, generatedCss, componentSources });
    if (missing.length === 0) return;
    const lines = missing.map(
      (m) => `  ${m.token}  (referenced by ${m.referencedBy.join(", ")})`
    );
    log(
      `[live-tokens] ${missing.length} token(s) referenced by components are not defined in ${path3.relative(process.cwd(), CSS_PATH)}:
${lines.join("\n")}
  These render as blank/empty editor slots. Run \`npx live-tokens migrate\` to reconcile.`
    );
  }
  function autoMigrateAdditive(log) {
    let before = "";
    try {
      before = fs2.readFileSync(CSS_PATH, "utf-8");
    } catch {
      return;
    }
    const { css, applied, changed } = runAdditiveTokensCssMigrations(before);
    if (!changed) return;
    fs2.writeFileSync(CSS_PATH, css);
    log(
      `[live-tokens] autoMigrate applied ${applied.length} additive migration(s) to ${path3.relative(process.cwd(), CSS_PATH)}: ${applied.join(", ")}. Review the diff in git.`
    );
  }
  function generateDefaultConfig(comp, sourcePath) {
    if (!fs2.existsSync(sourcePath)) return;
    const r = componentResource(comp);
    r.ensureDir();
    const defaultPath = r.filePath("default");
    const sourceStat = fs2.statSync(sourcePath);
    let createdAt = (/* @__PURE__ */ new Date()).toISOString();
    let existingUpdatedAt;
    let existingAliases;
    let existingSchemaVersion;
    if (fs2.existsSync(defaultPath)) {
      try {
        const existing = JSON.parse(fs2.readFileSync(defaultPath, "utf-8"));
        if (existing.createdAt) createdAt = existing.createdAt;
        if (typeof existing.updatedAt === "string") existingUpdatedAt = existing.updatedAt;
        if (existing.aliases && typeof existing.aliases === "object") {
          existingAliases = existing.aliases;
        }
        if (typeof existing.schemaVersion === "number") existingSchemaVersion = existing.schemaVersion;
      } catch {
      }
      const defaultStat = fs2.statSync(defaultPath);
      if (defaultStat.mtimeMs >= sourceStat.mtimeMs && existingSchemaVersion === CURRENT_COMPONENT_SCHEMA_VERSION) {
        return;
      }
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const source = fs2.readFileSync(sourcePath, "utf-8");
    const body = extractGlobalRootBody(source);
    const aliases = extractAliasDeclarations(body);
    const aliasesUnchanged = existingAliases !== void 0 && JSON.stringify(existingAliases) === JSON.stringify(aliases);
    const schemaStampCurrent = existingSchemaVersion === CURRENT_COMPONENT_SCHEMA_VERSION;
    const defaultConfig = {
      name: "default",
      component: comp,
      createdAt,
      updatedAt: aliasesUnchanged && existingUpdatedAt ? existingUpdatedAt : now,
      aliases,
      schemaVersion: CURRENT_COMPONENT_SCHEMA_VERSION
    };
    if (aliasesUnchanged && schemaStampCurrent && existingUpdatedAt) {
      const t = /* @__PURE__ */ new Date();
      fs2.utimesSync(defaultPath, t, t);
      return;
    }
    fs2.writeFileSync(defaultPath, JSON.stringify(defaultConfig, null, 2));
  }
  function ensureComponentConfigsDir() {
    if (!fs2.existsSync(COMPONENT_CONFIGS_DIR)) {
      fs2.mkdirSync(COMPONENT_CONFIGS_DIR, { recursive: true });
    }
    for (const sourcePath of listComponentSourcePaths()) {
      const comp = componentNameFromFile(sourcePath);
      const r = componentResource(comp);
      r.ensureDir();
      generateDefaultConfig(comp, sourcePath);
    }
  }
  function listLegacyPointers() {
    const legacy = [];
    const check = (dir) => {
      for (const name of ["_active.json", "_production.json"]) {
        const p = path3.join(dir, name);
        if (fs2.existsSync(p)) legacy.push(path3.relative(process.cwd(), p));
      }
    };
    check(COLORS_AND_TYPE_DIR);
    if (fs2.existsSync(COMPONENT_CONFIGS_DIR)) {
      for (const entry of fs2.readdirSync(COMPONENT_CONFIGS_DIR, { withFileTypes: true })) {
        if (entry.isDirectory()) check(path3.join(COMPONENT_CONFIGS_DIR, entry.name));
      }
    }
    return legacy;
  }
  function warnOnLegacyPointers(legacy, bakeHeld, warn) {
    if (legacy.length === 0) return;
    warn(
      `[live-tokens] ${legacy.length} legacy pointer file(s) left from the pre-working-set data model, starting with ${legacy[0]}. They are no longer read. Run \`npx live-tokens migrate\` to heal the tree.` + (bakeHeld ? ` Until then this tree has named no production theme, so ${path3.basename(GENERATED_CSS_PATH)} is left exactly as it is rather than rebuilt from the default.` : "")
    );
  }
  function warnOnLegacyLayout(evidence, warn) {
    warn(
      `[live-tokens] This project still uses the data layout from 0.47 and earlier: ${evidence}. Since 0.48 the whole-theme theme files live in \`themes/\` and the colors and type live in \`colors-and-type/\`. Nothing in the data directory was written, the editor cannot save, and ${path3.basename(GENERATED_CSS_PATH)} is left exactly as it is. Run \`npx live-tokens migrate\` to move the directories and heal the tree, then restart the dev server.`
    );
  }
  function warnOnUnmigratedSketchStyles(warn) {
    const legacyDir = path3.join(dataDirs.dataDir, "sketch-presets");
    if (!fs2.existsSync(legacyDir)) return;
    warn(
      `[live-tokens] Saved sketchstyles still live under the retired ${path3.basename(legacyDir)}/ directory name. Run \`npx live-tokens migrate\` to rename it to ${path3.basename(SKETCH_STYLES_DIR)}/; until then they will not show up in the Sketchstyle view.`
    );
  }
  const diskThemeResolvers = {
    readColorsAndType: (name) => colorsAndTypeResource.readJson(sanitizeFileName(name)),
    readComponentConfig: (comp, name) => readComponentConfig(comp, sanitizeFileName(name)),
    listComponentNames,
    normalizeColorsAndType: (colorsAndType) => normalizeColorsAndType(colorsAndType)
  };
  function readTheme(fileName) {
    let raw;
    try {
      raw = themesResource.readJson(fileName);
    } catch {
      return null;
    }
    if (!raw) return null;
    if (isColorsAndTypeShaped(raw)) return null;
    return normalizeTheme(raw, diskThemeResolvers);
  }
  function unreadableThemeReason(fileName) {
    const resolved = themesResource.existingPath(fileName);
    if (resolved === null) return "missing";
    try {
      if (isColorsAndTypeShaped(JSON.parse(fs2.readFileSync(resolved, "utf-8")))) {
        return "colors-and-type";
      }
    } catch {
    }
    return "corrupt";
  }
  function notAThemeError(fileName) {
    return `"${fileName}" is a colors-and-type file, not a theme. Before 0.48 those lived in themes/; move it to ${path3.basename(COLORS_AND_TYPE_DIR)}/ or delete it. To build a theme, use the theme skill "create-theme".`;
  }
  function respondUnreadableTheme(res, fileName, missingError) {
    switch (unreadableThemeReason(fileName)) {
      case "missing":
        jsonResponse(res, 404, { error: missingError });
        return;
      case "colors-and-type":
        jsonResponse(res, 422, { error: notAThemeError(fileName), code: "CORRUPT_THEME" });
        return;
      case "corrupt":
        jsonResponse(res, 422, {
          error: `Theme file "${fileName}" is not valid JSON`,
          code: "CORRUPT_THEME"
        });
    }
  }
  function writeTheme(fileName, theme) {
    themesResource.ensureDir();
    fs2.writeFileSync(themesResource.filePath(fileName), JSON.stringify(theme, null, 2));
  }
  function migrateLocalThemes(warn) {
    if (path3.resolve(THEMES_DIR) === path3.resolve(packageThemesDir)) return;
    if (!fs2.existsSync(THEMES_DIR)) return;
    for (const file of fs2.readdirSync(THEMES_DIR)) {
      if (!file.endsWith(".json") || file.startsWith("_")) continue;
      const fileName = file.slice(0, -".json".length);
      if (fileName === "default") continue;
      let raw;
      try {
        raw = JSON.parse(fs2.readFileSync(path3.join(THEMES_DIR, file), "utf-8"));
      } catch {
        continue;
      }
      if (isColorsAndTypeShaped(raw)) {
        warn(`[live-tokens] ${notAThemeError(fileName)} It is left untouched.`);
        continue;
      }
      const { theme, dropped, migrated } = normalizeTheme(raw, diskThemeResolvers);
      if (!migrated) continue;
      writeTheme(fileName, theme);
      if (dropped.length > 0) {
        warn(
          `[live-tokens] Theme "${fileName}": ${dropped.join(", ")} no longer exists; those slices now use their defaults.`
        );
      }
    }
  }
  function ensureDefaultTheme(warn) {
    let existing = null;
    try {
      existing = JSON.parse(fs2.readFileSync(themesResource.filePath("default"), "utf-8"));
    } catch {
    }
    if (isColorsAndTypeShaped(existing)) {
      warn(`[live-tokens] ${notAThemeError("default")} The Default theme was not materialised.`);
      return;
    }
    const colorsAndType = normalizeColorsAndType(colorsAndTypeResource.readJson("default"));
    const componentConfigs = {};
    for (const comp of listComponentNames()) {
      const cfg = readComponentConfig(comp, "default");
      if (cfg) {
        const { schemaVersion: _standaloneStamp, ...rest } = cfg;
        componentConfigs[comp] = rest;
      }
    }
    const contentUnchanged = JSON.stringify(existing?.colorsAndType) === JSON.stringify(colorsAndType) && JSON.stringify(existing?.componentConfigs) === JSON.stringify(componentConfigs);
    if (existing?.schemaVersion === THEME_SCHEMA_VERSION && existing?.componentSchemaVersion === CURRENT_COMPONENT_SCHEMA_VERSION && contentUnchanged) {
      return;
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    writeTheme("default", {
      name: "Motion Proto",
      createdAt: typeof existing?.createdAt === "string" ? existing.createdAt : now,
      // A stamp-only rewrite (componentSchemaVersion catching up) is not a
      // content change, so it doesn't bump this the way a real edit would.
      updatedAt: contentUnchanged && typeof existing?.updatedAt === "string" ? existing.updatedAt : now,
      schemaVersion: THEME_SCHEMA_VERSION,
      colorsAndType,
      componentConfigs,
      componentSchemaVersion: CURRENT_COMPONENT_SCHEMA_VERSION
    });
  }
  function ensureThemesDir(warn) {
    themesResource.ensureDir();
    ensureDefaultTheme(warn);
    migrateLocalThemes(warn);
    const productionPointerHeld = !fs2.existsSync(themesResource.productionPath) && listLegacyPointers().length > 0;
    if (productionPointerHeld) {
      if (!fs2.existsSync(themesResource.activePath)) themesResource.setActiveName("default");
    } else {
      themesResource.ensureMeta();
    }
    if (themesResource.existingPath(themesResource.getActiveName()) === null) {
      themesResource.setActiveName("default");
    }
    if (themesResource.existingPath(themesResource.getProductionName()) === null) {
      themesResource.setProductionName("default");
    }
    return { productionPointerHeld };
  }
  function activeTheme() {
    return readTheme(themesResource.getActiveName())?.theme ?? null;
  }
  function resolveLiveColorsAndType(theme) {
    const working = colorsAndTypeResource.readWorking();
    if (working !== null) return { data: normalizeColorsAndType(working), source: "working" };
    if (theme?.colorsAndType) return { data: theme.colorsAndType, source: "theme" };
    const shipped = colorsAndTypeResource.readJson("default");
    if (!shipped) return null;
    return { data: normalizeColorsAndType(shipped), source: "default" };
  }
  const loggedMissingThemeEntries = /* @__PURE__ */ new Set();
  function resolveComponentConfigOrDefault(comp, theme) {
    const embedded = theme?.componentConfigs[comp];
    if (embedded) return { ...embedded, component: comp };
    if (!loggedMissingThemeEntries.has(comp)) {
      loggedMissingThemeEntries.add(comp);
      console.warn(
        `[live-tokens] "${comp}" has no entry in the open theme; resolving from its shipped default.`
      );
    }
    return readComponentConfig(comp, "default");
  }
  function resolveLiveComponentConfig(comp, theme) {
    const working = componentResource(comp).readWorking();
    if (working !== null) return { data: working, source: "working" };
    const cfg = resolveComponentConfigOrDefault(comp, theme);
    if (!cfg) return null;
    return { data: cfg, source: "theme" };
  }
  function resolveSavedColorsAndType(theme) {
    if (theme?.colorsAndType) return theme.colorsAndType;
    const shipped = colorsAndTypeResource.readJson("default");
    return shipped ? normalizeColorsAndType(shipped) : null;
  }
  function resolveSavedComponentConfig(comp, theme) {
    return resolveComponentConfigOrDefault(comp, theme);
  }
  function sameJsonValue(a, b) {
    if (a === null || b === null) return a === b;
    if (typeof a !== typeof b) return false;
    if (typeof a !== "object") return a === b;
    if (Array.isArray(a) || Array.isArray(b)) {
      return Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((value, i) => sameJsonValue(value, b[i]));
    }
    const aRecord = a;
    const bRecord = b;
    const aKeys = Object.keys(aRecord).sort();
    const bKeys = Object.keys(bRecord).sort();
    return aKeys.length === bKeys.length && aKeys.every((key, i) => key === bKeys[i] && sameJsonValue(aRecord[key], bRecord[key]));
  }
  function pruneMatchingWorking(theme) {
    const colorsWorking = colorsAndTypeResource.readWorking();
    const savedColors = resolveSavedColorsAndType(theme);
    if (colorsWorking !== null && savedColors !== null && sameJsonValue(normalizeColorsAndType(colorsWorking), savedColors)) {
      colorsAndTypeResource.clearWorking();
    }
    for (const comp of listComponentNames()) {
      const r = componentResource(comp);
      const working = r.readWorking();
      if (working !== null && sameJsonValue(working, resolveSavedComponentConfig(comp, theme))) {
        r.clearWorking();
      }
    }
  }
  function clearAllWorking() {
    colorsAndTypeResource.clearWorking();
    if (!fs2.existsSync(COMPONENT_CONFIGS_DIR)) return;
    for (const entry of fs2.readdirSync(COMPONENT_CONFIGS_DIR, { withFileTypes: true })) {
      if (entry.isDirectory()) componentResource(entry.name).clearWorking();
    }
  }
  function aliasValueToCss(v) {
    if (typeof v === "string") return v.startsWith("--") ? `var(${v})` : v;
    return formatGradientValue(v.value);
  }
  function aliasValuesEqual(a, b) {
    if (a === void 0 || b === void 0) return a === b;
    if (typeof a === "string" && typeof b === "string") return a === b;
    if (typeof a !== typeof b) return false;
    return JSON.stringify(a) === JSON.stringify(b);
  }
  function readComponentConfig(comp, name) {
    try {
      return componentResource(comp).readJson(name);
    } catch {
      return null;
    }
  }
  const escapedBase = API_BASE.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const COLORS_AND_TYPE_ROUTE = `${API_BASE}/colors-and-type`;
  const COLORS_AND_TYPE_ACTIVE_ROUTE = `${API_BASE}/colors-and-type/active`;
  const COLORS_AND_TYPE_PRODUCTION_ROUTE = `${API_BASE}/colors-and-type/production`;
  const COLORS_AND_TYPE_WORKING_ROUTE = `${API_BASE}/colors-and-type/working`;
  const COMPONENT_CONFIGS_ROUTE = `${API_BASE}/component-configs`;
  const THEMES_ROUTE = `${API_BASE}/themes`;
  const THEMES_ACTIVE_ROUTE = `${API_BASE}/themes/active`;
  const THEMES_PRODUCTION_ROUTE = `${API_BASE}/themes/production`;
  const COLORS_AND_TYPE_BY_NAME_REGEX = new RegExp(`^${escapedBase}/colors-and-type/([a-z0-9\\-_]+)$`);
  const COMP_LIST_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)$`);
  const COMP_ACTIVE_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)/active$`);
  const COMP_PRODUCTION_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)/production$`);
  const COMP_WORKING_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)/working$`);
  const COMP_BY_NAME_REGEX = new RegExp(`^${escapedBase}/component-configs/([a-z0-9\\-_]+)/([a-z0-9\\-_]+)$`);
  const THEME_APPLY_REGEX = new RegExp(`^${escapedBase}/themes/([a-z0-9\\-_]+)/apply$`);
  const THEME_EXPORT_REGEX = new RegExp(`^${escapedBase}/themes/([a-z0-9\\-_]+)/export$`);
  const THEME_IMPORT_ROUTE = `${API_BASE}/themes/import`;
  const THEME_BY_NAME_REGEX = new RegExp(`^${escapedBase}/themes/([a-z0-9\\-_]+)$`);
  const SKETCH_STYLES_ROUTE = `${API_BASE}/sketch-styles`;
  const SKETCH_STYLE_BY_NAME_REGEX = new RegExp(`^${escapedBase}/sketch-styles/([a-z0-9\\-_]+)$`);
  const PRODUCTION_ROUTE = `${API_BASE}/production`;
  const EVENTS_ROUTE = `${API_BASE}/events`;
  async function handleListColorsAndType(_ctx) {
    const files = colorsAndTypeResource.listNames().map((fileName) => {
      const data = colorsAndTypeResource.readJson(fileName);
      return {
        name: data?.name || fileName,
        fileName,
        updatedAt: data?.updatedAt || "",
        // Package-owned rows are the shipped presets and the default. The Load
        // window offers those as whole themes, so it lists only the rows a
        // local file backs — including a local copy of a shipped name, which
        // holds whatever the user did to it.
        isPackage: colorsAndTypeResource.isPackageFile(fileName)
      };
    });
    jsonResponse(_ctx.res, 200, { files });
  }
  async function handleGetActiveColorsAndType({ res }) {
    const resolved = resolveLiveColorsAndType(activeTheme());
    if (!resolved) {
      jsonResponse(res, 404, { error: "Active colors and type not found" });
      return;
    }
    jsonResponse(res, 200, {
      ...resolved.data,
      _fileName: themesResource.getActiveName(),
      _source: resolved.source
    });
  }
  async function readBufferBody(req, res) {
    let parsed;
    try {
      parsed = JSON.parse(await readBody(req));
    } catch {
      parsed = void 0;
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      jsonResponse(res, 400, { error: "Body must be a JSON object", code: "INVALID_BODY" });
      return null;
    }
    return parsed;
  }
  async function handleGetWorkingColorsAndType({ res }) {
    const raw = colorsAndTypeResource.readWorking();
    if (raw === null) {
      jsonResponse(res, 404, { error: "No working colors and type" });
      return;
    }
    jsonResponse(res, 200, normalizeColorsAndType(raw));
  }
  async function handleSetWorkingColorsAndType({ req, res }) {
    const body = await readBufferBody(req, res);
    if (!body) return;
    const normalized = normalizeColorsAndType(body);
    const saved = resolveSavedColorsAndType(activeTheme());
    if (saved !== null && sameJsonValue(normalized, saved)) colorsAndTypeResource.clearWorking();
    else colorsAndTypeResource.writeWorking(body);
    jsonResponse(res, 200, { ok: true });
  }
  async function handleClearWorkingColorsAndType({ res }) {
    colorsAndTypeResource.clearWorking();
    jsonResponse(res, 200, { ok: true });
  }
  async function handleColorsAndTypeByName({ params, req, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const filePath = colorsAndTypeResource.filePath(fileName);
    if (req.method === "GET") {
      const raw = colorsAndTypeResource.readJson(fileName);
      if (!raw) {
        jsonResponse(res, 404, { error: "Not found" });
        return;
      }
      const data = normalizeColorsAndType(raw);
      data._fileName = fileName;
      jsonResponse(res, 200, data);
      return;
    }
    if (req.method === "PUT") {
      if (fileName === "default") {
        jsonResponse(res, 403, { error: "Cannot overwrite the default colors and type (live from package)" });
        return;
      }
      const body = JSON.parse(await readBody(req));
      body.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (fs2.existsSync(filePath)) {
        try {
          const existing = JSON.parse(fs2.readFileSync(filePath, "utf-8"));
          if (existing.createdAt) body.createdAt = existing.createdAt;
        } catch {
        }
      }
      if (!body.createdAt) body.createdAt = body.updatedAt;
      fs2.writeFileSync(filePath, JSON.stringify(body, null, 2));
      jsonResponse(res, 200, { ok: true, fileName });
      return;
    }
    if (req.method === "DELETE") {
      if (fileName === "default") {
        jsonResponse(res, 403, { error: "Cannot delete the default colors and type" });
        return;
      }
      if (fs2.existsSync(filePath)) {
        fs2.unlinkSync(filePath);
      } else if (colorsAndTypeResource.existingPath(fileName)) {
        jsonResponse(res, 403, {
          error: "Cannot delete colors and type shipped with the package. Saving it creates a local copy; deleting that copy restores the shipped version.",
          code: "PACKAGE_COLORS_AND_TYPE"
        });
        return;
      }
      jsonResponse(res, 200, { ok: true });
      return;
    }
  }
  async function handleListComponents({ res }) {
    const components = listComponentNames().map((comp) => ({
      name: comp,
      source: componentResource(comp).hasWorking() ? "working" : "theme"
    }));
    jsonResponse(res, 200, { components });
  }
  function rejectUnknownComponent(res, comp) {
    if (listComponentNames().includes(comp)) return false;
    jsonResponse(res, 404, { error: `Unknown component "${comp}"`, code: "UNKNOWN_COMPONENT" });
    return true;
  }
  async function handleGetComponentActive({ params, res }) {
    const [comp] = params;
    if (rejectUnknownComponent(res, comp)) return;
    const resolved = resolveLiveComponentConfig(comp, activeTheme());
    if (!resolved) {
      jsonResponse(res, 404, { error: "Active config not found" });
      return;
    }
    jsonResponse(res, 200, {
      ...resolved.data,
      _fileName: themesResource.getActiveName(),
      _source: resolved.source
    });
  }
  async function handleGetComponentWorking({ params, res }) {
    const [comp] = params;
    const raw = componentResource(comp).readWorking();
    if (raw === null) {
      jsonResponse(res, 404, { error: "No working config" });
      return;
    }
    jsonResponse(res, 200, raw);
  }
  async function handleSetComponentWorking({ params, req, res }) {
    const [comp] = params;
    if (rejectUnknownComponent(res, comp)) return;
    const body = await readBufferBody(req, res);
    if (!body) return;
    const r = componentResource(comp);
    if (sameJsonValue(body, resolveSavedComponentConfig(comp, activeTheme()))) r.clearWorking();
    else r.writeWorking(body);
    jsonResponse(res, 200, { ok: true });
  }
  async function handleClearComponentWorking({ params, res }) {
    const [comp] = params;
    componentResource(comp).clearWorking();
    jsonResponse(res, 200, { ok: true });
  }
  async function handleComponentConfigByName({ params, req, res }) {
    const [comp, name] = params;
    if (rejectReservedName(res, name)) return;
    const r = componentResource(comp);
    const configPath = r.filePath(name);
    if (req.method === "GET") {
      const raw = r.readJson(name);
      if (!raw) {
        jsonResponse(res, 404, { error: "Not found" });
        return;
      }
      const data = raw;
      data._fileName = name;
      jsonResponse(res, 200, data);
      return;
    }
    if (req.method === "PUT") {
      if (name === "default") {
        jsonResponse(res, 403, { error: "Cannot modify default config (regenerated from source)" });
        return;
      }
      const body = JSON.parse(await readBody(req));
      body.component = comp;
      body.name = body.name || name;
      body.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (fs2.existsSync(configPath)) {
        try {
          const existing = JSON.parse(fs2.readFileSync(configPath, "utf-8"));
          if (existing.createdAt) body.createdAt = existing.createdAt;
        } catch {
        }
      }
      if (!body.createdAt) body.createdAt = body.updatedAt;
      r.ensureDir();
      fs2.writeFileSync(configPath, JSON.stringify(body, null, 2));
      jsonResponse(res, 200, { ok: true, fileName: name });
      return;
    }
    if (req.method === "DELETE") {
      if (name === "default") {
        jsonResponse(res, 403, { error: "Cannot delete default config" });
        return;
      }
      if (fs2.existsSync(configPath)) fs2.unlinkSync(configPath);
      jsonResponse(res, 200, { ok: true });
      return;
    }
  }
  async function handleListComponentConfigs({ params, res }) {
    const [comp] = params;
    const r = componentResource(comp);
    if (!fs2.existsSync(r.dir)) {
      jsonResponse(res, 404, { error: "Component not found" });
      return;
    }
    const files = r.listNames().map((fileName) => {
      const data = r.readJson(fileName);
      return {
        name: data?.name || fileName,
        fileName,
        updatedAt: data?.updatedAt || "",
        isPackage: sketchStylesResource.isPackageFile(fileName)
      };
    });
    jsonResponse(res, 200, { component: comp, files });
  }
  async function handleListThemes({ res }) {
    const activeFile = themesResource.getActiveName();
    const productionFile = themesResource.getProductionName();
    const files = [];
    for (const fileName of themesResource.listNames()) {
      const read = readTheme(fileName);
      if (!read) {
        console.warn(
          unreadableThemeReason(fileName) === "colors-and-type" ? `[live-tokens] ${notAThemeError(fileName)} It is left out of the theme list.` : `[live-tokens] Theme "${fileName}" is unreadable and was left out of the list.`
        );
        continue;
      }
      files.push({
        name: read.theme.name,
        fileName,
        updatedAt: read.theme.updatedAt,
        isActive: fileName === activeFile,
        isProduction: fileName === productionFile,
        isProtected: fileName === "default"
      });
    }
    jsonResponse(res, 200, { files, activeFile, productionFile });
  }
  async function handleGetProductionTheme({ res }) {
    const fileName = themesResource.getProductionName();
    const read = readTheme(fileName);
    if (!read) {
      respondUnreadableTheme(res, fileName, "Production theme not found");
      return;
    }
    jsonResponse(res, 200, { ...read.theme, _fileName: fileName, _baked: bakeIsCurrent() });
  }
  async function handleGetActiveTheme({ res }) {
    const activeFile = themesResource.getActiveName();
    const read = readTheme(activeFile);
    if (!read) {
      respondUnreadableTheme(res, activeFile, "Active theme not found");
      return;
    }
    jsonResponse(res, 200, { ...read.theme, _fileName: activeFile });
  }
  async function handleSetActiveTheme({ req, res }) {
    const body = JSON.parse(await readBody(req));
    const fileName = sanitizeFileName(body.name || "default");
    if (themesResource.existingPath(fileName) === null) {
      jsonResponse(res, 404, { error: "Theme not found" });
      return;
    }
    themesResource.setActiveName(fileName);
    pruneMatchingWorking(readTheme(fileName)?.theme ?? null);
    jsonResponse(res, 200, { ok: true, activeFile: fileName });
  }
  async function handleThemeByName({ params, req, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const filePath = themesResource.filePath(fileName);
    if (req.method === "GET") {
      const read = readTheme(fileName);
      if (!read) {
        respondUnreadableTheme(res, fileName, "Not found");
        return;
      }
      jsonResponse(res, 200, { ...read.theme, _fileName: fileName });
      return;
    }
    if (req.method === "PUT") {
      if (fileName === "default") {
        jsonResponse(res, 403, { error: "Cannot overwrite the default theme" });
        return;
      }
      const body = JSON.parse(await readBody(req));
      const { theme } = normalizeTheme(body, diskThemeResolvers);
      theme.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (fs2.existsSync(filePath)) {
        try {
          const existing = JSON.parse(fs2.readFileSync(filePath, "utf-8"));
          if (existing.createdAt) theme.createdAt = existing.createdAt;
        } catch {
        }
      }
      writeTheme(fileName, theme);
      if (themesResource.getActiveName() === fileName) pruneMatchingWorking(theme);
      jsonResponse(res, 200, { ok: true, fileName });
      return;
    }
    if (req.method === "DELETE") {
      if (fileName === "default") {
        jsonResponse(res, 403, { error: "Cannot delete the default theme" });
        return;
      }
      if (fileName === themesResource.getProductionName()) {
        jsonResponse(res, 403, {
          error: "Cannot delete the theme that is in production. Adopt another theme first.",
          code: "PRODUCTION_THEME"
        });
        return;
      }
      if (fs2.existsSync(filePath)) {
        const deletingActive = themesResource.getActiveName() === fileName;
        const liveColors = deletingActive ? resolveLiveColorsAndType(activeTheme()) : null;
        const liveComponents = {};
        if (deletingActive) {
          for (const comp of listComponentNames()) {
            const resolved = resolveLiveComponentConfig(comp, activeTheme());
            if (resolved) liveComponents[comp] = resolved.data;
          }
        }
        fs2.unlinkSync(filePath);
        if (themesResource.existingPath(fileName) === null && deletingActive) {
          themesResource.setActiveName("default");
        }
        if (deletingActive) {
          const replacement = activeTheme();
          const savedColors = resolveSavedColorsAndType(replacement);
          if (liveColors && !sameJsonValue(liveColors.data, savedColors)) {
            colorsAndTypeResource.writeWorking(liveColors.data);
          } else {
            colorsAndTypeResource.clearWorking();
          }
          for (const comp of listComponentNames()) {
            const r = componentResource(comp);
            const live = liveComponents[comp] ?? null;
            const saved = resolveSavedComponentConfig(comp, replacement);
            if (live !== null && !sameJsonValue(live, saved)) r.writeWorking({ ...live });
            else r.clearWorking();
          }
        }
      } else if (themesResource.existingPath(fileName)) {
        jsonResponse(res, 403, {
          error: "Cannot delete a theme shipped with the package. Saving it creates a local copy; deleting that copy restores the shipped version.",
          code: "PACKAGE_THEME"
        });
        return;
      }
      jsonResponse(res, 200, { ok: true });
      return;
    }
  }
  async function handleApplyTheme({ params, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const read = readTheme(fileName);
    if (!read) {
      respondUnreadableTheme(res, fileName, "Theme not found");
      return;
    }
    const { theme, filled } = read;
    if (!theme.colorsAndType) {
      jsonResponse(res, 422, {
        error: 'This theme carries no colors and type. Build one with the theme skill "create-theme".'
      });
      return;
    }
    clearAllWorking();
    themesResource.setActiveName(fileName);
    const knownComponents = listComponentNames();
    const skippedComponents = Object.keys(theme.componentConfigs).filter(
      (comp) => !knownComponents.includes(comp)
    );
    jsonResponse(res, 200, {
      ok: true,
      ...resolveLiveState(theme, fileName),
      skippedComponents,
      filled
    });
  }
  function resolveLiveState(theme, fileName) {
    const componentConfigs = {};
    for (const comp of listComponentNames()) {
      const resolved = resolveLiveComponentConfig(comp, theme);
      if (resolved) componentConfigs[comp] = { ...resolved.data, _fileName: fileName, _source: resolved.source };
    }
    const colorsAndType = resolveLiveColorsAndType(theme);
    return {
      fileName,
      theme: { ...theme, _fileName: fileName },
      colorsAndType: colorsAndType && { ...colorsAndType.data, _fileName: fileName, _source: colorsAndType.source },
      componentConfigs
    };
  }
  async function handleEvents({ req, res }) {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.write(": connected\n\n");
    const unsubscribe = liveWatch.subscribe(() => {
      const activeFile = themesResource.getActiveName();
      const read = readTheme(activeFile);
      if (!read) return;
      const state = resolveLiveState(read.theme, activeFile);
      res.write(`event: live-state
data: ${JSON.stringify(state)}

`);
    });
    req.on("close", unsubscribe);
  }
  async function handleExportTheme({ params, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const read = readTheme(fileName);
    if (!read) {
      respondUnreadableTheme(res, fileName, "Theme not found");
      return;
    }
    const bundle = {
      kind: "theme-bundle",
      schemaVersion: THEME_SCHEMA_VERSION,
      liveTokensVersion: PKG_VERSION,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      manifest: read.theme
    };
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${fileName}.bundle.json"`
    );
    res.end(JSON.stringify(bundle, null, 2));
  }
  function nextAvailableName2(exists, baseName) {
    return nextAvailableName(exists, sanitizeFileName(baseName));
  }
  async function handleImportTheme({ req, res }) {
    let bundle;
    try {
      bundle = JSON.parse(await readBody(req));
    } catch {
      jsonResponse(res, 400, { error: "Body is not valid JSON" });
      return;
    }
    if (!bundle || !Object.values(BUNDLE_KIND_BY_VERSION).includes(bundle.kind)) {
      jsonResponse(res, 400, {
        error: "Not a theme bundle (kind discriminator missing or wrong)"
      });
      return;
    }
    if (bundle.kind !== BUNDLE_KIND_BY_VERSION[bundle.schemaVersion]) {
      jsonResponse(res, 400, {
        error: `Unsupported bundle: kind "${bundle.kind}" with schemaVersion ${bundle.schemaVersion}`
      });
      return;
    }
    if (!bundle.manifest) {
      jsonResponse(res, 400, { error: "Bundle missing theme" });
      return;
    }
    const bundleResolvers = {
      readColorsAndType: () => bundle.theme,
      // A named ref resolves inside the bundle only — a v1 bundle's
      // `${comp}/${name}` map is itself the sender's data, and a stale name
      // must still land in `dropped` rather than quietly picking up this
      // install's copy. But `'default'` never named a bundled entry; v1
      // spelled "no override" that way (normalizeTheme.ts's pointer-
      // resolution loop treats it identically), so it always meant *this
      // install's* default, not something the bundle carries. The
      // completeness fill relies on that fall-through: without it,
      // `readComponentConfig(comp, 'default')` answers undefined for every
      // component (no bundle ever carries a `<comp>/default` entry), the
      // fill loop no-ops 25 times, and an incomplete bundle stays incomplete
      // forever.
      readComponentConfig: (comp, name) => bundle.componentConfigs?.[`${comp}/${name}`] ?? (name === "default" ? readComponentConfig(comp, "default") : void 0),
      // Installed components are a property of this install, not of the
      // bundle being imported, so the completeness fill uses the
      // same list the disk resolver does.
      listComponentNames,
      normalizeColorsAndType: (colorsAndType) => normalizeColorsAndType(colorsAndType)
    };
    const { theme, dropped, filled } = normalizeTheme(bundle.manifest, bundleResolvers);
    if (theme.colorsAndType) theme.colorsAndType = normalizeColorsAndType(theme.colorsAndType);
    if (!theme.colorsAndType) {
      jsonResponse(res, 400, { error: "Bundle carries no theme" });
      return;
    }
    theme.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const renames = {};
    const originalName = sanitizeFileName(theme.name || "imported");
    const finalName = nextAvailableName2(
      (n) => themesResource.existingPath(n) !== null,
      originalName
    );
    if (finalName !== originalName) {
      renames[`theme:${originalName}`] = finalName;
    }
    writeTheme(finalName, theme);
    jsonResponse(res, 200, {
      ok: true,
      theme: finalName,
      renames,
      dropped,
      filled
    });
  }
  async function handleAdoptTheme({ res }) {
    const activeName = themesResource.getActiveName();
    if (activeName === "default") {
      jsonResponse(res, 409, {
        error: "Active theme is protected. Save As first.",
        code: "ACTIVE_IS_PROTECTED"
      });
      return;
    }
    const read = readTheme(activeName);
    if (!read) {
      respondUnreadableTheme(res, activeName, "Active theme not found");
      return;
    }
    themesResource.setProductionName(activeName);
    regenerateTokensCss();
    syncFontsToCss(read.theme.colorsAndType);
    jsonResponse(res, 200, {
      ok: true,
      productionTheme: {
        fileName: activeName,
        name: read.theme.name,
        updatedAt: read.theme.updatedAt
      }
    });
  }
  async function handleListSketchStyles({ res }) {
    const files = sketchStylesResource.listNames().map((fileName) => {
      let data = null;
      try {
        data = sketchStylesResource.readJson(fileName);
      } catch {
      }
      return {
        name: data?.name || fileName,
        fileName,
        updatedAt: data?.updatedAt || "",
        isPackage: sketchStylesResource.isPackageFile(fileName)
      };
    });
    jsonResponse(res, 200, { files });
  }
  async function handleSketchStyleByName({ params, req, res }) {
    const [fileName] = params;
    if (rejectReservedName(res, fileName)) return;
    const filePath = sketchStylesResource.filePath(fileName);
    if (req.method === "GET") {
      const raw = sketchStylesResource.readJson(fileName);
      if (!raw) {
        jsonResponse(res, 404, { error: "Not found" });
        return;
      }
      jsonResponse(res, 200, { ...raw, _fileName: fileName });
      return;
    }
    if (req.method === "PUT") {
      const body = JSON.parse(await readBody(req));
      if (!body || typeof body !== "object" || !body.settings || typeof body.settings !== "object") {
        jsonResponse(res, 400, { error: "A sketchstyle needs a settings object" });
        return;
      }
      body.name = String(body.name || fileName);
      body.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (fs2.existsSync(filePath)) {
        try {
          const existing = JSON.parse(fs2.readFileSync(filePath, "utf-8"));
          if (existing.createdAt) body.createdAt = existing.createdAt;
        } catch {
        }
      }
      if (!body.createdAt) body.createdAt = body.updatedAt;
      sketchStylesResource.ensureDir();
      fs2.writeFileSync(filePath, JSON.stringify(body, null, 2));
      jsonResponse(res, 200, { ok: true, fileName });
      return;
    }
    if (req.method === "DELETE") {
      if (fs2.existsSync(filePath)) {
        fs2.unlinkSync(filePath);
      } else if (sketchStylesResource.existingPath(fileName)) {
        jsonResponse(res, 403, {
          error: "Cannot delete a sketchstyle shipped with the package. Saving it creates a local copy; deleting that copy restores the shipped version.",
          code: "PACKAGE_SKETCH_STYLE"
        });
        return;
      }
      jsonResponse(res, 200, { ok: true });
      return;
    }
  }
  function methodNotAllowed({ res }) {
    jsonResponse(res, 405, { error: "Method not allowed" });
  }
  let legacyLayout = null;
  const routes = [
    // Colors and type — list / active / production / working are exact strings;
    // they must run before COLORS_AND_TYPE_BY_NAME_REGEX
    { method: "GET", pattern: COLORS_AND_TYPE_ROUTE, handler: handleListColorsAndType },
    { method: "GET", pattern: COLORS_AND_TYPE_ACTIVE_ROUTE, handler: handleGetActiveColorsAndType },
    { method: "PUT", pattern: COLORS_AND_TYPE_ACTIVE_ROUTE, handler: methodNotAllowed },
    { method: "GET", pattern: COLORS_AND_TYPE_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "PUT", pattern: COLORS_AND_TYPE_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "POST", pattern: COLORS_AND_TYPE_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: COLORS_AND_TYPE_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "GET", pattern: COLORS_AND_TYPE_WORKING_ROUTE, handler: handleGetWorkingColorsAndType },
    { method: "PUT", pattern: COLORS_AND_TYPE_WORKING_ROUTE, handler: handleSetWorkingColorsAndType },
    { method: "DELETE", pattern: COLORS_AND_TYPE_WORKING_ROUTE, handler: handleClearWorkingColorsAndType },
    { method: "POST", pattern: COLORS_AND_TYPE_WORKING_ROUTE, handler: methodNotAllowed },
    // Component configs — list of components
    { method: "GET", pattern: COMPONENT_CONFIGS_ROUTE, handler: handleListComponents },
    // Component configs — :comp/active (must precede :comp/:name)
    { method: "GET", pattern: COMP_ACTIVE_REGEX, handler: handleGetComponentActive },
    { method: "PUT", pattern: COMP_ACTIVE_REGEX, handler: methodNotAllowed },
    { method: "POST", pattern: COMP_ACTIVE_REGEX, handler: methodNotAllowed },
    { method: "DELETE", pattern: COMP_ACTIVE_REGEX, handler: methodNotAllowed },
    // Component configs — :comp/production, retired with the per-layer pointers
    { method: "GET", pattern: COMP_PRODUCTION_REGEX, handler: methodNotAllowed },
    { method: "PUT", pattern: COMP_PRODUCTION_REGEX, handler: methodNotAllowed },
    { method: "POST", pattern: COMP_PRODUCTION_REGEX, handler: methodNotAllowed },
    { method: "DELETE", pattern: COMP_PRODUCTION_REGEX, handler: methodNotAllowed },
    // Component configs — :comp/working (must precede :comp/:name)
    { method: "GET", pattern: COMP_WORKING_REGEX, handler: handleGetComponentWorking },
    { method: "PUT", pattern: COMP_WORKING_REGEX, handler: handleSetComponentWorking },
    { method: "DELETE", pattern: COMP_WORKING_REGEX, handler: handleClearComponentWorking },
    { method: "POST", pattern: COMP_WORKING_REGEX, handler: methodNotAllowed },
    // Component configs — :comp/:name (must precede :comp listing)
    { method: "GET", pattern: COMP_BY_NAME_REGEX, handler: handleComponentConfigByName },
    { method: "PUT", pattern: COMP_BY_NAME_REGEX, handler: handleComponentConfigByName },
    { method: "DELETE", pattern: COMP_BY_NAME_REGEX, handler: handleComponentConfigByName },
    { method: "POST", pattern: COMP_BY_NAME_REGEX, handler: methodNotAllowed },
    // Component configs — list configs for :comp (broadest, runs last among comp routes)
    { method: "GET", pattern: COMP_LIST_REGEX, handler: handleListComponentConfigs },
    // Colors and type — :name CRUD (broadest colors-and-type route, runs last)
    { method: "GET", pattern: COLORS_AND_TYPE_BY_NAME_REGEX, handler: handleColorsAndTypeByName },
    { method: "PUT", pattern: COLORS_AND_TYPE_BY_NAME_REGEX, handler: handleColorsAndTypeByName },
    { method: "DELETE", pattern: COLORS_AND_TYPE_BY_NAME_REGEX, handler: handleColorsAndTypeByName },
    // Themes — list / active / production are exact strings, must run before regexes
    { method: "GET", pattern: THEMES_ROUTE, handler: handleListThemes },
    { method: "GET", pattern: THEMES_ACTIVE_ROUTE, handler: handleGetActiveTheme },
    { method: "PUT", pattern: THEMES_ACTIVE_ROUTE, handler: handleSetActiveTheme },
    { method: "GET", pattern: THEMES_PRODUCTION_ROUTE, handler: handleGetProductionTheme },
    // Adopt is the one door that moves the production pointer; naming a theme
    // here would be a second, silent way to publish.
    { method: "PUT", pattern: THEMES_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "POST", pattern: THEMES_PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: THEMES_PRODUCTION_ROUTE, handler: methodNotAllowed },
    // Themes — exact import route runs before :name regexes
    { method: "POST", pattern: THEME_IMPORT_ROUTE, handler: handleImportTheme },
    { method: "PUT", pattern: THEME_IMPORT_ROUTE, handler: methodNotAllowed },
    { method: "GET", pattern: THEME_IMPORT_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: THEME_IMPORT_ROUTE, handler: methodNotAllowed },
    // Themes — :name/apply (more specific than :name)
    { method: "PUT", pattern: THEME_APPLY_REGEX, handler: handleApplyTheme },
    { method: "POST", pattern: THEME_APPLY_REGEX, handler: methodNotAllowed },
    { method: "GET", pattern: THEME_APPLY_REGEX, handler: methodNotAllowed },
    { method: "DELETE", pattern: THEME_APPLY_REGEX, handler: methodNotAllowed },
    // Themes — :name/export (more specific than :name)
    { method: "GET", pattern: THEME_EXPORT_REGEX, handler: handleExportTheme },
    { method: "PUT", pattern: THEME_EXPORT_REGEX, handler: methodNotAllowed },
    { method: "POST", pattern: THEME_EXPORT_REGEX, handler: methodNotAllowed },
    { method: "DELETE", pattern: THEME_EXPORT_REGEX, handler: methodNotAllowed },
    // Themes — :name CRUD (broadest theme route, runs last)
    { method: "GET", pattern: THEME_BY_NAME_REGEX, handler: handleThemeByName },
    { method: "PUT", pattern: THEME_BY_NAME_REGEX, handler: handleThemeByName },
    { method: "DELETE", pattern: THEME_BY_NAME_REGEX, handler: handleThemeByName },
    // Production — the whole-theme adopt door
    { method: "GET", pattern: SKETCH_STYLES_ROUTE, handler: handleListSketchStyles },
    { method: "PUT", pattern: SKETCH_STYLES_ROUTE, handler: methodNotAllowed },
    { method: "POST", pattern: SKETCH_STYLES_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: SKETCH_STYLES_ROUTE, handler: methodNotAllowed },
    { method: "GET", pattern: SKETCH_STYLE_BY_NAME_REGEX, handler: handleSketchStyleByName },
    { method: "PUT", pattern: SKETCH_STYLE_BY_NAME_REGEX, handler: handleSketchStyleByName },
    { method: "DELETE", pattern: SKETCH_STYLE_BY_NAME_REGEX, handler: handleSketchStyleByName },
    { method: "POST", pattern: SKETCH_STYLE_BY_NAME_REGEX, handler: methodNotAllowed },
    { method: "GET", pattern: EVENTS_ROUTE, handler: handleEvents },
    { method: "PUT", pattern: PRODUCTION_ROUTE, handler: handleAdoptTheme },
    { method: "GET", pattern: PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "POST", pattern: PRODUCTION_ROUTE, handler: methodNotAllowed },
    { method: "DELETE", pattern: PRODUCTION_ROUTE, handler: methodNotAllowed }
  ];
  const isEditorOwnedJson = (file) => file.endsWith(".json") && path3.resolve(file).startsWith(dataDirs.dataDir + path3.sep);
  let buildLogger = null;
  let buildChecked = false;
  let productionCssLogger = null;
  return {
    name: "theme-file-api",
    config() {
      return {
        define: {
          __PROJECT_ROOT__: JSON.stringify(process.cwd()),
          __APP_VERSION__: JSON.stringify(PKG_VERSION),
          __LIVE_TOKENS_API_BASE__: JSON.stringify(API_BASE)
        },
        server: { watch: { ignored: [isEditorOwnedJson] } }
      };
    },
    configResolved(config) {
      buildLogger = config.command === "build" && opts.checks !== false ? config.logger : null;
      productionCssLogger = config.command === "build" && opts.productionCss !== false ? config.logger : null;
    },
    async buildStart() {
      if (!buildLogger || buildChecked) return;
      buildChecked = true;
      const failure = await checkBeforeBuild({ root: process.cwd(), logger: buildLogger });
      if (failure) this.error(failure);
    },
    generateBundle: {
      // After Vite's own hooks, so the bundle holds the minified CSS and index.html.
      order: "post",
      handler(output, bundle) {
        if (!productionCssLogger) return;
        const report = rewriteBundle(bundle, opts.productionCss || {}, output);
        if (report) productionCssLogger.info(formatReport(report));
      }
    },
    configureServer(server) {
      legacyLayout = detectLegacyLayout({
        dataDir: dataDirs.dataDir,
        colorsAndTypeDir: COLORS_AND_TYPE_DIR,
        themesDir: THEMES_DIR,
        configuredManifestsDir: dataDirs.legacyManifestsDir
      });
      if (legacyLayout) {
        warnOnLegacyLayout(legacyLayout.evidence, (msg) => server.config.logger.warn(msg));
      } else {
        ensureColorsAndTypeDir();
        ensureComponentConfigsDir();
        const { productionPointerHeld } = ensureThemesDir((msg) => server.config.logger.warn(msg));
        const openTheme = activeTheme();
        if (openTheme) pruneMatchingWorking(openTheme);
        if (!productionPointerHeld || !fs2.existsSync(GENERATED_CSS_PATH)) regenerateTokensCss();
        if (opts.autoMigrate && !ISOLATED_DATA_DIR) {
          autoMigrateAdditive((msg) => server.config.logger.info(msg));
        }
        warnOnTokenDrift((msg) => server.config.logger.warn(msg));
        warnOnLegacyPointers(
          listLegacyPointers(),
          productionPointerHeld,
          (msg) => server.config.logger.warn(msg)
        );
        warnOnUnmigratedSketchStyles((msg) => server.config.logger.warn(msg));
      }
      server.middlewares.use(async (req, res, next) => {
        if (legacyLayout && req.method !== "GET" && (req.url ?? "").startsWith(API_BASE)) {
          jsonResponse(res, 409, {
            error: "This project still uses the data layout from 0.47 and earlier. Run `npx live-tokens migrate`, then restart the dev server.",
            code: "LEGACY_LAYOUT"
          });
          return;
        }
        const handled = await dispatch(req, res, routes);
        if (!handled) next();
      });
    },
    handleHotUpdate(ctx) {
      if (legacyLayout) return;
      const normalized = path3.resolve(ctx.file);
      if (!COMPONENTS_SCAN_DIRS.some((d) => normalized.startsWith(d))) return;
      if (!normalized.endsWith(".svelte")) return;
      if (!isThemeAwareComponent(normalized)) return;
      const comp = componentNameFromFile(normalized);
      generateDefaultConfig(comp, normalized);
    }
  };
}
export {
  TOKENS_CSS_MIGRATIONS,
  runTokensCssMigrations,
  themeFileApi,
  validateTokensCss
};
