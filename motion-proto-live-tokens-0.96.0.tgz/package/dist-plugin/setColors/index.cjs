"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// vite-plugin/setColors/index.ts
var setColors_exports = {};
__export(setColors_exports, {
  CURRENT_COMPONENT_SCHEMA_VERSION: () => CURRENT_COMPONENT_SCHEMA_VERSION,
  buildColors: () => buildColors,
  readLiveTokensConfig: () => readLiveTokensConfig,
  resolveDataDirs: () => resolveDataDirs,
  sanitizeFileName: () => sanitizeFileName
});
module.exports = __toCommonJS(setColors_exports);

// src/system/internal/oklch.ts
function srgbToLinear(c) {
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}
function linearToSrgb(c) {
  return c <= 31308e-7 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
}
function hexToLinearRgb(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  return [srgbToLinear(r), srgbToLinear(g), srgbToLinear(b)];
}
function linearRgbToHex(r, g, b) {
  const toHex = (c) => {
    const v = Math.round(Math.max(0, Math.min(1, linearToSrgb(c))) * 255);
    return v.toString(16).padStart(2, "0");
  };
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
function linearRgbToOklab(r, g, b) {
  const l_ = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b;
  const m_ = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b;
  const s_ = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b;
  const l = Math.cbrt(l_);
  const m = Math.cbrt(m_);
  const s = Math.cbrt(s_);
  return [
    0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s
  ];
}
function oklabToLinearRgb(L, a, b) {
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ * l_ * l_;
  const m = m_ * m_ * m_;
  const s = s_ * s_ * s_;
  return [
    4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s
  ];
}
function oklabToOklch(L, a, b) {
  const c = Math.sqrt(a * a + b * b);
  let h = Math.atan2(b, a) * 180 / Math.PI;
  if (h < 0) h += 360;
  return { l: L, c, h };
}
function oklchToOklab(l, c, h) {
  const hRad = h * Math.PI / 180;
  return [l, c * Math.cos(hRad), c * Math.sin(hRad)];
}
function hexToOklch(hex) {
  const [r, g, b] = hexToLinearRgb(hex);
  const [L, a, bVal] = linearRgbToOklab(r, g, b);
  return oklabToOklch(L, a, bVal);
}
function oklchToHex(l, c, h) {
  const [L, a, b] = oklchToOklab(l, c, h);
  const [r, g, bVal] = oklabToLinearRgb(L, a, b);
  return linearRgbToHex(r, g, bVal);
}
function isInGamut(r, g, b) {
  const eps = 1e-4;
  return r >= -eps && r <= 1 + eps && g >= -eps && g <= 1 + eps && b >= -eps && b <= 1 + eps;
}
function oklchToHexClamped(l, c, h) {
  const g = gamutClamp(l, c, h);
  return oklchToHex(g.l, g.c, g.h);
}
function gamutClamp(l, c, h) {
  if (l <= 0) return { l: 0, c: 0, h };
  if (l >= 1) return { l: 1, c: 0, h };
  const [L, a, b] = oklchToOklab(l, c, h);
  const [r, g, bVal] = oklabToLinearRgb(L, a, b);
  if (isInGamut(r, g, bVal)) return { l, c, h };
  let lo = 0;
  let hi = c;
  for (let i = 0; i < 20; i++) {
    const mid = (lo + hi) / 2;
    const [La, aa, ba] = oklchToOklab(l, mid, h);
    const [rr, gg, bb] = oklabToLinearRgb(La, aa, ba);
    if (isInGamut(rr, gg, bb)) {
      lo = mid;
    } else {
      hi = mid;
    }
  }
  return { l, c: lo, h };
}
function trim(value, decimals) {
  return Number(value.toFixed(decimals)).toString();
}
function oklchToCss(l, c, h) {
  const cs = trim(c, 4);
  return `oklch(${trim(l, 4)} ${cs} ${cs === "0" ? "0" : trim(h, 2)})`;
}
var OKLCH_RE = /^oklch\(\s*([\d.]+)(%?)\s+([\d.]+)(%?)\s+([\d.]+)(?:deg)?\s*\)$/i;
var HEX6_RE = /^#[0-9a-f]{6}$/i;
function parseOklchCss(value) {
  const m = OKLCH_RE.exec(value.trim());
  if (!m) return null;
  const l = Number.parseFloat(m[1]) / (m[2] === "%" ? 100 : 1);
  const c = Number.parseFloat(m[3]) * (m[4] === "%" ? 4e-3 : 1);
  return { l, c, h: Number.parseFloat(m[5]) };
}
function cssColorToOklch(value) {
  const raw = value.trim();
  if (HEX6_RE.test(raw)) return hexToOklch(raw);
  return parseOklchCss(raw);
}

// src/editor/ui/curveEngine.ts
function makeAnchor(x, y, tangentLen = 15) {
  return { x, y, inDx: -tangentLen, inDy: 0, outDx: tangentLen, outDy: 0 };
}
var HANDLE_SPAN = 1 / 3;
function tangentSlope(prev, x, y, next) {
  const hPrev = prev ? x - prev.x : 0;
  const hNext = next ? next.x - x : 0;
  const dPrev = hPrev > 0 ? (y - prev.y) / hPrev : null;
  const dNext = hNext > 0 ? (next.y - y) / hNext : null;
  if (dPrev === null) return dNext ?? 0;
  if (dNext === null) return dPrev;
  if (dPrev * dNext <= 0) return 0;
  const wPrev = 2 * hNext + hPrev;
  const wNext = hNext + 2 * hPrev;
  return (wPrev + wNext) / (wPrev / dPrev + wNext / dNext);
}
function tangentAnchor(x, y, prev, next) {
  const m = tangentSlope(prev, x, y, next);
  const inDx = prev ? -(x - prev.x) * HANDLE_SPAN : 0;
  const outDx = next ? (next.x - x) * HANDLE_SPAN : 0;
  return { x, y, inDx, inDy: m * inDx, outDx, outDy: m * outDx };
}
function isCornerAnchor(a) {
  return a.inDx === 0 && a.inDy === 0 && a.outDx === 0 && a.outDy === 0;
}
function resmoothAutoCurve(anchors) {
  if (anchors.length < 2) return anchors;
  return anchors.map(
    (a, i) => isCornerAnchor(a) ? a : tangentAnchor(a.x, a.y, anchors[i - 1] ?? null, anchors[i + 1] ?? null)
  );
}
function evalBezier(p0x, p0y, c0x, c0y, c1x, c1y, p1x, p1y, t) {
  const u = 1 - t, u2 = u * u, u3 = u2 * u;
  const t2 = t * t, t3 = t2 * t;
  return {
    x: u3 * p0x + 3 * u2 * t * c0x + 3 * u * t2 * c1x + t3 * p1x,
    y: u3 * p0y + 3 * u2 * t * c0y + 3 * u * t2 * c1y + t3 * p1y
  };
}
function sampleCurve(anchors, xPos) {
  if (anchors.length === 0) return 0;
  if (anchors.length === 1) return anchors[0].y;
  if (xPos <= anchors[0].x) return anchors[0].y;
  if (xPos >= anchors[anchors.length - 1].x) return anchors[anchors.length - 1].y;
  let seg = 0;
  while (seg < anchors.length - 2 && anchors[seg + 1].x < xPos) seg++;
  const a0 = anchors[seg], a1 = anchors[seg + 1];
  const p0x = a0.x, p0y = a0.y;
  const c0x = a0.x + a0.outDx, c0y = a0.y + a0.outDy;
  const c1x = a1.x + a1.inDx, c1y = a1.y + a1.inDy;
  const p1x = a1.x, p1y = a1.y;
  let lo = 0, hi = 1;
  for (let i = 0; i < 20; i++) {
    const mid = (lo + hi) / 2;
    const pt = evalBezier(p0x, p0y, c0x, c0y, c1x, c1y, p1x, p1y, mid);
    if (pt.x < xPos) lo = mid;
    else hi = mid;
  }
  return evalBezier(p0x, p0y, c0x, c0y, c1x, c1y, p1x, p1y, (lo + hi) / 2).y;
}

// src/editor/core/palettes/paletteDerivation.ts
var PALETTE_SPECS = [
  { label: "Brand", cssNamespace: "brand", initialColor: { l: 0.5573, c: 0.1841, h: 25.49 } },
  { label: "Accent", cssNamespace: "accent", initialColor: { l: 0.7674, c: 0.164, h: 70.44 } },
  { label: "Special", cssNamespace: "special", initialColor: { l: 0.6056, c: 0.2189, h: 292.72 } },
  { label: "Canvas", cssNamespace: "canvas", emptySelector: true, initialColor: { l: 0.2284, c: 0.0384, h: 282.93 } },
  { label: "Neutral", cssNamespace: "neutral", neutral: true, initialColor: { l: 0.5679, c: 0.0134, h: 240.07 } },
  { label: "Alternate", cssNamespace: "alternate", neutral: true, displayLabel: "Alternate (neutral)", initialColor: { l: 0.5873, c: 87e-4, h: 48.57 } },
  { label: "Info", cssNamespace: "info", initialColor: { l: 0.5871, c: 0.1855, h: 259.56 } },
  { label: "Success", cssNamespace: "success", initialColor: { l: 0.7198, c: 0.1918, h: 149.52 } },
  { label: "Warning", cssNamespace: "warning", initialColor: { l: 0.6704, c: 0.1716, h: 48.75 } },
  { label: "Danger", cssNamespace: "danger", initialColor: { l: 0.6103, c: 0.2165, h: 18.1 } }
];
var PALETTE_STEPS = [
  { label: "100" },
  { label: "200" },
  { label: "300" },
  { label: "400" },
  { label: "500" },
  { label: "600" },
  { label: "700" },
  { label: "800" },
  { label: "850" },
  { label: "900" },
  { label: "950" }
];
var SCALES = [
  {
    title: "Surfaces",
    isText: false,
    steps: [
      { name: "lowest", position: -1 },
      { name: "lower", position: -2 / 3 },
      { name: "low", position: -1 / 3 },
      { name: "default", position: 0 },
      { name: "high", position: 1 / 3 },
      { name: "higher", position: 2 / 3 },
      { name: "highest", position: 1 }
    ]
  },
  {
    title: "Borders",
    isText: false,
    steps: [
      { name: "faint", position: -1 },
      { name: "subtle", position: -0.5 },
      { name: "default", position: 0 },
      { name: "medium", position: 0.5 },
      { name: "strong", position: 1 }
    ]
  },
  {
    title: "Text",
    isText: true,
    steps: [
      { name: "primary", position: 0 },
      { name: "secondary", position: 0 },
      { name: "tertiary", position: 0 },
      { name: "muted", position: 0 },
      { name: "disabled", position: 0 }
    ]
  }
];
var BW_GUARD_MIN_L = 0.17;
var BW_GUARD_MAX_L = 0.93;
var autoCurve = (...anchors) => resmoothAutoCurve(anchors);
var DEFAULT_PALETTE_LIGHTNESS = () => autoCurve(makeAnchor(0, 95), makeAnchor(100, 8));
var DEFAULT_PALETTE_SATURATION = () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100));
var wrapHue = (h) => (h % 360 + 360) % 360;
function scaleCurveDefaults(scheme = "dark") {
  if (scheme === "light") {
    return {
      Surfaces: {
        lightness: () => autoCurve(makeAnchor(0, 98), makeAnchor(100, 82)),
        saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
      },
      Borders: {
        lightness: () => autoCurve(makeAnchor(0, 92), makeAnchor(100, 45)),
        saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
      },
      Text: {
        lightness: () => autoCurve(makeAnchor(0, 30), makeAnchor(100, 120)),
        saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 15))
      }
    };
  }
  return {
    Surfaces: {
      lightness: () => autoCurve(makeAnchor(0, 15), makeAnchor(100, 47)),
      saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
    },
    Borders: {
      lightness: () => autoCurve(makeAnchor(0, 25), makeAnchor(100, 80)),
      saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 100))
    },
    Text: {
      lightness: () => autoCurve(makeAnchor(0, 120), makeAnchor(100, 55)),
      saturation: () => autoCurve(makeAnchor(0, 100), makeAnchor(100, 15))
    }
  };
}
var defaultScaleCurves = scaleCurveDefaults("dark");
function paletteStepKey(label) {
  return `Palette-${label}`;
}
function stepKey(scaleTitle, stepName) {
  return `${scaleTitle}-${stepName}`;
}
function stepIndexToX(index) {
  return index / (PALETTE_STEPS.length - 1) * 100;
}
function scaleStepToX(step, scale) {
  const idx = scale.steps.indexOf(step);
  return scale.steps.length > 1 ? idx / (scale.steps.length - 1) * 100 : 50;
}
function serializeDerivedValue(value) {
  return value.kind === "raw" ? value.css : oklchToCss(value.l, value.c, value.h);
}
function computePaletteOklch(index, base, lightnessCurve, saturationCurve, curveOffset, hueCurve) {
  const { c: baseC } = base;
  const xPos = stepIndexToX(index);
  const targetL = Math.max(0, Math.min(100, sampleCurve(lightnessCurve, xPos) + (curveOffset.lightness ?? 0))) / 100;
  const satMul = Math.max(0, Math.min(2, (sampleCurve(saturationCurve, xPos) + (curveOffset.saturation ?? 0)) / 100));
  const targetC = baseC * satMul;
  const hueDelta = (hueCurve ? sampleCurve(hueCurve, xPos) : 0) + (curveOffset.hue ?? 0);
  const h = hueDelta === 0 ? base.h : wrapHue(base.h + hueDelta);
  return gamutClamp(targetL, targetC, h);
}
function nearestPaletteStep(lightnessCurve, baseL) {
  let best = 0;
  let bestD = Infinity;
  for (let i = 0; i < PALETTE_STEPS.length; i++) {
    const d = Math.abs(sampleCurve(lightnessCurve, stepIndexToX(i)) - baseL * 100);
    if (d < bestD) {
      bestD = d;
      best = i;
    }
  }
  return best;
}
function setCurveAnchor(curve, x, y, smooth = false) {
  if (smooth && curve.length === 2) {
    const [p0, p2] = curve;
    const mid = { x, y, inDx: 0, inDy: 0, outDx: 0, outDy: 0 };
    if (Math.abs(p0.x - x) < 0.5) {
      return {
        curve: [tangentAnchor(x, y, null, p2), tangentAnchor(p2.x, p2.y, mid, null)],
        displacedY: p0.y,
        priorEndpoints: [p0, p2]
      };
    }
    if (Math.abs(p2.x - x) < 0.5) {
      return {
        curve: [tangentAnchor(p0.x, p0.y, null, mid), tangentAnchor(x, y, p0, null)],
        displacedY: p2.y,
        priorEndpoints: [p0, p2]
      };
    }
    return {
      curve: [
        tangentAnchor(p0.x, p0.y, null, mid),
        tangentAnchor(x, y, p0, p2),
        tangentAnchor(p2.x, p2.y, mid, null)
      ],
      priorEndpoints: [p0, p2]
    };
  }
  const existing = curve.findIndex((a) => Math.abs(a.x - x) < 0.5);
  if (existing >= 0) {
    const displacedY = curve[existing].y;
    return { curve: curve.map((a, i) => i === existing ? { ...a, x, y } : a), displacedY };
  }
  let insertAt = curve.findIndex((a) => a.x > x);
  if (insertAt < 0) insertAt = curve.length;
  const prev = curve[insertAt - 1] ?? null;
  const next = curve[insertAt] ?? null;
  const out = [...curve];
  if (prev && next) {
    const span = next.x - prev.x;
    out[insertAt - 1] = scaleOutHandle(prev, (x - prev.x) / span);
    out[insertAt] = scaleInHandle(next, (next.x - x) / span);
  }
  out.splice(insertAt, 0, fitBetween(tangentAnchor(x, y, prev, next), out[insertAt - 1] ?? null, out[insertAt] ?? null));
  return { curve: out };
}
var scaleOutHandle = (a, k) => ({ ...a, outDx: a.outDx * k, outDy: a.outDy * k });
var scaleInHandle = (a, k) => ({ ...a, inDx: a.inDx * k, inDy: a.inDy * k });
function fitBetween(a, prev, next) {
  let out = a;
  if (prev) {
    const room = a.x - (prev.x + prev.outDx);
    if (room < -out.inDx) out = scaleInHandle(out, room <= 0 ? 0 : room / -out.inDx);
  }
  if (next) {
    const room = next.x + next.inDx - a.x;
    if (room < out.outDx) out = scaleOutHandle(out, room <= 0 ? 0 : room / out.outDx);
  }
  return out;
}
function liftCurveAnchor(curve, x, displacedY, priorEndpoints) {
  if (priorEndpoints) return priorEndpoints;
  const idx = curve.findIndex((a) => Math.abs(a.x - x) < 0.5);
  if (idx < 0) return curve;
  if (displacedY !== void 0) return curve.map((a, i) => i === idx ? { ...a, y: displacedY } : a);
  if (idx === 0 || idx === curve.length - 1) return curve;
  const out = curve.filter((_, i) => i !== idx);
  const prev = curve[idx - 1];
  const next = curve[idx + 1];
  if (prev && next) {
    const span = next.x - prev.x;
    out[idx - 1] = scaleOutHandle(prev, span / (curve[idx].x - prev.x));
    out[idx] = scaleInHandle(next, span / (next.x - curve[idx].x));
  }
  return out;
}
function syncBaseAnchor(cfg) {
  if (cfg.anchorToBase === false) return;
  const prev = cfg.anchorPlacement;
  const fresh = prev === void 0;
  let lCurve = cfg.lightnessCurve;
  let sCurve = cfg.saturationCurve;
  let hCurve = cfg.hueCurve;
  if (prev) {
    const prevX = stepIndexToX(prev.step);
    lCurve = liftCurveAnchor(lCurve, prevX, prev.displacedL);
    sCurve = liftCurveAnchor(sCurve, prevX, prev.displacedS);
    if (hCurve) hCurve = liftCurveAnchor(hCurve, prevX, prev.displacedH);
  }
  const step = nearestPaletteStep(lCurve, cfg.baseColor.l);
  const x = stepIndexToX(step);
  const l = setCurveAnchor(lCurve, x, cfg.baseColor.l * 100, fresh);
  const s = setCurveAnchor(sCurve, x, 100, fresh);
  cfg.lightnessCurve = l.curve;
  cfg.saturationCurve = s.curve;
  const h = hCurve ? setCurveAnchor(hCurve, x, 0, fresh) : void 0;
  if (h) cfg.hueCurve = h.curve;
  cfg.anchorPlacement = {
    step,
    displacedL: l.displacedY,
    displacedS: s.displacedY,
    displacedH: h?.displacedY,
    priorLightnessEndpoints: prev?.priorLightnessEndpoints ?? l.priorEndpoints,
    priorSaturationEndpoints: prev?.priorSaturationEndpoints ?? s.priorEndpoints,
    // No else-branch reading `prev?.priorHueEndpoints`: that could only fire
    // if a placed hue curve later went absent, which RJC 7 (reset never
    // deletes) never lets happen.
    priorHueEndpoints: h ? prev?.priorHueEndpoints ?? h.priorEndpoints : void 0
  };
}
function computeDerivedOklch(step, base, scaleTitle, scaleCurves, curveOffset) {
  const scale = SCALES.find((s) => s.title === scaleTitle);
  const xPos = scaleStepToX(step, scale);
  const defs = defaultScaleCurves[scaleTitle];
  const lCurve = scaleCurves[scaleTitle]?.lightness ?? defs.lightness();
  const sCurve = scaleCurves[scaleTitle]?.saturation ?? defs.saturation();
  const hCurve = scaleCurves[scaleTitle]?.hue;
  const lOff = curveOffset[`${scaleTitle}-lightness`] ?? 0;
  const sOff = curveOffset[`${scaleTitle}-saturation`] ?? 0;
  const hOff = curveOffset[`${scaleTitle}-hue`] ?? 0;
  const { l: baseL, c: baseC, h: baseH } = base;
  let targetL;
  if (scale.isText) {
    const lMul = Math.max(0, Math.min(2, (sampleCurve(lCurve, xPos) + lOff) / 100));
    targetL = Math.max(0, Math.min(1, baseL * lMul));
  } else {
    targetL = Math.max(0, Math.min(100, sampleCurve(lCurve, xPos) + lOff)) / 100;
  }
  const satMul = Math.max(0, Math.min(2, (sampleCurve(sCurve, xPos) + sOff) / 100));
  const targetC = baseC * satMul;
  const hueDelta = (hCurve ? sampleCurve(hCurve, xPos) : 0) + hOff;
  const targetH = hueDelta === 0 ? baseH : wrapHue(baseH + hueDelta);
  return gamutClamp(targetL, targetC, targetH);
}
function scaleToCssVar(scaleTitle, stepName, cssNamespace) {
  if (cssNamespace === null) return null;
  if (scaleTitle === "Surfaces") {
    const suffix = stepName === "default" ? "" : `-${stepName}`;
    return cssNamespace === "neutral" ? `--surface-neutral${suffix}` : `--surface-${cssNamespace}${suffix}`;
  }
  if (scaleTitle === "Borders") {
    const suffix = stepName === "default" ? "" : `-${stepName}`;
    return cssNamespace === "neutral" ? `--border-neutral${suffix}` : `--border-${cssNamespace}${suffix}`;
  }
  if (scaleTitle === "Text") {
    if (cssNamespace === "neutral") return `--text-${stepName}`;
    return stepName === "primary" ? `--text-${cssNamespace}` : `--text-${cssNamespace}-${stepName}`;
  }
  return null;
}
function derivePaletteValues(spec, config) {
  const out = {};
  if (!config) return out;
  const baseColor = config.baseColor ?? spec.initialColor;
  const overrides = config.overrides ?? {};
  const curveOffset = config.curveOffset ?? {};
  const scaleCurves = config.scaleCurves ?? {};
  const lightnessCurve = config.lightnessCurve ?? DEFAULT_PALETTE_LIGHTNESS();
  const saturationCurve = config.saturationCurve ?? DEFAULT_PALETTE_SATURATION();
  PALETTE_STEPS.forEach((ps, index) => {
    const k = paletteStepKey(ps.label);
    const value = k in overrides ? { kind: "color", ...overrides[k] } : { kind: "color", ...computePaletteOklch(index, baseColor, lightnessCurve, saturationCurve, curveOffset, config.hueCurve) };
    out[`--color-${spec.cssNamespace}-${ps.label}`] = value;
  });
  for (const scale of SCALES) {
    for (const step of scale.steps) {
      const k = stepKey(scale.title, step.name);
      const value = k in overrides ? { kind: "color", ...overrides[k] } : { kind: "color", ...computeDerivedOklch(step, baseColor, scale.title, scaleCurves, curveOffset) };
      const varName = scaleToCssVar(scale.title, step.name, spec.cssNamespace);
      if (varName) out[varName] = value;
    }
  }
  const textPrimary = out["--text-primary"];
  if (textPrimary?.kind === "color") {
    const mirroredL = Math.max(BW_GUARD_MIN_L, Math.min(BW_GUARD_MAX_L, 1 - textPrimary.l));
    out["--text-inverted"] = { kind: "color", ...gamutClamp(mirroredL, textPrimary.c, textPrimary.h) };
  }
  if (spec.emptySelector) {
    const emptyMode = config.emptyMode ?? "solid";
    const gradientStyle = config.gradientStyle ?? "linear";
    const gradientAngle = config.gradientAngle ?? 180;
    const gradientReverse = config.gradientReverse ?? false;
    const gradientSize = config.gradientSize ?? "page";
    const gradientStops = config.gradientStops ?? [
      { position: 0, paletteLabel: "800" },
      { position: 100, paletteLabel: "950" }
    ];
    if (emptyMode === "solid") {
      out["--page-bg"] = { kind: "color", ...baseColor };
      out["--page-bg-attachment"] = { kind: "raw", css: "scroll" };
    } else {
      const sortedStops = [...gradientStops].sort(
        (a, b) => gradientReverse ? b.position - a.position : a.position - b.position
      );
      const stopsCss = sortedStops.map((s) => {
        const stopValue = out[`--color-${spec.cssNamespace}-${s.paletteLabel}`];
        const css = stopValue ? serializeDerivedValue(stopValue) : "oklch(0 0 0)";
        return `${css} ${s.position}%`;
      }).join(", ");
      let gradient;
      switch (gradientStyle) {
        case "radial":
          gradient = `radial-gradient(circle, ${stopsCss})`;
          break;
        case "conic":
          gradient = `conic-gradient(from ${gradientAngle}deg, ${stopsCss})`;
          break;
        default:
          gradient = `linear-gradient(${gradientAngle}deg, ${stopsCss})`;
      }
      out["--page-bg"] = { kind: "raw", css: gradient };
      out["--page-bg-attachment"] = { kind: "raw", css: gradientSize === "window" ? "fixed" : "scroll" };
    }
  }
  return out;
}
function palettesToValues(palettes) {
  const out = {};
  for (const spec of PALETTE_SPECS) {
    Object.assign(out, derivePaletteValues(spec, palettes[spec.label]));
  }
  return out;
}
function palettesToVars(palettes) {
  const out = {};
  for (const [k, v] of Object.entries(palettesToValues(palettes))) {
    out[k] = serializeDerivedValue(v);
  }
  return out;
}

// src/editor/core/themes/parsers/colorOpacity.ts
function formatColorOpacity(name, opacity) {
  return `color-mix(in srgb, var(${name}) ${opacity}%, transparent)`;
}

// src/editor/core/themes/parsers/gradient.ts
var DIRECTION_ANGLES = {
  "to top": 0,
  "to top right": 45,
  "to right": 90,
  "to bottom right": 135,
  "to bottom": 180,
  "to bottom left": 225,
  "to left": 270,
  "to top left": 315
};
var RADIAL_BASE_PX = 100;
function formatStopColor(s) {
  const opacity = s.opacity ?? 100;
  if (s.color.startsWith("--")) {
    return opacity >= 100 ? `var(${s.color})` : formatColorOpacity(s.color, opacity);
  }
  return opacity >= 100 ? s.color : `color-mix(in srgb, ${s.color} ${opacity}%, transparent)`;
}
function formatGradientStops(stops) {
  return stops.map((s) => `${formatStopColor(s)} ${s.position}%`).join(", ");
}
function formatRadialShape(v) {
  const ax = v.aspectX ?? 1;
  const ay = v.aspectY ?? 1;
  if (ax === 1 && ay === 1) {
    return v.radius && v.radius > 0 ? `circle ${v.radius}px` : "circle";
  }
  const base = v.radius && v.radius > 0 ? v.radius : RADIAL_BASE_PX;
  return `ellipse ${(base * ax).toFixed(2)}px ${(base * ay).toFixed(2)}px`;
}
function formatGradientValue(v) {
  if (v.type === "none") return "transparent";
  if (v.type === "solid") {
    const first = v.stops[0];
    return first ? formatStopColor(first) : "transparent";
  }
  const stops = formatGradientStops(v.stops);
  if (v.type === "linear") {
    return `linear-gradient(${v.direction ?? `${v.angle}deg`}, ${stops})`;
  }
  return `radial-gradient(${formatRadialShape(v)} at ${v.centerX ?? 50}% 50%, ${stops})`;
}
var NUM = String.raw`-?\d+(?:\.\d+)?`;
var HEADING = String.raw`${NUM}deg|to\s+\w+(?:\s+\w+)?`;
var LINEAR_RE = new RegExp(String.raw`^linear-gradient\(\s*(${HEADING})\s*,\s*(.+)\)$`, "i");
var DEG_RE = new RegExp(String.raw`^(${NUM})deg$`, "i");
var RADIAL_RE = new RegExp(
  String.raw`^radial-gradient\(\s*(circle|circle\s+${NUM}px|ellipse\s+${NUM}px\s+${NUM}px)\s+at\s+(${NUM})%\s+50%\s*,\s*(.+)\)$`,
  "i"
);
var STOP_RE = new RegExp(String.raw`^(.*?)\s+(${NUM})%$`);
var CIRCLE_RADIUS_RE = new RegExp(String.raw`^circle\s+(${NUM})px$`, "i");
var ELLIPSE_RE = new RegExp(String.raw`^ellipse\s+(${NUM})px\s+(${NUM})px$`, "i");

// src/editor/core/themes/slices/gradients.ts
function makeDefaultGradients() {
  return [
    {
      variable: "--gradient-1",
      type: "linear",
      angle: DIRECTION_ANGLES["to right"],
      direction: "to right",
      stops: [
        { position: 0, color: "--color-brand-500" },
        { position: 100, color: "--color-accent-500" }
      ]
    },
    {
      variable: "--gradient-2",
      type: "linear",
      angle: 135,
      stops: [
        { position: 0, color: "--color-brand-500" },
        { position: 100, color: "--color-special-500" }
      ]
    },
    {
      variable: "--gradient-3",
      type: "linear",
      angle: DIRECTION_ANGLES["to right"],
      direction: "to right",
      stops: [
        { position: 0, color: "--color-success-500" },
        { position: 100, color: "--color-info-500" }
      ]
    },
    {
      variable: "--gradient-4",
      type: "linear",
      angle: 45,
      stops: [
        { position: 0, color: "--color-danger-500" },
        { position: 100, color: "--color-warning-500" }
      ]
    }
  ];
}

// src/editor/core/themes/parsers/shadow.ts
var SHADOW_VAR_NAMES = [
  "--shadow-sm",
  "--shadow-md",
  "--shadow-lg",
  "--shadow-xl",
  "--shadow-2xl"
];
function computeAngleDistance(x, y) {
  const distance = Math.round(Math.sqrt(x * x + y * y));
  if (distance === 0) return { angle: 135, distance: 0 };
  let angle = Math.atan2(y, -x) * (180 / Math.PI);
  if (angle < 0) angle += 360;
  return { angle: Math.round(angle), distance };
}
function shadowTokenCss(t) {
  const spread = t.spread ? `${t.spread}px ` : "";
  return `${t.x}px ${t.y}px ${t.blur}px ${spread}hsla(${t.hue}, ${t.saturation}%, ${t.lightness}%, ${t.opacity})`;
}
function parseShadowCss(variable, raw) {
  const m = raw.trim().match(/^(-?\d+)px\s+(-?\d+)px\s+(\d+)px\s+(?:(-?\d+)px\s+)?hsla\(([\d.]+),\s*([\d.]+)%,\s*([\d.]+)%,\s*([\d.]+)\)$/);
  if (!m) return null;
  const x = parseInt(m[1], 10);
  const y = parseInt(m[2], 10);
  const blur = parseInt(m[3], 10);
  const spread = m[4] === void 0 ? 0 : parseInt(m[4], 10);
  const hue = Math.round(parseFloat(m[5]));
  const saturation = Math.round(parseFloat(m[6]));
  const lightness = Math.round(parseFloat(m[7]));
  const opacity = parseFloat(m[8]);
  const { angle, distance } = computeAngleDistance(x, y);
  return { variable, x, y, blur, spread, opacity, hue, saturation, lightness, angle, distance };
}

// src/editor/core/palettes/contrast.ts
var AA_BODY = 4.5;
var AA_LARGE = 3;
function linearizeChannel(v8) {
  const s = v8 / 255;
  return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
}
function relativeLuminance(hex) {
  const r = linearizeChannel(parseInt(hex.slice(1, 3), 16));
  const g = linearizeChannel(parseInt(hex.slice(3, 5), 16));
  const b = linearizeChannel(parseInt(hex.slice(5, 7), 16));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function contrastRatio(a, b) {
  const la = relativeLuminance(a);
  const lb = relativeLuminance(b);
  const hi = Math.max(la, lb);
  const lo = Math.min(la, lb);
  return (hi + 0.05) / (lo + 0.05);
}
function findLForContrast(opts) {
  const { against, ratio, direction, c, h } = opts;
  const margin = opts.margin ?? 0.05;
  const lMin = opts.lMin ?? 0;
  const lMax = opts.lMax ?? 1;
  const target = ratio + margin;
  const againstL = hexToOklch(against).l;
  const evalAt = (l2, cc) => {
    const g = gamutClamp(l2, cc, h);
    const hex2 = oklchToHex(g.l, g.c, g.h);
    return { hex: hex2, chroma: g.c, ratio: contrastRatio(hex2, against) };
  };
  const solveAtChroma = (cc) => {
    const lighter = direction === "lighter";
    const lo0 = lighter ? Math.max(lMin, againstL) : lMin;
    const hi0 = lighter ? lMax : Math.min(lMax, againstL);
    if (lo0 >= hi0) return null;
    const extreme = lighter ? hi0 : lo0;
    if (evalAt(extreme, cc).ratio < target) return null;
    let lo = lo0;
    let hi = hi0;
    for (let i = 0; i < 24; i++) {
      const mid = (lo + hi) / 2;
      const meets = evalAt(mid, cc).ratio >= target;
      if (lighter ? meets : !meets) hi = mid;
      else lo = mid;
    }
    const at = lighter ? hi : lo;
    const e = evalAt(at, cc);
    return { l: at, hex: e.hex, chroma: e.chroma };
  };
  let sol = solveAtChroma(c);
  if (!sol) {
    if (!solveAtChroma(0)) {
      const extremeL = direction === "lighter" ? lMax : lMin;
      const e = evalAt(extremeL, 0);
      return { l: extremeL, c: 0, hex: e.hex };
    }
    let lo = 0;
    let hi = c;
    for (let i = 0; i < 24; i++) {
      const mid = (lo + hi) / 2;
      if (solveAtChroma(mid)) lo = mid;
      else hi = mid;
    }
    sol = solveAtChroma(lo);
  }
  let { l, hex, chroma } = sol;
  const step = direction === "lighter" ? 4e-3 : -4e-3;
  for (let k = 0; k < 12 && contrastRatio(hex, against) < ratio; k++) {
    l = Math.min(lMax, Math.max(lMin, l + step));
    const g = gamutClamp(l, chroma, h);
    l = g.l;
    chroma = g.c;
    hex = oklchToHex(g.l, g.c, g.h);
  }
  return { l, c: chroma, hex };
}

// src/editor/ui/palette/paletteMath.ts
var DEFAULT_NEUTRAL_LIGHTNESS = () => resmoothAutoCurve([makeAnchor(0, 92), makeAnchor(100, 3)]);
function defaultPaletteConfig(opts) {
  const cfg = {
    baseColor: opts.baseColor,
    lightnessCurve: opts.neutral ? DEFAULT_NEUTRAL_LIGHTNESS() : DEFAULT_PALETTE_LIGHTNESS(),
    saturationCurve: DEFAULT_PALETTE_SATURATION(),
    scaleCurves: defaultScaleCurvesObject(opts.scheme ?? "dark"),
    curveOffset: { lightness: 0, saturation: 0 },
    overrides: {},
    snappedScales: [],
    anchorToBase: true
  };
  syncBaseAnchor(cfg);
  return cfg;
}
function defaultScaleCurvesObject(scheme = "dark") {
  const defs = scaleCurveDefaults(scheme);
  return {
    Surfaces: { lightness: defs.Surfaces.lightness(), saturation: defs.Surfaces.saturation() },
    Borders: { lightness: defs.Borders.lightness(), saturation: defs.Borders.saturation() },
    Text: { lightness: defs.Text.lightness(), saturation: defs.Text.saturation() }
  };
}

// src/editor/core/themes/buildColors.ts
var HEX_RE = /^#[0-9a-f]{6}$/i;
var HARMONY_MODES = [
  "complementary",
  "split-complementary",
  "triadic",
  "tetradic",
  "compound",
  "square",
  "analogous",
  "monochromatic",
  "custom"
];
var TEXT_SCALE = SCALES.find((s) => s.title === "Text");
var SURFACE_SCALE = SCALES.find((s) => s.title === "Surfaces");
var NEUTRAL_TEXT_FLOORS = [
  ["primary", AA_BODY, 7],
  ["secondary", AA_BODY, 5.5],
  ["tertiary", AA_LARGE, 3.5]
];
var FUNCTIONAL_TEXT_TARGET = 3.5;
var FUNCTIONAL_TEXT_LABELS = PALETTE_SPECS.filter((s) => s.label !== "Neutral" && s.label !== "Canvas").map((s) => s.label);
var norm = (h) => h >= 0 && h < 360 ? h : (h % 360 + 360) % 360;
function parseBaseColor(label, raw, problems) {
  if (typeof raw === "string") {
    if (!HEX_RE.test(raw.trim())) {
      problems.push(`${label}: "${raw}" is not a #rrggbb hex color`);
      return null;
    }
    return hexToOklch(raw.trim());
  }
  const { l, c, h } = raw ?? {};
  if (typeof l !== "number" || l <= 0 || l >= 1) problems.push(`${label}: l must be in (0, 1), got ${l}`);
  if (typeof c !== "number" || c < 0 || c > 0.4) problems.push(`${label}: c must be in [0, 0.4], got ${c}`);
  if (typeof h !== "number" || !Number.isFinite(h)) problems.push(`${label}: h must be a finite number, got ${h}`);
  if (problems.length > 0) return null;
  return { l, c, h: norm(h) };
}
function validateInput(input) {
  const problems = [];
  if (input.scheme !== "light" && input.scheme !== "dark") {
    problems.push(`scheme: must be "light" or "dark", got ${JSON.stringify(input.scheme)}`);
  }
  if (input.harmony && !HARMONY_MODES.includes(input.harmony.mode)) {
    problems.push(`harmony.mode: unknown mode ${JSON.stringify(input.harmony.mode)}`);
  }
  if (input.canvasGradient !== void 0 && typeof input.canvasGradient !== "boolean") {
    problems.push(`canvasGradient: must be a boolean, got ${JSON.stringify(input.canvasGradient)}`);
  }
  const baseColors = {};
  const given = input.baseColors ?? {};
  for (const spec of PALETTE_SPECS) {
    if (!(spec.label in given)) {
      problems.push(`baseColors.${spec.label}: missing`);
      continue;
    }
    const parsed = parseBaseColor(spec.label, given[spec.label], problems);
    if (parsed) baseColors[spec.label] = parsed;
  }
  const known = new Set(PALETTE_SPECS.map((s) => s.label));
  for (const label of Object.keys(given)) {
    if (!known.has(label)) problems.push(`baseColors.${label}: unknown palette (expected ${[...known].join(", ")})`);
  }
  if (problems.length > 0) {
    throw new Error(`Invalid base color file:
  ${problems.join("\n  ")}`);
  }
  return baseColors;
}
function checkDefs() {
  const defs = [];
  for (const [stepName, floor, target] of NEUTRAL_TEXT_FLOORS) {
    defs.push({
      paletteLabel: "Neutral",
      step: TEXT_SCALE.steps.find((s) => s.name === stepName),
      textVar: scaleToCssVar("Text", stepName, "neutral"),
      floor,
      target
    });
  }
  const primary = TEXT_SCALE.steps.find((s) => s.name === "primary");
  for (const label of FUNCTIONAL_TEXT_LABELS) {
    const ns = PALETTE_SPECS.find((s) => s.label === label).cssNamespace;
    defs.push({
      paletteLabel: label,
      step: primary,
      textVar: scaleToCssVar("Text", "primary", ns),
      floor: AA_LARGE,
      target: FUNCTIONAL_TEXT_TARGET
    });
  }
  return defs;
}
function surfaceVars() {
  return [
    ...SURFACE_SCALE.steps.map((s) => scaleToCssVar("Surfaces", s.name, "neutral")),
    "--page-bg"
  ];
}
function varToHex(value) {
  const parsed = value ? cssColorToOklch(value) : null;
  return parsed ? oklchToHexClamped(parsed.l, parsed.c, parsed.h) : null;
}
function worstSurface(textHex, vars) {
  let against = "";
  let ratio = Infinity;
  for (const surfVar of surfaceVars()) {
    const surfHex = varToHex(vars[surfVar]);
    if (!surfHex) continue;
    const r = contrastRatio(textHex, surfHex);
    if (r < ratio) {
      ratio = r;
      against = surfVar;
    }
  }
  return { against, ratio };
}
function pinTextStep(cfg, step, solved) {
  const x = scaleStepToX(step, TEXT_SCALE);
  const base = cfg.baseColor;
  const yL = Math.max(0, Math.min(200, solved.l / base.l * 100));
  cfg.scaleCurves.Text.lightness = setCurveAnchor(cfg.scaleCurves.Text.lightness, x, yL).curve;
  if (base.c > 0) {
    const yC = Math.max(0, Math.min(200, solved.c / base.c * 100));
    cfg.scaleCurves.Text.saturation = setCurveAnchor(cfg.scaleCurves.Text.saturation, x, yC).curve;
  }
}
var MAX_CORRECTION_ROUNDS = 3;
function runContrastGate(configs, scheme) {
  const defs = checkDefs();
  const direction = scheme === "light" ? "darker" : "lighter";
  const corrected = /* @__PURE__ */ new Set();
  for (let round = 0; round < MAX_CORRECTION_ROUNDS; round++) {
    const vars = palettesToVars(configs);
    let anyFixed = false;
    for (const def of defs) {
      const text = cssColorToOklch(vars[def.textVar] ?? "");
      if (!text) continue;
      const textHex = oklchToHexClamped(text.l, text.c, text.h);
      const worst = worstSurface(textHex, vars);
      if (worst.ratio >= def.floor) continue;
      const cfg = configs[def.paletteLabel];
      const base = cfg.baseColor;
      const solved = findLForContrast({
        against: varToHex(vars[worst.against]) ?? "#000000",
        ratio: def.target,
        direction,
        c: text.c,
        h: base.h,
        lMax: Math.min(1, 2 * base.l)
      });
      pinTextStep(cfg, def.step, solved);
      corrected.add(def.textVar);
      anyFixed = true;
    }
    if (!anyFixed) break;
  }
  const finalVars = palettesToVars(configs);
  const checks = defs.map((def) => {
    const worst = worstSurface(varToHex(finalVars[def.textVar]) ?? "#000000", finalVars);
    return {
      textVar: def.textVar,
      floor: def.floor,
      against: worst.against,
      ratio: worst.ratio,
      pass: worst.ratio >= def.floor,
      corrected: corrected.has(def.textVar)
    };
  });
  const failures = checks.filter((c) => !c.pass).map((c) => {
    const label = defs.find((d) => d.textVar === c.textVar).paletteLabel;
    const hint = scheme === "dark" ? `raise the ${label} base color lightness (derived text tops out at 2\xD7 its L)` : `raise the ${label} base color lightness or reduce its chroma`;
    return `${c.textVar} reaches ${c.ratio.toFixed(2)}:1 vs ${c.against} (floor ${c.floor}:1): ${hint}`;
  });
  return { scheme, checks, failures };
}
var ADJACENT_HUE_MAX = 120;
var hueDist = (a, b) => {
  const d = Math.abs(norm(a) - norm(b));
  return Math.min(d, 360 - d);
};
var linear = (variable, angle, from, to) => ({
  variable,
  type: "linear",
  angle,
  stops: [{ position: 0, color: from }, { position: 100, color: to }]
});
function recipeGradients(baseColors, scheme) {
  return [
    linear("--gradient-1", 90, "--color-brand-400", "--color-brand-700"),
    hueDist(baseColors.Special.h, baseColors.Brand.h) <= ADJACENT_HUE_MAX ? linear("--gradient-2", 135, "--color-special-500", "--color-brand-500") : linear("--gradient-2", 135, "--color-special-400", "--color-special-700"),
    hueDist(baseColors.Brand.h, baseColors.Accent.h) <= ADJACENT_HUE_MAX ? linear("--gradient-3", 90, "--color-brand-500", "--color-accent-500") : linear("--gradient-3", 90, "--color-accent-400", "--color-accent-700"),
    scheme === "dark" ? linear("--gradient-4", 180, "--color-canvas-600", "--color-canvas-900") : linear("--gradient-4", 180, "--color-canvas-200", "--color-canvas-500")
  ];
}
function isStockGradients(gradients) {
  return !gradients || gradients.length === 0 || JSON.stringify(gradients) === JSON.stringify(makeDefaultGradients());
}
function applyCanvasGradient(canvas, scheme) {
  const labels = PALETTE_STEPS.map((s) => s.label);
  const anchor = canvas.anchorPlacement.step;
  const sky = scheme === "dark" ? Math.min(anchor + 2, labels.length - 1) : Math.max(anchor - 2, 0);
  if (sky === anchor) {
    return `skipped: the Canvas base color anchors at the ramp edge (${labels[anchor]}), leaving no room for a sky; commit the canvas further from ${scheme === "dark" ? "black" : "white"}`;
  }
  canvas.emptyMode = "gradient";
  canvas.gradientStyle = "linear";
  canvas.gradientAngle = 180;
  canvas.gradientReverse = false;
  canvas.gradientStops = [
    { position: 0, paletteLabel: labels[sky] },
    { position: 100, paletteLabel: labels[anchor] }
  ];
  canvas.gradientSize = "window";
  return `on, ${labels[sky]} to ${labels[anchor]}`;
}
var STOCK_SHADOW_GEOMETRY = {
  "--shadow-sm": [1, 1, 2],
  "--shadow-md": [3, 3, 6],
  "--shadow-lg": [5, 5, 9],
  "--shadow-xl": [6, 7, 13],
  "--shadow-2xl": [8, 9, 16]
};
var STOCK_SHADOW_COLOR = { spread: 0, hue: 237, saturation: 18, lightness: 3, opacity: 0.9 };
var SHADOW_OPACITY_DEEP = 0.9;
var SHADOW_OPACITY_SOFT = 0.2;
var SHADOW_GROUND_DEEP = 0.5;
var SHADOW_GROUND_SOFT = 0.9;
function shadowOpacityForCanvas(canvasL) {
  const t = (canvasL - SHADOW_GROUND_DEEP) / (SHADOW_GROUND_SOFT - SHADOW_GROUND_DEEP);
  const ramp = Math.max(0, Math.min(1, t));
  const opacity = SHADOW_OPACITY_DEEP + ramp * (SHADOW_OPACITY_SOFT - SHADOW_OPACITY_DEEP);
  return Math.round(opacity * 100) / 100;
}
function shadowVars(carried, canvas) {
  const opacity = shadowOpacityForCanvas(canvas.l);
  const out = {};
  for (const variable of SHADOW_VAR_NAMES) {
    const [x, y, blur] = STOCK_SHADOW_GEOMETRY[variable];
    const base = parseShadowCss(variable, carried[variable] ?? "") ?? { x, y, blur, ...STOCK_SHADOW_COLOR };
    out[variable] = shadowTokenCss({ ...base, opacity });
  }
  return out;
}
function buildColors(input, carry = {}) {
  const baseColors = validateInput(input);
  const configs = {};
  for (const spec of PALETTE_SPECS) {
    configs[spec.label] = defaultPaletteConfig({
      baseColor: baseColors[spec.label],
      neutral: spec.neutral,
      scheme: input.scheme
    });
  }
  const report = runContrastGate(configs, input.scheme);
  const canvasGradient = input.canvasGradient ? applyCanvasGradient(configs.Canvas, input.scheme) : void 0;
  const gradients = isStockGradients(carry.gradients) ? recipeGradients(baseColors, input.scheme) : carry.gradients;
  const harmonyAxes = [
    { hue: norm(baseColors.Brand.h), family: "Brand" },
    { hue: norm(baseColors.Accent.h), family: "Accent" },
    { hue: norm(baseColors.Canvas.h), family: "Canvas" },
    { hue: norm(baseColors.Brand.h + 270), family: null }
  ];
  const owned = new Set(Object.keys(palettesToVars(configs)));
  const cssVariables = Object.fromEntries(
    Object.entries(carry.cssVariables ?? {}).filter(([k]) => !owned.has(k))
  );
  for (const t of gradients) cssVariables[t.variable] = formatGradientValue(t);
  Object.assign(cssVariables, shadowVars(carry.cssVariables ?? {}, baseColors.Canvas));
  return {
    colors: { editorConfigs: configs, harmonyAxes, gradients, cssVariables },
    report: {
      ...report,
      gradients: gradients === carry.gradients ? "carried" : "recipes",
      shadows: `opacity ${shadowOpacityForCanvas(baseColors.Canvas.l)} for a canvas at L ${baseColors.Canvas.l.toFixed(2)}`,
      ...canvasGradient ? { canvasGradient } : {}
    }
  };
}

// src/editor/core/storage/files/versionedFileResourceClient.ts
function sanitizeFileName(name) {
  return name.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^a-z0-9\-_]/g, "").replace(/-+/g, "-").replace(/^[-_]+|-+$/g, "") || "unnamed";
}

// vite-plugin/files/dataPaths.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var DEFAULT_DATA_DIR = "src/live-tokens/data";
var TEST_DATA_DIR_ENV = "LIVE_TOKENS_TEST_DATA_DIR";
function testDataDir() {
  const raw = process.env[TEST_DATA_DIR_ENV];
  return raw && raw.trim() !== "" ? import_path.default.resolve(raw.trim()) : void 0;
}
var KNOWN_CONFIG_KEYS = /* @__PURE__ */ new Set([
  "dataDir",
  "colorsAndTypeDir",
  "componentConfigsDir",
  "themesDir",
  "manifestsDir",
  "tokensCssPath",
  "componentDirs",
  "checks"
]);
var cached = null;
function readLiveTokensConfig() {
  if (cached) return cached;
  try {
    const configPath = import_path.default.resolve("live-tokens.config.json");
    if (!import_fs.default.existsSync(configPath)) return cached = {};
    const parsed = JSON.parse(import_fs.default.readFileSync(configPath, "utf-8"));
    if (!parsed || typeof parsed !== "object") return cached = {};
    const unknown = Object.keys(parsed).filter(
      (k) => k !== "$schema" && !KNOWN_CONFIG_KEYS.has(k)
    );
    if (unknown.length > 0) {
      console.warn(
        `[live-tokens] Unknown key(s) in live-tokens.config.json: ${unknown.join(", ")}. Known keys: ${Array.from(KNOWN_CONFIG_KEYS).join(", ")}.`
      );
    }
    cached = parsed;
    return cached;
  } catch {
    return cached = {};
  }
}
function resolveDataDirs(opts = {}) {
  const isolated = testDataDir();
  if (isolated) {
    return {
      dataDir: isolated,
      colorsAndTypeDir: import_path.default.join(isolated, "colors-and-type"),
      componentConfigsDir: import_path.default.join(isolated, "component-configs"),
      themesDir: import_path.default.join(isolated, "themes"),
      sketchStylesDir: import_path.default.join(isolated, "sketch-styles")
    };
  }
  const fileConfig = readLiveTokensConfig();
  const dataDirRaw = opts.dataDir ?? fileConfig.dataDir ?? DEFAULT_DATA_DIR;
  const dataDir = import_path.default.resolve(dataDirRaw);
  const sub = (name) => import_path.default.resolve(dataDir, name);
  return {
    dataDir,
    colorsAndTypeDir: opts.colorsAndTypeDir ? import_path.default.resolve(opts.colorsAndTypeDir) : fileConfig.colorsAndTypeDir ? import_path.default.resolve(fileConfig.colorsAndTypeDir) : sub("colors-and-type"),
    componentConfigsDir: opts.componentConfigsDir ? import_path.default.resolve(opts.componentConfigsDir) : fileConfig.componentConfigsDir ? import_path.default.resolve(fileConfig.componentConfigsDir) : sub("component-configs"),
    themesDir: opts.themesDir ? import_path.default.resolve(opts.themesDir) : fileConfig.themesDir ? import_path.default.resolve(fileConfig.themesDir) : sub("themes"),
    sketchStylesDir: sub("sketch-styles"),
    legacyManifestsDir: fileConfig.manifestsDir ? import_path.default.resolve(fileConfig.manifestsDir) : void 0
  };
}

// src/editor/core/themes/migrations/2026-04-24-legacy-keys-and-bg-to-canvas.ts
var LEGACY_KEY_RENAMES = {
  "--empty": "--page-bg",
  "--empty-attachment": "--page-bg-attachment",
  // Orphan exports dropped from tokens.css; no new home — silently discard.
  "--border-neutral": null,
  // Shadow cleanup: these five tokens were removed (low/zero consumers,
  // aesthetic drift). Dialog migrated onto --shadow-2xl; focus rings moved
  // to their own --ring-focus-* namespace, which themes don't carry by
  // default — tokens.css provides the canonical values.
  "--shadow-app": null,
  "--shadow-card": null,
  "--shadow-overlay": null,
  "--shadow-focus": null,
  "--shadow-glow-green": null
};
var BG_TO_CANVAS_PREFIXES = ["--color-bg-", "--surface-bg", "--border-bg", "--text-bg"];
function migrateBgToCanvas(rawVars) {
  for (const oldKey of Object.keys(rawVars)) {
    for (const prefix of BG_TO_CANVAS_PREFIXES) {
      if (!oldKey.startsWith(prefix)) continue;
      const suffix = oldKey.slice(prefix.length);
      if (suffix && !suffix.startsWith("-")) continue;
      const newKey = prefix.replace("-bg", "-canvas") + suffix;
      if (newKey === oldKey) continue;
      const value = rawVars[oldKey];
      delete rawVars[oldKey];
      if (!(newKey in rawVars)) rawVars[newKey] = value;
      break;
    }
  }
}
function migrateLegacyKeys(rawVars) {
  for (const [oldKey, newKey] of Object.entries(LEGACY_KEY_RENAMES)) {
    if (!(oldKey in rawVars)) continue;
    const value = rawVars[oldKey];
    delete rawVars[oldKey];
    if (newKey && !(newKey in rawVars)) rawVars[newKey] = value;
  }
  migrateBgToCanvas(rawVars);
}
var colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas = {
  id: "2026-04-24-legacy-keys-and-bg-to-canvas",
  fromVersion: 0,
  toVersion: 1,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = { ...rawVars };
    migrateLegacyKeys(out);
    return out;
  }
};

// src/editor/core/themes/migrations/2026-04-24-component-prefix-and-suffix-renames.ts
var COMPONENT_PREFIX_RENAMES = {
  "--segment-": "--segmentedcontrol-",
  "--collapsible-": "--collapsiblesection-",
  "--progress-": "--progressbar-",
  "--section-divider-": "--sectiondivider-",
  "--radio-": "--radiobutton-",
  "--inline-edit-": "--inlineeditactions-"
};
var COMPONENT_SUFFIX_RENAMES = {
  progressbar: [["-track-bg", "-track-surface"]],
  inlineeditactions: [
    ["-bg-hover", "-hover-surface"],
    ["-bg", "-surface"]
  ]
};
var componentMigration_2026_04_24_prefixAndSuffixRenames = {
  id: "2026-04-24-component-prefix-and-suffix-renames",
  fromVersion: 0,
  toVersion: 1,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const component = meta.component ?? "";
    const out = {};
    const suffixRules = COMPONENT_SUFFIX_RENAMES[component] ?? [];
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key === "--detail-nav-bg") key = "--detailnav-surface";
      for (const [oldPrefix, newPrefix] of Object.entries(COMPONENT_PREFIX_RENAMES)) {
        if (key.startsWith(oldPrefix)) {
          key = newPrefix + key.slice(oldPrefix.length);
          break;
        }
      }
      for (const [oldSuffix, newSuffix] of suffixRules) {
        if (key.endsWith(oldSuffix)) {
          key = key.slice(0, -oldSuffix.length) + newSuffix;
          break;
        }
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-04-27-segmentedcontrol-disabled-flatten.ts
var OPTION_DISABLED_PREFIX = "--segmentedcontrol-option-disabled-";
var DISABLED_PREFIX = "--segmentedcontrol-disabled-";
var SELECTED_DISABLED_PREFIX = "--segmentedcontrol-selected-disabled-";
var SELECTED_HOVER_PREFIX = "--segmentedcontrol-selected-hover-";
var componentMigration_2026_04_27_segmentedcontrolDisabledFlatten = {
  id: "2026-04-27-segmentedcontrol-disabled-flatten",
  fromVersion: 1,
  toVersion: 2,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key.startsWith(SELECTED_DISABLED_PREFIX)) continue;
      if (key.startsWith(SELECTED_HOVER_PREFIX)) continue;
      if (key.startsWith(OPTION_DISABLED_PREFIX)) {
        key = DISABLED_PREFIX + key.slice(OPTION_DISABLED_PREFIX.length);
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-08-collapsiblesection-variant-namespace.ts
var PREFIX = "--collapsiblesection-";
var STATE_NAMES = /* @__PURE__ */ new Set(["default", "hover", "active", "expanded"]);
var componentMigration_2026_05_08_collapsiblesectionVariantNamespace = {
  id: "2026-05-08-collapsiblesection-variant-namespace",
  fromVersion: 2,
  toVersion: 3,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "collapsiblesection") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      let key = oldKey;
      if (key.startsWith(PREFIX)) {
        const tail = key.slice(PREFIX.length);
        const firstSegment = tail.split("-", 1)[0];
        if (STATE_NAMES.has(firstSegment)) {
          key = `${PREFIX}container-${tail}`;
        }
      }
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-08-collapsiblesection-frame-and-cleanup.ts
var PFX = "--collapsiblesection-";
var componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup = {
  id: "2026-05-08-collapsiblesection-frame-and-cleanup",
  fromVersion: 3,
  toVersion: 4,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "collapsiblesection") return { ...rawVars };
    const out = {};
    for (const prop of ["surface", "border", "border-width", "radius"]) {
      const src = `${PFX}container-default-${prop}`;
      if (src in rawVars) {
        out[`${PFX}container-frame-${prop}`] = rawVars[src];
      }
    }
    for (const [key, value] of Object.entries(rawVars)) {
      if (/^--collapsiblesection-chromeless-(default|hover|active)-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-container-(hover|active)-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-container-default-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-divider-(default|hover|active)-radius$/.test(key)) continue;
      if (/^--collapsiblesection-(chromeless|divider|container)-expanded-(border|border-width|radius)$/.test(key)) continue;
      if (/^--collapsiblesection-(chromeless|divider)-expanded-surface$/.test(key)) continue;
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-10-sectiondivider-gradient-stops.ts
var PFX2 = "--sectiondivider-";
var VARIANTS = ["canvas", "neutral", "alternate", "primary", "accent", "special"];
var OLD_STOP_RE = /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-gradient-stop-\d+$/;
var componentMigration_2026_05_10_sectiondividerGradientStops = {
  id: "2026-05-10-sectiondivider-gradient-stops",
  fromVersion: 4,
  toVersion: 5,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (OLD_STOP_RE.test(key)) continue;
      out[key] = value;
    }
    const setIfMissing = (key, fallback) => {
      if (!(key in out)) out[key] = fallback;
    };
    for (const v of VARIANTS) {
      const old1 = rawVars[`${PFX2}${v}-gradient-stop-1`];
      const old2 = rawVars[`${PFX2}${v}-gradient-stop-2`];
      const old4 = rawVars[`${PFX2}${v}-gradient-stop-4`];
      setIfMissing(`${PFX2}${v}-gradient-angle`, "--gradient-angle-diagonal");
      setIfMissing(`${PFX2}${v}-gradient-stop-1-color`, old1 ?? `--surface-${v}-highest`);
      setIfMissing(`${PFX2}${v}-gradient-stop-1-position`, "--gradient-stop-start");
      setIfMissing(`${PFX2}${v}-gradient-stop-2-color`, old2 ?? `--surface-${v}-higher`);
      setIfMissing(`${PFX2}${v}-gradient-stop-2-position`, "--gradient-stop-mid");
      setIfMissing(`${PFX2}${v}-gradient-stop-3-color`, old4 ?? `--surface-${v}`);
      setIfMissing(`${PFX2}${v}-gradient-stop-3-position`, "--gradient-stop-end");
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-13-primary-to-brand.ts
var PALETTE_STEPS2 = ["100", "200", "300", "400", "500", "600", "700", "800", "850", "900", "950"];
var SURFACE_SUFFIXES = ["lowest", "lower", "low", "high", "higher", "highest"];
var BORDER_SUFFIXES = ["faint", "subtle", "medium", "strong"];
var TEXT_SUFFIXES = ["secondary", "tertiary", "muted", "disabled"];
var RENAME_MAP = (() => {
  const m = {};
  for (const step of PALETTE_STEPS2) m[`--color-primary-${step}`] = `--color-brand-${step}`;
  m["--surface-primary"] = "--surface-brand";
  for (const suf of SURFACE_SUFFIXES) m[`--surface-primary-${suf}`] = `--surface-brand-${suf}`;
  m["--border-primary"] = "--border-brand";
  for (const suf of BORDER_SUFFIXES) m[`--border-primary-${suf}`] = `--border-brand-${suf}`;
  m["--text-primary-color"] = "--text-brand";
  for (const suf of TEXT_SUFFIXES) m[`--text-primary-${suf}`] = `--text-brand-${suf}`;
  return m;
})();
function renameToken(name) {
  return RENAME_MAP[name] ?? name;
}
function renameKeys(rawVars) {
  const out = {};
  for (const [k, v] of Object.entries(rawVars)) {
    out[renameToken(k)] = v;
  }
  return out;
}
function renameKeysAndValues(rawVars) {
  const out = {};
  for (const [k, v] of Object.entries(rawVars)) {
    out[renameToken(k)] = renameToken(v);
  }
  return out;
}
var colorsAndTypeMigration_2026_05_13_primaryToBrand = {
  id: "2026-05-13-primary-to-brand-theme",
  fromVersion: 1,
  toVersion: 2,
  appliesTo: "colors-and-type",
  apply: renameKeys
};
var componentMigration_2026_05_13_primaryToBrand = {
  id: "2026-05-13-primary-to-brand-component",
  fromVersion: 5,
  toVersion: 6,
  appliesTo: "component-config",
  apply: renameKeysAndValues
};

// src/editor/core/themes/migrations/2026-05-19-collapsiblesection-drop-frame-surface.ts
function dropFrameSurface(rawVars, meta) {
  if (meta.component !== "collapsiblesection") return rawVars;
  const { "--collapsiblesection-container-frame-surface": _drop, ...rest } = rawVars;
  return rest;
}
var componentMigration_2026_05_19_collapsiblesectionDropFrameSurface = {
  id: "2026-05-19-collapsiblesection-drop-frame-surface",
  fromVersion: 6,
  toVersion: 7,
  appliesTo: "component-config",
  apply: dropFrameSurface
};

// src/editor/core/themes/migrations/2026-05-19-sectiondivider-rich-gradient.ts
var FLAT_RE = /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-gradient-(angle|stop-[123]-(color|position))$/;
var componentMigration_2026_05_19_sectiondividerRichGradient = {
  id: "2026-05-19-sectiondivider-rich-gradient",
  fromVersion: 7,
  toVersion: 8,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (FLAT_RE.test(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-20-sectiondivider-slim-variants.ts
var VARIANTS2 = ["lg", "md", "sm"];
var SUFFIX_RENAMES = [
  [/-title-border-width$/, "-title-outline-width"],
  [/-title-stroke-color$/, "-title-outline-color"],
  [
    /^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-padding$/,
    "--sectiondivider-$1-spacing"
  ]
];
function renameKeySuffix(key) {
  for (const [re, repl] of SUFFIX_RENAMES) {
    if (re.test(key)) return key.replace(re, repl);
  }
  return key;
}
function splitFamilyKey(key) {
  const m = key.match(/^--sectiondivider-(canvas|neutral|alternate|primary|accent|special)-(.+)$/);
  if (!m) return null;
  return { family: m[1], suffix: m[2] };
}
var componentMigration_2026_05_20_sectiondividerSlimVariants = {
  id: "2026-05-20-sectiondivider-slim-variants",
  fromVersion: 8,
  toVersion: 9,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    const canvasValues = {};
    for (const [rawKey, value] of Object.entries(rawVars)) {
      const key = renameKeySuffix(rawKey);
      const parts = splitFamilyKey(key);
      if (!parts) {
        out[key] = value;
        continue;
      }
      if (parts.family !== "canvas") continue;
      canvasValues[parts.suffix] = value;
    }
    for (const suffix of Object.keys(canvasValues)) {
      for (const v of VARIANTS2) {
        out[`--sectiondivider-${v}-${suffix}`] = canvasValues[suffix];
      }
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-21-sectiondivider-spacing-to-padding.ts
var componentMigration_2026_05_21_sectiondividerSpacingToPadding = {
  id: "2026-05-21-sectiondivider-spacing-to-padding",
  fromVersion: 9,
  toVersion: 10,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const renamed = key.replace(
        /^--sectiondivider-(lg|md|sm)-spacing$/,
        "--sectiondivider-$1-padding"
      );
      out[renamed] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-22-sectiondivider-intrinsics-to-css.ts
var componentMigration_2026_05_22_sectiondividerIntrinsicsToCss = {
  id: "2026-05-22-sectiondivider-intrinsics-to-css",
  fromVersion: 10,
  toVersion: 11,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const VARIANTS4 = ["lg", "md", "sm"];
    const prefix = "--sectiondivider-";
    const dropped = /* @__PURE__ */ new Set();
    for (const v of VARIANTS4) {
      dropped.add(`${prefix}${v}-show-eyebrow`);
      dropped.add(`${prefix}${v}-show-description`);
      dropped.add(`${prefix}${v}-show-hairline`);
      dropped.add(`${prefix}${v}-hairline`);
      dropped.add(`${prefix}${v}-eyebrow-uppercase`);
    }
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (dropped.has(key)) continue;
      out[key] = value;
    }
    for (const v of VARIANTS4) {
      const showEyebrow = rawVars[`${prefix}${v}-show-eyebrow`];
      if (showEyebrow !== void 0) {
        out[`${prefix}${v}-eyebrow-display`] = showEyebrow === "1" ? "block" : "none";
      }
      const showDesc = rawVars[`${prefix}${v}-show-description`];
      if (showDesc !== void 0) {
        out[`${prefix}${v}-description-display`] = showDesc === "1" ? "flex" : "none";
      }
      const showHair = rawVars[`${prefix}${v}-show-hairline`];
      const oldHair = rawVars[`${prefix}${v}-hairline`];
      const oldHairIsPos = typeof oldHair === "string" && oldHair !== "" && oldHair !== "off";
      let newHair;
      if (showHair === "") newHair = "none";
      else if (showHair === "1") newHair = oldHairIsPos ? oldHair : "above-label";
      else if (oldHair !== void 0) newHair = oldHairIsPos ? oldHair : "none";
      if (newHair !== void 0) {
        out[`${prefix}${v}-hairline`] = newHair;
      }
      const upper = rawVars[`${prefix}${v}-eyebrow-uppercase`];
      if (upper !== void 0) {
        out[`${prefix}${v}-eyebrow-text-transform`] = upper === "1" ? "uppercase" : "none";
      }
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-segmentedcontrol-divider-inset.ts
var componentMigration_2026_05_24_segmentedcontrolDividerInset = {
  id: "2026-05-24-segmentedcontrol-divider-inset",
  fromVersion: 11,
  toVersion: 12,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === "--segmentedcontrol-divider-height") continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-promote-state-shared-tokens.ts
var BUTTON_VARIANTS = ["primary", "secondary", "outline", "success", "danger", "warning"];
var BUTTON_STATES = ["hover", "disabled"];
var BUTTON_PROPS = ["padding", "radius", "border-width"];
var buttonDeadKeys = new Set(
  BUTTON_VARIANTS.flatMap(
    (v) => BUTTON_STATES.flatMap(
      (s) => BUTTON_PROPS.map((p) => `--button-${v}-${s}-${p}`)
    )
  )
);
var segmentedcontrolDeadKeys = /* @__PURE__ */ new Set([
  "--segmentedcontrol-selected-icon-size",
  "--segmentedcontrol-option-hover-icon-size",
  "--segmentedcontrol-disabled-icon-size"
]);
var componentMigration_2026_05_24_promoteStateSharedTokens = {
  id: "2026-05-24-promote-state-shared-tokens",
  fromVersion: 12,
  toVersion: 13,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const dead = meta.component === "button" ? buttonDeadKeys : meta.component === "segmentedcontrol" ? segmentedcontrolDeadKeys : null;
    if (!dead) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (dead.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-progressbar-collapse-variants.ts
var PRIMARY_PREFIX = "--progressbar-primary-";
var NEW_PREFIX = "--progressbar-";
var DROP_PREFIXES = [
  "--progressbar-success-",
  "--progressbar-warning-",
  "--progressbar-danger-",
  "--progressbar-info-"
];
var componentMigration_2026_05_24_progressbarCollapseVariants = {
  id: "2026-05-24-progressbar-collapse-variants",
  fromVersion: 13,
  toVersion: 14,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "progressbar") return { ...rawVars };
    const out = {};
    for (const [oldKey, value] of Object.entries(rawVars)) {
      if (DROP_PREFIXES.some((p) => oldKey.startsWith(p))) continue;
      const key = oldKey.startsWith(PRIMARY_PREFIX) ? NEW_PREFIX + oldKey.slice(PRIMARY_PREFIX.length) : oldKey;
      if (!(key in out)) out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-24-collapsiblesection-drop-active-state.ts
function dropActiveState(rawVars, meta) {
  if (meta.component !== "collapsiblesection") return rawVars;
  const re = /^--collapsiblesection-(chromeless|divider|container)-active-/;
  const out = {};
  for (const [key, value] of Object.entries(rawVars)) {
    if (re.test(key)) continue;
    out[key] = value;
  }
  return out;
}
var componentMigration_2026_05_24_collapsiblesectionDropActiveState = {
  id: "2026-05-24-collapsiblesection-drop-active-state",
  fromVersion: 14,
  toVersion: 15,
  appliesTo: "component-config",
  apply: dropActiveState
};

// src/editor/core/themes/migrations/2026-05-25-cornerbadge-flatten-variants.ts
var VARIANTS3 = ["primary", "accent", "neutral", "alternate", "canvas", "special", "success", "warning", "danger", "info"];
var RE = new RegExp(`^--corner-badge-(${VARIANTS3.join("|")})-(.+)$`);
var CURRENT_COLOR_PROPS = /* @__PURE__ */ new Set(["surface", "border", "text"]);
function flattenVariants(rawVars, meta) {
  if (meta.component !== "cornerbadge") return rawVars;
  const out = {};
  const collected = /* @__PURE__ */ new Map();
  for (const [key, value] of Object.entries(rawVars)) {
    const m = key.match(RE);
    if (m) {
      const prop = m[2];
      if (CURRENT_COLOR_PROPS.has(prop)) {
        out[key] = value;
        continue;
      }
      if (!collected.has(prop)) collected.set(prop, value);
      continue;
    }
    out[key] = value;
  }
  for (const [prop, value] of collected) {
    const flatKey = `--corner-badge-${prop}`;
    if (!(flatKey in out)) out[flatKey] = value;
  }
  return out;
}
var componentMigration_2026_05_25_cornerbadgeFlattenVariants = {
  id: "2026-05-25-cornerbadge-flatten-variants",
  fromVersion: 15,
  toVersion: 16,
  appliesTo: "component-config",
  apply: flattenVariants
};

// src/editor/core/themes/migrations/2026-05-26-drop-overlay-extra-stops.ts
var DROPPED_TO_KEPT = {
  "--overlay-lowest": "--overlay-low",
  "--overlay-lower": "--overlay-low",
  "--overlay-higher": "--overlay-high",
  "--overlay-highest": "--overlay-high"
};
var colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops = {
  id: "2026-05-26-drop-overlay-extra-stops-theme",
  fromVersion: 2,
  toVersion: 3,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key in DROPPED_TO_KEPT) continue;
      out[key] = value;
    }
    return out;
  }
};
var componentMigration_2026_05_26_dropOverlayExtraStops = {
  id: "2026-05-26-drop-overlay-extra-stops-component",
  fromVersion: 16,
  toVersion: 17,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[key] = DROPPED_TO_KEPT[value] ?? value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-tabbar-indicator-thickness-to-per-state-width.ts
var TABBAR_STATES = ["default", "hover", "active", "disabled"];
var OLD_KEY = "--tabbar-bar-indicator-thickness";
var FALLBACK = "--border-width-2";
var componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth = {
  id: "2026-05-29-tabbar-indicator-thickness-to-per-state-width",
  fromVersion: 17,
  toVersion: 18,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "tabbar") return { ...rawVars };
    const seed = rawVars[OLD_KEY] ?? FALLBACK;
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === OLD_KEY) continue;
      out[key] = value;
    }
    for (const state of TABBAR_STATES) {
      const newKey = `--tabbar-${state}-indicator-border-width`;
      if (!(newKey in out)) out[newKey] = seed;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-segmentedcontrol-small-divider-rename.ts
var RENAMES = {
  "--segmentedcontrol-divider-small-thickness": "--segmentedcontrol-small-divider-thickness",
  "--segmentedcontrol-divider-small-inset": "--segmentedcontrol-small-divider-inset"
};
var componentMigration_2026_05_29_segmentedcontrolSmallDividerRename = {
  id: "2026-05-29-segmentedcontrol-small-divider-rename",
  fromVersion: 18,
  toVersion: 19,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "segmentedcontrol") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMES[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-05-29-toggle-derive-track-from-thumb.ts
var componentMigration_2026_05_29_toggleDeriveTrackFromThumb = {
  id: "2026-05-29-toggle-derive-track-from-thumb",
  fromVersion: 19,
  toVersion: 20,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "toggle") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (key === "--toggle-track-width" || key === "--toggle-track-thickness") continue;
      out[key] = value;
    }
    if (!("--toggle-track-padding" in out)) {
      out["--toggle-track-padding"] = "--space-2";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-08-13-drop-legacy-shape-space-keys.ts
var DROPPED = /* @__PURE__ */ new Set([
  "--badge-trait-radius",
  "--badge-trait-padding",
  "--sectiondivider-padding",
  "--dialog-primary-default-radius",
  "--dialog-primary-default-padding",
  "--dialog-primary-hover-radius",
  "--dialog-primary-hover-padding",
  "--dialog-secondary-default-radius",
  "--dialog-secondary-default-padding",
  "--dialog-secondary-hover-radius",
  "--dialog-secondary-hover-padding"
]);
var colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys = {
  id: "2026-08-13-drop-legacy-shape-space-keys",
  fromVersion: 3,
  toVersion: 4,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-08-15-line-height-scale-rename.ts
var RENAMED = {
  "--line-height-xs": "--line-height-none",
  "--line-height-sm": "--line-height-tighter",
  "--line-height-md": "--line-height-normal",
  "--line-height-lg": "--line-height-relaxed",
  "--line-height-xl": "--line-height-relaxed"
};
var REFERENCE = /--line-height-(?:xs|sm|md|lg|xl)(?![\w-])/g;
function renameValues(rawVars) {
  const out = {};
  for (const [key, value] of Object.entries(rawVars)) {
    out[key] = typeof value === "string" ? value.replace(REFERENCE, (name) => RENAMED[name]) : value;
  }
  return out;
}
var colorsAndTypeMigration_2026_08_15_lineHeightScaleRename = {
  id: "2026-08-15-line-height-scale-rename-colors-and-type",
  fromVersion: 4,
  toVersion: 5,
  appliesTo: "colors-and-type",
  apply: renameValues
};
var componentMigration_2026_08_15_lineHeightScaleRename = {
  id: "2026-08-15-line-height-scale-rename-component",
  fromVersion: 20,
  toVersion: 21,
  appliesTo: "component-config",
  apply: renameValues
};

// src/editor/core/themes/migrations/2026-09-01-scrim-rename.ts
var RENAMED2 = {
  "--overlay-low": "--scrim-low",
  "--overlay": "--scrim",
  "--overlay-high": "--scrim-high"
};
var RENAMED_COMPONENT_KEYS = {
  "--dialog-overlay-surface": "--dialog-scrim-surface"
};
var colorsAndTypeMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename-theme",
  fromVersion: 5,
  toVersion: 6,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMED2[key] ?? key] = value;
    }
    return out;
  }
};
var componentMigration_2026_09_01_scrimRename = {
  id: "2026-09-01-scrim-rename-component",
  fromVersion: 21,
  toVersion: 22,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMED_COMPONENT_KEYS[key] ?? key] = RENAMED2[value] ?? value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-tint-rename.ts
var RENAMED3 = {
  "--hover-low": "--tint-low",
  "--hover": "--tint",
  "--hover-high": "--tint-high"
};
var colorsAndTypeMigration_2026_09_01_tintRename = {
  id: "2026-09-01-tint-rename-theme",
  fromVersion: 6,
  toVersion: 7,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[RENAMED3[key] ?? key] = value;
    return out;
  }
};
var componentMigration_2026_09_01_tintRename = {
  id: "2026-09-01-tint-rename-component",
  fromVersion: 22,
  toVersion: 23,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[key] = RENAMED3[value] ?? value;
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-tabbar-active-tint.ts
var componentMigration_2026_09_01_tabbarActiveTint = {
  id: "2026-09-01-tabbar-active-tint",
  fromVersion: 23,
  toVersion: 24,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "tabbar") return { ...rawVars };
    const out = { ...rawVars };
    if (out["--tabbar-active-surface"] === "--scrim-low") {
      out["--tabbar-active-surface"] = "--tint-low";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-01-gate-suffix-enabled.ts
var RENAMED4 = {
  "--card-hover-border-active": "--card-hover-border-enabled",
  "--card-hover-shadow-active": "--card-hover-shadow-enabled",
  "--image-zoom-hover": "--image-zoom-enabled",
  "--image-grow-hover": "--image-grow-enabled"
};
var componentMigration_2026_09_01_gateSuffixEnabled = {
  id: "2026-09-01-gate-suffix-enabled",
  fromVersion: 24,
  toVersion: 25,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) out[RENAMED4[key] ?? key] = value;
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-02-sectiondivider-drop-title-outline.ts
var DROPPED2 = new Set(
  ["lg", "md", "sm"].flatMap((v) => [
    `--sectiondivider-${v}-title-outline-width`,
    `--sectiondivider-${v}-title-outline-color`
  ])
);
var componentMigration_2026_09_02_sectiondividerDropTitleOutline = {
  id: "2026-09-02-sectiondivider-drop-title-outline",
  fromVersion: 25,
  toVersion: 26,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "sectiondivider") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED2.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-03-drop-legacy-component-keys.ts
var DROPPED3 = /* @__PURE__ */ new Set([
  "--badge-trait-surface",
  "--badge-trait-text",
  "--badge-trait-text-font-family",
  "--badge-trait-text-font-size",
  "--badge-trait-text-font-weight",
  "--badge-trait-text-line-height",
  "--badge-trait-border",
  "--badge-trait-border-width",
  "--badge-trait-shadow",
  "--sectiondivider-title",
  "--sectiondivider-title-font-family",
  "--sectiondivider-title-font-size",
  "--sectiondivider-title-font-weight",
  "--sectiondivider-title-line-height",
  "--sectiondivider-title-border-width",
  "--sectiondivider-title-stroke-color",
  "--sectiondivider-description",
  "--sectiondivider-description-font-family",
  "--sectiondivider-description-font-size",
  "--sectiondivider-description-font-weight",
  "--sectiondivider-description-line-height",
  "--dialog-primary-default-surface",
  "--dialog-primary-default-text",
  "--dialog-primary-default-border",
  "--dialog-primary-default-border-width",
  "--dialog-primary-hover-surface",
  "--dialog-primary-hover-text",
  "--dialog-primary-hover-border",
  "--dialog-primary-hover-border-width",
  "--dialog-secondary-default-text",
  "--dialog-secondary-default-border",
  "--dialog-secondary-default-border-width",
  "--dialog-secondary-hover-surface",
  "--dialog-secondary-hover-text",
  "--dialog-secondary-hover-border",
  "--dialog-secondary-hover-border-width"
]);
var colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys = {
  id: "2026-09-03-drop-legacy-component-keys",
  fromVersion: 7,
  toVersion: 8,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      if (DROPPED3.has(key)) continue;
      out[key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-07-stroke-role-renames.ts
var RENAMES2 = {
  tabbar: Object.fromEntries(
    ["default", "hover", "active", "disabled"].map((s) => [
      `--tabbar-${s}-indicator-border-width`,
      `--tabbar-${s}-indicator-width`
    ])
  ),
  collapsiblesection: Object.fromEntries(
    ["default", "hover"].flatMap((s) => [
      [`--collapsiblesection-divider-${s}-border`, `--collapsiblesection-divider-${s}-hairline-color`],
      [`--collapsiblesection-divider-${s}-border-width`, `--collapsiblesection-divider-${s}-hairline-thickness`]
    ])
  ),
  dialog: Object.fromEntries(
    ["header", "footer"].flatMap((part) => [
      [`--dialog-${part}-border`, `--dialog-${part}-divider`],
      [`--dialog-${part}-border-width`, `--dialog-${part}-divider-width`]
    ])
  ),
  table: {
    "--table-default-header-border": "--table-default-header-divider",
    "--table-default-header-border-width": "--table-default-header-divider-width"
  }
};
var componentMigration_2026_09_07_strokeRoleRenames = {
  id: "2026-09-07-stroke-role-renames",
  fromVersion: 26,
  toVersion: 27,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES2[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-selected-state.ts
var RADIOBUTTON_SUFFIXES = [
  "dot-border-color",
  "dot-border-width",
  "dot-fill",
  "dot-size",
  "label",
  "label-font-family",
  "label-font-size",
  "label-font-weight",
  "label-line-height"
];
var TABBAR_SUFFIXES = [
  "border",
  "icon-size",
  "indicator-width",
  "padding",
  "surface",
  "tab-border-color",
  "tab-border-width",
  "tab-bottom-radius",
  "tab-top-radius",
  "text",
  "text-font-family",
  "text-font-size",
  "text-font-weight",
  "text-line-height"
];
var SIDENAVIGATION_SUFFIXES = {
  title: [
    "accent",
    "accent-width",
    "border",
    "border-width",
    "label",
    "label-font-family",
    "label-font-size",
    "label-font-weight",
    "label-line-height",
    "padding",
    "surface"
  ],
  section: [
    "accent",
    "accent-width",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ],
  item: [
    "accent",
    "accent-width",
    "padding",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ],
  footer: [
    "accent",
    "accent-width",
    "gap",
    "icon",
    "icon-size",
    "padding",
    "surface",
    "text",
    "text-font-family",
    "text-font-size",
    "text-font-weight",
    "text-line-height"
  ]
};
var RENAMES3 = {
  radiobutton: Object.fromEntries(
    RADIOBUTTON_SUFFIXES.map((s) => [`--radiobutton-active-${s}`, `--radiobutton-selected-${s}`])
  ),
  tabbar: Object.fromEntries(
    TABBAR_SUFFIXES.map((s) => [`--tabbar-active-${s}`, `--tabbar-selected-${s}`])
  ),
  sidenavigation: Object.fromEntries(
    Object.entries(SIDENAVIGATION_SUFFIXES).flatMap(
      ([part, suffixes]) => suffixes.map((s) => [
        `--sidenavigation-${part}-active-${s}`,
        `--sidenavigation-${part}-selected-${s}`
      ])
    )
  )
};
var componentMigration_2026_09_13_selectedState = {
  id: "2026-09-13-selected-state",
  fromVersion: 27,
  toVersion: 28,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES3[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-hairline.ts
var COLLAPSIBLESECTION_SUFFIXES = [
  "surface",
  "hairline-color",
  "padding",
  "label",
  "label-font-family",
  "label-font-size",
  "label-font-weight",
  "label-line-height",
  "icon",
  "icon-size"
];
var COLLAPSIBLESECTION_STATES = ["default", "hover"];
var RENAMES4 = {
  dialog: {
    "--dialog-header-divider": "--dialog-header-hairline-color",
    "--dialog-header-divider-width": "--dialog-header-hairline-width",
    "--dialog-footer-divider": "--dialog-footer-hairline-color",
    "--dialog-footer-divider-width": "--dialog-footer-hairline-width"
  },
  table: {
    "--table-default-header-divider": "--table-default-header-hairline-color",
    "--table-default-header-divider-width": "--table-default-header-hairline-width",
    "--table-default-row-divider": "--table-default-row-hairline-color",
    "--table-default-row-divider-width": "--table-default-row-hairline-width",
    "--table-default-column-divider": "--table-default-column-hairline-color",
    "--table-default-column-divider-width": "--table-default-column-hairline-width"
  },
  tabbar: {
    "--tabbar-bar-divider": "--tabbar-bar-hairline-color",
    "--tabbar-bar-divider-thickness": "--tabbar-bar-hairline-width"
  },
  segmentedcontrol: {
    "--segmentedcontrol-divider-color": "--segmentedcontrol-hairline-color",
    "--segmentedcontrol-divider-thickness": "--segmentedcontrol-hairline-width",
    "--segmentedcontrol-divider-inset": "--segmentedcontrol-hairline-inset",
    "--segmentedcontrol-small-divider-thickness": "--segmentedcontrol-small-hairline-width",
    "--segmentedcontrol-small-divider-inset": "--segmentedcontrol-small-hairline-inset"
  },
  collapsiblesection: {
    ...Object.fromEntries(
      COLLAPSIBLESECTION_STATES.flatMap((state) => [
        ...COLLAPSIBLESECTION_SUFFIXES.map((s) => [
          `--collapsiblesection-divider-${state}-${s}`,
          `--collapsiblesection-hairline-${state}-${s}`
        ]),
        [
          `--collapsiblesection-divider-${state}-hairline-thickness`,
          `--collapsiblesection-hairline-${state}-hairline-width`
        ]
      ])
    ),
    "--collapsiblesection-divider-expanded-padding": "--collapsiblesection-hairline-expanded-padding"
  },
  sectiondivider: {
    "--sectiondivider-lg-hairline-thickness": "--sectiondivider-lg-hairline-width",
    "--sectiondivider-md-hairline-thickness": "--sectiondivider-md-hairline-width",
    "--sectiondivider-sm-hairline-thickness": "--sectiondivider-sm-hairline-width"
  }
};
var componentMigration_2026_09_13_hairline = {
  id: "2026-09-13-hairline",
  fromVersion: 28,
  toVersion: 29,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES4[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-indicator.ts
var SIDENAVIGATION_PARTS = ["title", "section", "item", "footer"];
var SIDENAVIGATION_STATES = ["default", "hover", "selected"];
var CALLOUT_VARIANTS = ["info", "success", "warning", "danger"];
var RENAMES5 = {
  sidenavigation: Object.fromEntries(
    SIDENAVIGATION_PARTS.flatMap(
      (part) => SIDENAVIGATION_STATES.flatMap((state) => [
        [
          `--sidenavigation-${part}-${state}-accent`,
          `--sidenavigation-${part}-${state}-indicator`
        ],
        [
          `--sidenavigation-${part}-${state}-accent-width`,
          `--sidenavigation-${part}-${state}-indicator-width`
        ]
      ])
    )
  ),
  callout: Object.fromEntries(
    CALLOUT_VARIANTS.map((v) => [
      `--callout-${v}-accent-width`,
      `--callout-${v}-indicator-width`
    ])
  )
};
var componentMigration_2026_09_13_indicator = {
  id: "2026-09-13-indicator",
  fromVersion: 29,
  toVersion: 30,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES5[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-sectiondivider-surface.ts
var SECTIONDIVIDER_VARIANTS = ["lg", "md", "sm"];
var RENAMES6 = {
  sectiondivider: Object.fromEntries(
    SECTIONDIVIDER_VARIANTS.map((v) => [
      `--sectiondivider-${v}-background`,
      `--sectiondivider-${v}-surface`
    ])
  )
};
var componentMigration_2026_09_13_sectiondividerSurface = {
  id: "2026-09-13-sectiondivider-surface",
  fromVersion: 30,
  toVersion: 31,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES6[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-20-imagelightbox-scrim.ts
var RENAMES7 = {
  "--imagelightbox-overlay-surface": "--imagelightbox-scrim-surface"
};
var componentMigration_2026_09_20_imagelightboxScrim = {
  id: "2026-09-20-imagelightbox-scrim",
  fromVersion: 35,
  toVersion: 36,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    if (meta.component !== "imagelightbox") return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[RENAMES7[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-20-scrim-color-and-opacity.ts
var STOPS = {
  "--scrim-low": "--scrim-opacity-low",
  "--scrim": "--scrim-opacity",
  "--scrim-high": "--scrim-opacity-high"
};
var SURFACE = /^--(imagelightbox|dialog)-scrim-surface$/;
var componentMigration_2026_09_20_scrimColorAndOpacity = {
  id: "2026-09-20-scrim-color-and-opacity",
  fromVersion: 36,
  toVersion: 37,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const match = SURFACE.exec(key);
      if (!match) {
        out[key] = value;
        continue;
      }
      const stem = `--${match[1]}-scrim`;
      const stop = STOPS[value];
      out[`${stem}-color`] = stop ? "--scrim-color" : value;
      out[`${stem}-opacity`] = stop ?? "1";
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-21-wash-color-and-opacity.ts
var FAMILIES = ["scrim", "tint"];
var COLOR_MIX_RE = /^color-mix\(in srgb,\s*var\((--[a-z0-9-]+)\)\s+(\d+(?:\.\d+)?)%,\s*transparent\)$/i;
var PLAIN_VAR_RE = /^var\((--[a-z0-9-]+)\)$/i;
function parseFill(raw) {
  const s = raw.trim();
  const mix = s.match(COLOR_MIX_RE);
  if (mix) return { color: mix[1], opacity: Math.min(100, Number(mix[2])) / 100 };
  const plain = s.match(PLAIN_VAR_RE);
  return plain ? { color: plain[1], opacity: 1 } : null;
}
var colorsAndTypeMigration_2026_09_21_washColorAndOpacity = {
  id: "2026-09-21-wash-color-and-opacity",
  fromVersion: 8,
  toVersion: 9,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    const out = { ...rawVars };
    for (const family of FAMILIES) {
      let color = null;
      for (const suffix of ["", "-low", "-high"]) {
        const key = `--${family}${suffix}`;
        const parsed = out[key] === void 0 ? null : parseFill(out[key]);
        if (!parsed) continue;
        color ??= parsed.color;
        out[`--${family}-opacity${suffix}`] = String(parsed.opacity);
        delete out[key];
      }
      if (color) out[`--${family}-color`] = `var(${color})`;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-10-15-responsive-columns.ts
var RENAMES8 = {
  "--columns-gutter": "--columns-desktop-gutter",
  "--columns-margin": "--columns-desktop-margin"
};
var SHIPPED = {
  "--columns-count": ["12"],
  "--columns-gutter": ["32px"],
  "--columns-margin": ["0px", "0"]
};
var colorsAndTypeMigration_2026_10_15_responsiveColumns = {
  id: "2026-10-15-responsive-columns",
  fromVersion: 9,
  toVersion: 10,
  appliesTo: "colors-and-type",
  apply(rawVars) {
    return Object.fromEntries(
      Object.entries(rawVars).filter(([name, value]) => !SHIPPED[name]?.includes(value.trim())).map(([name, value]) => [RENAMES8[name] ?? name, value])
    );
  }
};

// src/editor/core/themes/migrations/2026-09-21-scrim-surface.ts
var STOPS2 = {
  "--scrim-opacity-low": "--scrim-low",
  "--scrim-opacity": "--scrim",
  "--scrim-opacity-high": "--scrim-high"
};
var PAIR = /^--(imagelightbox|dialog)-scrim-(color|opacity)$/;
var ref = (value) => value.startsWith("--") ? `var(${value})` : value;
function fill(color, opacity) {
  if (color === "--scrim-color" && STOPS2[opacity]) return STOPS2[opacity];
  if (opacity === "1") return color;
  const pct = Number.isFinite(Number(opacity)) ? `${Number(opacity) * 100}%` : `calc(${ref(opacity)} * 100%)`;
  return `color-mix(in srgb, ${ref(color)} ${pct}, transparent)`;
}
var componentMigration_2026_09_21_scrimSurface = {
  id: "2026-09-21-scrim-surface",
  fromVersion: 37,
  toVersion: 38,
  appliesTo: "component-config",
  apply(rawVars) {
    const out = {};
    const pairs = {};
    for (const [key, value] of Object.entries(rawVars)) {
      const match = PAIR.exec(key);
      if (!match) {
        out[key] = value;
        continue;
      }
      (pairs[match[1]] ??= {})[match[2]] = value;
    }
    for (const [id, { color = "--scrim-color", opacity = "--scrim-opacity-high" }] of Object.entries(pairs)) {
      out[`--${id}-scrim-surface`] = fill(color, opacity);
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-cornerbadge-prefix.ts
var RENAMES9 = {
  cornerbadge: {
    "--corner-badge-margin": "--cornerbadge-margin",
    "--corner-badge-outer-radius": "--cornerbadge-outer-radius",
    "--corner-badge-inner-radius": "--cornerbadge-inner-radius",
    "--corner-badge-h-axis-radius": "--cornerbadge-h-axis-radius",
    "--corner-badge-v-axis-radius": "--cornerbadge-v-axis-radius",
    "--corner-badge-padding": "--cornerbadge-padding",
    "--corner-badge-text-font-family": "--cornerbadge-text-font-family",
    "--corner-badge-text-font-size": "--cornerbadge-text-font-size",
    "--corner-badge-text-font-weight": "--cornerbadge-text-font-weight",
    "--corner-badge-text-line-height": "--cornerbadge-text-line-height",
    "--corner-badge-primary-surface": "--cornerbadge-primary-surface",
    "--corner-badge-primary-border": "--cornerbadge-primary-border",
    "--corner-badge-primary-text": "--cornerbadge-primary-text",
    "--corner-badge-accent-surface": "--cornerbadge-accent-surface",
    "--corner-badge-accent-border": "--cornerbadge-accent-border",
    "--corner-badge-accent-text": "--cornerbadge-accent-text",
    "--corner-badge-neutral-surface": "--cornerbadge-neutral-surface",
    "--corner-badge-neutral-border": "--cornerbadge-neutral-border",
    "--corner-badge-neutral-text": "--cornerbadge-neutral-text",
    "--corner-badge-alternate-surface": "--cornerbadge-alternate-surface",
    "--corner-badge-alternate-border": "--cornerbadge-alternate-border",
    "--corner-badge-alternate-text": "--cornerbadge-alternate-text",
    "--corner-badge-canvas-surface": "--cornerbadge-canvas-surface",
    "--corner-badge-canvas-border": "--cornerbadge-canvas-border",
    "--corner-badge-canvas-text": "--cornerbadge-canvas-text",
    "--corner-badge-special-surface": "--cornerbadge-special-surface",
    "--corner-badge-special-border": "--cornerbadge-special-border",
    "--corner-badge-special-text": "--cornerbadge-special-text",
    "--corner-badge-success-surface": "--cornerbadge-success-surface",
    "--corner-badge-success-border": "--cornerbadge-success-border",
    "--corner-badge-success-text": "--cornerbadge-success-text",
    "--corner-badge-warning-surface": "--cornerbadge-warning-surface",
    "--corner-badge-warning-border": "--cornerbadge-warning-border",
    "--corner-badge-warning-text": "--cornerbadge-warning-text",
    "--corner-badge-danger-surface": "--cornerbadge-danger-surface",
    "--corner-badge-danger-border": "--cornerbadge-danger-border",
    "--corner-badge-danger-text": "--cornerbadge-danger-text",
    "--corner-badge-info-surface": "--cornerbadge-info-surface",
    "--corner-badge-info-border": "--cornerbadge-info-border",
    "--corner-badge-info-text": "--cornerbadge-info-text"
  }
};
var componentMigration_2026_09_13_cornerbadgePrefix = {
  id: "2026-09-13-cornerbadge-prefix",
  fromVersion: 31,
  toVersion: 32,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES9[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-toggle-label.ts
var RENAMES10 = {
  toggle: {
    "--toggle-label-text": "--toggle-label",
    "--toggle-disabled-label-text": "--toggle-disabled-label"
  }
};
var componentMigration_2026_09_13_toggleLabel = {
  id: "2026-09-13-toggle-label",
  fromVersion: 32,
  toVersion: 33,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES10[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-collapsiblesection-open.ts
var RENAMES11 = {
  collapsiblesection: {
    "--collapsiblesection-chromeless-expanded-padding": "--collapsiblesection-chromeless-open-padding",
    "--collapsiblesection-hairline-expanded-padding": "--collapsiblesection-hairline-open-padding",
    "--collapsiblesection-container-expanded-surface": "--collapsiblesection-container-open-surface",
    "--collapsiblesection-container-expanded-padding": "--collapsiblesection-container-open-padding"
  }
};
var componentMigration_2026_09_13_collapsiblesectionOpen = {
  id: "2026-09-13-collapsiblesection-open",
  fromVersion: 33,
  toVersion: 34,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES11[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/2026-09-13-badge-brand.ts
var BADGE_SUFFIXES = [
  "surface",
  "text",
  "border",
  "text-font-family",
  "text-font-size",
  "text-font-weight",
  "text-line-height",
  "border-width",
  "radius",
  "padding",
  "shadow",
  "blur",
  "icon-size"
];
var CORNERBADGE_SUFFIXES = ["surface", "border", "text"];
var RENAMES12 = {
  badge: Object.fromEntries(
    BADGE_SUFFIXES.map((s) => [`--badge-primary-${s}`, `--badge-brand-${s}`])
  ),
  cornerbadge: Object.fromEntries(
    CORNERBADGE_SUFFIXES.map((s) => [`--cornerbadge-primary-${s}`, `--cornerbadge-brand-${s}`])
  )
};
var componentMigration_2026_09_13_badgeBrand = {
  id: "2026-09-13-badge-brand",
  fromVersion: 34,
  toVersion: 35,
  appliesTo: "component-config",
  apply(rawVars, meta) {
    const renames = meta.component ? RENAMES12[meta.component] : void 0;
    if (!renames) return { ...rawVars };
    const out = {};
    for (const [key, value] of Object.entries(rawVars)) {
      out[renames[key] ?? key] = value;
    }
    return out;
  }
};

// src/editor/core/themes/migrations/index.ts
var MIGRATIONS = [
  colorsAndTypeMigration_2026_04_24_legacyKeysAndBgToCanvas,
  colorsAndTypeMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_04_24_prefixAndSuffixRenames,
  componentMigration_2026_04_27_segmentedcontrolDisabledFlatten,
  componentMigration_2026_05_08_collapsiblesectionVariantNamespace,
  componentMigration_2026_05_08_collapsiblesectionFrameAndCleanup,
  componentMigration_2026_05_10_sectiondividerGradientStops,
  componentMigration_2026_05_13_primaryToBrand,
  componentMigration_2026_05_19_collapsiblesectionDropFrameSurface,
  componentMigration_2026_05_19_sectiondividerRichGradient,
  componentMigration_2026_05_20_sectiondividerSlimVariants,
  componentMigration_2026_05_21_sectiondividerSpacingToPadding,
  componentMigration_2026_05_22_sectiondividerIntrinsicsToCss,
  componentMigration_2026_05_24_segmentedcontrolDividerInset,
  componentMigration_2026_05_24_promoteStateSharedTokens,
  componentMigration_2026_05_24_progressbarCollapseVariants,
  componentMigration_2026_05_24_collapsiblesectionDropActiveState,
  componentMigration_2026_05_25_cornerbadgeFlattenVariants,
  colorsAndTypeMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_26_dropOverlayExtraStops,
  componentMigration_2026_05_29_tabbarIndicatorThicknessToPerStateWidth,
  componentMigration_2026_05_29_segmentedcontrolSmallDividerRename,
  componentMigration_2026_05_29_toggleDeriveTrackFromThumb,
  colorsAndTypeMigration_2026_08_13_dropLegacyShapeSpaceKeys,
  colorsAndTypeMigration_2026_08_15_lineHeightScaleRename,
  componentMigration_2026_08_15_lineHeightScaleRename,
  colorsAndTypeMigration_2026_09_01_scrimRename,
  componentMigration_2026_09_01_scrimRename,
  colorsAndTypeMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tintRename,
  componentMigration_2026_09_01_tabbarActiveTint,
  componentMigration_2026_09_01_gateSuffixEnabled,
  componentMigration_2026_09_02_sectiondividerDropTitleOutline,
  colorsAndTypeMigration_2026_09_03_dropLegacyComponentKeys,
  componentMigration_2026_09_07_strokeRoleRenames,
  componentMigration_2026_09_13_selectedState,
  componentMigration_2026_09_13_hairline,
  componentMigration_2026_09_13_indicator,
  componentMigration_2026_09_13_sectiondividerSurface,
  componentMigration_2026_09_13_cornerbadgePrefix,
  componentMigration_2026_09_13_toggleLabel,
  componentMigration_2026_09_13_collapsiblesectionOpen,
  componentMigration_2026_09_13_badgeBrand,
  componentMigration_2026_09_20_imagelightboxScrim,
  componentMigration_2026_09_20_scrimColorAndOpacity,
  colorsAndTypeMigration_2026_09_21_washColorAndOpacity,
  componentMigration_2026_09_21_scrimSurface,
  colorsAndTypeMigration_2026_10_15_responsiveColumns
];
function countFor(kind) {
  return MIGRATIONS.filter((m) => m.appliesTo === kind).length;
}
var CURRENT_COLORS_AND_TYPE_SCHEMA_VERSION = countFor("colors-and-type");
var CURRENT_COMPONENT_SCHEMA_VERSION = countFor("component-config");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CURRENT_COMPONENT_SCHEMA_VERSION,
  buildColors,
  readLiveTokensConfig,
  resolveDataDirs,
  sanitizeFileName
});
