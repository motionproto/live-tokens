import {
  ContractViolation,
  isInapplicable,
  partLocator,
  requiresInteraction
} from "./chunk-3UKGXCDL.js";
import {
  createVitestConfig
} from "./chunk-GKO27NGN.js";
import {
  COMPONENTS_PATH_ENV,
  COMPONENT_ENV,
  DEFAULT_PAGE_VIEWPORTS,
  PAGES_ENV,
  PAGE_VIEWPORTS_ENV,
  TESTING_CONFIG_FILE,
  defineTestingConfig,
  devServerCommand,
  resolveTestingConfig
} from "./chunk-NB3NZRBM.js";
import {
  CONTRACTS_MODULE_ENV,
  allContracts,
  selectedContracts,
  shippedContracts
} from "./chunk-SHBYZUPD.js";

// src/testing/playwright.ts
import path2 from "path";
import { fileURLToPath } from "url";
import {
  defineConfig,
  devices
} from "@playwright/test";

// src/testing/isolation.ts
import fs from "fs";
import os from "os";
import path from "path";
var TEST_DATA_DIR_ENV = "LIVE_TOKENS_TEST_DATA_DIR";
var DATA_DIR_ENV = "LIVE_TOKENS_DATA_DIR";
var SESSION_FILES = /* @__PURE__ */ new Set(["_working.json", "_active.json", "_production.json"]);
var removed = false;
function registerCleanup(dataDir) {
  const remove = () => {
    if (removed) return;
    removed = true;
    fs.rmSync(dataDir, { recursive: true, force: true });
  };
  process.once("exit", remove);
  process.once("SIGINT", remove);
  process.once("SIGTERM", remove);
}
function isolateDataDir(sourceDataDir) {
  const existing = process.env[TEST_DATA_DIR_ENV];
  if (existing) {
    const dataDir2 = path.resolve(existing);
    if (!fs.existsSync(dataDir2)) {
      throw new Error(`${TEST_DATA_DIR_ENV} names ${dataDir2}, which does not exist`);
    }
    process.env[DATA_DIR_ENV] = dataDir2;
    return { dataDir: dataDir2, created: false };
  }
  const source = path.resolve(sourceDataDir);
  if (!fs.existsSync(source)) {
    throw new Error(
      `No data directory at ${source}. Set \`dataDir\` in live-tokens.testing.ts when the project keeps its live-tokens data somewhere else.`
    );
  }
  const dataDir = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "live-tokens-contract-")));
  fs.cpSync(source, dataDir, { recursive: true });
  for (const entry of fs.readdirSync(dataDir, { recursive: true })) {
    if (SESSION_FILES.has(path.basename(entry))) {
      fs.rmSync(path.join(dataDir, entry), { force: true });
    }
  }
  process.env[TEST_DATA_DIR_ENV] = dataDir;
  process.env[DATA_DIR_ENV] = dataDir;
  registerCleanup(dataDir);
  return { dataDir, created: true };
}

// src/testing/port.ts
import { execFileSync } from "child_process";
var PORT_ENV = "LIVE_TOKENS_TEST_PORT";
var PREFERRED_PORT = 4173;
var PROBE = `
const net = require('net');
const listen = (port) => new Promise((resolve, reject) => {
  const server = net.createServer();
  server.once('error', reject);
  server.listen(port, '127.0.0.1', () => {
    const { port: bound } = server.address();
    server.close(() => resolve(bound));
  });
});
// process.stdout.write, not console.log: the parent's FORCE_COLOR makes
// console.log wrap a number in ANSI escapes.
listen(Number(process.argv[1])).catch(() => listen(0)).then((port) => process.stdout.write(String(port)));
`;
function resolvePort(preferred) {
  const cached = process.env[PORT_ENV];
  if (cached) return Number(cached);
  const port = preferred ?? Number(execFileSync(process.execPath, ["-e", PROBE, String(PREFERRED_PORT)], {
    encoding: "utf-8"
  }).trim());
  if (!Number.isInteger(port) || port <= 0) {
    throw new Error(`Could not settle on a dev-server port (read ${port})`);
  }
  process.env[PORT_ENV] = String(port);
  return port;
}

// src/testing/playwright.ts
var HOST = "127.0.0.1";
var CONTRACT_TEST_DIR = path2.dirname(fileURLToPath(import.meta.url));
var DEFAULT_GLOBAL_TIMEOUT_MS = 15 * 6e4;
async function createPlaywrightConfig(options = {}) {
  const settings = resolveTestingConfig(options, options.root);
  const { dataDir } = isolateDataDir(settings.dataDir);
  const port = resolvePort(settings.port);
  const baseURL = `http://${HOST}:${port}`;
  process.env[COMPONENTS_PATH_ENV] = settings.componentsPath;
  process.env[PAGE_VIEWPORTS_ENV] = JSON.stringify(settings.pageViewports);
  if (settings.contractsModule) process.env[CONTRACTS_MODULE_ENV] = settings.contractsModule;
  return defineConfig({
    testDir: options.testDir ?? CONTRACT_TEST_DIR,
    // The component suites carry their serial and parallel intent per file:
    // `component-editor.contract.ts` runs each component's save and reset
    // cycles in order against one data tree. Turning this on would interleave
    // them.
    fullyParallel: false,
    // One worker is the safe default: the specs share a dev server and a data
    // directory. A run that can afford more passes a worker count on the
    // command line.
    workers: 1,
    timeout: 3e4,
    globalTimeout: options.globalTimeout ?? DEFAULT_GLOBAL_TIMEOUT_MS,
    expect: { timeout: 5e3 },
    // A shared-server suite times out under CI load in ways it never does
    // locally, and without a retry budget one wobble aborts a tagged release.
    retries: process.env.CI ? 2 : 0,
    // Absolute and rooted at the consumer project, not the config file's own
    // directory: `check-component --tests`'s generated config lives in a
    // temporary directory that gets removed on completion, and a relative
    // `outputDir` would put every trace and screenshot in there too.
    outputDir: path2.join(settings.root, "test-results/playwright"),
    reporter: process.env.CI ? [["line"], ["html", { open: "never" }]] : "list",
    use: {
      baseURL,
      // Unset, both of these are unbounded: a locator that never resolves waits
      // out the whole test timeout and reports nothing about where it stopped.
      actionTimeout: 1e4,
      navigationTimeout: 3e4,
      trace: "on-first-retry",
      screenshot: "only-on-failure",
      // `retain-on-failure` still records every passing test and throws the
      // file away, which costs ~28% CPU. Match the trace policy instead.
      video: "on-first-retry"
    },
    projects: [
      ...options.extraProjects ?? [],
      {
        name: "contract",
        testDir: CONTRACT_TEST_DIR,
        // `.ts` in this repo, `.js` once tsup compiles the shipped build into
        // `src/testing-js`; matching both here needs no build-time swap.
        testMatch: "**/component-*.contract.{ts,js}",
        // The behavior suite shares the prefix and runs under Vitest. Left in,
        // Playwright collects it, meets its Svelte imports and reports the
        // whole project as collecting nothing.
        testIgnore: "**/component-behavior.contract.{ts,js}",
        // `.tabs-preview` now caps its sticky band at 50vh, which is enough for
        // image, panel, card and sidenavigation to pass alone at 1280x720. A
        // full parallel run still fails panel's gradient radio there, so the
        // band can cover a control at some scroll positions. Until that is
        // fixed the suite runs taller. See docs/contract-test-defects.md.
        use: { ...devices["Desktop Chrome"], viewport: { width: 1280, height: 900 } }
      },
      {
        name: "page",
        testDir: CONTRACT_TEST_DIR,
        testMatch: "**/page-*.contract.{ts,js}",
        // The suite sizes the window itself, once per viewport in
        // `pageViewports`, so the sizes stay one list rather than a project
        // per viewport whose name the reporter would have to decode.
        use: { ...devices["Desktop Chrome"] }
      }
    ],
    webServer: {
      command: devServerCommand(settings.devCommand, HOST, port),
      // Otherwise defaults to the config file's own directory. A generated
      // config that lives outside the consumer root (`check-component
      // --tests`'s temporary config) would run `npm run dev` from wherever
      // that happens to be instead.
      cwd: settings.root,
      url: baseURL,
      // A server this run did not start carries none of these variables, so it
      // would write the project's own data tree.
      reuseExistingServer: false,
      timeout: 12e4,
      env: {
        ...process.env,
        [TEST_DATA_DIR_ENV]: dataDir,
        [DATA_DIR_ENV]: dataDir
      }
    }
  });
}
export {
  COMPONENTS_PATH_ENV,
  COMPONENT_ENV,
  CONTRACTS_MODULE_ENV,
  ContractViolation,
  DATA_DIR_ENV,
  DEFAULT_PAGE_VIEWPORTS,
  PAGES_ENV,
  PAGE_VIEWPORTS_ENV,
  PORT_ENV,
  TESTING_CONFIG_FILE,
  TEST_DATA_DIR_ENV,
  allContracts,
  createPlaywrightConfig,
  createVitestConfig,
  defineTestingConfig,
  devServerCommand,
  isInapplicable,
  isolateDataDir,
  partLocator,
  requiresInteraction,
  resolvePort,
  resolveTestingConfig,
  selectedContracts,
  shippedContracts
};
//# sourceMappingURL=index.js.map