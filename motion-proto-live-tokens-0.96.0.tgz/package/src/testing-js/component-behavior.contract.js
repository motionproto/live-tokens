import {
  ContractViolation,
  isInapplicable,
  partLocator
} from "./chunk-3UKGXCDL.js";
import {
  selectedContracts
} from "./chunk-SHBYZUPD.js";

// src/testing/component-behavior.contract.ts
import { existsSync } from "fs";
import path from "path";
import { fileURLToPath, pathToFileURL } from "url";
import { describe, it, vi } from "vitest";
import { flushSync, mount, unmount } from "svelte";
import { getComponentRegistryEntries } from "../editor/component-editor/registry";
var REGISTRY_SETUP_ENV = "LIVE_TOKENS_REGISTRY_SETUP";
var setupModule = process.env[REGISTRY_SETUP_ENV];
if (setupModule) await import(pathToFileURL(path.resolve(setupModule)).href);
var packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
var consumerRoot = process.cwd();
var contracts = await selectedContracts();
function runtimeSource(contract) {
  const entry = getComponentRegistryEntries().find((candidate) => candidate.id === contract.id);
  if (!entry) return { skip: "no component is registered under this id" };
  const root = entry.origin === "system" ? packageRoot : consumerRoot;
  const file = path.resolve(root, entry.sourceFile);
  if (!existsSync(file)) return { skip: `the registration names ${entry.sourceFile}, which does not exist` };
  return { url: pathToFileURL(file).href };
}
function resolvePart(contract, target, key) {
  const locator = partLocator(contract, key);
  const scope = locator.portal ? document : target;
  const node = scope.querySelector(locator.selector);
  if (!node) {
    throw new ContractViolation("contract-behavior", contract.id, `no element matches part "${key}" (${locator.selector})`);
  }
  return node;
}
function dispatch(node, action) {
  if (action.kind === "click") {
    node.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    return;
  }
  if (action.kind === "keydown") {
    node.dispatchEvent(new KeyboardEvent("keydown", { key: action.key ?? "", bubbles: true, cancelable: true }));
    return;
  }
  node.value = action.value ?? "";
  node.dispatchEvent(new Event("input", { bubbles: true }));
}
function describeValue(value) {
  if (value instanceof Event) return `${value.constructor.name}(${value.type})`;
  return JSON.stringify(value) ?? String(value);
}
function matchesArg(actual, expected) {
  if (expected === null || typeof expected !== "object" || Array.isArray(expected)) {
    return Object.is(actual, expected);
  }
  if (actual === null || typeof actual !== "object") return false;
  return Object.entries(expected).every(([key, value]) => matchesArg(actual[key], value));
}
function sameArgs(actual, expected) {
  return actual.length === expected.length && expected.every((value, index) => matchesArg(actual[index], value));
}
async function runCase(contract, runtime, testCase) {
  const target = document.createElement("div");
  document.body.appendChild(target);
  const fail = (message) => {
    throw new ContractViolation("contract-behavior", contract.id, `${testCase.name}: ${message}`);
  };
  const expectation = testCase.expect;
  const callbackProp = expectation.kind === "callback" || expectation.kind === "no-callback" ? expectation.prop : null;
  const spy = callbackProp === null ? null : vi.fn();
  const props = {
    ...testCase.props,
    ...callbackProp === null ? {} : { [callbackProp]: spy }
  };
  const instance = mount(runtime, { target, props });
  flushSync();
  try {
    if (testCase.action) {
      dispatch(resolvePart(contract, target, testCase.action.part), testCase.action);
      flushSync();
    }
    if (expectation.kind === "callback") {
      const calls = spy.mock.calls;
      if (calls.length === 0) fail(`${expectation.prop} was not called`);
      if (!sameArgs(calls[0], expectation.args)) {
        fail(`${expectation.prop} was called with [${calls[0].map(describeValue).join(", ")}], expected ${describeValue(expectation.args)}`);
      }
      return;
    }
    if (expectation.kind === "no-callback") {
      if (spy.mock.calls.length > 0) {
        fail(`${expectation.prop} was called with [${spy.mock.calls[0].map(describeValue).join(", ")}]`);
      }
      return;
    }
    const node = resolvePart(contract, target, expectation.part);
    if (expectation.kind === "attribute") {
      const actual = node.getAttribute(expectation.name);
      if (actual !== expectation.value) {
        fail(`${expectation.part}[${expectation.name}] is ${describeValue(actual)}, expected ${describeValue(expectation.value)}`);
      }
      return;
    }
    const text = (node.textContent ?? "").replace(/\s+/g, " ").trim();
    if (text !== expectation.value) {
      fail(`${expectation.part} reads ${describeValue(text)}, expected ${describeValue(expectation.value)}`);
    }
  } finally {
    unmount(instance);
    target.remove();
  }
}
describe("component behavior contract", () => {
  describe.each(contracts.map((contract) => [contract.id, contract]))("%s", (_id, contract) => {
    const declared = contract.behavior;
    if (isInapplicable(declared)) {
      it("says why it declares no behavior", () => {
        if (declared.reason.trim() === "") {
          throw new ContractViolation("contract-behavior", contract.id, "behavior is inapplicable with no reason");
        }
      });
      return;
    }
    if (!declared || declared.cases.length === 0) {
      it("declares its behavior", () => {
        throw new ContractViolation(
          "contract-behavior",
          contract.id,
          "declare `behavior` with at least one case, or mark it { applicable: false, reason }"
        );
      });
      return;
    }
    const source = runtimeSource(contract);
    if ("skip" in source) {
      for (const testCase of declared.cases) it.skip(`${testCase.name} (${source.skip})`, () => {
      });
      return;
    }
    const { url } = source;
    let loading = null;
    it.each(declared.cases.map((testCase) => [testCase.name, testCase]))("%s", async (_name, testCase) => {
      loading ??= import(
        /* @vite-ignore */
        url
      ).then((module) => module.default);
      await runCase(contract, await loading, testCase);
    });
  });
});
//# sourceMappingURL=component-behavior.contract.js.map