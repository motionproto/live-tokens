"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// vite-plugin/setType/index.ts
var setType_exports = {};
__export(setType_exports, {
  SLOT_ORDER: () => SLOT_ORDER,
  SLOT_VARIABLES: () => SLOT_VARIABLES,
  applyFontPairing: () => applyFontPairing,
  discoveryUrl: () => discoveryUrl,
  fontPairingLabel: () => fontPairingLabel,
  persistUrlFor: () => persistUrlFor,
  readLiveTokensConfig: () => readLiveTokensConfig,
  requiredWeights: () => requiredWeights,
  resolveDataDirs: () => resolveDataDirs,
  resolveGoogleFont: () => resolveGoogleFont,
  slugifyFamily: () => slugifyFamily,
  weightCoverage: () => weightCoverage
});
module.exports = __toCommonJS(setType_exports);

// src/editor/core/fonts/fontParse.ts
function parseGoogleFontsUrl(url2) {
  let u;
  try {
    u = new URL(url2);
  } catch {
    return null;
  }
  if (!u.hostname.includes("fonts.googleapis.com")) return null;
  const familyParams = u.searchParams.getAll("family");
  if (familyParams.length === 0) return null;
  return familyParams.map((raw) => {
    const [rawName, spec] = raw.split(":");
    const name = decodeURIComponent(rawName).replace(/\+/g, " ");
    const parsed = { name };
    if (spec) {
      const axisMatch = spec.match(/(?:ital,)?wght@([^&]+)/);
      const italics = spec.startsWith("ital,");
      if (italics) parsed.italics = true;
      if (axisMatch) {
        const tokens = axisMatch[1].split(";");
        const weights = /* @__PURE__ */ new Set();
        for (const tok of tokens) {
          const parts = tok.split(",");
          const wghtStr = parts.length === 2 ? parts[1] : parts[0];
          if (wghtStr.includes("..")) {
            const [lo, hi] = wghtStr.split("..").map((n) => parseInt(n, 10));
            if (!isNaN(lo) && !isNaN(hi)) {
              for (let w = lo; w <= hi; w += 100) weights.add(w);
            }
          } else {
            const w = parseInt(wghtStr, 10);
            if (!isNaN(w)) weights.add(w);
          }
        }
        if (weights.size > 0) parsed.weights = [...weights].sort((a, b) => a - b);
      }
    }
    return parsed;
  });
}
function parseFontFaceText(css) {
  const rules = [...css.matchAll(/@font-face\s*\{([^}]*)\}/g)];
  const byName = /* @__PURE__ */ new Map();
  for (const [, body] of rules) {
    const nameMatch = body.match(/font-family\s*:\s*([^;]+);/i);
    if (!nameMatch) continue;
    const name = nameMatch[1].trim().replace(/^['"]|['"]$/g, "");
    const weightMatch = body.match(/font-weight\s*:\s*([^;]+);/i);
    const styleMatch = body.match(/font-style\s*:\s*([^;]+);/i);
    const entry = byName.get(name) ?? { weights: /* @__PURE__ */ new Set(), italics: false };
    if (weightMatch) {
      const val = weightMatch[1].trim();
      const rangeParts = val.split(/\s+/).map((s) => parseInt(s, 10)).filter((n) => !isNaN(n));
      if (rangeParts.length === 2) {
        const [lo, hi] = rangeParts;
        for (let w = lo; w <= hi; w += 100) entry.weights.add(w);
      } else if (rangeParts.length === 1) {
        entry.weights.add(rangeParts[0]);
      }
    }
    if (styleMatch && /italic|oblique/i.test(styleMatch[1])) entry.italics = true;
    byName.set(name, entry);
  }
  return [...byName.entries()].map(([name, e]) => ({
    name,
    ...e.weights.size > 0 ? { weights: [...e.weights].sort((a, b) => a - b) } : {},
    ...e.italics ? { italics: true } : {}
  }));
}

// src/editor/core/fonts/fontPairing.ts
var PAIRING = ["--font-display", "--font-sans"];
function familyIndex(sources) {
  const familyById = /* @__PURE__ */ new Map();
  for (const source of sources) {
    for (const family of source.families) familyById.set(family.id, family);
  }
  return familyById;
}
function resolvedFaceName(stack, familyById) {
  for (const slot of stack?.slots ?? []) {
    if (slot.kind === "project") {
      const family = familyById.get(slot.familyId);
      if (family) return family.name;
      continue;
    }
    if (slot.kind === "system") return "System";
    return slot.value;
  }
  return null;
}
function fontPairingLabel(stacks, sources) {
  const familyById = familyIndex(sources);
  return PAIRING.map((variable) => resolvedFaceName(stacks.find((s) => s.variable === variable), familyById)).filter((label) => label !== null).join(" / ");
}

// src/editor/core/fonts/applyFontPairing.ts
var SLOT_ORDER = ["display", "body", "serif", "mono", "editorial"];
var SLOT_VARIABLES = {
  display: "--font-display",
  body: "--font-sans",
  serif: "--font-serif",
  mono: "--font-mono",
  editorial: "--font-editorial"
};
function slugifyFamily(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
function weightsFor(face) {
  if (face.weights) {
    return { weights: face.weights, ...face.italics ? { italics: true } : {} };
  }
  const parsed = parseGoogleFontsUrl(face.url)?.[0];
  return {
    ...parsed?.weights ? { weights: parsed.weights } : {},
    ...face.italics || parsed?.italics ? { italics: true } : {}
  };
}
function sourceFor(face, idPrefix) {
  const id = `${idPrefix}${slugifyFamily(face.name)}`;
  return {
    id,
    kind: "google",
    url: face.url,
    label: "Google Fonts",
    families: [
      {
        id: `${id}:${slugifyFamily(face.name)}`,
        name: face.name,
        cssName: `"${face.name}"`,
        ...weightsFor(face)
      }
    ]
  };
}
function rewriteStack(stacks, variable, familyId) {
  const stack = stacks.find((s) => s.variable === variable);
  if (!stack) throw new Error(`colors and type have no ${variable} stack to rewrite`);
  return stacks.map(
    (s) => s === stack ? { ...s, slots: [{ kind: "project", familyId }, ...s.slots.filter((slot) => slot.kind !== "project")] } : s
  );
}
function applyFontPairing(colorsAndType, pairing, { idPrefix = "src_google_" } = {}) {
  const slots = SLOT_ORDER.filter((slot) => pairing[slot]);
  if (slots.length === 0) throw new Error("pairing names no slot to change");
  const before = colorsAndType.fontStacks ?? [];
  const beforeSources = colorsAndType.fontSources ?? [];
  const beforeIndex = familyIndex(beforeSources);
  const stamped = slots.map((slot) => ({ slot, source: sourceFor(pairing[slot], idPrefix) }));
  const stampedIds = new Set(stamped.map((s) => s.source.id));
  let stacks = before;
  const changes = [];
  for (const { slot, source } of stamped) {
    const variable = SLOT_VARIABLES[slot];
    const from = resolvedFaceName(before.find((s) => s.variable === variable), beforeIndex);
    stacks = rewriteStack(stacks, variable, source.families[0].id);
    changes.push({ slot, variable, from, to: source.families[0].name });
  }
  const referenced = new Set(
    stacks.flatMap((s) => s.slots).filter((s) => s.kind === "project").map((s) => s.familyId)
  );
  const kept = [...beforeSources.filter((s) => !stampedIds.has(s.id)), ...stamped.map((s) => s.source)];
  const sources = kept.filter((s) => s.families.some((f) => referenced.has(f.id)));
  const dropped = kept.filter((s) => !sources.includes(s)).map((s) => ({ id: s.id, names: s.families.map((f) => f.name) }));
  const next = { ...colorsAndType, fontSources: sources, fontStacks: stacks };
  const changed = JSON.stringify([beforeSources, before]) !== JSON.stringify([sources, stacks]);
  return {
    colorsAndType: next,
    report: { changes: changes.filter((c) => c.from !== c.to), dropped, changed }
  };
}

// src/editor/core/fonts/googleFontsUrl.ts
var LADDER = [100, 200, 300, 400, 500, 600, 700, 800, 900];
function familyParam(name) {
  return name.trim().replace(/\s+/g, "+");
}
function url(name, spec) {
  const family = spec ? `${familyParam(name)}:${spec}` : familyParam(name);
  return `https://fonts.googleapis.com/css2?family=${family}&display=swap`;
}
function discoveryUrl(name) {
  const pairs = [
    ...LADDER.map((w) => `0,${w}`),
    ...LADDER.map((w) => `1,${w}`)
  ];
  return url(name, `ital,wght@${pairs.join(";")}`);
}
function isContiguous(weights) {
  return weights.length > 1 && weights.every((w, i) => i === 0 || w - weights[i - 1] === 100);
}
function persistUrlFor(name, weights, italics) {
  if (weights.length === 0 || weights.length === 1 && weights[0] === 400 && !italics) {
    return url(name);
  }
  if (isContiguous(weights)) {
    const range = `${weights[0]}..${weights[weights.length - 1]}`;
    return url(name, italics ? `ital,wght@0,${range};1,${range}` : `wght@${range}`);
  }
  const spec = italics ? `ital,wght@${[...weights.map((w) => `0,${w}`), ...weights.map((w) => `1,${w}`)].join(";")}` : `wght@${weights.join(";")}`;
  return url(name, spec);
}
function censusFrom(css, requested) {
  const families = parseFontFaceText(css);
  if (families.length === 0) {
    throw new Error(`Google Fonts returned no @font-face rules for "${requested}".`);
  }
  const family = families[0];
  return {
    name: family.name,
    weights: family.weights ?? [],
    italics: family.italics === true
  };
}
async function probeFor(fetcher, url2) {
  try {
    const res = await fetcher(url2);
    return res.ok ? { res } : { status: res.status };
  } catch {
    return {};
  }
}
function titleCase(name) {
  return name.replace(/\S+/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
}
async function resolveGoogleFont(name, fetcher) {
  const requested = name.trim();
  const spellings = [.../* @__PURE__ */ new Set([requested, titleCase(requested)])];
  let probe;
  let probeUrl = discoveryUrl(requested);
  let status;
  for (const spelling of spellings) {
    const candidateUrl = discoveryUrl(spelling);
    const attempt = await probeFor(fetcher, candidateUrl);
    if (attempt.res) {
      probe = attempt.res;
      probeUrl = candidateUrl;
      break;
    }
    status ??= attempt.status;
  }
  if (!probe) {
    throw new Error(
      `"${requested}" is not on Google Fonts` + (status === void 0 ? "" : ` (the API answered ${status})`) + `. Check the spelling against fonts.google.com.`
    );
  }
  const census = censusFrom(await probe.text(), requested);
  const candidates = [persistUrlFor(census.name, census.weights, census.italics)];
  const enumerated = census.weights.length > 0 ? url(
    census.name,
    census.italics ? `ital,wght@${[...census.weights.map((w) => `0,${w}`), ...census.weights.map((w) => `1,${w}`)].join(";")}` : `wght@${census.weights.join(";")}`
  ) : null;
  if (enumerated && !candidates.includes(enumerated)) candidates.push(enumerated);
  const bare = url(census.name);
  if (!candidates.includes(bare)) candidates.push(bare);
  for (const candidate of candidates) {
    const { res } = await probeFor(fetcher, candidate);
    if (!res) continue;
    const served = censusFrom(await res.text(), census.name);
    return {
      name: census.name,
      url: candidate,
      weights: served.weights,
      italics: served.italics,
      probeUrl
    };
  }
  throw new Error(`Could not build a working Google Fonts URL for "${census.name}".`);
}

// src/editor/core/fonts/fontWeightAvailability.ts
function inferFontFamilyVariable(weightVariable) {
  return weightVariable.endsWith("-font-weight") ? `${weightVariable.slice(0, -"-font-weight".length)}-font-family` : null;
}

// src/editor/core/fonts/weightCoverage.ts
var STACK_REF = /var\(\s*(--font-(?:display|sans|serif|mono))\s*\)/;
var VAR_REF = /var\(\s*(--[a-z0-9-]+)/i;
var ALIAS = /^var\(\s*(--[a-z0-9-]+)\s*\)$/i;
function declarations(css) {
  const decls = /* @__PURE__ */ new Map();
  for (const [, name, value] of css.matchAll(/(--[a-z0-9-]+)\s*:\s*([^;{}]+);/gi)) {
    decls.set(name, value.trim());
  }
  return decls;
}
function follow(decls, value, read) {
  const seen = /* @__PURE__ */ new Set();
  while (value !== void 0) {
    const hit = read(value);
    if (hit !== void 0) return hit;
    const next = value.match(ALIAS)?.[1];
    if (!next || next.startsWith("--font-") || seen.has(next)) return void 0;
    seen.add(next);
    value = decls.get(next);
  }
  return void 0;
}
function requiredWeights(tokensCss, overrides = {}) {
  const decls = declarations(tokensCss);
  for (const [name, value] of Object.entries(overrides)) decls.set(name, String(value).trim());
  const scale = /* @__PURE__ */ new Map();
  for (const [name, value] of decls) {
    if (name.startsWith("--font-weight-") && /^\d+$/.test(value)) scale.set(name, Number(value));
  }
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const [name, value] of decls) {
    const familyVariable = inferFontFamilyVariable(name);
    if (!familyVariable) continue;
    const stack = follow(
      decls,
      decls.get(familyVariable),
      (v) => v.match(STACK_REF)?.[1]
    );
    if (!stack) continue;
    const weight = follow(
      decls,
      value,
      (v) => /^\d+$/.test(v) ? Number(v) : scale.get(v.match(VAR_REF)?.[1] ?? "")
    );
    if (weight === void 0) continue;
    const key = `${stack}:${weight}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ variable: name, stack, weight });
  }
  return out;
}
function weightCoverage(requirements, faces) {
  const out = [];
  for (const [stack, face] of Object.entries(faces)) {
    const required = [...new Set(requirements.filter((r) => r.stack === stack).map((r) => r.weight))].sort(
      (a, b) => a - b
    );
    out.push({
      stack,
      family: face.name,
      required,
      available: face.weights,
      missing: required.filter((w) => !face.weights.includes(w)),
      italics: face.italics
    });
  }
  return out;
}

// vite-plugin/files/dataPaths.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var DEFAULT_DATA_DIR = "src/live-tokens/data";
var TEST_DATA_DIR_ENV = "LIVE_TOKENS_TEST_DATA_DIR";
function testDataDir() {
  const raw = process.env[TEST_DATA_DIR_ENV];
  return raw && raw.trim() !== "" ? import_path.default.resolve(raw.trim()) : void 0;
}
var KNOWN_CONFIG_KEYS = /* @__PURE__ */ new Set([
  "dataDir",
  "colorsAndTypeDir",
  "componentConfigsDir",
  "themesDir",
  "manifestsDir",
  "tokensCssPath",
  "componentDirs",
  "checks"
]);
var cached = null;
function readLiveTokensConfig() {
  if (cached) return cached;
  try {
    const configPath = import_path.default.resolve("live-tokens.config.json");
    if (!import_fs.default.existsSync(configPath)) return cached = {};
    const parsed = JSON.parse(import_fs.default.readFileSync(configPath, "utf-8"));
    if (!parsed || typeof parsed !== "object") return cached = {};
    const unknown = Object.keys(parsed).filter(
      (k) => k !== "$schema" && !KNOWN_CONFIG_KEYS.has(k)
    );
    if (unknown.length > 0) {
      console.warn(
        `[live-tokens] Unknown key(s) in live-tokens.config.json: ${unknown.join(", ")}. Known keys: ${Array.from(KNOWN_CONFIG_KEYS).join(", ")}.`
      );
    }
    cached = parsed;
    return cached;
  } catch {
    return cached = {};
  }
}
function resolveDataDirs(opts = {}) {
  const isolated = testDataDir();
  if (isolated) {
    return {
      dataDir: isolated,
      colorsAndTypeDir: import_path.default.join(isolated, "colors-and-type"),
      componentConfigsDir: import_path.default.join(isolated, "component-configs"),
      themesDir: import_path.default.join(isolated, "themes"),
      sketchStylesDir: import_path.default.join(isolated, "sketch-styles")
    };
  }
  const fileConfig = readLiveTokensConfig();
  const dataDirRaw = opts.dataDir ?? fileConfig.dataDir ?? DEFAULT_DATA_DIR;
  const dataDir = import_path.default.resolve(dataDirRaw);
  const sub = (name) => import_path.default.resolve(dataDir, name);
  return {
    dataDir,
    colorsAndTypeDir: opts.colorsAndTypeDir ? import_path.default.resolve(opts.colorsAndTypeDir) : fileConfig.colorsAndTypeDir ? import_path.default.resolve(fileConfig.colorsAndTypeDir) : sub("colors-and-type"),
    componentConfigsDir: opts.componentConfigsDir ? import_path.default.resolve(opts.componentConfigsDir) : fileConfig.componentConfigsDir ? import_path.default.resolve(fileConfig.componentConfigsDir) : sub("component-configs"),
    themesDir: opts.themesDir ? import_path.default.resolve(opts.themesDir) : fileConfig.themesDir ? import_path.default.resolve(fileConfig.themesDir) : sub("themes"),
    sketchStylesDir: sub("sketch-styles"),
    legacyManifestsDir: fileConfig.manifestsDir ? import_path.default.resolve(fileConfig.manifestsDir) : void 0
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SLOT_ORDER,
  SLOT_VARIABLES,
  applyFontPairing,
  discoveryUrl,
  fontPairingLabel,
  persistUrlFor,
  readLiveTokensConfig,
  requiredWeights,
  resolveDataDirs,
  resolveGoogleFont,
  slugifyFamily,
  weightCoverage
});
