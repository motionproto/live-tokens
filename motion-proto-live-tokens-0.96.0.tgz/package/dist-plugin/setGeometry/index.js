import {
  CURRENT_COMPONENT_SCHEMA_VERSION
} from "../chunk-QQASYPW7.js";
import {
  readLiveTokensConfig,
  resolveDataDirs
} from "../chunk-6WGFOJXO.js";

// src/editor/core/components/aliasKinds.ts
var KIND_RULES = [
  { kind: "font-family", suffix: ["-font-family"] },
  { kind: "font-weight", suffix: ["-font-weight"] },
  { kind: "font-size", suffix: ["-font-size", "-icon-size", "-thumb-size"] },
  { kind: "line-height", suffix: ["-line-height"] },
  { kind: "letter-spacing", suffix: ["-letter-spacing"] },
  // Element-named colour roles: the property *is* the element it paints.
  {
    kind: "text-color",
    suffix: [
      "-text",
      "-label",
      "-icon",
      "-title",
      "-body",
      "-eyebrow",
      "-description",
      "-hint",
      "-error",
      "-placeholder",
      "-value"
    ],
    prefix: ["--text-"]
  },
  { kind: "radius", suffix: ["-radius"], prefix: ["--radius-"] },
  // Three stroke roles share the `--border-width-*` scale: a border encloses,
  // a hairline separates, an indicator emphasises. `set-geometry` moves each
  // role on its own, so a suffix has to say which line it names.
  { kind: "hairline-width", suffix: ["-hairline-width"] },
  { kind: "indicator-width", suffix: ["-indicator-width"] },
  { kind: "track-height", suffix: ["-track-height"] },
  { kind: "hairline-inset", suffix: ["-hairline-inset"] },
  { kind: "dot-size", suffix: ["-dot-size"] },
  { kind: "blur", suffix: ["-blur"], prefix: ["--blur-"] },
  { kind: "scale", suffix: ["-scale"], prefix: ["--scale-"] },
  { kind: "shadow", suffix: ["-shadow"], prefix: ["--shadow-"] },
  { kind: "padding", suffix: ["-padding", "-margin"] },
  { kind: "gap", suffix: ["-gap"] },
  { kind: "duration", suffix: ["-duration"], prefix: ["--duration-"] },
  { kind: "easing", suffix: ["-easing"], prefix: ["--ease-"] },
  { kind: "border-width", suffix: ["-border-width"], prefix: ["--border-width-"] },
  { kind: "border", suffix: ["-border"], prefix: ["--border-"] },
  // A dimension with no more specific name behind it — a panel's width, an
  // avatar's size. Last of the geometry rules, so every `-border-width`,
  // `-track-height`, `-icon-size` and the rest claim their token first.
  { kind: "length", suffix: ["-width", "-height", "-size"] },
  // Fills. A tint is a wash over a surface, so it takes the surface picker: the
  // full palette with an alpha, not just the tint stops it defaults to.
  {
    kind: "surface",
    suffix: [
      "-surface",
      "-fill",
      "-indicator",
      "-thumb",
      "-color",
      "-tint"
    ],
    prefix: ["--surface-", "--tint", "--color-"]
  }
];
var KIND_PATTERNS = KIND_RULES.map(({ kind, suffix = [], prefix = [] }) => ({
  kind,
  matches: (v) => suffix.some((s) => v.endsWith(s)) || prefix.some((p) => v.startsWith(p))
}));
var MATCHER_BY_KIND = Object.fromEntries(
  KIND_PATTERNS.map((p) => [p.kind, p.matches])
);
var SIDE_SUFFIXES = ["-top", "-right", "-bottom", "-left"];
function stripSide(variable) {
  const side = SIDE_SUFFIXES.find((s) => variable.endsWith(s));
  return side ? variable.slice(0, -side.length) : variable;
}
function matchesKind(variable, kind) {
  return MATCHER_BY_KIND[kind](stripSide(variable));
}

// src/editor/core/components/adjustAliases.ts
var RADIUS_FULL = "--radius-full";
var RADIUS_STEPS = [
  "--radius-none",
  "--radius-sm",
  "--radius-md",
  "--radius-lg",
  "--radius-xl",
  "--radius-2xl",
  "--radius-3xl",
  "--radius-4xl"
];
var SPACE_SETTABLE = [
  "--space-0",
  "--space-2",
  "--space-4",
  "--space-6",
  "--space-8",
  "--space-10",
  "--space-12",
  "--space-16",
  "--space-20",
  "--space-24",
  "--space-32",
  "--space-48"
];
var SPACE_STEPS = SPACE_SETTABLE;
var INSET_STEPS = SPACE_SETTABLE.slice(SPACE_SETTABLE.indexOf("--space-4"));
var TEXT_INSET_STEPS = SPACE_SETTABLE.slice(SPACE_SETTABLE.indexOf("--space-6"));
var SPACE_FAMILY = [...SPACE_SETTABLE, "--space-40", "--space-64", "--space-96", "--space-128"];
var BORDER_WIDTH_NONE = "--border-width-0";
var BORDER_WIDTH_SETTABLE = [
  BORDER_WIDTH_NONE,
  "--border-width-1",
  "--border-width-2",
  "--border-width-3",
  "--border-width-4",
  "--border-width-5",
  "--border-width-6",
  "--border-width-8",
  "--border-width-10",
  "--border-width-12",
  "--border-width-16",
  "--border-width-20",
  "--border-width-24"
];
var STROKE_STEPS = BORDER_WIDTH_SETTABLE.slice(1);
var STROKE_SCALE = {
  steps: STROKE_STEPS,
  settable: BORDER_WIDTH_SETTABLE,
  family: BORDER_WIDTH_SETTABLE
};
var SCALES = {
  radius: {
    steps: RADIUS_STEPS,
    settable: [...RADIUS_STEPS, RADIUS_FULL],
    family: [...RADIUS_STEPS, RADIUS_FULL]
  },
  padding: { steps: SPACE_STEPS, settable: SPACE_SETTABLE, family: SPACE_FAMILY },
  gap: { steps: SPACE_STEPS, settable: SPACE_SETTABLE, family: SPACE_FAMILY },
  "border-width": STROKE_SCALE,
  "hairline-width": STROKE_SCALE,
  "indicator-width": STROKE_SCALE
};
var TOKEN_NAME = /^--[a-z0-9-]+$/;
function stepsFor(op, variable, aliases) {
  if (op.kind === "radius") return op.full ? [...RADIUS_STEPS, RADIUS_FULL] : RADIUS_STEPS;
  if (op.kind !== "padding") return SCALES[op.kind].steps;
  const base = stripSide(variable);
  if (!base.endsWith("-padding")) return SCALES.padding.steps;
  const variant = base.slice(0, -"-padding".length);
  return `${variant}-text-font-size` in aliases ? TEXT_INSET_STEPS : INSET_STEPS;
}
function spaceStep(token) {
  return Number(token.slice("--space-".length));
}
function snapStep(token, steps, direction) {
  const step = spaceStep(token);
  if (direction > 0) return steps.findIndex((candidate) => spaceStep(candidate) > step);
  for (let index = steps.length - 1; index >= 0; index--) {
    if (spaceStep(steps[index]) < step) return index;
  }
  return -1;
}
function resolve(op, variable, value, aliases) {
  if (typeof value !== "string" || !TOKEN_NAME.test(value)) return { skip: "raw-value" };
  if (!SCALES[op.kind].family.includes(value)) return { skip: "off-scale" };
  if (op.set !== void 0) return { from: value, to: op.set };
  const steps = stepsFor(op, variable, aliases);
  let index = steps.indexOf(value);
  let shift = op.shift;
  if (index < 0) {
    if (value === RADIUS_FULL) return { skip: "pill-preserved" };
    if (value === BORDER_WIDTH_NONE) return { skip: "none-preserved" };
    index = snapStep(value, steps, shift);
    if (index < 0) return { skip: "clamped" };
    shift -= Math.sign(shift);
  }
  const wanted = index + shift;
  const landed = Math.min(Math.max(wanted, 0), steps.length - 1);
  if (landed !== wanted && steps[landed] === value) return { skip: "clamped" };
  return { from: value, to: steps[landed] };
}
function validateOp(op, configs) {
  const scale = SCALES[op.kind];
  if (!scale) throw new Error(`Unknown kind "${op.kind}" (expected ${Object.keys(SCALES).join(", ")})`);
  if (op.target !== void 0 && !(op.target in configs)) {
    throw new Error(`Unknown target component "${op.target}"`);
  }
  const hasSet = op.set !== void 0;
  const hasShift = op.shift !== void 0;
  if (hasSet === hasShift) throw new Error(`A ${op.kind} op needs exactly one of "set" or "shift"`);
  const settable = scale.settable;
  if (hasSet && !settable.includes(op.set)) {
    throw new Error(`"${op.set}" is not on the ${op.kind} scale`);
  }
  if (hasShift && !Number.isInteger(op.shift)) {
    throw new Error(`"shift" must be a whole number of steps, got ${op.shift}`);
  }
  if (op.full !== void 0 && !(op.kind === "radius" && hasShift)) {
    throw new Error('"full" applies to radius shifts only');
  }
}
function adjustAliases(configs, ops, now) {
  for (const op of ops) validateOp(op, configs);
  const next = { ...configs };
  const reports = /* @__PURE__ */ new Map();
  const reportFor = (component) => {
    let report = reports.get(component);
    if (!report) {
      report = { component, changes: [], skips: [] };
      reports.set(component, report);
    }
    return report;
  };
  for (const op of ops) {
    for (const component of op.target ? [op.target] : Object.keys(next)) {
      const config = next[component];
      const aliases = { ...config.aliases };
      let changed = false;
      for (const [variable, value] of Object.entries(config.aliases)) {
        if (!matchesKind(variable, op.kind)) continue;
        const outcome = resolve(op, variable, value, config.aliases);
        if ("skip" in outcome) {
          reportFor(component).skips.push({ variable, value, reason: outcome.skip });
          continue;
        }
        if (outcome.to === outcome.from) continue;
        aliases[variable] = outcome.to;
        reportFor(component).changes.push({ variable, from: outcome.from, to: outcome.to });
        changed = true;
      }
      if (changed) next[component] = { ...config, aliases, updatedAt: now };
    }
  }
  return { configs: next, report: { components: [...reports.values()] } };
}
export {
  CURRENT_COMPONENT_SCHEMA_VERSION,
  adjustAliases,
  matchesKind,
  readLiveTokensConfig,
  resolveDataDirs
};
