interface LiveTokensFileConfig {
    dataDir?: string;
    colorsAndTypeDir?: string;
    componentConfigsDir?: string;
    themesDir?: string;
    /**
     * Retired in 0.48, where `themesDir` took over the meaning. Still recognised
     * so an unmigrated project is not told its key is a typo, and so the
     * migration can find (or refuse to guess at) a whole-theme directory the
     * consumer moved.
     */
    manifestsDir?: string;
    /**
     * Path to the developer-authored `tokens.css`. The dev plugin takes this from
     * its `themeFileApi({ tokensCssPath })` option; the standalone `live-tokens
     * migrate` CLI has no plugin options, so it reads this key to locate the file.
     */
    tokensCssPath?: string;
    /** Extra directories the component checkers and the registry query discover. */
    componentDirs?: string[];
    /** Checker settings: `rules` per-rule severities, `exclude` paths to skip. */
    checks?: Record<string, unknown>;
}
interface ResolveDataDirsInput {
    dataDir?: string;
    colorsAndTypeDir?: string;
    componentConfigsDir?: string;
    themesDir?: string;
}
interface ResolvedDataDirs {
    dataDir: string;
    colorsAndTypeDir: string;
    componentConfigsDir: string;
    themesDir: string;
    /** No per-folder config override: a sketchstyle has no reason to live apart
     *  from the rest of the data tree. */
    sketchStylesDir: string;
    /** Absolute path of the retired `manifestsDir` key, when the config sets it.
     *  Only the pre-0.48 layout detector and the migration read it. */
    legacyManifestsDir?: string;
}
declare function readLiveTokensConfig(): LiveTokensFileConfig;
/**
 * Resolve the four data directories for a single plugin/preprocessor.
 *
 * Per-folder resolution order (most specific wins):
 *   0. `LIVE_TOKENS_TEST_DATA_DIR`, which redirects all four folders at once
 *   1. explicit opts (e.g. `opts.colorsAndTypeDir`)
 *   2. `live-tokens.config.json` field (e.g. `fileConfig.colorsAndTypeDir`)
 *   3. `<dataDir>/<sub>` where dataDir comes from opts > config file > the
 *      package default (`src/live-tokens/data`)
 *
 * This lets a consumer set `dataDir` once and have all three subfolders move
 * together, while still allowing per-folder overrides for unusual layouts
 * (e.g. a monorepo where colors and type are shared across packages but
 * component-configs aren't).
 *
 * All returned paths are absolute (resolved via `path.resolve` against cwd).
 */
declare function resolveDataDirs(opts?: ResolveDataDirsInput): ResolvedDataDirs;

export { resolveDataDirs as a, readLiveTokensConfig as r };
