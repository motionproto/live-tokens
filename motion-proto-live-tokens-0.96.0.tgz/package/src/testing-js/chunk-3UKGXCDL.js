// src/testing/componentContract.ts
var ContractViolation = class extends Error {
  constructor(rule, component, message) {
    super(`[${rule}] ${component}: ${message}`);
    this.rule = rule;
    this.component = component;
    this.name = "ContractViolation";
  }
  rule;
  component;
};
function isInapplicable(value) {
  return typeof value === "object" && value !== null && value.applicable === false;
}
var INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
  "button",
  "switch",
  "checkbox",
  "radio",
  "slider",
  "spinbutton",
  "textbox",
  "combobox",
  "listbox",
  "menuitem",
  "tab",
  "link",
  "searchbox",
  "option"
]);
function requiresInteraction(role) {
  return role !== null && INTERACTIVE_ROLES.has(role);
}
function partLocator(contract, key) {
  const declared = contract.parts[key];
  if (declared === void 0) {
    throw new ContractViolation("contract-render", contract.id, `no part named "${key}" is declared`);
  }
  return typeof declared === "string" ? { selector: declared } : declared;
}

export {
  ContractViolation,
  isInapplicable,
  requiresInteraction,
  partLocator
};
//# sourceMappingURL=chunk-3UKGXCDL.js.map