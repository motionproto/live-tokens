<script module lang="ts">
  import { buildSiblings } from './scaffolding/siblings';
  import type { Token, IntrinsicSpec } from './scaffolding/types';

  export const component = 'button';

  const variants = ['primary', 'secondary', 'outline', 'success', 'danger', 'warning'] as const;
  type Variant = typeof variants[number];
  const stateNames = ['default', 'hover', 'disabled'] as const;
  type StateName = typeof stateNames[number];
  function statePrefix(v: Variant, s: StateName): string {
    return s === 'default' ? `--button-${v}` : `--button-${v}-${s}`;
  }

  // Shape + type. These don't change per state in the runtime — promoted into
  // their own "base" part so state panels carry only what genuinely varies.
  // Tagged with `element` so StateBlock partitions base into labeled `frame`
  // and `text` subsections, matching the Badge editor's layout.
  function variantBaseTokens(v: Variant): Token[] {
    return [
      { label: 'padding', canBeLinked: true, groupKey: 'padding', variable: `--button-${v}-padding`, element: 'frame' },
      { label: 'padding-top', canBeLinked: true, groupKey: 'padding-top', variable: `--button-${v}-padding-top`, hidden: true, element: 'frame' },
      { label: 'padding-right', canBeLinked: true, groupKey: 'padding-right', variable: `--button-${v}-padding-right`, hidden: true, element: 'frame' },
      { label: 'padding-bottom', canBeLinked: true, groupKey: 'padding-bottom', variable: `--button-${v}-padding-bottom`, hidden: true, element: 'frame' },
      { label: 'padding-left', canBeLinked: true, groupKey: 'padding-left', variable: `--button-${v}-padding-left`, hidden: true, element: 'frame' },
      { label: 'corner radius', canBeLinked: true, groupKey: 'radius', variable: `--button-${v}-radius`, element: 'frame' },
      { label: 'border width', canBeLinked: true, groupKey: 'border-width', variable: `--button-${v}-border-width`, element: 'frame' },
      { label: 'icon size', canBeLinked: true, groupKey: 'icon-size', variable: `--button-${v}-icon-size`, element: 'frame' },
      { label: 'font family', canBeLinked: true, groupKey: 'font-family', variable: `--button-${v}-text-font-family`, element: 'text' },
      { label: 'font size', canBeLinked: true, groupKey: 'font-size', variable: `--button-${v}-text-font-size`, element: 'text' },
      { label: 'font weight', canBeLinked: true, groupKey: 'font-weight', variable: `--button-${v}-text-font-weight`, element: 'text' },
      { label: 'line height', canBeLinked: true, groupKey: 'line-height', variable: `--button-${v}-text-line-height`, element: 'text' },
    ];
  }

  // State panels carry only what changes between states: the three color slots.
  function variantStateTokens(v: Variant, s: StateName): Token[] {
    const colorVar = s === 'default' ? `--button-${v}-text` : `--button-${v}-${s}-text`;
    return [
      { label: 'surface color', groupKey: 'surface', variable: `${statePrefix(v, s)}-surface` },
      { label: 'border color', groupKey: 'border', variable: `${statePrefix(v, s)}-border` },
      { label: 'text color', groupKey: 'text', variable: colorVar },
    ];
  }

  // Outline is the only variant that paints a surface tint on :active; the rest
  // express press feedback through transform/shadow only. Expose just the one
  // tunable property here rather than adding an active state to every variant.
  const outlineActiveTokens: Token[] = [
    { label: 'surface color', groupKey: 'surface', variable: '--button-outline-active-surface' },
  ];

  function variantStates(v: Variant): Record<string, Token[]> {
    const out: Record<string, Token[]> = {};
    out.base = variantBaseTokens(v);
    out.default = variantStateTokens(v, 'default');
    out.hover = variantStateTokens(v, 'hover');
    if (v === 'outline') out.active = outlineActiveTokens;
    out.disabled = variantStateTokens(v, 'disabled');
    return out;
  }

  // Small-size schema. One shared spec across all variants (matches the runtime
  // `.small` rule, which is variant-agnostic). Per-side padding rows are hidden
  // and surface only when the editor splits the padding control.
  // Same frame/text element split as the default-size base for visual parity.
  const smallStates: Record<string, Token[]> = {
    small: [
      { label: 'padding', groupKey: 'small-padding', variable: '--button-small-padding', element: 'frame' },
      { label: 'padding-top', groupKey: 'small-padding-top', variable: '--button-small-padding-top', hidden: true, element: 'frame' },
      { label: 'padding-right', groupKey: 'small-padding-right', variable: '--button-small-padding-right', hidden: true, element: 'frame' },
      { label: 'padding-bottom', groupKey: 'small-padding-bottom', variable: '--button-small-padding-bottom', hidden: true, element: 'frame' },
      { label: 'padding-left', groupKey: 'small-padding-left', variable: '--button-small-padding-left', hidden: true, element: 'frame' },
      { label: 'icon size', groupKey: 'small-icon-size', variable: '--button-small-icon-size', element: 'frame' },
      { label: 'font size', groupKey: 'small-font-size', variable: '--button-small-text-font-size', element: 'text' },
      { label: 'font weight', groupKey: 'small-font-weight', variable: '--button-small-text-font-weight', element: 'text' },
      { label: 'line height', groupKey: 'small-line-height', variable: '--button-small-text-line-height', element: 'text' },
    ],
  };
  const smallTokensFlat: Token[] = Object.values(smallStates).flat();

  export const allTokens: Token[] = [
    ...variants.flatMap((v) => Object.values(variantStates(v)).flat()),
    ...smallTokensFlat,
  ];

  // All shape + type props live under each variant's "base" part; they link
  // across variants from there. Small tokens stay in their own namespace —
  // no cross-size linking.
  const linkableContexts = new Map<string, string>(
    variants.flatMap((v) => [
      [`--button-${v}-padding`, `${v} base`] as const,
      [`--button-${v}-radius`, `${v} base`] as const,
      [`--button-${v}-border-width`, `${v} base`] as const,
      [`--button-${v}-text-font-family`, `${v} base`] as const,
      [`--button-${v}-text-font-size`, `${v} base`] as const,
      [`--button-${v}-text-font-weight`, `${v} base`] as const,
      [`--button-${v}-text-line-height`, `${v} base`] as const,
      [`--button-${v}-icon-size`, `${v} base`] as const,
    ]),
  );

  const variantOptions = variants.map((v) => ({ value: v, label: v.charAt(0).toUpperCase() + v.slice(1) }));

  // The hover tint is off unless a project turns it on: the gate holds a
  // transparent layer, a no-op, until it holds the tint itself.
  export const intrinsics: IntrinsicSpec[] = [
    {
      key: 'shimmer',
      variants: ['default'],
      variable: () => '--button-shimmer',
      values: ['var(--shimmer-on)', 'var(--shimmer-off)'],
      default: { default: 'var(--shimmer-on)' },
    },
    {
      key: 'hover-tint',
      variants: ['default'],
      variable: () => '--button-hover-tint-enabled',
      values: ['var(--color-transparent)', 'var(--button-hover-tint)'],
      default: { default: 'var(--color-transparent)' },
    },
  ];
</script>

<script lang="ts">
  import Button from '../../system/components/Button.svelte';
  import Toggle from '../ui/Toggle.svelte';
  import UIPaletteSelector from '../ui/UIPaletteSelector.svelte';
  import VariantGroup from './scaffolding/VariantGroup.svelte';
  import ComponentEditorBase from './scaffolding/ComponentEditorBase.svelte';
  import { editorState, setComponentAlias, clearComponentAlias } from '../core/store/editorStore';
  import { computeLinkedBlock, withLinkedDisabled } from './scaffolding/linkedBlock';

  let shimmerRef = $derived($editorState.components.button?.aliases['--button-shimmer']);
  let shimmerEnabled = $derived(!(shimmerRef?.kind === 'token' && shimmerRef.name === '--shimmer-off'));

  function handleShimmerChange(checked: boolean) {
    setComponentAlias('button', '--button-shimmer', { kind: 'token', name: checked ? '--shimmer-on' : '--shimmer-off' });
  }

  // One switch. Turning the tint on also stands each hover surface down to its
  // own base, so hover is the tint alone rather than a swap wearing a wash.
  // Written as aliases rather than gated in CSS: a component token's value is
  // substituted at :root, so it can never name a per-variant private var.
  // Off clears the overrides, returning each surface to its shipped default.
  const HOVER_SWAPS: readonly (readonly [hover: string, base: string])[] = [
    ['--button-primary-hover-surface', '--button-primary-surface'],
    ['--button-secondary-hover-surface', '--button-secondary-surface'],
    ['--button-outline-hover-surface', '--button-outline-surface'],
    ['--button-success-hover-surface', '--button-success-surface'],
    ['--button-danger-hover-surface', '--button-danger-surface'],
    ['--button-warning-hover-surface', '--button-warning-surface'],
  ];
  const TINT_ON = 'var(--button-hover-tint)';
  const TINT_OFF = 'var(--color-transparent)';

  let tintOn = $derived.by(() => {
    const ref = $editorState.components.button?.aliases['--button-hover-tint-enabled'];
    return (ref?.kind === 'literal' ? ref.value : TINT_OFF) === TINT_ON;
  });

  function setTintOn(checked: boolean) {
    setComponentAlias('button', '--button-hover-tint-enabled', {
      kind: 'literal',
      value: checked ? TINT_ON : TINT_OFF,
    });
    for (const [hover, base] of HOVER_SWAPS) {
      if (checked) setComponentAlias('button', hover, { kind: 'token', name: base });
      else clearComponentAlias('button', hover);
    }
  }

  let previewSize = $state<'default' | 'small'>('default');

  let linked = $derived(computeLinkedBlock(component, linkableContexts, allTokens, $editorState));

  let visibleVariantStates = $derived((v: Variant) => Object.fromEntries(
    Object.entries(variantStates(v)).map(([name, list]) => [
      name,
      withLinkedDisabled(list, linked.varSet).map((t) =>
        tintOn && t.variable.endsWith('-hover-surface') ? { ...t, disabled: true } : t,
      ),
    ]),
  ) as Record<string, Token[]>);

  let visibleSmallStates = $derived(Object.fromEntries(
    Object.entries(smallStates).map(([name, list]) => [name, withLinkedDisabled(list, linked.varSet)]),
  ) as Record<string, Token[]>);

  // At small size, no variant strip — the small spec is shared across all
  // variants, so the strip would have nothing to navigate between.
  let baseVariantOptions = $derived(previewSize === 'small' ? [] : variantOptions);
</script>

{#snippet sizeAction()}
  <label>
    <span>Size</span>
    <select bind:value={previewSize}>
      <option value="default">Default</option>
      <option value="small">Small</option>
    </select>
  </label>
{/snippet}

<ComponentEditorBase {component} title="Button" description="Reusable button component with multiple variants and sizes." tokens={allTokens} {linked} variants={baseVariantOptions}>
  {#if previewSize === 'default'}
    {#each variants as v}
      <VariantGroup
        name={v}
        title={v.charAt(0).toUpperCase() + v.slice(1)}
        states={visibleVariantStates(v)}
        {component}
        siblings={buildSiblings(variants, v, variantStates)}
        previewActions={sizeAction}
      >
        {#snippet extraPropertyRows(stateName)}
          {#if stateName === 'hover'}
            <div class="property-row" data-token-variables="--button-hover-tint-enabled">
              <span class="property-label">tint layer</span>
              <Toggle checked={tintOn} onchange={setTintOn} />
            </div>
            {#if tintOn}
              <div class="property-row">
                <span class="property-label">tint color</span>
                <UIPaletteSelector variable="--button-hover-tint" {component} showNone={false} />
              </div>
            {/if}
            <div class="property-row" data-token-variables="--button-shimmer">
              <span class="property-label">hover shimmer</span>
              <Toggle checked={shimmerEnabled} onchange={handleShimmerChange} />
            </div>
          {/if}
        {/snippet}
        {#snippet children({ activeState })}
          {@const forceClass = activeState === 'hover' ? 'force-hover' : activeState === 'active' ? 'force-active' : ''}
          {@const isDisabled = activeState === 'disabled'}
          <div class="button-showcase-grid">
            <div class="button-showcase-item">
              <Button variant={v} disabled={isDisabled} class={forceClass}>{v.charAt(0).toUpperCase() + v.slice(1)}</Button>
            </div>
            <div class="button-showcase-item">
              <Button variant={v} icon="fas fa-star" iconPosition="left" disabled={isDisabled} class={forceClass}>With Icon</Button>
            </div>
          </div>
        {/snippet}
      </VariantGroup>
    {/each}
  {:else}
    <VariantGroup
      name="small"
      title="Small"
      states={visibleSmallStates}
      {component}
      previewActions={sizeAction}
    >
      {#snippet children()}
        <div class="small-preview">
          {#each variants as v}
            <Button variant={v} size="small">{v.charAt(0).toUpperCase() + v.slice(1)}</Button>
          {/each}
          {#each variants as v}
            <Button variant={v} size="small" icon="fas fa-star" iconPosition="left">{v.charAt(0).toUpperCase() + v.slice(1)}</Button>
          {/each}
        </div>
      {/snippet}
    </VariantGroup>
  {/if}
</ComponentEditorBase>

<style>
  .button-showcase-grid {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-16);
    align-items: start;
  }

  .button-showcase-item {
    display: flex;
    flex-direction: column;
    gap: var(--space-8);
    align-items: flex-start;
  }

  .small-preview {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-12);
    align-items: center;
  }
</style>
