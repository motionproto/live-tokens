// src/testing/registry.contract.ts
import path from "path";
import { fileURLToPath, pathToFileURL } from "url";
import { describe, expect, it } from "vitest";
import { checkRegistryEntry } from "../editor/component-editor/contract";
import { getComponentRegistryEntries } from "../editor/component-editor/registry";
import { discoverComponents } from "../../bin/check-component.mjs";
var REGISTRY_SETUP_ENV = "LIVE_TOKENS_REGISTRY_SETUP";
var setupModule = process.env[REGISTRY_SETUP_ENV];
if (setupModule) await import(pathToFileURL(path.resolve(setupModule)).href);
var packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
var consumerRoot = process.cwd();
var componentConfigsDir = path.resolve(
  process.env.LIVE_TOKENS_DATA_DIR ?? "src/live-tokens/data",
  "component-configs"
);
var entries = getComponentRegistryEntries();
var requested = process.env.LIVE_TOKENS_COMPONENT;
var targets = requested ? entries.filter((entry) => entry.id === requested) : entries;
var authored = discoverComponents(consumerRoot);
describe("component registry contract", () => {
  it("selects at least one component", () => {
    expect(
      targets.map((entry) => entry.id),
      requested ? `no component is registered under the id "${requested}"` : "no component is registered"
    ).not.toEqual([]);
  });
  describe.each(authored.map((id) => [id]))("%s", (id) => {
    it("is registered", () => {
      const ids = new Set(entries.map((entry) => entry.id));
      expect(ids.has(id), `${id} is authored in the project and registered nowhere`).toBe(true);
    });
  });
  describe.each(targets.map((entry) => [entry.id, entry]))("%s", (_id, entry) => {
    it("meets the registry contract", () => {
      const projectRoot = entry.origin === "system" ? packageRoot : consumerRoot;
      expect(checkRegistryEntry(entry, { projectRoot, componentConfigsDir })).toEqual([]);
    });
  });
});
//# sourceMappingURL=registry.contract.js.map