import { UserConfig } from 'vite';
import { TestUserConfig } from 'vitest/config';

/** The file a project puts its shared test settings in, at the project root. */
declare const TESTING_CONFIG_FILE = "live-tokens.testing.ts";
/** The components route the run drives, published from the settings so the
 *  suites need no argument. */
declare const COMPONENTS_PATH_ENV = "LIVE_TOKENS_COMPONENTS_PATH";
/** Narrows a run to one component. */
declare const COMPONENT_ENV = "LIVE_TOKENS_COMPONENT";
/** The page targets a run opens, as JSON: `[{ source, route }]`. */
declare const PAGES_ENV = "LIVE_TOKENS_PAGES";
/** The viewports every page rule runs at, as JSON: `[{ width, height }]`. */
declare const PAGE_VIEWPORTS_ENV = "LIVE_TOKENS_PAGE_VIEWPORTS";
interface PageViewport {
    width: number;
    height: number;
}
/** The contract project's own desktop size, and the phone the text styles
 *  carry media overrides for. Nothing here is derived from a page. */
declare const DEFAULT_PAGE_VIEWPORTS: PageViewport[];
interface LiveTokensTestingConfig {
    /** Vite config a generated Vitest config merges. Default `vite.config.ts`. */
    viteConfig?: string;
    /** Command that starts the dev server. `{host}` and `{port}` are substituted.
     *  Default `npm run dev -- --host {host} --port {port}`. */
    devCommand?: string;
    /** Fixed port for the dev server. Omitted, the run takes a free one. */
    port?: number;
    /** The components route, when `editorRoutes` moved it off the owned default. */
    componentsPath?: string;
    /** The plugin's data directory. Default: `dataDir` from
     *  `live-tokens.config.json`, else `src/live-tokens/data`. The run never uses
     *  it directly; it is the tree the isolated copy is made from. */
    dataDir?: string;
    /** Module that registers the project's components without mounting the app.
     *  The registry contract imports it before it selects entries. */
    registrySetup?: string;
    /** Module exporting the `ComponentContract[]` a custom component adds to the
     *  shipped list (default export or a named `contracts` export). The suite
     *  files are static Playwright entry points, so an env var naming this path
     *  plus a dynamic import inside `selectedContracts()` is the only way a
     *  custom contract reaches them. */
    contractsModule?: string;
    /** Page source path to the concrete URL that renders it, for a route the
     *  `pages` object cannot express: one served by `resolve()`, or one whose
     *  parameters only the project knows. Page paths are relative to the
     *  project root. */
    pageRoutes?: Record<string, string>;
    /** Replaces the two sizes every page rule runs at. */
    pageViewports?: PageViewport[];
}
interface ResolvedTestingConfig {
    root: string;
    viteConfig: string;
    devCommand: string;
    port?: number;
    componentsPath: string;
    dataDir: string;
    registrySetup?: string;
    contractsModule?: string;
    pageRoutes: Record<string, string>;
    pageViewports: PageViewport[];
}
/** Types the settings file without importing the interface by hand. */
declare function defineTestingConfig(config: LiveTokensTestingConfig): LiveTokensTestingConfig;
declare function resolveTestingConfig(config?: LiveTokensTestingConfig, root?: string): ResolvedTestingConfig;
declare function devServerCommand(command: string, host: string, port: number): string;

interface VitestConfigOptions {
    /** Files the run collects, relative to the project root. Default: the
     *  registry and behavior contracts in this module's own directory. */
    include?: string[];
    exclude?: string[];
    setupFiles?: string[];
    /** Default `happy-dom`, which the registry contract needs to mount a store. */
    environment?: TestUserConfig['environment'];
    /** Module the registry contract imports to register the project's
     *  components. Reaches the run as an environment variable because the
     *  contract file resolves the path itself. */
    registrySetup?: string;
    /** Module `selectedContracts()` imports a project's own `ComponentContract[]`
     *  from, same env-var seam as `registrySetup` and mirroring
     *  `createPlaywrightConfig`'s own use of it: the behavior contract's
     *  `describe.each` runs at module top, before a test can resolve anything
     *  for it. */
    contractsModule?: string;
}
/**
 * The project's Vite config plus what the registry contract needs on top.
 *
 * The package ships Svelte and TypeScript source and imports a FontAwesome
 * stylesheet. Left external, Node meets that `.css` and stops with
 * `Unknown file extension ".css"` before a single test runs, so both are
 * inlined for Vite to transform.
 */
declare function createVitestConfig(viteConfig: UserConfig, options?: VitestConfigOptions): UserConfig;

export { COMPONENTS_PATH_ENV as C, DEFAULT_PAGE_VIEWPORTS as D, type LiveTokensTestingConfig as L, PAGES_ENV as P, type ResolvedTestingConfig as R, TESTING_CONFIG_FILE as T, type VitestConfigOptions as V, COMPONENT_ENV as a, PAGE_VIEWPORTS_ENV as b, type PageViewport as c, createVitestConfig as d, defineTestingConfig as e, devServerCommand as f, resolveTestingConfig as r };
